"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/JellyfinNowPlaying/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PollSeconds"];
const CHECK_FIELDS = ["ShowWhenPaused", "IncludeMusic", "ShowOverview", "ShowClock", "Takeover", "ShowOverlay"];
const TEXT_FIELDS = ["ServerUrl", "UserName"];
const SELECT_FIELDS = ["EpisodeCover", "Look"];
let current = null;
let editing = false;

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache gilt auch
// für die Szene auf dem Rahmen.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Solange ein gewählter Jellyfin-Benutzer etwas schaut, zeigt der Rahmen Cover, Titel und Fortschritt. Danach läuft deine Playlist weiter. Jede Änderung hier wird sofort gespeichert.",
    "While a chosen Jellyfin user is watching something, the frame shows cover, title and progress. Afterwards your playlist carries on. Every change here is saved immediately.",
    "Mientras un usuario elegido de Jellyfin ve algo, el marco muestra la carátula, el título y el progreso. Después sigue tu lista. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Jetzt prüfen", "Check now", "Comprobar ahora"],
  factConnection: ["Verbindung", "Connection", "Conexión"],
  factScreen: ["Bildschirm", "Screen", "Pantalla"],
  factVersion: ["Version", "Version", "Versión"],
  serverTitle: ["Jellyfin-Server", "Jellyfin server", "Servidor Jellyfin"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  userName: ["Benutzer, dessen Wiedergabe gezeigt wird", "User whose playback is shown", "Usuario cuya reproducción se muestra"],
  serverHint: ["Den API-Schlüssel legst du in Jellyfin unter Dashboard › API-Schlüssel an. Er bleibt auf dem Rahmen und wird hier nicht wieder angezeigt; zum Ändern einfach einen neuen eintragen.",
    "Create the API key in Jellyfin under Dashboard › API Keys. It stays on the frame and is not shown here again; to change it, just enter a new one.",
    "Crea la clave API en Jellyfin en Panel › Claves API. Se queda en el marco y no se vuelve a mostrar aquí; para cambiarla, escribe una nueva."],
  keySet: ["gespeichert – zum Ändern neu eintragen", "saved – enter a new one to change it", "guardada – escribe una nueva para cambiarla"],
  keyMissing: ["noch nicht eingetragen", "not set yet", "aún no indicada"],
  whatTitle: ["Was gezeigt wird", "What is shown", "Qué se muestra"],
  showWhenPaused: ["Auch bei Pause zeigen", "Also show while paused", "Mostrar también en pausa"],
  includeMusic: ["Auch Musik zeigen", "Also show music", "Mostrar también música"],
  episodeCover: ["Cover bei Serien", "Cover for series", "Carátula de series"],
  coverSeries: ["Poster der Serie", "Series poster", "Póster de la serie"],
  coverEpisode: ["Bild der Folge", "Episode image", "Imagen del episodio"],
  pollSeconds: ["Jellyfin fragen alle … Sekunden", "Ask Jellyfin every … seconds", "Preguntar a Jellyfin cada … segundos"],
  lookTitle: ["Aussehen der Szene", "Scene appearance", "Aspecto de la escena"],
  look: ["Darstellung", "Layout", "Diseño"],
  lookDetails: ["Cover mit Infos", "Cover with details", "Carátula con detalles"],
  lookCover: ["Nur das Cover", "Cover only", "Solo la carátula"],
  showOverview: ["Inhalt (Kurzbeschreibung) zeigen", "Show the plot summary", "Mostrar la sinopsis"],
  showClock: ["Uhrzeit zeigen", "Show the time", "Mostrar la hora"],
  lookHint: ["„Nur das Cover“ zeigt das Poster groß vor seinem Hintergrundbild, mit einer feinen Fortschrittslinie, wie das alte Plugin.",
    "“Cover only” shows the poster large in front of its backdrop, with a thin progress line, like the old plugin.",
    "«Solo la carátula» muestra el póster grande delante de su fondo, con una fina línea de progreso, como el plugin anterior."],
  takeoverTitle: ["Über die Playlist legen", "Show over the playlist", "Mostrar sobre la lista"],
  takeover: ["Bildschirm übernehmen, solange etwas läuft", "Take the screen while something is playing", "Tomar la pantalla mientras algo se reproduce"],
  showOverlay: ["Dein Foto-Overlay dabei anlassen", "Keep your photo overlay on meanwhile", "Mantener tu overlay de fotos"],
  takeoverHint: ["Dafür muss auf der Plugins-Seite bei Jellyfin Now Playing „Allow takeover“ eingeschaltet sein. Die Playlist „Jellyfin Now Playing (takeover)“ benutzt das Plugin selbst; lass sie ausgeschaltet.",
    "For this, “Allow takeover” must be on for Jellyfin Now Playing on the Plugins page. The playlist “Jellyfin Now Playing (takeover)” is used by the plugin itself; leave it switched off.",
    "Para ello, «Allow takeover» debe estar activado para Jellyfin Now Playing en la página Plugins. La lista «Jellyfin Now Playing (takeover)» la usa el propio plugin; déjala desactivada."],
  nowPlaying: ["Läuft gerade", "Now playing", "Reproduciendo"],
  nowPaused: ["Pausiert", "Paused", "En pausa"],
  nothing: ["Gerade läuft nichts", "Nothing is playing", "No se reproduce nada"],
  on: ["auf {device}", "on {device}", "en {device}"],
  connOk: ["Verbunden", "Connected", "Conectado"],
  connUnset: ["Noch nicht eingerichtet", "Not set up yet", "Sin configurar"],
  connError: ["Fehler", "Error", "Error"],
  connWait: ["Wird geprüft …", "Checking …", "Comprobando …"],
  screenTaken: ["Übernommen", "Taken over", "Tomada"],
  screenFree: ["Bei der Playlist", "With the playlist", "Con la lista"],
  screenOff: ["Übernahme aus", "Takeover off", "Toma desactivada"],
  noteNoScene: ["Die Szene Jellyfin Now Playing ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal aus dem Store.",
    "The Jellyfin Now Playing scene is not installed on this frame. Install the package again from the store.",
    "La escena Jellyfin Now Playing no está instalada en este marco. Vuelve a instalar el paquete desde la tienda."],
  noteSceneOff: ["Die Szene Jellyfin Now Playing ist ausgeschaltet.", "The Jellyfin Now Playing scene is switched off.", "La escena Jellyfin Now Playing está desactivada."],
  noteNoPermission: ["„Allow takeover“ ist für Jellyfin Now Playing auf der Plugins-Seite aus, deshalb kann es den Bildschirm nicht übernehmen.",
    "“Allow takeover” is off for Jellyfin Now Playing on the Plugins page, so it cannot take the screen.",
    "«Allow takeover» está desactivado para Jellyfin Now Playing en la página Plugins, así que no puede tomar la pantalla."],
  noteBusy: ["Ein anderes Plugin hat gerade den Bildschirm. Jellyfin Now Playing versucht es weiter.",
    "Another plugin has the screen right now. Jellyfin Now Playing keeps trying.",
    "Otro plugin tiene la pantalla ahora mismo. Jellyfin Now Playing lo sigue intentando."],
  notePlaylist: ["Die Takeover-Playlist konnte nicht angelegt werden; Details im Plugin-Log.",
    "The takeover playlist could not be made; details in the plugin log.",
    "No se pudo crear la lista de toma; detalles en el registro del plugin."],
  noteFailed: ["Der Rahmen hat die Szene nicht rechtzeitig angezeigt.", "The frame did not show the scene in time.", "El marco no mostró la escena a tiempo."],
  noteTooOld: ["Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.", "This frame is too old to hand the screen to a plugin.", "Este marco es demasiado antiguo para ceder la pantalla a un plugin."],
  noteEnded: ["Der Rahmen hat die Anzeige beendet ({state}). Beim nächsten Abfragen versucht es das Plugin wieder.",
    "The frame ended the display ({state}). The plugin tries again on the next check.",
    "El marco terminó la visualización ({state}). El plugin lo intenta de nuevo en la próxima consulta."],
  testing: ["Teste …", "Testing …", "Probando …"],
  testOk: ["Verbunden mit {server}. Benutzer: {users}", "Connected to {server}. Users: {users}", "Conectado a {server}. Usuarios: {users}"],
  testUnknownUser: ["Den Benutzer „{user}“ gibt es auf diesem Server nicht.", "There is no user “{user}” on this server.", "No existe el usuario «{user}» en este servidor."],
  testUnset: ["Bitte zuerst Adresse und API-Schlüssel eintragen.", "Please enter address and API key first.", "Introduce primero la dirección y la clave API."],
  testFailed: ["Test fehlgeschlagen: {error}", "Test failed: {error}", "La prueba falló: {error}"],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
  back: ["← Zurück zu DynaFrame", "← Back to DynaFrame", "← Volver a DynaFrame"]
};
const LANGS = ["de", "en", "es"];
const NOTES = { noScene: "noteNoScene", sceneOff: "noteSceneOff", noPermission: "noteNoPermission", busy: "noteBusy",
  playlist: "notePlaylist", failed: "noteFailed", tooOld: "noteTooOld" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(name, value) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify({ [name]: value }) });
    setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function itemLine(item) {
  if (item.type === "Episode") {
    const code = item.season != null && item.episode != null
      ? `S${String(item.season).padStart(2, "0")}E${String(item.episode).padStart(2, "0")} · ` : "";
    return [item.series, `${code}${item.title}`];
  }
  if (item.type === "Audio") return [item.title, [item.artists.join(", "), item.album].filter(Boolean).join(" · ")];
  return [item.title, [item.year, item.genres.join(", ")].filter(Boolean).join(" · ")];
}

function renderNow(now) {
  const art = el("nowArt");
  if (!now.playing || !now.item) {
    el("nowLabel").textContent = t("nothing");
    el("nowTitle").textContent = "";
    el("nowSub").textContent = "";
    el("nowBar").hidden = true;
    art.style.backgroundImage = "";
    art.className = "now-art";
    return;
  }
  const item = now.item;
  const [title, sub] = itemLine(item);
  const label = now.paused ? t("nowPaused") : t("nowPlaying");
  el("nowLabel").textContent = now.device ? `${label} · ${t("on", { device: now.device })}` : label;
  el("nowTitle").textContent = title;
  el("nowSub").textContent = sub;
  art.className = `now-art${item.type === "Audio" ? " square" : ""}`;
  art.style.backgroundImage = item.poster ? `url("./api/image/${item.poster}")` : "";
  if (item.runtimeMs > 0) {
    let pos = now.positionMs;
    if (!now.paused) pos += Math.max(0, now.serverNow - now.sampledAt);
    el("nowFill").style.width = `${Math.min(100, (pos / item.runtimeMs) * 100).toFixed(1)}%`;
    el("nowBar").hidden = false;
  } else {
    el("nowBar").hidden = true;
  }
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const values = state.settings;
  applyLanguage(values.Language);
  el("Language").value = values.Language;
  el("factVersion").textContent = state.version || "—";

  const status = state.status || {};
  const conn = el("factConnection");
  conn.textContent = status.connection === "ok" ? t("connOk") : status.connection === "unset" ? t("connUnset")
    : status.connection === "error" ? `${t("connError")}: ${status.error}` : t("connWait");
  conn.className = status.connection === "ok" ? "ok" : status.connection ? "warn" : "";

  const take = state.takeover || {};
  const screen = el("factScreen");
  screen.textContent = take.active ? t("screenTaken") : values.Takeover ? t("screenFree") : t("screenOff");
  screen.className = take.active ? "ok" : "";
  let note = "";
  if (take.note && take.note.startsWith("ended:")) note = t("noteEnded", { state: take.note.slice(6) });
  else if (NOTES[take.note]) note = t(NOTES[take.note]);
  else if (state.scene && NOTES[state.scene.note]) note = t(NOTES[state.scene.note]);
  setStatus(note, note ? "bad" : "", "takeoverNote");

  renderNow(state.now || {});

  if (!editing) {
    for (const name of [...NUMBER_FIELDS, ...TEXT_FIELDS, ...SELECT_FIELDS]) el(name).value = values[name];
  }
  el("ApiKey").placeholder = values.ApiKeySet ? t("keySet") : t("keyMissing");
  for (const name of CHECK_FIELDS) el(name).checked = !!values[name];
  el("ShowOverlay").disabled = !values.Takeover;
  el("ShowOverview").disabled = values.Look === "cover";
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function trackEditing(input) {
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}

for (const name of NUMBER_FIELDS) {
  const input = el(name);
  trackEditing(input);
  input.addEventListener("change", () => save(name, Number(input.value)));
}
for (const name of TEXT_FIELDS) {
  const input = el(name);
  trackEditing(input);
  input.addEventListener("change", () => save(name, input.value.trim()));
}
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save(name, e.target.value));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save(name, e.target.checked));

// Der Schlüssel wird nie zurückgeschickt; ein leeres Feld lässt den alten stehen.
const keyInput = el("ApiKey");
trackEditing(keyInput);
keyInput.addEventListener("change", async () => {
  const value = keyInput.value.trim();
  if (!value) return;
  keyInput.value = "";
  await save("ApiKey", value);
});

el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  if (current) render(current);
  save("Language", e.target.value);
});

function fillUsers(names) {
  const list = el("userList");
  list.textContent = "";
  for (const name of names || []) {
    const option = document.createElement("option");
    option.value = name;
    list.appendChild(option);
  }
}

el("testButton").addEventListener("click", async () => {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    if (result.ok) {
      fillUsers(result.users);
      let text = t("testOk", { server: result.server, users: (result.users || []).join(", ") || "—" });
      if (result.userKnown === false) text += " " + t("testUnknownUser", { user: el("UserName").value });
      setStatus(text, result.userKnown === false ? "bad" : "ok", "testNote");
    } else {
      setStatus(result.code === "unset" ? t("testUnset") : t("testFailed", { error: result.error }), "bad", "testNote");
    }
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
});

el("refreshButton").addEventListener("click", async () => {
  try {
    await api("./api/refresh", { method: "POST" });
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

refresh();
setInterval(refresh, 4000);
