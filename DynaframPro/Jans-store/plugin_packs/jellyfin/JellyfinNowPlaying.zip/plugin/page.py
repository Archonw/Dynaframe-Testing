"""Einstellungen und Plugin-Seite von Jellyfin Now Playing.

Alle Einstellungen liegen in data/settings.json (bleibt bei Updates) und werden
auf der eigenen Plugin-Seite (Advanced Settings) bearbeitet, wie bei Fußball
Live. Beim ersten Start nach dem Update werden die Werte der alten
Plugins-Seite (manifest.json bis 0.3.5) übernommen, damit Server, Schlüssel
und Benutzer erhalten bleiben.

Derselbe kleine Server liefert der Szene ihre Daten (/api/scene) und die
Bilder (/api/image/...). Die Szene kommt über den Proxy der Weboberfläche auf
:8003, deshalb bekommen diese Antworten CORS-Header.
"""
import json
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

PLUGIN_DIR = Path(__file__).resolve().parent
DATA_DIR = PLUGIN_DIR / "data"
SETTINGS_FILE = DATA_DIR / "settings.json"
STUDIO_DIR = PLUGIN_DIR / "studio"
DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
LANGUAGES = ("de", "en", "es")

SETTINGS = {
    "Language":       {"kind": "choice", "default": "de", "options": list(LANGUAGES)},
    "ServerUrl":      {"kind": "url", "default": ""},
    "ApiKey":         {"kind": "secret", "default": ""},
    "UserName":       {"kind": "text", "default": ""},
    "PollSeconds":    {"kind": "int", "default": 10, "min": 3, "max": 120},
    "ShowWhenPaused": {"kind": "bool", "default": True},
    "IncludeMusic":   {"kind": "bool", "default": False},
    "EpisodeCover":   {"kind": "choice", "default": "series", "options": ["series", "episode"]},
    "Takeover":       {"kind": "bool", "default": True},
    "ShowOverlay":    {"kind": "bool", "default": False},
    "Look":           {"kind": "choice", "default": "details", "options": ["details", "cover"]},
    "ShowOverview":   {"kind": "bool", "default": True},
    "ShowClock":      {"kind": "bool", "default": True},
}
# Diese Werte gab es schon auf der alten Plugins-Seite.
MIGRATE = ("ServerUrl", "ApiKey", "UserName", "PollSeconds", "ShowWhenPaused", "IncludeMusic",
           "EpisodeCover", "Takeover", "ShowOverlay")

_lock = threading.Lock()


def _number(raw):
    try:
        value = float(str(raw).strip().replace(",", "."))
    except (TypeError, ValueError):
        return None
    return value if value == value else None  # NaN


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return default
    if kind == "bool":
        if isinstance(raw, bool):
            return raw
        text = str(raw).strip().lower()
        return True if text in ("true", "1", "yes", "on") else False if text in ("false", "0", "no", "off") else default
    if kind == "int":
        value = _number(raw)
        if value is None:
            return default
        return int(round(max(spec["min"], min(spec["max"], value))))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "url":
        url = str(raw).strip().rstrip("/")
        if url and not re.match(r"^https?://", url, re.I):
            url = "http://" + url
        return url[:300]
    return str(raw).strip()[:300]


def _read():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return None
    except (OSError, ValueError):
        return {}


def _write(stored):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = SETTINGS_FILE.with_suffix(".json.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(stored, stream, indent=1, ensure_ascii=False)
    temp.replace(SETTINGS_FILE)


def migrate(plugin):
    """Erster Start mit der eigenen Seite: Werte der alten Plugins-Seite übernehmen."""
    with _lock:
        if _read() is not None:
            return
        stored = {}
        for name in MIGRATE:
            try:
                raw = plugin.get_setting(name, None)
            except Exception:
                raw = None
            if raw is not None and raw != "":
                stored[name] = coerce(name, raw)
        try:
            _write(stored)
        except OSError as exc:
            plugin.log(f"Could not write settings.json: {exc}", level="error")
            return
    if stored:
        plugin.log(f"Settings taken over from the previous version: {', '.join(sorted(stored))}")


def settings():
    with _lock:
        stored = _read() or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def public_settings():
    """Für die Seite: der API-Schlüssel verlässt das Plugin nie."""
    values = settings()
    values["ApiKey"] = ""
    values["ApiKeySet"] = bool(settings()["ApiKey"])
    return values


def save(changes):
    changed = []
    with _lock:
        stored = _read() or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            kind = SETTINGS[name]["kind"]
            if kind == "int" and _number(raw) is None:
                continue  # leeres oder ungültiges Zahlenfeld: alten Wert behalten
            if kind == "secret" and not str(raw or "").strip():
                continue  # die Seite kennt den Schlüssel nicht; leer heißt "behalten"
            value = coerce(name, raw)
            if stored.get(name, SETTINGS[name]["default"]) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            _write(stored)
    return changed


# --------------------------------------------------------------------------
# Die Seite
# --------------------------------------------------------------------------

def theme_id():
    try:
        with open(DFR_DATA_DIR / "webui_theme.json", "r", encoding="utf-8") as handle:
            stored = json.load(handle)
    except (OSError, ValueError):
        return ""
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def _page_html():
    html = (STUDIO_DIR / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio.js", "application/javascript; charset=utf-8"),
}

# Vom Plugin gesetzt: state() -> dict, changed(names), scene() -> dict,
# image(name) -> (bytes, content_type) | None, actions: {name: fn() -> dict}
_hooks = {"state": lambda: {}, "changed": lambda changed: None, "scene": lambda: {},
          "image": lambda name: None, "actions": {}}


class _Handler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        pass

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        # Immer ganz lesen: ungelesene Bytes landen sonst in der nächsten Anfrage.
        raw = self.rfile.read(length) if length > 0 else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        url = urlparse(self.path)
        path = unquote(url.path)
        try:
            if path in ("/", "/index.html"):
                self._send(_page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((STUDIO_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                payload = {"success": True, "settings": public_settings(), "theme": {"id": theme_id()}}
                payload.update(_hooks["state"]())
                self._json(payload)
                return
            if path == "/api/scene":
                self._json(_hooks["scene"](), cors=True)
                return
            if path.startswith("/api/image/"):
                found = _hooks["image"](path.rsplit("/", 1)[-1])
                if found is None:
                    self._json({"success": False, "error": "No image"}, 404, cors=True)
                else:
                    self._send(found[0], found[1], cache="max-age=86400", cors=True)
                return
            if path.startswith("/api/") and path[5:] in _hooks["actions"]:
                query = {k: v[-1] for k, v in parse_qs(url.query).items()}
                self._json(_hooks["actions"][path[5:]](query))
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        body = self._body()
        try:
            if path == "/api/settings":
                changed = save(body)
                if changed:
                    _hooks["changed"](changed)
                self._json({"success": True, "changed": changed, "settings": public_settings()})
                return
            if path.startswith("/api/") and path[5:] in _hooks["actions"]:
                self._json(_hooks["actions"][path[5:]](body))
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:
            self._json({"success": False, "error": str(exc)}, 500)


_server = None


def start(plugin, **hooks):
    """Seite auf Loopback starten und beim Host anmelden. Wirft nie."""
    global _server
    _hooks.update({k: v for k, v in hooks.items() if v is not None})
    try:
        _server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        threading.Thread(target=_server.serve_forever, name="settings-page", daemon=True).start()
        url = f"http://127.0.0.1:{_server.server_address[1]}/"
        plugin.register_advanced_settings_page(url)
        plugin.log(f"Plugin page at {url}")
    except Exception as exc:
        try:
            plugin.log(f"Plugin page not available: {exc}", level="warning")
        except Exception:
            pass


def stop(plugin):
    global _server
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if _server is not None:
        try:
            _server.shutdown()
            _server.server_close()
        except Exception:
            pass
        _server = None
