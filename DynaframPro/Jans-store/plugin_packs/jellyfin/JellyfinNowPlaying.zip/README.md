# Jellyfin Now Playing

Solange ein gewählter Jellyfin-Benutzer etwas schaut (oder auf Wunsch hört), zeigt der Rahmen, was läuft: Cover, Hintergrundbild, Titel, Staffel und Folge, Jahr, Altersfreigabe, Genres, Bewertung, Inhalt und den Fortschritt mit Restzeit und Endzeit. Hört die Wiedergabe auf, läuft deine Playlist weiter.

Das Paket besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene Jellyfin Now Playing** zeichnet die Anzeige, quer und hoch. Wahlweise *Cover mit Infos* oder *Nur das Cover* (wie das alte Plugin).
- **Das Plugin** fragt Jellyfin alle paar Sekunden, liefert der Szene Daten und Bilder (der API-Schlüssel bleibt im Plugin) und legt die Szene über die laufende Playlist, solange etwas läuft.

## Einrichten

1. Paket aus dem Store installieren.
2. Auf der Plugins-Seite bei Jellyfin Now Playing **Allow takeover** einschalten.
3. **Open Jellyfin Now Playing** öffnen, Adresse, API-Schlüssel (Jellyfin: Dashboard › API-Schlüssel) und Benutzer eintragen, **Verbindung testen** drücken. Alles wird sofort gespeichert. Die Seite gibt es auf Deutsch, Englisch und Spanisch; die Sprache gilt auch für die Szene.

Wer von Version 0.3.x kommt: Server, Schlüssel, Benutzer und die anderen Einstellungen werden beim ersten Start übernommen. Das alte Cover-Bild und die alte Playlist „Jellyfin (takeover)“ werden aufgeräumt.

Die Playlist **Jellyfin Now Playing (takeover)** benutzt das Plugin selbst. Lass sie ausgeschaltet; wird sie gelöscht, legt das Plugin sie neu an.

## Aktionen

**Check now** fragt Jellyfin sofort, **Test connection** prüft Server, Schlüssel und Benutzer und schreibt das Ergebnis ins Log.
