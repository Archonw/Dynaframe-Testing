/* Jellyfin Now Playing - die Szene.
 *
 * Daten und Bilder kommen vom Plugin Jellyfin Now Playing, über den Proxy der
 * Weboberfläche auf :8003 (der Proxy der Engine lehnt lokale Adressen ab).
 * Der API-Schlüssel bleibt im Plugin; die Szene fragt Jellyfin nie selbst.
 * Mit ?demo=1 zeigt sie Beispieldaten (zum Ansehen im Browser), mit
 * ?demo=music bzw. ?demo=episode andere Beispiele, mit ?look=cover das
 * reine Cover.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "JellyfinNowPlaying";
  const POLL_MS = 3000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.get("demo");
  const pluginBase = params.get("plugin") ||
    `${location.protocol}//${location.hostname}:8003/Plugins/Advanced/${PLUGIN_ID}/`;

  const el = (id) => document.getElementById(id);
  const ui = {
    stage: el("stage"), backA: el("backA"), backB: el("backB"), clock: el("clock"), content: el("content"),
    poster: el("poster"), label: el("label"), labelText: el("labelText"), kicker: el("kicker"), title: el("title"),
    meta: el("meta"), overview: el("overview"), progress: el("progress"), fill: el("fill"), elapsed: el("elapsed"),
    remaining: el("remaining"), thin: el("thin"), thinFill: el("thinFill"), idle: el("idle"),
    idleText: el("idleText"), idleSub: el("idleSub")
  };

  const TEXT = {
    de: { playing: "Läuft gerade", paused: "Pausiert", on: "auf", nothing: "Gerade läuft nichts",
      nothingSub: "Sobald in Jellyfin etwas startet, erscheint es hier.", unreachable: "Plugin nicht erreichbar",
      unreachableSub: "Die Szene bekommt ihre Daten vom Plugin Jellyfin Now Playing. Läuft es?",
      season: "Staffel", episode: "Folge", left: "noch", ends: "endet um", min: "Min.", h: "Std." },
    en: { playing: "Now playing", paused: "Paused", on: "on", nothing: "Nothing is playing",
      nothingSub: "As soon as something starts in Jellyfin, it appears here.", unreachable: "Plugin not reachable",
      unreachableSub: "This scene gets its data from the Jellyfin Now Playing plugin. Is it running?",
      season: "Season", episode: "Episode", left: "", ends: "ends at", min: "min", h: "h" },
    es: { playing: "Reproduciendo", paused: "En pausa", on: "en", nothing: "No se reproduce nada",
      nothingSub: "En cuanto algo empiece en Jellyfin, aparecerá aquí.", unreachable: "Plugin no disponible",
      unreachableSub: "Esta escena recibe sus datos del plugin Jellyfin Now Playing. ¿Está en marcha?",
      season: "Temporada", episode: "Episodio", left: "quedan", ends: "termina a las", min: "min", h: "h" }
  };
  const LOCALE = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = TEXT[params.get("lang")] ? params.get("lang") : "de";
  let T = TEXT[lang];
  let timeFmt = null;
  function setLanguage(next) {
    if (timeFmt && next === lang) return;
    lang = TEXT[next] ? next : "de";
    T = TEXT[lang];
    document.documentElement.lang = lang;
    timeFmt = new Intl.DateTimeFormat(LOCALE[lang], { hour: "2-digit", minute: "2-digit" });
  }
  setLanguage(lang);

  let data = null;           // letzte Antwort des Plugins
  let receivedAt = 0;        // Date.now() bei der Antwort
  let shownKey = null;       // was gerade gezeigt wird (Item + Darstellung)
  let backLayer = 0;
  let backUrl = null;
  let failures = 0;
  let readySent = false;

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function imageUrl(name) {
    if (!name) return "";
    if (/^(https?:|data:)/.test(name)) return name;
    return new URL(`api/image/${name}`, pluginBase).toString();
  }

  // ------------------------------------------------------------ Beispieldaten

  function demoArt(w, h, a, b, text) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">` +
      `<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/>` +
      `<stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/>` +
      (text ? `<circle cx="${w * .72}" cy="${h * .3}" r="${Math.min(w, h) * .16}" fill="#ffe3a3" opacity=".85"/>` : "") +
      `<path d="M0 ${h * .78} Q ${w * .3} ${h * .6} ${w * .55} ${h * .74} T ${w} ${h * .7} V ${h} H 0 Z" fill="#000" opacity=".35"/>` +
      (text ? `<text x="50%" y="${h * .9}" font-family="Georgia,serif" font-size="${w * .09}" fill="#fff" text-anchor="middle" opacity=".9">${text}</text>` : "") +
      `</svg>`;
    return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }

  function demoData() {
    const now = Date.now();
    const base = { success: true, lang, look: params.get("look") || "details", showOverview: true, showClock: true,
      playing: true, paused: params.has("paused"), sampledAt: now, serverNow: now, device: "Wohnzimmer-TV", version: 1 };
    if (DEMO === "music") {
      return Object.assign(base, { positionMs: 74000, item: { id: "m", type: "Audio", title: "Blue in Green",
        artists: ["Miles Davis"], album: "Kind of Blue", year: 1959, genres: ["Jazz"], runtimeMs: 337000,
        overview: "", poster: demoArt(800, 800, "#1d3b6e", "#0b1530", "KIND OF BLUE"), backdrop: null } });
    }
    if (DEMO === "episode") {
      return Object.assign(base, { positionMs: 1260000, item: { id: "e", type: "Episode", title: "Der lange Winter",
        series: "Nordlicht", season: 2, episode: 5, year: 2024, genres: ["Drama", "Krimi"], rating: "FSK 12",
        communityRating: 8.1, runtimeMs: 2820000,
        overview: "Als ein Schneesturm die Insel von der Außenwelt abschneidet, muss Ermittlerin Hanna Lund einen alten Fall neu aufrollen – und jemandem vertrauen, dem sie nie wieder vertrauen wollte.",
        poster: demoArt(600, 900, "#2b5d7a", "#0d1b2a", "NORDLICHT"), backdrop: demoArt(1920, 1080, "#16324a", "#04070f", "") } });
    }
    return Object.assign(base, { positionMs: 2533000, item: { id: "f", type: "Movie", title: "Die Reise zum Leuchtturm",
      series: "", year: 2023, genres: ["Abenteuer", "Familie"], rating: "FSK 6", communityRating: 7.4, runtimeMs: 6480000,
      overview: "Zwei Geschwister finden auf dem Dachboden ihrer Großmutter eine alte Seekarte. Sie führt zu einem Leuchtturm, der auf keiner anderen Karte zu finden ist, und zu einer Geschichte, die ihre Familie seit drei Generationen verschweigt.",
      poster: demoArt(600, 900, "#c0602c", "#3b1b4a", "LEUCHTTURM"), backdrop: demoArt(1920, 1080, "#6a3a5c", "#0d0b1f", "") } });
  }

  // ------------------------------------------------------------ Darstellung

  function hms(ms) {
    const s = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    const mm = String(m).padStart(h ? 2 : 1, "0"), ss = String(sec).padStart(2, "0");
    return h ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
  }

  function runtimeText(ms) {
    const min = Math.round(ms / 60000);
    if (min < 60) return `${min} ${T.min}`;
    return `${Math.floor(min / 60)} ${T.h} ${String(min % 60).padStart(2, "0")} ${T.min}`;
  }

  function chip(text, cls = "") {
    const span = document.createElement("span");
    span.className = `chip${cls ? " " + cls : ""}`;
    span.textContent = text;
    return span;
  }

  function setBackdrop(url, blurred) {
    const key = url ? `${url}|${blurred}` : null;
    if (key === backUrl) return;
    backUrl = key;
    const layers = [ui.backA, ui.backB];
    const next = layers[backLayer ^ 1], prev = layers[backLayer];
    if (!url) {
      prev.classList.remove("show");
      next.classList.remove("show");
      return;
    }
    const img = new Image();
    img.onload = () => {
      if (backUrl !== key) return;
      next.style.backgroundImage = `url("${url}")`;
      next.classList.toggle("blurred", !!blurred);
      next.classList.add("show");
      prev.classList.remove("show");
      backLayer ^= 1;
    };
    img.src = url;
  }

  function position() {
    if (!data || !data.item) return 0;
    let pos = data.positionMs || 0;
    // Die Zeit des Plugins und der Szene können abweichen: gerechnet wird ab
    // dem Moment, an dem die Antwort kam, plus ihr Alter beim Plugin.
    if (!data.paused) pos += Math.max(0, (data.serverNow - data.sampledAt)) + (Date.now() - receivedAt);
    return data.item.runtimeMs ? Math.min(pos, data.item.runtimeMs) : pos;
  }

  function renderProgress() {
    if (!data || !data.item) return;
    const total = data.item.runtimeMs || 0;
    const pos = position();
    if (!total) {
      ui.progress.hidden = true;
      ui.thin.classList.remove("on");
      return;
    }
    const pct = `${Math.min(100, (pos / total) * 100).toFixed(2)}%`;
    ui.progress.hidden = false;
    ui.thin.classList.add("on");
    ui.fill.style.width = pct;
    ui.thinFill.style.width = pct;
    ui.elapsed.textContent = hms(pos);
    const left = total - pos;
    const end = timeFmt.format(new Date(Date.now() + left));
    ui.remaining.textContent = data.paused
      ? `${T.left ? T.left + " " : "−"}${hms(left)}`
      : `${T.left ? T.left + " " : "−"}${hms(left)} · ${T.ends} ${end}`;
  }

  function renderIdle(unreachable) {
    ui.stage.classList.add("idle-mode");
    ui.stage.classList.remove("look-cover", "paused");
    ui.idle.hidden = false;
    ui.idleText.textContent = unreachable ? T.unreachable : T.nothing;
    ui.idleSub.textContent = unreachable ? T.unreachableSub : T.nothingSub;
    setBackdrop(null);
    shownKey = null;
  }

  function fillItem(d) {
    const item = d.item;
    const kind = item.type;
    ui.poster.className = "poster" + (kind === "Audio" ? " square" : "");
    ui.poster.onload = () => {
      // Folgenbilder sind meist 16:9, Poster 2:3.
      const ratio = ui.poster.naturalWidth / Math.max(1, ui.poster.naturalHeight);
      ui.poster.classList.toggle("square", ratio > .85 && ratio < 1.2);
      ui.poster.classList.toggle("wide", ratio >= 1.2);
    };
    ui.poster.src = imageUrl(item.poster) || "";

    let kicker = "", title = item.title || "";
    if (kind === "Episode") {
      kicker = item.series || "";
      const code = [item.season != null ? `${T.season} ${item.season}` : "", item.episode != null ? `${T.episode} ${item.episode}` : ""]
        .filter(Boolean).join(" · ");
      if (code) kicker = kicker ? `${kicker} · ${code}` : code;
    } else if (kind === "Audio") {
      kicker = (item.artists || []).join(", ");
    }
    ui.kicker.textContent = kicker;
    ui.title.textContent = title;
    ui.title.classList.toggle("long", title.length > 38);

    ui.meta.textContent = "";
    if (kind === "Audio" && item.album) ui.meta.appendChild(chip(item.album));
    if (item.year) ui.meta.appendChild(chip(String(item.year)));
    if (item.rating) ui.meta.appendChild(chip(item.rating));
    if (item.runtimeMs && kind !== "Audio") ui.meta.appendChild(chip(runtimeText(item.runtimeMs)));
    for (const g of item.genres || []) ui.meta.appendChild(chip(g));
    if (typeof item.communityRating === "number" && item.communityRating > 0) {
      ui.meta.appendChild(chip(item.communityRating.toFixed(1), "star"));
    }
    ui.overview.textContent = d.showOverview && kind !== "Audio" ? (item.overview || "") : "";

    const back = item.backdrop ? imageUrl(item.backdrop) : imageUrl(item.poster);
    setBackdrop(back, !item.backdrop);
  }

  function render() {
    ui.clock.hidden = !(data ? data.showClock !== false : true);
    if (!data || !data.playing || !data.item) {
      renderIdle(failures >= 3 && !data);
      return;
    }
    ui.stage.classList.remove("idle-mode");
    ui.idle.hidden = true;
    ui.stage.classList.toggle("look-cover", data.look === "cover");
    ui.stage.classList.toggle("paused", !!data.paused);
    const device = data.device ? ` · ${T.on} ${data.device}` : "";
    ui.labelText.textContent = `${data.paused ? T.paused : T.playing}${device}`;
    const key = `${data.item.id}|${data.item.poster}|${data.item.backdrop}|${data.look}|${data.showOverview}|${lang}`;
    if (key !== shownKey) {
      const first = shownKey === null;
      shownKey = key;
      if (first) {
        fillItem(data);
      } else {
        ui.content.classList.add("fade");
        const snapshot = data;
        setTimeout(() => {
          fillItem(snapshot);
          ui.content.classList.remove("fade");
        }, 700);
      }
    }
    renderProgress();
  }

  function tickClock() {
    ui.clock.textContent = timeFmt.format(new Date());
  }

  // ------------------------------------------------------------ Daten holen

  async function load() {
    if (DEMO) return demoData();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);
    try {
      const response = await fetch(new URL("api/scene", pluginBase), { signal: controller.signal, cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } finally {
      clearTimeout(timer);
    }
  }

  async function poll() {
    try {
      const next = await load();
      if (next && next.success !== false) {
        data = next;
        receivedAt = Date.now();
        failures = 0;
        setLanguage(next.lang);
      }
    } catch (_) {
      failures += 1;
      if (failures >= 3) data = null;
    }
    render();
    tickClock();
    ready();
    if (!DEMO) setTimeout(poll, POLL_MS);
  }

  function start() {
    tickClock();
    setInterval(() => { tickClock(); renderProgress(); }, 1000);
    // Spätestens nach 5 s ist etwas zu sehen.
    setTimeout(ready, 5000);
    poll();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
