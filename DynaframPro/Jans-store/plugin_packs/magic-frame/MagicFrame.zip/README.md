# Dynaframe's Magic Mirror

Dynaframe's Magic Mirror macht aus dem DynaFrame einen „Magic Mirror“: eine Szene mit Regionen, in die du Module setzt, ganz wie bei [MagicMirror²](https://github.com/MagicMirrorOrg/MagicMirror). Alles wird auf der Plugin-Seite eingestellt, ohne Konfigurationsdatei.

**Regionen:** oben über die ganze Breite, oben links/Mitte/rechts, links, Mitte, rechts, unten links/Mitte/rechts, unten über die ganze Breite. Leere Regionen nehmen keinen Platz weg; das Layout passt sich an Quer- und Hochformat an.

**Eingebaute Module** (jedes darf mehrmals vorkommen):

- **Uhr** mit Datum, Sekunden und Kalenderwoche nach Wunsch
- **Wetter jetzt**, **Wettervorhersage** (bis 7 Tage) und **Regen in den nächsten 3 Stunden** (Open-Meteo, weltweit, ohne Schlüssel)
- **Termine** aus Nextcloud, Google oder jedem ICS-Link
- **Nachrichten** aus einem RSS-Feed: eine Schlagzeile nach der anderen, als Laufband oder als Liste
- **Abfahrten** an einer Haltestelle mit Echtzeit (Transitous)
- **Sprüche** je nach Tageszeit, auch eigene
- **Unwetterwarnungen** des DWD (nur Deutschland, unsichtbar ohne Warnung)
- **Home Assistant**: Werte beliebiger Entitäten
- **Webseite** in einem Rahmen

**Weitere Module** installierst du direkt auf der Plugin-Seite aus dem Modul-Katalog (oder per ZIP-Link). Sie tauchen nicht als eigene Plugins in der Plugins-Übersicht auf. Im Katalog sind bisher: Pegelstand, WLAN für Gäste (QR-Code), WebUntis Stundenplan und Music Assistant. Wie man eines baut, steht in [MODULES.md](MODULES.md).

## Einrichten

1. Paket aus dem Store installieren, dann auf der Plugins-Seite **Open Dynaframe's Magic Mirror**.
2. Oben den **Ort** suchen (für Wetter, Regen, Warnungen und Haltestellen in der Nähe).
3. Module hinzufügen, einstellen und in der Vorschau in die gewünschte Region ziehen.
4. **Playlist „Dynaframe's Magic Mirror“ anlegen** und auf der Startseite starten. Für einen Spiegel, der immer dasselbe zeigt, läuft diese Playlist allein; sonst kommt die Szene wie ein Bild zwischen die anderen.

## Daten

Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), Deutscher Wetterdienst über Bright Sky, OpenStreetMap/Nominatim. Abfahrten und Home Assistant werden nur abgefragt, solange die Szene zu sehen ist.

Dynaframe's Magic Mirror ist ein eigenständiger Nachbau für DynaFrame und gehört nicht zum MagicMirror²-Projekt; Module von MagicMirror laufen nicht direkt darin.
