/* Dynaframe's Magic Mirror - erfundene Daten für ?demo=1 (Vorschau und Store-Bilder). */
(function () {
  "use strict";
  window.MagicFrameDemo = function () {
    const now = Math.floor(Date.now() / 1000);
    const day0 = new Date(); day0.setHours(0, 0, 0, 0);
    const d0 = day0.getTime() / 1000;
    const at = (h, m = 0, d = 0) => d0 + d * 86400 + h * 3600 + m * 60;
    const q = new URLSearchParams(location.search);
    const lang = q.get("lang") || "de";
    const de = lang === "de";
    const portrait = innerHeight > innerWidth;
    const mods = [
      { id: "c1", type: "clock", region: "top_left", config: { date: true, seconds: true, size: "large" } },
      { id: "k1", type: "calendar", region: "top_left", config: { header: de ? "Termine" : "Calendar", count: 6, fade: true } },
      { id: "w1", type: "weather", region: "top_right", config: { feels: true, wind: true, sun: true } },
      { id: "f1", type: "forecast", region: "top_right", config: { header: de ? "Wettervorhersage" : "Forecast", days: 5, pop: true, fade: true } },
      { id: "s1", type: "compliments", region: "middle_center", config: { builtin: true, seconds: 30, size: "large" } },
      { id: "d1", type: "departures", region: portrait ? "bottom_left" : "middle_left", config: { header: de ? "Abfahrten" : "Departures", count: 5, walk: 4 } },
      { id: "h1", type: "homeassistant", region: portrait ? "bottom_right" : "middle_right", config: { header: "Home Assistant" } },
      { id: "n1", type: "news", region: "bottom_bar", config: { style: q.get("news") || "rotate", seconds: 15, count: 5, more: "bbc", showSource: true } },
    ];
    const names = { clock: "Uhr", calendar: "Termine", weather: "Wetter jetzt", forecast: "Wettervorhersage", compliments: "Sprüche",
      departures: "Abfahrten", homeassistant: "Home Assistant", news: "Nachrichten" };
    mods.forEach((m) => { m.name = names[m.type] || m.type; });
    const ev = (title, s, e, allDay = false, location = "") => ({ title, start: s, end: e, allDay, location });
    const dep = (line, kind, dir, min, delay = null, cancelled = false) =>
      ({ line, kind, direction: dir, when: now + min * 60, planned: now + (min - (delay || 0)) * 60, delayMin: delay, cancelled });
    const data = {
      k1: { at: now, value: { events: [
        ev(de ? "Zahnarzt" : "Dentist", now + 50 * 60, now + 110 * 60),
        ev(de ? "Elternabend" : "Parents' evening", at(19, 30), at(21)),
        ev(de ? "Müllabfuhr Bio" : "Bin collection", at(0, 0, 1), at(0, 0, 2), true),
        ev(de ? "Training" : "Training", at(18, 0, 1), at(19, 30, 1)),
        ev(de ? "Geburtstag Oma" : "Grandma's birthday", at(0, 0, 3), at(0, 0, 4), true),
        ev(de ? "Werkstatt" : "Car service", at(8, 0, 5), at(9, 0, 5)),
      ] } },
      w1: { at: now, value: { current: { temp: 12.4, feels: 10.1, code: 2, isDay: true, wind: 14, windDir: 240 },
        sunrise: at(7, 41), sunset: at(18, 22), max: 14, min: 6, imperial: false } },
      f1: { at: now, value: { imperial: false, daily: [[2, 14, 6, 10], [61, 12, 7, 80], [3, 11, 5, 30], [0, 15, 4, 0], [80, 13, 8, 60]]
        .map((r, i) => ({ day: d0 + i * 86400, code: r[0], max: r[1], min: r[2], pop: r[3] })) } },
      d1: { at: now, value: { stop: de ? "Hauptbahnhof" : "Central Station", rows: [
        dep("S3", "sbahn", de ? "Flughafen" : "Airport", 2), dep("12", "tram", de ? "Westfriedhof" : "Westside", 6, 2),
        dep("RE5", "train", "Koblenz", 11), dep("U4", "ubahn", de ? "Messe" : "Fairground", 14),
        dep("43", "bus", de ? "Waldstraße" : "Forest Road", 19, null, true), dep("S3", "sbahn", de ? "Flughafen" : "Airport", 22)] } },
      h1: { at: now, value: { entities: [
        { name: de ? "Wohnzimmer" : "Living room", state: "21.4", unit: "°C", deviceClass: "temperature", domain: "sensor" },
        { name: de ? "Luftfeuchte Bad" : "Bathroom humidity", state: "58", unit: "%", deviceClass: "humidity", domain: "sensor" },
        { name: de ? "Fenster Küche" : "Kitchen window", state: "on", deviceClass: "window", domain: "binary_sensor" },
        { name: de ? "Haustür" : "Front door", state: "locked", domain: "lock" },
        { name: de ? "Waschmaschine" : "Washer", state: "off", domain: "switch", icon: "mdi:washing-machine" },
        { name: de ? "Licht Flur" : "Hall light", state: "on", domain: "light" },
        { name: de ? "Strom jetzt" : "Power now", state: "412", unit: "W", deviceClass: "power", domain: "sensor" }] } },
      n1: { at: now, value: { sources: [
        { name: "tagesschau.de", items: [
        { title: de ? "Bahn kündigt neuen Fahrplan für den Winter an" : "Rail operator announces new winter timetable", at: now - 1800 },
        { title: de ? "Forscher entdecken neue Art in der Tiefsee" : "Researchers discover new deep-sea species", at: now - 4000 },
        { title: de ? "Herbststurm zieht über Norddeutschland" : "Autumn storm sweeps across the north", at: now - 7200 }] },
        { name: "BBC News", items: [
          { title: "Leaders meet for climate talks in Brazil", at: now - 2400 },
          { title: "Central bank holds interest rates steady", at: now - 5400 }] }] } },
    };
    const skinType = q.get("skin");
    // Belegung der Felder wie die Vorgabe der Skins, ?set=clock=n1:headlines;pic=h1:values ändert einzelne
    const slots = skinType === "mosaic"
      ? { date: "skin:date", clock: "skin:analog", wx: "skin:weather", time: "skin:time", pic: "skin:weatherpicture" }
      : { days: "skin:weekdays", time: "skin:time", year: "skin:year", date: "skin:date", clock: "skin:analog", rise: "skin:sunrise",
        set: "skin:sunset", cd: "skin:countdown", wx: "skin:weather", net: "skin:wifi" };
    String(q.get("set") || "").split(";").filter(Boolean).forEach((pair) => { const [k, v] = pair.split("="); slots[k] = v || ""; });
    const skin = skinType ? { id: "skin", type: skinType, region: "", missing: false, slots,
      config: { tint: q.get("tint") || "mint", seconds: skinType === "lcd", countdown: q.get("cd") ?? "17:00", countdownLabel: "",
        palette: q.get("palette") || "classic", picture: q.get("picture") || "weather" },
      data: { at: now, value: { current: { temp: 12.4, feels: 10.1, code: Number(q.get("code") ?? 2), isDay: q.get("night") == null, wind: 14, windDir: 240 },
        sunrise: at(7, 41), sunset: at(18, 22), max: 14, min: 6, imperial: false, daily: data.f1.value.daily } } } : null;
    return { success: true, version: "demo", skin, lang, scale: 100, background: q.get("bg") || "black",
      backgroundColor: "#" + (q.get("color") || "1b2430"), backgroundImage: q.get("img") || "", backgroundDim: Number(q.get("dim") ?? 55), clock24: lang !== "en", place: de ? "Mainz" : "Mainz",
      modules: mods, data, addons: [], compliments: {
        any: de ? ["Schön, dass du da bist.", "Heute wird ein guter Tag."] : ["Nice to see you.", "Today is going to be a good day."] } };
  };
})();
