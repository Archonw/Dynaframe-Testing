/* Magic Frame - der Rahmen der Szene.
 *
 * Holt alle 10 Sekunden vom Plugin Magic Frame, welche Module in welcher
 * Region stehen, und deren Daten. Jedes Modul zeichnet sein Renderer, den
 * es mit MagicFrame.register(typ, renderer) anmeldet: die eingebauten in
 * modules.js, Zusatzmodule in ihrer eigenen module.js, die die Szene vom
 * Plugin nachlädt.
 *
 * Ein Renderer ist { render(el, ctx), tick?(el, ctx) }. render schreibt den
 * Inhalt in el und gibt false zurück, wenn das Modul gerade nichts zu zeigen
 * hat. tick läuft jede Sekunde (Uhr, Countdown). ctx enthält config, data,
 * error, lang und die Helfer in ctx.h (siehe unten).
 *
 * ?demo=1 zeigt erfundene Daten, ?lang=en.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "MagicFrame";
  const POLL_MS = 10000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  // Die Plugin-Seite ist über den Proxy der Weboberfläche erreichbar. Je nach
  // DynaFrame-Version auf :8003 oder direkt auf Port 80; die Szene probiert der
  // Reihe nach und bleibt bei der Adresse, die antwortet.
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  let baseIndex = 0;

  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const TEXT = {
    de: { offline: "Magic Frame antwortet nicht", waiting: "Lädt …", empty: "Noch keine Module. Öffne Magic Frame auf der Plugins-Seite des Rahmens.",
      today: "Heute", tomorrow: "Morgen", missing: "Modul „{type}“ ist nicht installiert." },
    en: { offline: "Magic Frame is not responding", waiting: "Loading …", empty: "No modules yet. Open Magic Frame on the frame's Plugins page.",
      today: "Today", tomorrow: "Tomorrow", missing: "Module “{type}” is not installed." },
    es: { offline: "Magic Frame no responde", waiting: "Cargando …", empty: "Aún no hay módulos. Abre Magic Frame en la página de plugins del marco.",
      today: "Hoy", tomorrow: "Mañana", missing: "El módulo «{type}» no está instalado." },
  };

  const renderers = {};
  const views = {};          // id -> { el, body, key, type }
  const loadedAddons = {};   // type -> version
  let payload = null;
  let lang = params.get("lang") || "de";
  let failures = 0;
  let readySent = false;

  const el = (id) => document.getElementById(id);

  // ------------------------------------------------------------ Helfer für Renderer

  function esc(text) {
    return String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  }

  // t({de: "...", en: "...", es: "..."}, {n: 3}) oder t("Text")
  function t(texts, values = {}) {
    const text = typeof texts === "string" ? texts : (texts[lang] ?? texts.en ?? texts.de ?? "");
    return String(text).replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
  }

  const locale = () => LOCALES[lang] || "de-DE";
  const nowSec = () => Date.now() / 1000;

  function time(epoch, seconds = false) {
    return new Date(epoch * 1000).toLocaleTimeString(locale(), {
      hour: "2-digit", minute: "2-digit", second: seconds ? "2-digit" : undefined,
      hour12: payload ? !payload.clock24 : false,
    });
  }

  function dayStart(epoch) {
    const d = new Date(epoch * 1000);
    d.setHours(0, 0, 0, 0);
    return d.getTime() / 1000;
  }

  // "Heute", "Morgen" oder der Wochentag (kurz), innerhalb einer Woche; sonst Datum
  function dayName(epoch, long = false) {
    const days = Math.round((dayStart(epoch) - dayStart(nowSec())) / 86400);
    if (days === 0) return TEXT[lang]?.today || TEXT.de.today;
    if (days === 1) return TEXT[lang]?.tomorrow || TEXT.de.tomorrow;
    const d = new Date(epoch * 1000);
    if (days > 1 && days < 7) return d.toLocaleDateString(locale(), { weekday: long ? "long" : "short" });
    return d.toLocaleDateString(locale(), { weekday: "short", day: "numeric", month: "short" });
  }

  function number(value, digits = 0) {
    return Number(value).toLocaleString(locale(), { maximumFractionDigits: digits, minimumFractionDigits: digits });
  }

  // Strich-Symbole, 24 x 24
  const ICONS = {
    sunrise: '<path d="M4 18h16M7 18a5 5 0 0 1 10 0M12 4v5M9 7l3-3 3 3M4.5 12.5l1.5 1M19.5 12.5l-1.5 1"/>',
    sunset: '<path d="M4 18h16M7 18a5 5 0 0 1 10 0M12 4v5M9 6l3 3 3-3M4.5 12.5l1.5 1M19.5 12.5l-1.5 1"/>',
    wind: '<path d="M3 9h11a3 3 0 1 0-3-3M3 15h15a3 3 0 1 1-3 3M3 12h7"/>',
    umbrella: '<path d="M12 3a9 9 0 0 1 9 9H3a9 9 0 0 1 9-9zM12 12v7a2 2 0 0 0 4 0"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    train: '<rect x="6" y="3" width="12" height="14" rx="3"/><path d="M6 10h12M9 20l-1.5 1.5M15 20l1.5 1.5M9 14h.01M15 14h.01"/>',
    bus: '<rect x="5" y="3" width="14" height="15" rx="2"/><path d="M5 11h14M8 18v2.5M16 18v2.5M5 7h14"/>',
    warn: '<path d="M12 3l9.5 17h-19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
    home: '<path d="M4 11l8-7 8 7M6 9.5V20h12V9.5"/>',
    walk: '<circle cx="13" cy="4.5" r="1.6"/><path d="M10 21l2.2-6.5L15 17v4M9 11l2.5-3.5 3 1.5 1.5 3 2.5 1M11.5 7.5L10 14"/>',
  };

  function icon(name, cls = "") {
    return `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
      stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
  }

  // Wettersymbole nach WMO-Code (Open-Meteo), weiß wie bei MagicMirror
  function weatherIcon(code, isDay = true, cls = "") {
    const sun = '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/>';
    const moon = '<path d="M15.5 3.5a8.5 8.5 0 1 0 5 13.6A7 7 0 0 1 15.5 3.5z"/>';
    const cloud = '<path d="M7 19a4.5 4.5 0 0 1-.7-8.95A6 6 0 0 1 17.8 11 4 4 0 0 1 17.5 19z"/>';
    const smallSun = '<g transform="translate(-3 -4) scale(.62)">' + (isDay ? sun : moon) + "</g>";
    const smallCloud = '<path d="M9 20a3.6 3.6 0 0 1-.5-7.15A4.8 4.8 0 0 1 17.6 14 3.2 3.2 0 0 1 17.4 20z"/>';
    const drops = '<path d="M8 21.5l-1 1.5M12 21.5l-1 1.5M16 21.5l-1 1.5"/>';
    const flakes = '<path d="M8 22h.01M12 22.5h.01M16 22h.01M10 23.5h.01M14 23.5h.01"/>';
    const bolt = '<path d="M12.5 15l-2 3.5h3l-2 3.5"/>';
    const fog = '<path d="M4 10h16M6 14h12M4 18h16"/>';
    let body;
    if (code === 0) body = isDay ? sun : moon;
    else if (code <= 2) body = smallSun + smallCloud;
    else if (code === 3) body = cloud;
    else if (code === 45 || code === 48) body = fog;
    else if (code >= 95) body = '<g transform="translate(0 -3)">' + cloud + "</g>" + bolt;
    else if ((code >= 71 && code <= 77) || code === 85 || code === 86) body = '<g transform="translate(0 -3)">' + cloud + "</g>" + flakes;
    else if (code >= 51) body = '<g transform="translate(0 -3)">' + cloud + "</g>" + drops;
    else body = cloud;
    return `<svg class="wi ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"
      stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
  }

  const WEATHER_TEXT = [
    [[0], "klar", "clear", "despejado"], [[1], "überwiegend klar", "mainly clear", "mayormente despejado"],
    [[2], "teils bewölkt", "partly cloudy", "parcialmente nublado"], [[3], "bedeckt", "overcast", "cubierto"],
    [[45, 48], "Nebel", "fog", "niebla"], [[51, 53, 55, 56, 57], "Nieselregen", "drizzle", "llovizna"],
    [[61, 63, 66], "Regen", "rain", "lluvia"], [[65, 67], "starker Regen", "heavy rain", "lluvia fuerte"],
    [[71, 73, 77], "Schnee", "snow", "nieve"], [[75], "starker Schnee", "heavy snow", "nevada fuerte"],
    [[80, 81], "Regenschauer", "showers", "chubascos"], [[82], "heftige Schauer", "heavy showers", "chubascos fuertes"],
    [[85, 86], "Schneeschauer", "snow showers", "chubascos de nieve"], [[95, 96, 99], "Gewitter", "thunderstorm", "tormenta"],
  ];

  function weatherText(code) {
    const row = WEATHER_TEXT.find((r) => r[0].includes(code));
    return row ? row[1 + Math.max(0, ["de", "en", "es"].indexOf(lang))] : "";
  }

  function degrees(value, imperial) {
    return value == null ? "–" : `${number(Math.round(value))}°${imperial ? "F" : ""}`;
  }

  const helpers = { esc, t, time, dayName, dayStart, number, icon, weatherIcon, weatherText, degrees, nowSec,
    locale: () => locale(), lang: () => lang };

  // ------------------------------------------------------------ Registrierung

  window.MagicFrame = {
    register(type, renderer) {
      renderers[type] = renderer;
      // Ein Zusatzmodul kann später kommen als die Daten: dann neu zeichnen.
      Object.values(views).filter((v) => v.type === type).forEach((v) => { v.key = ""; });
      if (payload) draw();
    },
    helpers,
  };

  // ------------------------------------------------------------ Zeichnen

  function ctxFor(row) {
    const slot = (payload.data || {})[row.id] || {};
    return {
      id: row.id, type: row.type, region: row.region, config: row.config || {},
      data: slot.value ?? null, error: slot.error || "", at: slot.at || 0,
      lang, clock24: payload.clock24, place: payload.place, compliments: payload.compliments, h: helpers,
    };
  }

  function draw() {
    const rows = payload.modules || [];
    const seen = new Set();
    // In jeder Region in der Reihenfolge der Liste
    rows.forEach((row) => {
      seen.add(row.id);
      const region = el(row.region) || el("middle_center");
      let view = views[row.id];
      if (!view || view.type !== row.type) {
        if (view) view.el.remove();
        const box = document.createElement("section");
        box.className = `module m-${row.type.replace(/[^a-z0-9-]/g, "-")}`;
        box.innerHTML = '<header class="module-header"></header><div class="module-body"></div>';
        view = views[row.id] = { el: box, body: box.lastChild, head: box.firstChild, key: "", type: row.type };
      }
      region.appendChild(view.el);   // bewegt auch an die richtige Stelle
      const ctx = ctxFor(row);
      const renderer = renderers[row.type];
      const key = JSON.stringify([row.config, ctx.data, ctx.error, lang, !!renderer, row.missing]);
      if (key === view.key) return;
      view.key = key;
      view.ctx = ctx;
      const header = row.config?.header || "";
      view.head.textContent = header;
      view.head.hidden = !header;
      let shown = true;
      if (!renderer) {
        view.body.innerHTML = row.missing
          ? `<div class="xsmall dimmed">${esc((TEXT[lang] || TEXT.de).missing.replace("{type}", row.type))}</div>`
          : "";
        shown = !!row.missing;
      } else if (ctx.error && ctx.data == null) {
        view.body.innerHTML = `<div class="module-error xsmall dimmed">${esc(ctx.error)}</div>`;
      } else {
        try {
          shown = renderer.render(view.body, ctx) !== false;
        } catch (err) {
          view.body.innerHTML = `<div class="module-error xsmall dimmed">${esc(String(err))}</div>`;
        }
      }
      view.el.hidden = !shown;
    });
    Object.keys(views).forEach((id) => {
      if (!seen.has(id)) { views[id].el.remove(); delete views[id]; }
    });
    // Leere Regionen nehmen keinen Platz weg
    document.querySelectorAll(".region").forEach((region) => {
      region.classList.toggle("empty", ![...region.children].some((c) => !c.hidden));
    });
    document.querySelectorAll(".row").forEach((row) => {
      const full = [...row.children].filter((r) => !r.classList.contains("empty"));
      row.classList.toggle("empty", !full.length);
      row.classList.toggle("solo-left", full.length === 1 && full[0].classList.contains("left"));
      row.classList.toggle("solo-right", full.length === 1 && full[0].classList.contains("right"));
    });
    el("empty").hidden = rows.length > 0;
    if (!rows.length) el("empty").textContent = (TEXT[lang] || TEXT.de).empty;
  }

  function tick() {
    if (!payload) return;
    Object.values(views).forEach((view) => {
      const renderer = renderers[view.type];
      if (renderer?.tick && view.ctx && !view.el.hidden) {
        try { renderer.tick(view.body, view.ctx); } catch (_) { /* nächstes Mal */ }
      }
    });
  }

  function loadAddons(list) {
    (list || []).forEach((addon) => {
      if (loadedAddons[addon.type] === addon.version) return;
      loadedAddons[addon.type] = addon.version;
      const base = pluginBases[baseIndex];
      const v = encodeURIComponent(addon.version || "0");
      if (addon.style) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = `${base}${addon.style}?v=${v}`;
        document.head.appendChild(link);
      }
      const script = document.createElement("script");
      script.src = `${base}${addon.script}?v=${v}`;
      document.head.appendChild(script);
    });
  }

  function apply(next) {
    payload = next;
    lang = params.get("lang") || next.lang || "de";
    document.documentElement.lang = lang;
    const root = document.documentElement.style;
    root.setProperty("--scale", String((Number(next.scale) || 100) / 100));
    document.body.dataset.background = next.background || "black";
    el("offline").hidden = true;
    loadAddons(next.addons);
    draw();
    ready();
  }

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  async function poll() {
    if (DEMO) {
      apply(window.MagicFrameDemo());
      return;
    }
    for (let attempt = 0; attempt < pluginBases.length; attempt++) {
      const base = pluginBases[baseIndex];
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        const response = await fetch(`${base}api/scene`, { cache: "no-store", signal: controller.signal });
        clearTimeout(timer);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const next = await response.json();
        if (!next || !next.success) throw new Error("bad payload");
        failures = 0;
        apply(next);
        return;
      } catch (_) {
        if (!payload) baseIndex = (baseIndex + 1) % pluginBases.length;
      }
    }
    failures += 1;
    if (failures >= 3 || !payload) {
      el("offline").hidden = false;
      el("offline").textContent = (TEXT[lang] || TEXT.de).offline;
      ready();
    }
  }

  el("offline").textContent = (TEXT[lang] || TEXT.de).waiting;
  setTimeout(ready, 4000); // nicht ewig auf das Plugin warten
  window.addEventListener("load", () => {
    poll();
    setInterval(poll, DEMO ? 60000 : POLL_MS);
    setInterval(tick, 1000);
  });
})();
