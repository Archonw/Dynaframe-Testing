/* Dynaframe's Magic Mirror - der Rahmen der Szene.
 *
 * Holt alle 10 Sekunden vom Plugin Dynaframe's Magic Mirror, welche Module in welcher
 * Region stehen, und deren Daten. Jedes Modul zeichnet sein Renderer, den
 * es mit MagicFrame.register(typ, renderer) anmeldet: die eingebauten in
 * modules.js, Zusatzmodule in ihrer eigenen module.js, die die Szene vom
 * Plugin nachlädt.
 *
 * Ein Renderer ist { render(el, ctx), tick?(el, ctx) }. render schreibt den
 * Inhalt in el und gibt false zurück, wenn das Modul gerade nichts zu zeigen
 * hat. tick läuft jede Sekunde (Uhr, Countdown). ctx enthält config, data,
 * error, lang und die Helfer in ctx.h (siehe unten).
 *
 * Ist ein Skin gewählt (payload.skin) und angemeldet (registerSkin, die
 * eingebauten in skins.js), zeichnet er stattdessen die ganze Szene.
 *
 * ?demo=1 zeigt erfundene Daten, ?lang=en, ?skin=lcd.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "MagicFrame";
  const POLL_MS = 10000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  // Die Plugin-Seite ist über den Proxy der Weboberfläche erreichbar. Je nach
  // DynaFrame-Version auf :8003 oder direkt auf Port 80; die Szene probiert der
  // Reihe nach und bleibt bei der Adresse, die antwortet.
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  let baseIndex = 0;

  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const TEXT = {
    de: { offline: "Dynaframe's Magic Mirror antwortet nicht", waiting: "Lädt …", empty: "Noch keine Module. Öffne Dynaframe's Magic Mirror auf der Plugins-Seite des Rahmens.",
      today: "Heute", tomorrow: "Morgen", missing: "Modul „{type}“ ist nicht installiert." },
    en: { offline: "Dynaframe's Magic Mirror is not responding", waiting: "Loading …", empty: "No modules yet. Open Dynaframe's Magic Mirror on the frame's Plugins page.",
      today: "Today", tomorrow: "Tomorrow", missing: "Module “{type}” is not installed." },
    es: { offline: "Dynaframe's Magic Mirror no responde", waiting: "Cargando …", empty: "Aún no hay módulos. Abre Dynaframe's Magic Mirror en la página de plugins del marco.",
      today: "Hoy", tomorrow: "Mañana", missing: "El módulo «{type}» no está instalado." },
  };

  const renderers = {};
  const skinRenderers = {};
  const widgetRenderers = {};
  const skinView = { type: "", key: "", ctx: null, drawn: false, slots: {} };
  const views = {};          // id -> { el, body, key, type }
  const loadedAddons = {};   // type -> version
  let payload = null;
  let lang = params.get("lang") || "de";
  let failures = 0;
  let readySent = false;

  const el = (id) => document.getElementById(id);

  // ------------------------------------------------------------ Helfer für Renderer

  function esc(text) {
    return String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  }

  // t({de: "...", en: "...", es: "..."}, {n: 3}) oder t("Text")
  function t(texts, values = {}) {
    const text = typeof texts === "string" ? texts : (texts[lang] ?? texts.en ?? texts.de ?? "");
    return String(text).replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
  }

  const locale = () => LOCALES[lang] || "de-DE";
  const nowSec = () => Date.now() / 1000;

  function time(epoch, seconds = false) {
    return new Date(epoch * 1000).toLocaleTimeString(locale(), {
      hour: "2-digit", minute: "2-digit", second: seconds ? "2-digit" : undefined,
      hour12: payload ? !payload.clock24 : false,
    });
  }

  function dayStart(epoch) {
    const d = new Date(epoch * 1000);
    d.setHours(0, 0, 0, 0);
    return d.getTime() / 1000;
  }

  // "Heute", "Morgen" oder der Wochentag (kurz), innerhalb einer Woche; sonst Datum
  function dayName(epoch, long = false) {
    const days = Math.round((dayStart(epoch) - dayStart(nowSec())) / 86400);
    if (days === 0) return TEXT[lang]?.today || TEXT.de.today;
    if (days === 1) return TEXT[lang]?.tomorrow || TEXT.de.tomorrow;
    const d = new Date(epoch * 1000);
    if (days > 1 && days < 7) return d.toLocaleDateString(locale(), { weekday: long ? "long" : "short" });
    return d.toLocaleDateString(locale(), { weekday: "short", day: "numeric", month: "short" });
  }

  function number(value, digits = 0) {
    return Number(value).toLocaleString(locale(), { maximumFractionDigits: digits, minimumFractionDigits: digits });
  }

  // Strich-Symbole, 24 x 24
  const ICONS = {
    sunrise: '<path d="M4 18h16M7 18a5 5 0 0 1 10 0M12 4v5M9 7l3-3 3 3M4.5 12.5l1.5 1M19.5 12.5l-1.5 1"/>',
    sunset: '<path d="M4 18h16M7 18a5 5 0 0 1 10 0M12 4v5M9 6l3 3 3-3M4.5 12.5l1.5 1M19.5 12.5l-1.5 1"/>',
    wind: '<path d="M3 9h11a3 3 0 1 0-3-3M3 15h15a3 3 0 1 1-3 3M3 12h7"/>',
    umbrella: '<path d="M12 3a9 9 0 0 1 9 9H3a9 9 0 0 1 9-9zM12 12v7a2 2 0 0 0 4 0"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    train: '<rect x="6" y="3" width="12" height="14" rx="3"/><path d="M6 10h12M9 20l-1.5 1.5M15 20l1.5 1.5M9 14h.01M15 14h.01"/>',
    bus: '<rect x="5" y="3" width="14" height="15" rx="2"/><path d="M5 11h14M8 18v2.5M16 18v2.5M5 7h14"/>',
    warn: '<path d="M12 3l9.5 17h-19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
    home: '<path d="M4 11l8-7 8 7M6 9.5V20h12V9.5"/>',
    walk: '<circle cx="13" cy="4.5" r="1.6"/><path d="M10 21l2.2-6.5L15 17v4M9 11l2.5-3.5 3 1.5 1.5 3 2.5 1M11.5 7.5L10 14"/>',
    thermo: '<path d="M10 4a2 2 0 0 1 4 0v10a4 4 0 1 1-4 0z"/><path d="M12 9v7"/>',
    droplet: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
    bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    window: '<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M12 3v18M5 12h14"/>',
    door: '<path d="M6 21V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v17M4 21h16"/><path d="M14.5 12h.01"/>',
    battery: '<rect x="3" y="7" width="16" height="10" rx="2"/><path d="M21 11v2M6 10v4M9 10v4"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
    plug: '<path d="M9 3v5M15 3v5M7 8h10v3a5 5 0 0 1-10 0zM12 16v5"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    person: '<circle cx="12" cy="7" r="3.5"/><path d="M5 21a7 7 0 0 1 14 0"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/>',
    gauge: '<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/>',
    toggle: '<rect x="3" y="8" width="18" height="8" rx="4"/><circle cx="16" cy="12" r="2"/>',
    washer: '<rect x="4" y="3" width="16" height="18" rx="2"/><circle cx="12" cy="13" r="4.5"/><path d="M7 6.5h.01M10 6.5h3"/>',
    car: '<path d="M4 16v-3l2-5h12l2 5v3zM4 16v2.5M20 16v2.5M4 13h16"/><path d="M7.5 14.5h.01M16.5 14.5h.01"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14"/>',
    music: '<path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/>',
  };

  function icon(name, cls = "") {
    return `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
      stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
  }

  // Wettersymbole nach WMO-Code (Open-Meteo), weiß wie bei MagicMirror
  function weatherIcon(code, isDay = true, cls = "") {
    const sun = '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/>';
    const moon = '<path d="M15.5 3.5a8.5 8.5 0 1 0 5 13.6A7 7 0 0 1 15.5 3.5z"/>';
    const cloud = '<path d="M7 19a4.5 4.5 0 0 1-.7-8.95A6 6 0 0 1 17.8 11 4 4 0 0 1 17.5 19z"/>';
    const smallSun = '<g transform="translate(-3 -4) scale(.62)">' + (isDay ? sun : moon) + "</g>";
    const smallCloud = '<path d="M9 20a3.6 3.6 0 0 1-.5-7.15A4.8 4.8 0 0 1 17.6 14 3.2 3.2 0 0 1 17.4 20z"/>';
    const drops = '<path d="M8 21.5l-1 1.5M12 21.5l-1 1.5M16 21.5l-1 1.5"/>';
    const flakes = '<path d="M8 22h.01M12 22.5h.01M16 22h.01M10 23.5h.01M14 23.5h.01"/>';
    const bolt = '<path d="M12.5 15l-2 3.5h3l-2 3.5"/>';
    const fog = '<path d="M4 10h16M6 14h12M4 18h16"/>';
    let body;
    if (code === 0) body = isDay ? sun : moon;
    else if (code <= 2) body = smallSun + smallCloud;
    else if (code === 3) body = cloud;
    else if (code === 45 || code === 48) body = fog;
    else if (code >= 95) body = '<g transform="translate(0 -3)">' + cloud + "</g>" + bolt;
    else if ((code >= 71 && code <= 77) || code === 85 || code === 86) body = '<g transform="translate(0 -3)">' + cloud + "</g>" + flakes;
    else if (code >= 51) body = '<g transform="translate(0 -3)">' + cloud + "</g>" + drops;
    else body = cloud;
    return `<svg class="wi ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"
      stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
  }

  const WEATHER_TEXT = [
    [[0], "klar", "clear", "despejado"], [[1], "überwiegend klar", "mainly clear", "mayormente despejado"],
    [[2], "teils bewölkt", "partly cloudy", "parcialmente nublado"], [[3], "bedeckt", "overcast", "cubierto"],
    [[45, 48], "Nebel", "fog", "niebla"], [[51, 53, 55, 56, 57], "Nieselregen", "drizzle", "llovizna"],
    [[61, 63, 66], "Regen", "rain", "lluvia"], [[65, 67], "starker Regen", "heavy rain", "lluvia fuerte"],
    [[71, 73, 77], "Schnee", "snow", "nieve"], [[75], "starker Schnee", "heavy snow", "nevada fuerte"],
    [[80, 81], "Regenschauer", "showers", "chubascos"], [[82], "heftige Schauer", "heavy showers", "chubascos fuertes"],
    [[85, 86], "Schneeschauer", "snow showers", "chubascos de nieve"], [[95, 96, 99], "Gewitter", "thunderstorm", "tormenta"],
  ];

  function weatherText(code) {
    const row = WEATHER_TEXT.find((r) => r[0].includes(code));
    return row ? row[1 + Math.max(0, ["de", "en", "es"].indexOf(lang))] : "";
  }

  function degrees(value, imperial) {
    return value == null ? "–" : `${number(Math.round(value))}°${imperial ? "F" : ""}`;
  }

  const helpers = { esc, t, time, dayName, dayStart, number, icon, weatherIcon, weatherText, degrees, nowSec,
    locale: () => locale(), lang: () => lang };

  // ------------------------------------------------------------ Registrierung

  window.MagicFrame = {
    register(type, renderer) {
      renderers[type] = renderer;
      // Ein Zusatzmodul kann später kommen als die Daten: dann neu zeichnen.
      Object.values(views).filter((v) => v.type === type).forEach((v) => { v.key = ""; });
      if (payload) draw();
    },
    // Ein Widget-Typ für die Felder der Skins: { render(el, data, ctx), tick?(el, data, ctx) }
    registerWidget(type, renderer) {
      widgetRenderers[type] = renderer;
      skinView.slots = {};
      if (payload) drawSkin();
    },
    // Ein Skin zeichnet die ganze Szene statt der Module: { render(root, ctx), tick?(root, ctx),
    // widgets?: {typ: Widget} }. Seine Felder sind Elemente mit data-slot="id" (und auf Wunsch
    // data-caption="id" für die Beschriftung); was darin steht, wählt man auf der Plugin-Seite.
    registerSkin(type, renderer) {
      skinRenderers[type] = renderer;
      skinView.key = "";
      if (payload) drawSkin();
    },
    helpers,
  };

  // ------------------------------------------------------------ Ohne Container-Abfragen
  // Ältere Chromium-Versionen (auch auf manchem Rahmen) kennen cqh/cqw und @container
  // nicht, dann wären alle Widgets winzig. Dann holen wir die Stylesheets selbst, machen
  // aus 10cqh ein calc(10 * var(--cqh)) und aus jedem @container-Block Regeln, die an
  // einer Klasse des Felds hängen. Größe und Klassen setzt ein ResizeObserver je Feld.
  const CQ = !(window.CSS && CSS.supports && CSS.supports("container-type", "size")) && !!window.ResizeObserver;
  const cqConds = [];   // [{cls, cond, test(w, h)}]
  const cqObserver = CQ ? new ResizeObserver((entries) => entries.forEach((e) => cqApply(e.target))) : null;

  function cqApply(box) {
    const w = box.clientWidth, h = box.clientHeight;
    box.style.setProperty("--cqw", `${w / 100}px`);
    box.style.setProperty("--cqh", `${h / 100}px`);
    box.style.setProperty("--cqmin", `${Math.min(w, h) / 100}px`);
    box.style.setProperty("--cqmax", `${Math.max(w, h) / 100}px`);
    cqConds.forEach((c) => box.classList.toggle(c.cls, !!(w && h) && c.test(w, h)));
  }

  function cqWatch(box) {
    if (!cqObserver || box._cq) return;
    box._cq = true;
    cqObserver.observe(box);
    cqApply(box);
  }

  // "(aspect-ratio > 6)", "(max-height: 160px)", "(width >= 300px) and (aspect-ratio < 1.2)"
  function cqClass(cond) {
    cond = cond.replace(/^[a-z][\w-]*\s+(?=\()/i, "").trim();   // Name des Containers spielt keine Rolle
    const known = cqConds.find((c) => c.cond === cond);
    if (known) return known.cls;
    const tests = cond.split(/\s+and\s+/i).map((part) => {
      const m = part.match(/^\(\s*(min-|max-)?(aspect-ratio|width|height)\s*(>=|<=|>|<|=|:)\s*([\d.]+)(?:\s*\/\s*([\d.]+))?(?:px)?\s*\)$/i);
      if (!m) return () => false;
      const [, pre, feature, op0, a, b] = m;
      const limit = b ? Number(a) / Number(b) : Number(a);
      const op = pre === "min-" ? ">=" : pre === "max-" ? "<=" : op0 === ":" ? "=" : op0;
      return (w, h) => {
        const v = feature === "width" ? w : feature === "height" ? h : w / h;
        return op === ">" ? v > limit : op === "<" ? v < limit : op === ">=" ? v >= limit : op === "<=" ? v <= limit : Math.abs(v - limit) < 0.01;
      };
    });
    const cls = `cq${cqConds.length}`;
    cqConds.push({ cls, cond, test: (w, h) => tests.every((f) => f(w, h)) });
    return cls;
  }

  // Kommas nur auf oberster Ebene trennen (nicht in :not(a, b))
  function splitTop(text) {
    const out = [];
    let depth = 0, last = 0;
    for (let i = 0; i < text.length; i++) {
      if (text[i] === "(") depth++;
      else if (text[i] === ")") depth--;
      else if (text[i] === "," && !depth) { out.push(text.slice(last, i)); last = i + 1; }
    }
    out.push(text.slice(last));
    return out.map((x) => x.trim()).filter(Boolean);
  }

  // Das Feld kann über jedem Teil des Selektors liegen: ".bc .w-x b" wird zu
  // ".cq0 .bc .w-x b, .bc .cq0 .w-x b, .bc .w-x .cq0 b" - nur einer davon trifft.
  function cqSelectors(selector, cls) {
    return splitTop(selector).flatMap((sel) => {
      const tokens = sel.split(/\s+/);
      const out = [];
      tokens.forEach((tok, k) => {
        if (/^[>+~]$/.test(tok) || (k && /^[>+~]$/.test(tokens[k - 1]))) return;
        out.push([...tokens.slice(0, k), `.${cls}`, ...tokens.slice(k)].join(" "));
      });
      return out;
    }).join(", ");
  }

  function cqRewrite(css, href) {
    const urls = [];
    css = css.replace(/url\(([^)]*)\)/g, (_, u) => `\u0001${urls.push(u) - 1}\u0001`)
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/(-?\d*\.?\d+)cq(min|max|h|w)\b/g, (_, n, u) => `calc(${n} * var(--cq${u}))`);
    let out = "", i = 0;
    for (;;) {
      const at = css.indexOf("@container", i);
      const open = at < 0 ? -1 : css.indexOf("{", at);
      if (open < 0) { out += css.slice(i); break; }
      out += css.slice(i, at);
      let depth = 1, j = open + 1;
      while (j < css.length && depth) { if (css[j] === "{") depth++; else if (css[j] === "}") depth--; j++; }
      const cls = cqClass(css.slice(at + 10, open).trim());
      out += css.slice(open + 1, j - 1).replace(/([^{}]+)\{/g, (_, sel) => `${cqSelectors(sel, cls)} {`);
      i = j;
    }
    // Relative Adressen gelten jetzt für die Seite, nicht mehr für die CSS-Datei
    return out.replace(/\u0001(\d+)\u0001/g, (_, k) => {
      const raw = urls[k].trim().replace(/^["']|["']$/g, "");
      try { return /^data:/.test(raw) ? `url(${urls[k]})` : `url("${new URL(raw, href).href}")`; } catch (_) { return `url(${urls[k]})`; }
    });
  }

  function cqLink(link) {
    if (!CQ) return;
    fetch(link.href, { cache: "no-cache" }).then((r) => (r.ok ? r.text() : Promise.reject(r.status))).then((css) => {
      const style = document.createElement("style");
      style.textContent = cqRewrite(css, link.href);
      link.parentNode.insertBefore(style, link.nextSibling);
      link.disabled = true;
      document.querySelectorAll(".wslot").forEach(cqApply);
    }).catch(() => { /* bleibt wie es ist */ });
  }
  if (CQ) document.querySelectorAll('link[rel="stylesheet"]').forEach(cqLink);

  // ------------------------------------------------------------ Zeichnen

  function ctxFor(row) {
    const slot = (payload.data || {})[row.id] || {};
    return {
      id: row.id, type: row.type, region: row.region, config: row.config || {},
      data: slot.value ?? null, error: slot.error || "", at: slot.at || 0,
      lang, clock24: payload.clock24, place: payload.place, compliments: payload.compliments, h: helpers,
    };
  }

  function draw() {
    const rows = payload.modules || [];
    const seen = new Set();
    // In jeder Region in der Reihenfolge der Liste
    rows.forEach((row) => {
      seen.add(row.id);
      const region = el(row.region) || el("middle_center");
      let view = views[row.id];
      if (!view || view.type !== row.type) {
        if (view) view.el.remove();
        const box = document.createElement("section");
        box.className = `module m-${row.type.replace(/[^a-z0-9-]/g, "-")}`;
        box.innerHTML = '<header class="module-header"></header><div class="module-body"></div>';
        view = views[row.id] = { el: box, body: box.lastChild, head: box.firstChild, key: "", type: row.type };
      }
      region.appendChild(view.el);   // bewegt auch an die richtige Stelle
      const ctx = ctxFor(row);
      const renderer = renderers[row.type];
      const key = JSON.stringify([row.config, ctx.data, ctx.error, lang, !!renderer, row.missing]);
      if (key === view.key) return;
      view.key = key;
      view.ctx = ctx;
      const header = row.config?.header || "";
      view.head.textContent = header;
      view.head.hidden = !header;
      let shown = true;
      view.drawn = false;   // tick nur, wenn der Renderer selbst gezeichnet hat
      if (!renderer) {
        view.body.innerHTML = row.missing
          ? `<div class="xsmall dimmed">${esc((TEXT[lang] || TEXT.de).missing.replace("{type}", row.type))}</div>`
          : "";
        shown = !!row.missing;
      } else if (ctx.error && ctx.data == null) {
        view.body.innerHTML = `<div class="module-error xsmall dimmed">${esc(ctx.error)}</div>`;
      } else {
        try {
          shown = renderer.render(view.body, ctx) !== false;
          view.drawn = true;
        } catch (err) {
          view.body.innerHTML = `<div class="module-error xsmall dimmed">${esc(String(err))}</div>`;
        }
      }
      view.el.hidden = !shown;
    });
    Object.keys(views).forEach((id) => {
      if (!seen.has(id)) { views[id].el.remove(); delete views[id]; }
    });
    // Leere Regionen nehmen keinen Platz weg
    document.querySelectorAll(".region").forEach((region) => {
      region.classList.toggle("empty", ![...region.children].some((c) => !c.hidden));
    });
    document.querySelectorAll(".row").forEach((row) => {
      const full = [...row.children].filter((r) => !r.classList.contains("empty"));
      row.classList.toggle("empty", !full.length);
      row.classList.toggle("solo-left", full.length === 1 && full[0].classList.contains("left"));
      row.classList.toggle("solo-right", full.length === 1 && full[0].classList.contains("right"));
    });
    el("empty").hidden = rows.length > 0;
    if (!rows.length) el("empty").textContent = (TEXT[lang] || TEXT.de).empty;
  }

  function skinImage() {
    let image = payload.background === "image" ? String(payload.backgroundImage || "") : "";
    if (image && !/^https?:/.test(image)) image = pluginBases[baseIndex] + image;
    return image;
  }

  // Skin gewählt und geladen: er zeichnet die ganze Szene, die Regionen ruhen.
  function drawSkin() {
    const skin = payload.skin;
    const renderer = skin && skinRenderers[skin.type];
    const root = el("skin");
    el("stage").hidden = !!renderer;
    root.hidden = !renderer;
    document.body.dataset.skin = renderer ? skin.type : "";
    if (!renderer) { skinView.type = ""; return false; }
    const slot = skin.data || {};
    const ctx = { type: skin.type, config: skin.config || {}, data: slot.value ?? null, error: slot.error || "", at: slot.at || 0,
      lang, clock24: payload.clock24, place: payload.place, image: skinImage(), h: helpers };
    const key = JSON.stringify([skin.type, ctx.config, lang, ctx.clock24]);
    skinView.ctx = ctx;
    if (key !== skinView.key || skinView.type !== skin.type) {
      skinView.key = key;
      skinView.type = skin.type;
      skinView.slots = {};
      try {
        renderer.render(root, ctx);
        skinView.drawn = true;
      } catch (err) {
        skinView.drawn = false;
        root.innerHTML = `<p class="empty">${esc(String(err))}</p>`;
      }
    }
    fillSlots(root, skin, renderer, ctx);
    return true;
  }

  const CAPTIONS = {
    time: { de: "Zeit", en: "Time", es: "Hora" }, analog: { de: "Uhr", en: "Clock", es: "Reloj" },
    date: { de: "Datum", en: "Date", es: "Fecha" }, year: { de: "Tag", en: "Day", es: "Día" },
    sunrise: { de: "Aufgang", en: "Rise", es: "Salida" }, sunset: { de: "Untergang", en: "Set", es: "Puesta" },
    weather: { de: "Wetter", en: "Weather", es: "Tiempo" }, wifi: { de: "WLAN", en: "Wi-Fi", es: "Wi-Fi" },
    forecast: { de: "Vorhersage", en: "Forecast", es: "Previsión" }, nowplaying: { de: "Läuft gerade", en: "Now playing", es: "Sonando" },
  };

  // Jedes Feld: Daten aus dem Skin selbst oder von einem Modul, gezeichnet vom
  // Widget des Skins oder dem Standard-Widget. "modul-id:module" zeigt das
  // Modul so wie im Standard-Skin. Ein Feld mit "max" > 1 darf mehrere Einträge
  // haben ("skin:time,k1:list"): dann teilt es sich in Unterfelder (.wmulti > .wslot).
  function fillSlots(root, skin, skinRenderer, skinCtx) {
    root.querySelectorAll("[data-slot]").forEach((box) => {
      const id = box.dataset.slot;
      const parts = String((skin.slots || {})[id] || "").split(",").filter(Boolean);
      const captionNode = root.querySelector(`[data-caption="${id}"]`);
      const setCaption = (text) => { if (captionNode && captionNode.textContent !== (text || "")) captionNode.textContent = text || ""; };
      if (parts.length < 2) {
        if (box.classList.contains("wmulti")) {
          box.classList.remove("wmulti");
          box.innerHTML = "";
          dropSlotViews(id);
        }
        fillSlot(box, id, parts[0] || "", skin, skinRenderer, skinCtx, setCaption);
        return;
      }
      if (!box.classList.contains("wmulti") || box.children.length !== parts.length) {
        dropSlotViews(id);
        box.classList.remove("wslot");
        box.classList.add("wmulti");
        delete box.dataset.widget;
        delete box.dataset.source;
        box.innerHTML = parts.map(() => "<div></div>").join("");
      }
      box.dataset.count = parts.length;
      // Die Beschriftung des Felds nennt alle Einträge
      const captions = box._captions = (box._captions || []).slice(0, parts.length);
      parts.forEach((value, i) => {
        fillSlot(box.children[i], `${id}#${i}`, value, skin, skinRenderer, skinCtx, (text) => {
          captions[i] = text || "";
          setCaption(captions.filter(Boolean).join(" · "));
        });
      });
    });
  }

  function dropSlotViews(id) {
    Object.keys(skinView.slots).forEach((k) => { if (k === id || k.startsWith(`${id}#`)) delete skinView.slots[k]; });
  }

  function fillSlot(box, id, value, skin, skinRenderer, skinCtx, caption) {
    const [source, type] = value ? value.split(":") : ["", ""];
    let data = null, error = "", row = null, moduleCtx = null, moduleRenderer = null;
    if (source === "skin") {
      data = skinCtx.data;
      error = skinCtx.error;
    } else if (source) {
      row = (payload.modules || []).find((m) => m.id === source);
      moduleRenderer = row && renderers[row.type];
      if (moduleRenderer) {
        moduleCtx = ctxFor(row);
        error = moduleCtx.error;
        try {
          data = type === "module" ? null : moduleRenderer.widget ? moduleRenderer.widget(type, moduleCtx) ?? null : moduleCtx.data;
        } catch (_) { data = null; }
      }
    }
    const title = row ? row.config?.header || row.name || row.type : "";
    const widget = skinRenderer.widgets?.[type] || widgetRenderers[type];
    const key = JSON.stringify([value, data, error, lang, payload.clock24, skinCtx.config, skinCtx.image, !!widget, !!moduleRenderer,
      type === "module" && moduleCtx ? [moduleCtx.config, moduleCtx.data] : 0]);
    const view = skinView.slots[id];
    if (view && view.key === key) return;
    const ctx = { slot: id.split("#")[0], part: Number(id.split("#")[1] || 0), type, source, config: skinCtx.config,
      moduleConfig: row?.config || null, title, error,
      lang, clock24: payload.clock24, place: payload.place, image: skinCtx.image, h: helpers, caption };
    box.classList.add("wslot");
    box.dataset.widget = type || "";
    box.dataset.source = source === "skin" ? "skin" : source ? "module" : "";
    const next = skinView.slots[id] = { key, box, widget: null, data, ctx, module: null };
    caption(type === "module" || (row && !CAPTIONS[type]) ? title : CAPTIONS[type] ? t(CAPTIONS[type]) : "");
    try {
      if (!value || (source !== "skin" && !moduleRenderer)) {
        box.innerHTML = "";
        if (!value) caption("");
      } else if (type === "module") {
        box.innerHTML = `<section class="module w-module m-${row.type.replace(/[^a-z0-9-]/g, "-")}"><div class="module-body"></div></section>`;
        const body = box.querySelector(".module-body");
        if (moduleCtx.error && moduleCtx.data == null) body.innerHTML = `<div class="module-error xsmall dimmed">${esc(moduleCtx.error)}</div>`;
        else if (moduleRenderer.render(body, moduleCtx) !== false) next.module = { renderer: moduleRenderer, body, ctx: moduleCtx };
      } else if (widget) {
        widget.render(box, data, ctx);
        next.widget = widget;
      } else {
        box.innerHTML = "";
      }
    } catch (err) {
      box.innerHTML = `<div class="w w-wait"><small>${esc(String(err))}</small></div>`;
    }
    cqWatch(box);
  }

  function tickSlots() {
    Object.values(skinView.slots).forEach((v) => {
      try {
        if (v.widget?.tick) v.widget.tick(v.box, v.data, v.ctx);
        if (v.module?.renderer.tick) v.module.renderer.tick(v.module.body, v.module.ctx);
      } catch (_) { /* nächstes Mal */ }
    });
  }

  function tick() {
    if (!payload) return;
    if (skinView.type) {
      const renderer = skinRenderers[skinView.type];
      if (renderer?.tick && skinView.drawn) {
        try { renderer.tick(el("skin"), skinView.ctx); } catch (_) { /* nächstes Mal */ }
      }
      // Was Module für Felder liefern, hängt oft an der Uhrzeit (Abfahrten in Minuten):
      // alle 30 Sekunden neu fragen, gezeichnet wird nur, was sich geändert hat.
      if (new Date().getSeconds() % 30 === 0 && payload.skin) {
        fillSlots(el("skin"), payload.skin, renderer, skinView.ctx);
      }
      tickSlots();
      return;
    }
    Object.values(views).forEach((view) => {
      const renderer = renderers[view.type];
      if (renderer?.tick && view.ctx && view.drawn && !view.el.hidden) {
        try { renderer.tick(view.body, view.ctx); } catch (_) { /* nächstes Mal */ }
      }
    });
  }

  function loadAddons(list) {
    (list || []).forEach((addon) => {
      if (loadedAddons[addon.type] === addon.version) return;
      loadedAddons[addon.type] = addon.version;
      const base = pluginBases[baseIndex];
      const v = encodeURIComponent(addon.version || "0");
      if (addon.style) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = `${base}${addon.style}?v=${v}`;
        document.head.appendChild(link);
        cqLink(link);
      }
      const script = document.createElement("script");
      script.src = `${base}${addon.script}?v=${v}`;
      document.head.appendChild(script);
    });
  }

  // Hintergrund: Schwarz, Nachtblau, eine Farbe oder ein Bild. Auf einem Bild
  // oder einer hellen Farbe bekommt die Schrift einen Schatten, das Bild wird
  // nach Wunsch abgedunkelt.
  function luminance(hex) {
    const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255)
      .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  function applyBackground(next) {
    const mode = next.background || "black";
    const color = /^#[0-9a-f]{6}$/i.test(next.backgroundColor || "") ? next.backgroundColor : "#000000";
    let image = mode === "image" ? String(next.backgroundImage || "") : "";
    if (image && !/^https?:/.test(image)) image = pluginBases[baseIndex] + image;
    const body = document.body;
    body.dataset.background = mode;
    body.style.backgroundColor = mode === "color" || mode === "image" ? color : "";
    const layer = el("bg");
    if (layer.dataset.src !== image) {
      layer.dataset.src = image;
      layer.style.backgroundImage = image ? `url("${image.replace(/"/g, "%22")}")` : "";
    }
    layer.hidden = !image;
    el("bgdim").style.opacity = image ? String(Math.max(0, Math.min(90, Number(next.backgroundDim) || 0)) / 100) : "0";
    // Helle Farbe: dunkle Schrift. Mittlere Farbe oder Bild: Schatten unter der Schrift.
    const light = !image && mode === "color" ? luminance(color) : 0;
    body.classList.toggle("light-bg", light > 0.35);
    body.classList.toggle("shadowed", !!image || (light > 0.12 && light <= 0.35));
  }

  function apply(next) {
    payload = next;
    lang = params.get("lang") || next.lang || "de";
    document.documentElement.lang = lang;
    const root = document.documentElement.style;
    root.setProperty("--scale", String((Number(next.scale) || 100) / 100));
    applyBackground(next);
    el("offline").hidden = true;
    loadAddons(next.addons);
    draw();
    if (drawSkin()) el("empty").hidden = true;
    ready();
  }

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  async function poll() {
    if (DEMO) {
      apply(window.MagicFrameDemo());
      return;
    }
    for (let attempt = 0; attempt < pluginBases.length; attempt++) {
      const base = pluginBases[baseIndex];
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);
        const response = await fetch(`${base}api/scene`, { cache: "no-store", signal: controller.signal });
        clearTimeout(timer);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const next = await response.json();
        if (!next || !next.success) throw new Error("bad payload");
        failures = 0;
        apply(next);
        return;
      } catch (_) {
        if (!payload) baseIndex = (baseIndex + 1) % pluginBases.length;
      }
    }
    failures += 1;
    if (failures >= 3 || !payload) {
      el("offline").hidden = false;
      el("offline").textContent = (TEXT[lang] || TEXT.de).offline;
      ready();
    }
  }

  el("offline").textContent = (TEXT[lang] || TEXT.de).waiting;
  setTimeout(ready, 4000); // nicht ewig auf das Plugin warten
  window.addEventListener("load", () => {
    poll();
    setInterval(poll, DEMO ? 60000 : POLL_MS);
    setInterval(tick, 1000);
  });
})();
