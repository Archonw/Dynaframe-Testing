/* Dynaframe's Magic Mirror - die eingebauten Skins.
 *
 * Ein Skin zeichnet die ganze Szene statt der Module in Regionen. Er meldet
 * sich mit MagicFrame.registerSkin(typ, { render(root, ctx), tick?(root, ctx) })
 * an, genau wie ein Zusatz-Skin in seiner module.js. ctx enthält config, data
 * (Wetter jetzt, Sonne, die nächsten Tage), error, lang, clock24, place,
 * image (das Bild unter "Hintergrund", falls eins gesetzt ist) und die Helfer
 * in ctx.h.
 */
(function () {
  "use strict";

  const MF = window.MagicFrame;
  const h = MF.helpers;
  const { esc, t } = h;

  const pad = (n) => String(n).padStart(2, "0");
  // Ohne Akzente, damit die LCD-Schrift (A-Z) alles darstellen kann
  const plain = (text) => String(text).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\./g, "").toUpperCase();

  const DAYS = { de: ["MO", "DI", "MI", "DO", "FR", "SA", "SO"], en: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
    es: ["LUN", "MAR", "MIE", "JUE", "VIE", "SAB", "DOM"] };
  const days = () => DAYS[h.lang()] || DAYS.de;
  const weekday = (d) => days()[(d.getDay() + 6) % 7];
  const month = (d) => plain(d.toLocaleDateString(h.locale(), { month: "short" })).slice(0, 3);

  // Stunden und Minuten nach der Einstellung 24/12 Stunden
  function clockParts(d, clock24) {
    let hours = d.getHours();
    let ampm = "";
    if (!clock24) {
      ampm = hours < 12 ? "AM" : "PM";
      hours = hours % 12 || 12;
    }
    return { hm: `${pad(hours)}:${pad(d.getMinutes())}`, sec: pad(d.getSeconds()), ampm };
  }

  // Zeigeruhr als SVG, 100 x 100. Die Zeiger stellt setHands() jede Sekunde.
  function analogSvg(opts = {}) {
    const ticks = Array.from({ length: 12 }, (_, i) => {
      const a = (i * 30 * Math.PI) / 180;
      const r1 = i % 3 === 0 ? 40 : 41.5;
      const x1 = 50 + Math.sin(a) * r1, y1 = 50 - Math.cos(a) * r1;
      const x2 = 50 + Math.sin(a) * 45, y2 = 50 - Math.cos(a) * 45;
      return i % 3 === 0 ? "" : `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}"/>`;
    }).join("");
    const numbers = opts.numbers === false ? "" : [[12, 50, 15], [3, 86, 50], [6, 50, 86], [9, 14, 50]]
      .map(([n, x, y]) => `<text x="${x}" y="${y}">${n}</text>`).join("");
    return `<svg class="analog" viewBox="0 0 100 100" aria-hidden="true">
      ${opts.face ? `<circle cx="50" cy="50" r="47" class="face"/>` : ""}
      <g class="ticks">${ticks}</g><g class="nums">${numbers}</g>
      <line class="hand hour" x1="50" y1="54" x2="50" y2="28"/>
      <line class="hand min" x1="50" y1="56" x2="50" y2="15"/>
      ${opts.seconds ? `<line class="hand sec" x1="50" y1="58" x2="50" y2="12"/>` : ""}
      <circle cx="50" cy="50" r="2.4" class="pin"/></svg>`;
  }

  function setHands(svg, d) {
    if (!svg) return;
    const s = d.getSeconds(), m = d.getMinutes() + s / 60, hr = (d.getHours() % 12) + m / 60;
    const turn = (sel, deg) => { const n = svg.querySelector(sel); if (n) n.setAttribute("transform", `rotate(${deg.toFixed(2)} 50 50)`); };
    turn(".hour", hr * 30);
    turn(".min", m * 6);
    turn(".sec", s * 6);
  }

  // Nächster Zeitpunkt HH:MM ab jetzt (heute oder morgen)
  function nextTime(text) {
    const m = String(text || "").trim().match(/^(\d{1,2})[:.](\d{2})$/);
    if (!m || Number(m[1]) > 23 || Number(m[2]) > 59) return null;
    const d = new Date();
    d.setHours(Number(m[1]), Number(m[2]), 0, 0);
    if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
    return d;
  }

  // ================================================================ Retro-LCD

  // Ein LCD-Feld: die nicht leuchtenden Segmente schwach dahinter
  const lcd = (text, cls = "") => {
    const lit = String(text).replace(/ /g, "!");
    const ghost = String(text).replace(/[0-9]/g, "8").replace(/[^:.8 ]/g, "~").replace(/ /g, "!");
    return `<span class="seg ${cls}"><span class="ghost">${esc(ghost)}</span><span class="lit">${esc(lit)}</span></span>`;
  };

  const LCD_LABELS = {
    time: { de: "Zeit", en: "Time", es: "Hora" }, day: { de: "Tag", en: "Day", es: "Día" },
    date: { de: "Datum", en: "Date", es: "Fecha" }, clock: { de: "Uhr", en: "Clock", es: "Reloj" },
    rise: { de: "Aufgang", en: "Rise", es: "Salida" }, set: { de: "Untergang", en: "Set", es: "Puesta" },
    left: { de: "Noch", en: "Left", es: "Faltan" }, weather: { de: "Wetter", en: "Weather", es: "Tiempo" },
    online: { de: "WLAN", en: "Wi-Fi", es: "Wi-Fi" },
  };

  // Kleine Symbole im Stil der Tasten auf dem Gerät
  const PIX = {
    rise: '<path d="M3 19h18M6.5 19a5.5 5.5 0 0 1 11 0M12 4v6M9 7l3-3 3 3M3.5 13.5l2 1M20.5 13.5l-2 1M6.5 9.5l1.5 1.5M17.5 9.5L16 11"/>',
    set: '<path d="M3 19h18M6.5 19a5.5 5.5 0 0 1 11 0M12 4v6M9 7l3 3 3-3M3.5 13.5l2 1M20.5 13.5l-2 1M6.5 9.5l1.5 1.5M17.5 9.5L16 11"/>',
    wifi: '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.7 16a5 5 0 0 1 6.6 0"/><circle cx="12" cy="19.2" r="1.2"/>',
  };
  const pix = (name) => `<svg class="pix" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"
    stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${PIX[name]}</svg>`;

  MF.registerSkin("lcd", {
    render(root, ctx) {
      const cfg = ctx.config || {};
      const L = (k) => t(LCD_LABELS[k]);
      const wx = ctx.data;
      const sunTime = (v) => (v ? h.time(v) : "--:--");
      root.innerHTML = `<div class="lcd tint-${esc(cfg.tint || "mint")}">
        <div class="panel days">${days().map((d, i) => `<span class="day" data-i="${i}">${lcd(d)}</span>`).join("")}</div>
        <figure class="block time"><div class="panel"><span class="ampm"></span><span class="hm"></span>
          ${cfg.seconds !== false ? `<span class="sec"></span>` : ""}</div><figcaption>${esc(L("time"))}</figcaption></figure>
        <figure class="block year"><div class="panel small"></div><figcaption>${esc(L("day"))}</figcaption></figure>
        <figure class="block date"><div class="panel small"></div><figcaption>${esc(L("date"))}</figcaption></figure>
        <figure class="block clock"><div class="tile">${analogSvg({ seconds: cfg.seconds !== false })}</div><figcaption>${esc(L("clock"))}</figcaption></figure>
        <figure class="block rise"><div class="tile tall">${pix("rise")}<b>${esc(sunTime(wx?.sunrise))}</b></div><figcaption>${esc(L("rise"))}</figcaption></figure>
        <figure class="block set"><div class="tile tall">${pix("set")}<b>${esc(sunTime(wx?.sunset))}</b></div><figcaption>${esc(L("set"))}</figcaption></figure>
        <figure class="block cd"><div class="tile wide"><span class="cdname">${esc(cfg.countdownLabel || L("left"))}</span>
          <span class="cdrow"><span class="panel mini" data-cd="h"></span><span class="panel mini" data-cd="m"></span><span class="panel mini" data-cd="s"></span></span></div></figure>
        <figure class="block wx"><div class="tile">${wx?.current ? `${h.weatherIcon(wx.current.code, wx.current.isDay)}<b>${esc(h.degrees(wx.current.temp, wx.imperial))}</b>` : `<b>${esc(ctx.error ? "–" : "…")}</b>`}</div>
          <figcaption>${esc(wx?.current ? h.weatherText(wx.current.code) : L("weather"))}</figcaption></figure>
        <figure class="block net"><div class="tile">${pix("wifi")}</div><figcaption>${esc(L("online"))}</figcaption></figure>
      </div>`;
      root.querySelector(".cd").hidden = !nextTime(cfg.countdown);
      root.querySelector(".lcd").classList.toggle("no-cd", !nextTime(cfg.countdown));
      this.tick(root, ctx);
    },
    tick(root, ctx) {
      const cfg = ctx.config || {};
      const now = new Date();
      const parts = clockParts(now, ctx.clock24);
      const set = (sel, html) => { const n = root.querySelector(sel); if (n && n.dataset.v !== html) { n.dataset.v = html; n.innerHTML = html; } };
      set(".time .hm", lcd(parts.hm));
      set(".time .sec", lcd(parts.sec));
      set(".time .ampm", parts.ampm ? lcd(parts.ampm) : "");
      set(".year .panel", lcd(`${now.getFullYear()} ${weekday(now)}`));
      const date = h.lang() === "en" ? `${month(now)} ${pad(now.getDate())}` : `${pad(now.getDate())} ${month(now)}`;
      set(".date .panel", lcd(date));
      const today = (now.getDay() + 6) % 7;
      root.querySelectorAll(".days .day").forEach((n) => n.classList.toggle("on", Number(n.dataset.i) === today));
      setHands(root.querySelector(".clock svg"), now);
      const target = nextTime(cfg.countdown);
      if (target) {
        const left = Math.max(0, Math.floor((target - now) / 1000));
        set('[data-cd="h"]', lcd(pad(Math.floor(left / 3600))));
        set('[data-cd="m"]', lcd(pad(Math.floor(left / 60) % 60)));
        set('[data-cd="s"]', lcd(pad(left % 60)));
      }
    },
  });

  // ================================================================ Farbraster

  // Wetter als kleines Pixelbild: Himmel nach Tageszeit, Sonne oder Mond,
  // Wolken, Regen oder Schnee, Meer und eine Wiese mit Blumen. 64 x 48 Pixel.
  function weatherScene(wx) {
    const now = h.nowSec();
    const cur = wx?.current || { code: 1, isDay: true };
    const rise = wx?.sunrise || 0, set = wx?.sunset || 0;
    const dusk = rise && set && (Math.abs(now - set) < 2700 || Math.abs(now - rise) < 2700);
    const day = cur.isDay !== false;
    const code = Number(cur.code) || 0;
    const skies = dusk ? ["#3b3f8f", "#6a4c9c", "#b85c8a", "#e8735c", "#f4a259", "#f7c873"]
      : !day ? ["#0b1030", "#111a44", "#17245a", "#1d2f6e", "#253a80", "#2e468f"]
      : code >= 51 || code === 3 || code === 45 || code === 48 ? ["#7d8a99", "#8695a3", "#909fad", "#9aa9b6", "#a5b3bf", "#b0bdc8"]
      : ["#2f7fd8", "#3f8fe0", "#55a0e6", "#6cb1ec", "#86c2f1", "#a2d3f5"];
    const r = (x, y, w, hh, c) => `<rect x="${x}" y="${y}" width="${w}" height="${hh}" fill="${c}"/>`;
    let svg = skies.map((c, i) => r(0, i * 5, 64, 5, c)).join("");
    if (!day && !dusk) {
      [[6, 3], [15, 8], [27, 4], [40, 9], [52, 3], [58, 12], [21, 14], [47, 16]].forEach(([x, y]) => { svg += r(x, y, 1, 1, "#fff8d0"); });
    }
    // Sonne oder Mond: aus Rechtecken, damit es nach Pixeln aussieht
    const bx = day ? 38 : 42, by = dusk ? 19 : 6;
    const disc = [[2, 0, 4], [1, 1, 6], [0, 2, 8], [0, 3, 8], [0, 4, 8], [0, 5, 8], [1, 6, 6], [2, 7, 4]];
    const sunColor = dusk ? "#ffd27a" : day ? "#ffe066" : "#f4f1d8";
    if (code < 3 || dusk) {
      svg += disc.map(([dx, dy, w]) => r(bx + dx, by + dy, w, 1, sunColor)).join("");
      if (!day && !dusk) svg += disc.slice(1, 7).map(([dx, dy, w]) => r(bx + dx + 3, by + dy - 1, Math.max(1, w - 3), 1, skies[1])).join("");
    }
    const cloud = (x, y, c) => r(x + 3, y, 8, 1, c) + r(x + 1, y + 1, 13, 2, c) + r(x, y + 3, 17, 2, c);
    const cloudColor = code >= 61 || code >= 95 ? "#cfd6de" : "#ffffff";
    if (code >= 1) svg += cloud(8, 7, cloudColor);
    if (code >= 2) svg += cloud(30, 11, cloudColor);
    if (code >= 3) svg += cloud(46, 5, cloudColor) + cloud(20, 2, cloudColor);
    if (code === 45 || code === 48) svg += r(0, 20, 64, 2, "#dfe5ea") + r(0, 24, 64, 1, "#dfe5ea");
    const snow = (code >= 71 && code <= 77) || code === 85 || code === 86;
    if (code >= 51 && !snow) for (let i = 0; i < 18; i++) svg += r((i * 11 + 3) % 62, 13 + ((i * 7) % 14), 1, 2, "#bfe3ff");
    if (snow) for (let i = 0; i < 22; i++) svg += r((i * 13 + 5) % 62, 12 + ((i * 5) % 16), 1, 1, "#ffffff");
    if (code >= 95) svg += r(26, 13, 2, 3, "#ffe066") + r(25, 16, 2, 2, "#ffe066") + r(24, 18, 2, 3, "#ffe066");
    // Meer mit Wellen
    const sea = day ? ["#1d6fb8", "#2a82c9", "#1d6fb8"] : ["#0c2550", "#12306a", "#0c2550"];
    svg += r(0, 30, 64, 9, sea[0]);
    for (let i = 0; i < 8; i++) svg += r((i * 9 + 2) % 60, 31 + (i % 3) * 3, 4, 1, sea[1] === "#2a82c9" ? "#7fc3ef" : "#2f5aa0");
    // Wiese mit Blumen
    svg += r(0, 39, 64, 9, day ? "#4caf50" : "#1f5a2a") + r(0, 39, 64, 1, day ? "#7bd17e" : "#2f7a3a");
    [[5, "#ff6b9a"], [13, "#ffe066"], [22, "#ffffff"], [34, "#ff6b9a"], [43, "#ffe066"], [51, "#c38dff"], [59, "#ffffff"]].forEach(([x, c], i) => {
      const y = 42 + (i % 3);
      svg += r(x, y + 1, 1, 3, day ? "#2e7d32" : "#174a20") + r(x - 1, y, 3, 1, c) + r(x, y - 1, 1, 3, c);
    });
    return `<svg class="pixel-scene" viewBox="0 0 64 48" preserveAspectRatio="xMidYMid slice" shape-rendering="crispEdges">${svg}</svg>`;
  }

  MF.registerSkin("mosaic", {
    render(root, ctx) {
      const cfg = ctx.config || {};
      const wx = ctx.data;
      const picture = cfg.picture === "background" && ctx.image
        ? `<div class="photo" style="background-image:url('${esc(ctx.image).replace(/'/g, "%27")}')"></div>`
        : weatherScene(wx);
      const now = wx?.current;
      root.innerHTML = `<div class="mosaic pal-${esc(cfg.palette || "classic")}">
        <div class="cell a"></div><div class="cell b"></div><div class="cell g"></div><div class="cell d"></div>
        <div class="cell e"></div><div class="cell f"></div>
        <div class="cell date"><span class="dtext"></span></div>
        <div class="cell clock">${analogSvg({ face: true, numbers: false })}</div>
        <div class="cell wx"><div class="wxin">${now ? `${h.weatherIcon(now.code, now.isDay)}<b>${esc(h.degrees(now.temp, wx.imperial))}</b>` : `<b>${ctx.error ? "–" : "…"}</b>`}</div></div>
        <div class="cell time"><span class="ttext"></span><small class="tampm"></small></div>
        <div class="cell pic"><div class="picin">${picture}</div></div>
      </div>`;
      this.tick(root, ctx);
    },
    tick(root, ctx) {
      const now = new Date();
      const parts = clockParts(now, ctx.clock24);
      const date = h.lang() === "en" ? `${month(now)} ${pad(now.getDate())}` : `${pad(now.getDate())} ${month(now)}`;
      const dt = root.querySelector(".dtext");
      if (dt.textContent !== date) dt.textContent = date;
      const tt = root.querySelector(".ttext");
      if (tt.textContent !== parts.hm) tt.textContent = parts.hm;
      const ap = root.querySelector(".tampm");
      if (ap.textContent !== parts.ampm) ap.textContent = parts.ampm;
      setHands(root.querySelector(".clock svg"), now);
      // Das Wetterbild wechselt mit der Tageszeit: alle 10 Minuten neu zeichnen
      if (now.getSeconds() === 0 && now.getMinutes() % 10 === 0 && (ctx.config || {}).picture !== "background") {
        const box = root.querySelector(".picin");
        if (box && box.firstElementChild?.tagName === "svg") box.innerHTML = weatherScene(ctx.data);
      }
    },
  });

  // Für Zusatz-Skins: dieselbe Zeigeruhr und LCD-Schrift
  Object.assign(MF.helpers, { analogSvg, setHands, lcd, clockParts });
})();
