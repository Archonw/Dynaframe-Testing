"""Zusatzmodule von anderen: finden, prüfen, laden.

Ein Zusatzmodul ist ein Ordner "magicframe" mit einer module.json, einem
Renderer module.js und auf Wunsch module.css und fetch.py. Magic Frame sucht
solche Ordner an zwei Stellen:

1. in jedem anderen installierten DynaFrame-Plugin (ein Zusatzmodul kann also
   ganz normal als Plugin über einen Store kommen), und
2. in data/addons/<typ>/ dieses Plugins (dahin installiert die Plugin-Seite
   ein Modul aus einem ZIP-Link).

Die Beschreibung des Formats steht in MODULES.md im Paket.
"""

import importlib.util
import io
import json
import re
import shutil
import sys
import threading
import time
import zipfile
from pathlib import Path

import modules
import sources

TYPE = re.compile(r"^[a-z0-9][a-z0-9_.-]{1,47}$")
FILE = re.compile(r"^[A-Za-z0-9_.-]{1,64}\.(js|css|py)$")
KINDS = {"text", "textarea", "number", "bool", "select", "secret", "stop"}
SCAN_SECONDS = 60
MAX_ZIP = 2 * 1024 * 1024

_lock = threading.Lock()
_found = {"at": 0.0, "modules": {}, "problems": []}


def _label(value, fallback=""):
    """"Text" oder {"de": ..., "en": ..., "es": ...} -> [de, en, es]."""
    if isinstance(value, dict):
        first = next((str(v) for v in value.values() if v), fallback)
        return [str(value.get(code) or value.get("en") or first)[:300] for code in modules.LANGS]
    text = str(value or fallback)[:300]
    return [text, text, text]


def _field(raw):
    if not isinstance(raw, dict):
        return None
    key, kind = str(raw.get("key") or ""), str(raw.get("kind") or "text")
    if not re.match(r"^[A-Za-z][A-Za-z0-9_]{0,31}$", key) or kind not in KINDS or key == "header":
        return None
    field = {"key": key, "kind": kind, "label": _label(raw.get("label"), key), "default": raw.get("default")}
    if raw.get("hint"):
        field["hint"] = _label(raw["hint"])
    for name in ("min", "max"):
        if isinstance(raw.get(name), (int, float)):
            field[name] = raw[name]
    if kind == "select":
        options = []
        for option in raw.get("options") or []:
            if isinstance(option, dict) and "value" in option:
                options.append({"value": str(option["value"]), "label": _label(option.get("label"), str(option["value"]))})
            elif isinstance(option, (str, int)):
                options.append({"value": str(option), "label": _label(str(option))})
        if not options:
            return None
        field["options"] = options
        if str(field["default"]) not in [o["value"] for o in options]:
            field["default"] = options[0]["value"]
    if isinstance(raw.get("showIf"), dict):
        field["showIf"] = {str(k): v for k, v in raw["showIf"].items()}
    return field


_fetch_cache = {}


def _load_fetch(path, module_type):
    """fetch.py laden; beim nächsten Suchlauf nur neu, wenn sich die Datei geändert hat."""
    key = (str(path), path.stat().st_mtime)
    if key in _fetch_cache:
        return _fetch_cache[key]
    name = "mf_addon_" + re.sub(r"\W", "_", module_type)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    if not callable(getattr(module, "fetch", None)):
        raise ValueError("fetch.py hat keine Funktion fetch(config, ctx)")
    _fetch_cache[key] = module.fetch
    return module.fetch


def read_folder(folder, origin):
    """Ein magicframe-Ordner -> Modul-Spezifikation wie in modules.MODULES."""
    manifest = json.loads((folder / "module.json").read_text(encoding="utf-8"))
    module_type = str(manifest.get("type") or "").lower()
    if not TYPE.match(module_type):
        raise ValueError(f"ungültiger type {module_type!r}")
    if module_type in modules.MODULES:
        raise ValueError(f"type {module_type!r} gibt es schon als eingebautes Modul")
    script = str(manifest.get("script") or "module.js")
    if not FILE.match(script) or not (folder / script).is_file():
        raise ValueError(f"{script} fehlt")
    style = str(manifest.get("style") or "")
    if style and (not FILE.match(style) or not (folder / style).is_file()):
        style = ""
    fields = [f for f in (_field(raw) for raw in manifest.get("fields") or []) if f][:30]
    region = manifest.get("region") if manifest.get("region") in modules.REGION_IDS else "middle_center"
    spec = {
        "name": _label(manifest.get("name"), module_type),
        "description": _label(manifest.get("description")),
        "region": region,
        "fields": [modules.HEADER] + fields,
        "addon": {
            "origin": origin, "folder": str(folder), "script": script, "style": style,
            "version": str(manifest.get("version") or "")[:20], "author": str(manifest.get("author") or "")[:60],
            "url": str(manifest.get("url") or "")[:300],
        },
    }
    fetch_file = str(manifest.get("fetch") or ("fetch.py" if (folder / "fetch.py").is_file() else ""))
    if fetch_file:
        if not FILE.match(fetch_file) or not (folder / fetch_file).is_file():
            raise ValueError(f"{fetch_file} fehlt")
        spec["fetch"] = _load_fetch(folder / fetch_file, module_type)
        spec["every"] = max(30, min(86400, int(manifest.get("every") or 600)))
        spec["visibleOnly"] = bool(manifest.get("visibleOnly"))
        spec["place"] = bool(manifest.get("place"))
    return module_type, spec


def candidates(plugin_dir):
    """Andere Plugins neben diesem und data/addons/*."""
    own = plugin_dir.resolve()
    roots = {plugin_dir.parent}
    for root in roots:
        try:
            children = sorted(root.iterdir())
        except OSError:
            continue
        for child in children:
            try:
                if child.resolve() != own and (child / "magicframe" / "module.json").is_file():
                    yield child / "magicframe", child.name
            except OSError:
                continue
    store = plugin_dir / "data" / "addons"
    if store.is_dir():
        for child in sorted(store.iterdir()):
            if (child / "module.json").is_file():
                yield child, "link"


def scan(plugin_dir, log, force=False):
    with _lock:
        if not force and time.time() - _found["at"] < SCAN_SECONDS:
            return _found["modules"]
        found, problems = {}, []
        for folder, origin in candidates(plugin_dir):
            try:
                module_type, spec = read_folder(folder, origin)
            except Exception as exc:
                problems.append({"origin": origin, "error": str(exc)[:200]})
                continue
            if module_type in found:
                problems.append({"origin": origin, "error": f"type {module_type!r} gibt es doppelt"})
                continue
            found[module_type] = spec
        if set(found) != set(_found["modules"]):
            log(f"Zusatzmodule: {', '.join(sorted(found)) or 'keine'}")
        for problem in problems:
            if problem not in _found["problems"]:
                log(f"Zusatzmodul in {problem['origin']}: {problem['error']}", "warning")
        _found.update(at=time.time(), modules=found, problems=problems)
        return found


def problems():
    return list(_found["problems"])


def file_of(spec, name):
    """Die Datei, die die Szene laden darf (nur script und style)."""
    addon = spec.get("addon") or {}
    if name not in (addon.get("script"), addon.get("style")) or not name:
        return None
    return Path(addon["folder"]) / name


def install_from_url(url, plugin_dir):
    """Ein ZIP mit module.json (oben oder in einem Ordner) nach data/addons/<type>/."""
    if not re.match(r"^https?://", url or ""):
        raise sources.SourceError("no-url")
    body = sources._get(url, expect="text")
    if len(body) > MAX_ZIP:
        raise ValueError("ZIP größer als 2 MB")
    try:
        archive = zipfile.ZipFile(io.BytesIO(body))
    except zipfile.BadZipFile as exc:
        raise ValueError("kein ZIP") from exc
    names = [n for n in archive.namelist() if n.endswith("module.json")]
    if not names:
        raise ValueError("im ZIP fehlt module.json")
    prefix = min(names, key=len)[: -len("module.json")]
    temp = plugin_dir / "data" / "addons" / ".incoming"
    shutil.rmtree(temp, ignore_errors=True)
    temp.mkdir(parents=True)
    for name in archive.namelist():
        if not name.startswith(prefix) or name.endswith("/"):
            continue
        relative = name[len(prefix):]
        if "/" in relative or not (relative == "module.json" or FILE.match(relative)):
            continue  # nur flache, bekannte Dateien
        (temp / relative).write_bytes(archive.read(name))
    try:
        module_type, spec = read_folder(temp, "link")
    except Exception:
        shutil.rmtree(temp, ignore_errors=True)
        raise
    target = plugin_dir / "data" / "addons" / module_type
    shutil.rmtree(target, ignore_errors=True)
    temp.rename(target)
    (target / ".source").write_text(url, encoding="utf-8")
    return module_type, spec


def remove(module_type, plugin_dir):
    target = plugin_dir / "data" / "addons" / module_type
    if TYPE.match(module_type) and target.is_dir():
        shutil.rmtree(target)
        return True
    return False
