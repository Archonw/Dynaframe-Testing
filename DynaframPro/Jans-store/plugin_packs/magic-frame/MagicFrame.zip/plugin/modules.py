"""Die Module von Dynaframe's Magic Mirror.

Ein Modul ist ein Eintrag in MODULES: Name und Beschreibung in drei Sprachen,
die Felder für die Plugin-Seite, die Region, in der es neu landet, und wenn es
Daten aus dem Netz braucht eine fetch-Funktion samt Abfrageabstand. Die Seite
baut ihre Formulare aus FIELDS, die Szene zeichnet jedes Modul mit dem
Renderer gleichen Namens in modules.js.

Ein neues Modul braucht also: einen Eintrag hier, einen Renderer in der Szene
und, falls es Daten holt, eine Funktion in sources.py. Jedes Modul kann
mehrmals auf dem Bildschirm stehen (z. B. zwei Kalender oder zwei Uhren).
"""

import re
import threading
import time
from urllib.parse import urlparse

import sources

LANGS = ("de", "en", "es")

# Wie bei MagicMirror: Leisten über die ganze Breite oben und unten, dazwischen
# drei Spalten in drei Höhen.
REGIONS = [
    ("top_bar", "Oben, ganze Breite", "Top, full width", "Arriba, todo el ancho"),
    ("top_left", "Oben links", "Top left", "Arriba a la izquierda"),
    ("top_center", "Oben Mitte", "Top centre", "Arriba en el centro"),
    ("top_right", "Oben rechts", "Top right", "Arriba a la derecha"),
    ("middle_left", "Links", "Left", "Izquierda"),
    ("middle_center", "Mitte", "Centre", "Centro"),
    ("middle_right", "Rechts", "Right", "Derecha"),
    ("bottom_left", "Unten links", "Bottom left", "Abajo a la izquierda"),
    ("bottom_center", "Unten Mitte", "Bottom centre", "Abajo en el centro"),
    ("bottom_right", "Unten rechts", "Bottom right", "Abajo a la derecha"),
    ("bottom_bar", "Unten, ganze Breite", "Bottom, full width", "Abajo, todo el ancho"),
]
REGION_IDS = [r[0] for r in REGIONS]


def L(de, en, es):
    return [de, en, es]


def F(key, kind, label, default=None, **extra):
    """kind: text, textarea, number, bool, select, secret, stop."""
    field = {"key": key, "kind": kind, "label": label, "default": default}
    field.update(extra)
    return field


def opt(value, de, en, es):
    return {"value": value, "label": [de, en, es]}


HEADER = F("header", "text", L("Überschrift (leer = keine)", "Heading (empty = none)", "Título (vacío = ninguno)"), "")


# --------------------------------------------------------------------------
# Wetter: eine Abfrage für Wetter, Vorhersage und Regen, 10 Minuten geteilt
# --------------------------------------------------------------------------

_weather = {"key": None, "at": 0.0, "value": None}
_weather_lock = threading.Lock()


def shared_weather(ctx):
    key = (round(ctx["lat"], 3), round(ctx["lon"], 3), ctx["imperial"])
    with _weather_lock:
        if _weather["key"] == key and time.time() - _weather["at"] < 540:
            return _weather["value"]
        value = sources.weather(ctx["lat"], ctx["lon"], ctx["imperial"])
        _weather.update(key=key, at=time.time(), value=value)
        return value


def need_place(ctx):
    if ctx.get("lat") is None:
        raise sources.SourceError("no-place")


def fetch_weather(cfg, ctx):
    need_place(ctx)
    value = shared_weather(ctx)
    today = value["daily"][0] if value["daily"] else {}
    return {"current": value["current"], "sunrise": today.get("sunrise"), "sunset": today.get("sunset"),
            "max": today.get("max"), "min": today.get("min"), "imperial": value["imperial"]}


def fetch_forecast(cfg, ctx):
    need_place(ctx)
    value = shared_weather(ctx)
    return {"daily": value["daily"], "imperial": value["imperial"]}


def fetch_rain(cfg, ctx):
    need_place(ctx)
    value = shared_weather(ctx)
    return {"rain": value["rain"], "imperial": value["imperial"]}


def fetch_warnings(cfg, ctx):
    need_place(ctx)
    return sources.dwd_alerts(ctx["lat"], ctx["lon"], ctx["lang"])


def lines_of(text, limit=20):
    return [line.strip() for line in str(text or "").splitlines() if line.strip()][:limit]


def fetch_calendar(cfg, ctx):
    urls = lines_of(cfg.get("urls"), 5)
    if not urls:
        raise sources.SourceError("no-url")
    events = sources.calendar_events(urls, cfg.get("user") or "", cfg.get("password") or "",
                                     days=int(cfg.get("days") or 14))
    return {"events": events[:int(cfg.get("count") or 8) * 3]}


def news_url(cfg):
    feed = cfg.get("feed") or "tagesschau"
    if feed == "custom":
        return str(cfg.get("url") or "").strip()
    return sources.NEWS_FEEDS.get(feed, sources.NEWS_FEEDS["tagesschau"])


NEWS_NAMES = {"tagesschau": "tagesschau.de", "bbc": "BBC News", "elpais": "El País"}


def news_name(url):
    host = urlparse(url).hostname or url
    return host[4:] if host.startswith("www.") else host


def news_sources(cfg):
    """Die erste Quelle aus der Auswahl, weitere aus der Liste: je Zeile ein
    Kürzel (tagesschau, bbc, elpais), ein RSS-Link oder "Name = Link"."""
    out = []
    first = news_url(cfg)
    if first:
        feed = cfg.get("feed") or "tagesschau"
        out.append((NEWS_NAMES.get(feed) or news_name(first), first))
    for line in lines_of(cfg.get("more"), 8):
        named = re.match(r"^(.*?)\s*=\s*(https?://\S+)$", line)
        name, target = (named.group(1), named.group(2)) if named else ("", line.strip())
        if target.lower() in sources.NEWS_FEEDS:
            name, target = name or NEWS_NAMES[target.lower()], sources.NEWS_FEEDS[target.lower()]
        if re.match(r"^https?://\S+$", target) and target not in [u for _, u in out]:
            out.append((name or news_name(target), target))
    return out


def fetch_news(cfg, ctx):
    feeds = news_sources(cfg)
    if not feeds:
        raise sources.SourceError("no-url")
    count = int(cfg.get("count") or 8)
    groups, first_error = [], None
    for name, url in feeds:
        try:
            items = sources.news(url)["items"][:count]
        except sources.SourceError as exc:
            # eine kaputte Quelle soll die anderen nicht mitreißen
            first_error = first_error or exc
            ctx["log"](f"Nachrichten {url}: {exc}")
            continue
        groups.append({"name": name, "items": items})
    if not groups:
        raise first_error
    return {"sources": groups, "items": [dict(i, source=g["name"]) for g in groups for i in g["items"]]}


def fetch_departures(cfg, ctx):
    stop = cfg.get("stop") or {}
    if not stop.get("id"):
        raise sources.SourceError("no-stop")
    rows = sources.transitous_departures(stop["id"], ctx["lang"])
    wanted = {part.strip().lower() for part in str(cfg.get("lines") or "").split(",") if part.strip()}
    if wanted:
        rows = [row for row in rows if row["line"].lower() in wanted]
    cutoff = time.time() - 60
    rows = [row for row in rows if row["when"] >= cutoff]
    return {"stop": stop.get("name") or "", "rows": rows[:max(int(cfg.get("count") or 6) * 2, 10)]}


def ha_entities(text):
    """Eine Zeile je Entität: "sensor.x" oder "Name = sensor.x"."""
    out = []
    for line in lines_of(text, 20):
        name, _, entity = line.rpartition("=")
        out.append({"id": entity.strip(), "label": name.strip()})
    return [row for row in out if "." in row["id"]]


def fetch_homeassistant(cfg, ctx):
    rows = ha_entities(cfg.get("entities"))
    if not rows:
        raise sources.SourceError("no-entities")
    value = sources.ha_states(cfg.get("url"), cfg.get("token") or "", [r["id"] for r in rows])
    labels = {r["id"]: r["label"] for r in rows}
    for entity in value["entities"]:
        if labels.get(entity["id"]):
            entity["name"] = labels[entity["id"]]
    return value


# --------------------------------------------------------------------------
# Der Katalog
# --------------------------------------------------------------------------

MODULES = {
    "clock": {
        "name": L("Uhr", "Clock", "Reloj"),
        "description": L("Uhrzeit und Datum.", "Time and date.", "Hora y fecha."),
        "region": "top_left", "widgets": ["time", "analog", "date", "year", "weekdays"],
        "fields": [
            F("seconds", "bool", L("Sekunden zeigen", "Show seconds", "Mostrar segundos"), False),
            F("date", "bool", L("Datum zeigen", "Show date", "Mostrar fecha"), True),
            F("week", "bool", L("Kalenderwoche zeigen", "Show week number", "Mostrar número de semana"), False),
            F("size", "select", L("Größe", "Size", "Tamaño"), "large", options=[
                opt("small", "klein", "small", "pequeño"), opt("medium", "mittel", "medium", "mediano"),
                opt("large", "groß", "large", "grande"), opt("xlarge", "riesig", "huge", "enorme")]),
        ],
    },
    "weather": {
        "name": L("Wetter jetzt", "Current weather", "Tiempo actual"),
        "description": L("Temperatur, Himmel, Wind und Sonnenauf- und -untergang am eingestellten Ort.",
                         "Temperature, sky, wind and sunrise/sunset at your location.",
                         "Temperatura, cielo, viento y salida/puesta del sol en tu ubicación."),
        "region": "top_right", "widgets": ["weather", "sunrise", "sunset", "weatherpicture"],
        "fetch": fetch_weather, "every": 600, "place": True,
        "fields": [
            F("feels", "bool", L("Gefühlte Temperatur", "Feels like", "Sensación térmica"), True),
            F("wind", "bool", L("Wind", "Wind", "Viento"), True),
            F("sun", "bool", L("Sonnenauf- und -untergang", "Sunrise and sunset", "Salida y puesta del sol"), True),
            F("today", "bool", L("Höchst- und Tiefstwert heute", "Today's high and low", "Máxima y mínima de hoy"), False),
        ],
    },
    "forecast": {
        "name": L("Wettervorhersage", "Weather forecast", "Previsión del tiempo"),
        "description": L("Die nächsten Tage mit Höchst- und Tiefstwerten.", "The next days with highs and lows.",
                         "Los próximos días con máximas y mínimas."),
        "region": "top_right", "widgets": ["forecast"],
        "fetch": fetch_forecast, "every": 1800, "place": True,
        "fields": [
            F("days", "number", L("Tage", "Days", "Días"), 5, min=2, max=7),
            F("pop", "bool", L("Regenwahrscheinlichkeit", "Chance of rain", "Probabilidad de lluvia"), True),
            F("fade", "bool", L("Nach unten ausblenden", "Fade out towards the bottom", "Desvanecer hacia abajo"), True),
        ],
    },
    "rain": {
        "name": L("Regen in den nächsten 3 Stunden", "Rain in the next 3 hours", "Lluvia en las próximas 3 horas"),
        "description": L("Wann es anfängt oder aufhört zu regnen, mit kleinem Balkendiagramm.",
                         "When rain starts or stops, with a small bar chart.",
                         "Cuándo empieza o para de llover, con un pequeño gráfico de barras."),
        "region": "top_right", "widgets": ["text"],
        "fetch": fetch_rain, "every": 600, "place": True,
        "fields": [
            F("hideDry", "bool", L("Ausblenden, wenn es trocken bleibt", "Hide while it stays dry",
                                   "Ocultar mientras no llueva"), False),
        ],
    },
    "calendar": {
        "name": L("Termine", "Calendar", "Calendario"),
        "description": L("Die nächsten Termine aus Nextcloud, Google oder jedem ICS-Link.",
                         "Upcoming events from Nextcloud, Google or any ICS link.",
                         "Próximas citas de Nextcloud, Google o cualquier enlace ICS."),
        "region": "top_left", "widgets": ["list"],
        "fetch": fetch_calendar, "every": 900,
        "fields": [
            F("urls", "textarea", L("Kalender-Links (einer pro Zeile, bis zu 5)", "Calendar links (one per line, up to 5)",
                                    "Enlaces de calendario (uno por línea, hasta 5)"), "",
              hint=L("Nextcloud: „Link teilen“ und den öffentlichen Link kopieren. Google: „Privatadresse im iCal-Format“.",
                     "Nextcloud: switch on “Share link” and copy the public link. Google: “Secret address in iCal format”.",
                     "Nextcloud: activa «Compartir enlace» y copia el enlace público. Google: «Dirección secreta en formato iCal».")),
            F("user", "text", L("Benutzername (nur für private Links)", "User name (private links only)",
                                "Usuario (solo enlaces privados)"), ""),
            F("password", "secret", L("App-Passwort", "App password", "Contraseña de aplicación"), ""),
            F("days", "number", L("Zeitraum (Tage)", "Period (days)", "Periodo (días)"), 14, min=1, max=90),
            F("count", "number", L("Höchstens … Termine", "At most … events", "Como máximo … citas"), 8, min=1, max=25),
            F("location", "bool", L("Ort zeigen", "Show location", "Mostrar lugar"), False),
            F("fade", "bool", L("Nach unten ausblenden", "Fade out towards the bottom", "Desvanecer hacia abajo"), True),
        ],
    },
    "news": {
        "name": L("Nachrichten", "News", "Noticias"),
        "description": L("Schlagzeilen aus einem oder mehreren RSS-Feeds, als Laufband, einzeln nacheinander oder als Liste.",
                         "Headlines from one or more RSS feeds as a ticker, one after another, or as a list.",
                         "Titulares de uno o varios feeds RSS como cinta, uno tras otro o en lista."),
        "region": "bottom_bar", "widgets": ["headlines"],
        "fetch": fetch_news, "every": 900,
        "fields": [
            F("feed", "select", L("Quelle", "Source", "Fuente"), "tagesschau", options=[
                opt("tagesschau", "tagesschau.de", "tagesschau.de", "tagesschau.de"),
                opt("bbc", "BBC News", "BBC News", "BBC News"),
                opt("elpais", "El País", "El País", "El País"),
                opt("custom", "Eigener RSS-Link", "Own RSS link", "Enlace RSS propio")]),
            F("url", "text", L("RSS-Link", "RSS link", "Enlace RSS"), "", showIf={"feed": "custom"}),
            F("more", "textarea", L("Weitere Quellen (eine pro Zeile)", "More sources (one per line)", "Más fuentes (una por línea)"), "",
              hint=L("Ein RSS-Link oder tagesschau, bbc, elpais. Mit eigenem Namen: Spiegel = https://www.spiegel.de/schlagzeilen/index.rss. Die Quellen kommen nacheinander.",
                     "An RSS link or tagesschau, bbc, elpais. With your own name: Guardian = https://www.theguardian.com/world/rss. The sources take turns.",
                     "Un enlace RSS o tagesschau, bbc, elpais. Con nombre propio: El Mundo = https://e00-elmundo.uecdn.es/elmundo/rss/portada.xml. Las fuentes se turnan.")),
            F("showSource", "bool", L("Quelle vor den Meldungen zeigen", "Show the source before its headlines",
                                      "Mostrar la fuente antes de sus titulares"), True),
            F("style", "select", L("Darstellung", "Style", "Estilo"), "rotate", options=[
                opt("rotate", "eine Schlagzeile nach der anderen", "one headline at a time", "un titular tras otro"),
                opt("ticker", "Laufband", "ticker", "cinta"),
                opt("list", "Liste", "list", "lista")]),
            F("count", "number", L("Schlagzeilen (je Quelle)", "Headlines (per source)", "Titulares (por fuente)"), 8, min=1, max=15),
            F("seconds", "number", L("Sekunden je Schlagzeile", "Seconds per headline", "Segundos por titular"), 15,
              min=5, max=120, showIf={"style": "rotate"}),
        ],
    },
    "departures": {
        "name": L("Abfahrten", "Departures", "Salidas"),
        "description": L("Die nächsten Busse und Bahnen an einer Haltestelle, mit Echtzeit (Transitous).",
                         "The next buses and trains at a stop, with real-time data (Transitous).",
                         "Los próximos autobuses y trenes en una parada, en tiempo real (Transitous)."),
        "region": "middle_right", "widgets": ["list"],
        "fetch": fetch_departures, "every": 60, "visibleOnly": True,
        "fields": [
            F("stop", "stop", L("Haltestelle", "Stop", "Parada"), None),
            F("count", "number", L("Abfahrten", "Departures", "Salidas"), 6, min=1, max=15),
            F("lines", "text", L("Nur diese Linien (mit Komma, leer = alle)", "Only these lines (comma separated, empty = all)",
                                 "Solo estas líneas (separadas por comas, vacío = todas)"), ""),
            F("walk", "number", L("Fußweg zur Haltestelle (Minuten)", "Walk to the stop (minutes)",
                                  "Camino a la parada (minutos)"), 0, min=0, max=30,
              hint=L("Abfahrten, die du nicht mehr schaffst, werden blass.", "Departures you can no longer make are dimmed.",
                     "Las salidas que ya no alcanzas aparecen atenuadas.")),
        ],
    },
    "compliments": {
        "name": L("Sprüche", "Compliments", "Frases"),
        "description": L("Ein freundlicher Satz je nach Tageszeit, wie die Komplimente bei MagicMirror. Eigene Sätze gehen auch.",
                         "A friendly line depending on the time of day, like MagicMirror's compliments. Add your own too.",
                         "Una frase amable según la hora del día, como los cumplidos de MagicMirror. También las tuyas."),
        "region": "middle_center", "widgets": ["text"],
        "fields": [
            F("own", "textarea", L("Eigene Sätze (einer pro Zeile)", "Your own lines (one per line)",
                                   "Tus frases (una por línea)"), "",
              hint=L("Mit „morgens:“, „mittags:“, „abends:“ oder „nachts:“ davor nur zu dieser Tageszeit.",
                     "Start a line with “morning:”, “afternoon:”, “evening:” or “night:” to show it only then.",
                     "Empieza con «mañana:», «tarde:», «noche:» o «madrugada:» para mostrarla solo entonces.")),
            F("builtin", "bool", L("Mitgelieferte Sätze dazunehmen", "Include the built-in lines",
                                   "Incluir las frases incluidas"), True),
            F("seconds", "number", L("Wechsel alle … Sekunden", "Change every … seconds", "Cambiar cada … segundos"), 30,
              min=5, max=3600),
            F("size", "select", L("Größe", "Size", "Tamaño"), "large", options=[
                opt("medium", "mittel", "medium", "mediano"), opt("large", "groß", "large", "grande"),
                opt("xlarge", "riesig", "huge", "enorme")]),
        ],
    },
    "warnings": {
        "name": L("Unwetterwarnungen (DWD)", "Weather warnings (DWD)", "Avisos meteorológicos (DWD)"),
        "description": L("Warnungen des Deutschen Wetterdienstes für den Ort. Nur in Deutschland; ohne Warnung unsichtbar.",
                         "Warnings from the German Weather Service for your location. Germany only; invisible without a warning.",
                         "Avisos del servicio meteorológico alemán para tu ubicación. Solo Alemania; invisible sin aviso."),
        "region": "top_bar", "widgets": ["list", "text"],
        "fetch": fetch_warnings, "every": 600, "place": True,
        "fields": [
            F("level", "select", L("Ab Stufe", "From level", "A partir del nivel"), "2", options=[
                opt("1", "Wetterwarnung", "minor", "leve"), opt("2", "markantes Wetter", "moderate", "moderado"),
                opt("3", "Unwetter", "severe", "severo"), opt("4", "extremes Unwetter", "extreme", "extremo")]),
        ],
    },
    "homeassistant": {
        "name": L("Home Assistant", "Home Assistant", "Home Assistant"),
        "description": L("Werte aus Home Assistant: Temperaturen, Fenster, Strom, alles mit einer Entität.",
                         "Values from Home Assistant: temperatures, windows, power, anything with an entity.",
                         "Valores de Home Assistant: temperaturas, ventanas, energía, cualquier entidad."),
        "region": "middle_left", "widgets": ["values"],
        "fetch": fetch_homeassistant, "every": 30, "visibleOnly": True,
        "fields": [
            F("url", "text", L("Adresse von Home Assistant", "Home Assistant address", "Dirección de Home Assistant"),
              "http://homeassistant.local:8123"),
            F("token", "secret", L("Langzeit-Zugangstoken", "Long-lived access token", "Token de acceso de larga duración"), "",
              hint=L("In Home Assistant: Profil → Sicherheit → „Token erstellen“.",
                     "In Home Assistant: Profile → Security → “Create token”.",
                     "En Home Assistant: Perfil → Seguridad → «Crear token».")),
            F("entities", "textarea", L("Entitäten (eine pro Zeile)", "Entities (one per line)", "Entidades (una por línea)"),
              "", picker="homeassistant", hint=L("z. B. sensor.wohnzimmer_temperatur oder mit eigenem Namen: Wohnzimmer = sensor.wohnzimmer_temperatur",
                         "e.g. sensor.living_room_temperature or with your own name: Living room = sensor.living_room_temperature",
                         "p. ej. sensor.salon_temperatura o con nombre propio: Salón = sensor.salon_temperatura")),
            F("icons", "bool", L("Symbole zeigen", "Show icons", "Mostrar iconos"), True),
        ],
    },
    "webpage": {
        "name": L("Webseite", "Web page", "Página web"),
        "description": L("Eine Webseite in einem Rahmen, z. B. ein Dashboard oder eine Kamera. Manche Seiten verbieten das Einbetten.",
                         "A web page in a box, e.g. a dashboard or a camera. Some sites refuse to be embedded.",
                         "Una página web en un recuadro, p. ej. un panel o una cámara. Algunos sitios no permiten incrustarse."),
        "region": "middle_center", "widgets": [],
        "fields": [
            F("url", "text", L("Adresse", "Address", "Dirección"), "https://"),
            F("height", "number", L("Höhe (% des Bildschirms)", "Height (% of the screen)", "Altura (% de la pantalla)"), 30,
              min=5, max=100),
            F("zoom", "number", L("Zoom (%)", "Zoom (%)", "Zoom (%)"), 100, min=25, max=200),
            F("reload", "number", L("Neu laden alle … Minuten (0 = nie)", "Reload every … minutes (0 = never)",
                                    "Recargar cada … minutos (0 = nunca)"), 0, min=0, max=1440),
        ],
    },
}

for _spec in MODULES.values():
    _spec["fields"] = [HEADER] + _spec["fields"]


# --------------------------------------------------------------------------
# Skins: ein ganz anderes Aussehen für die ganze Szene. Statt der Module in
# Regionen zeichnet der Skin ein festes Bild (Renderer in skins.js, Zusatz-
# Skins wie Zusatzmodule mit "kind": "skin"). Die Module bleiben gespeichert.
# --------------------------------------------------------------------------

def fetch_skin(cfg, ctx):
    """Was die eingebauten Skins zeigen: Wetter jetzt, Sonne, die nächsten Tage."""
    need_place(ctx)
    value = shared_weather(ctx)
    today = value["daily"][0] if value["daily"] else {}
    return {"current": value["current"], "sunrise": today.get("sunrise"), "sunset": today.get("sunset"),
            "max": today.get("max"), "min": today.get("min"), "daily": value["daily"][:5],
            "imperial": value["imperial"]}


# Widget-Typen: was in einem Feld eines Skins stehen kann. Ein Modul nennt in
# "widgets", welche Typen es liefern kann (und liefert die Daten dazu in
# seinem Renderer mit widget(typ, ctx)); jedes Modul kann außerdem "module",
# also so aussehen wie im Standard-Skin. Ein Skin nennt seine Felder ("slots")
# mit den Typen, die hineinpassen, und was er selbst ohne Modul liefert ("own").
# Neue Typen sind einfach neue Namen: Zusatzmodule und Zusatz-Skins dürfen
# eigene mitbringen ("widgetNames" in der module.json).
WIDGET_NAMES = {
    "time": L("Uhrzeit (digital)", "Time (digital)", "Hora (digital)"),
    "analog": L("Zeigeruhr", "Analogue clock", "Reloj de agujas"),
    "date": L("Datum", "Date", "Fecha"),
    "year": L("Jahr und Wochentag", "Year and weekday", "Año y día"),
    "weekdays": L("Wochentage", "Weekdays", "Días de la semana"),
    "countdown": L("Countdown", "Countdown", "Cuenta atrás"),
    "weather": L("Wetter jetzt", "Current weather", "Tiempo actual"),
    "sunrise": L("Sonnenaufgang", "Sunrise", "Salida del sol"),
    "sunset": L("Sonnenuntergang", "Sunset", "Puesta del sol"),
    "weatherpicture": L("Wetter als Bild", "Weather as a picture", "El tiempo como imagen"),
    "picture": L("Bild unter „Hintergrund“", "Image under “Background”", "Imagen de «Fondo»"),
    "wifi": L("WLAN-Symbol", "Wi-Fi symbol", "Símbolo Wi-Fi"),
    "forecast": L("Vorhersage", "Forecast", "Previsión"),
    "headlines": L("Schlagzeilen", "Headlines", "Titulares"),
    "list": L("Liste", "List", "Lista"),
    "values": L("Werte", "Values", "Valores"),
    "text": L("Text", "Text", "Texto"),
    "nowplaying": L("Läuft gerade", "Now playing", "Reproduciendo"),
    "module": L("normale Ansicht", "normal view", "vista normal"),
}
WIDGET_TYPE = re.compile(r"^[a-z][a-z0-9_.-]{1,31}$")

# Was die eingebauten Skins selbst liefern (Wetter vom Ort oben auf der Seite)
OWN_WIDGETS = ["time", "analog", "date", "year", "weekdays", "countdown", "weather", "sunrise", "sunset",
               "weatherpicture", "picture", "wifi"]
# Was in welche Feldgröße passt
STRIP = ["weekdays", "headlines", "text", "date"]
SMALL_PANEL = ["year", "date", "time", "countdown", "weather", "sunrise", "sunset", "text", "values"]
TILE = ["sunrise", "sunset", "weather", "wifi", "time", "date", "countdown", "values", "text", "analog"]
WIDE = ["time", "date", "year", "countdown", "weather", "headlines", "text", "values", "nowplaying", "sunrise", "sunset"]
BIG = ["analog", "time", "date", "weather", "weatherpicture", "picture", "forecast", "list", "values", "headlines",
       "text", "nowplaying", "countdown", "module"]


def slot(slot_id, name, default, accepts, most=1, size=True):
    return {"id": slot_id, "name": name, "default": default, "accepts": list(dict.fromkeys(accepts)), "max": most,
            "size": size}


SKINS = {
    "standard": {
        "name": L("Standard (Module in Regionen)", "Standard (modules in regions)", "Estándar (módulos en regiones)"),
        "description": L("Wie MagicMirror: die Module unten auf dieser Seite, dort, wo du sie hingezogen hast.",
                         "Like MagicMirror: the modules below, where you placed them.",
                         "Como MagicMirror: los módulos de abajo, donde los colocaste."),
        "fields": [],
    },
    "lcd": {
        "name": L("Retro-LCD", "Retro LCD", "LCD retro"),
        "description": L("Hell leuchtendes Display mit dunklen LCD-Feldern: Wochentage, große Uhr mit Sekunden, Jahr, "
                         "Datum, Zeigeruhr, Sonnenauf- und -untergang, ein Countdown und das Wetter. Jedes Feld lässt sich anders belegen.",
                         "Backlit display with dark LCD panels: weekdays, big clock with seconds, year, date, "
                         "analogue clock, sunrise and sunset, a countdown and the weather. Each field can show something else.",
                         "Pantalla iluminada con paneles LCD oscuros: días, reloj grande con segundos, año, fecha, "
                         "reloj de agujas, salida y puesta del sol, una cuenta atrás y el tiempo. Cada campo se puede cambiar."),
        "fetch": fetch_skin, "every": 600, "place": True,
        "own": OWN_WIDGETS,
        "slots": [
            slot("days", L("Leiste oben", "Top strip", "Barra superior"), "skin:weekdays", STRIP),
            slot("time", L("Großes Feld", "Big panel", "Panel grande"), "skin:time", WIDE),
            slot("year", L("Feld links oben", "Upper left panel", "Panel superior izquierdo"), "skin:year", SMALL_PANEL),
            slot("date", L("Feld links unten", "Lower left panel", "Panel inferior izquierdo"), "skin:date", SMALL_PANEL),
            slot("clock", L("Großes Quadrat", "Big square", "Cuadrado grande"), "skin:analog", BIG),
            slot("rise", L("Hohes Feld links", "Tall tile left", "Pieza alta izquierda"), "skin:sunrise", TILE),
            slot("set", L("Hohes Feld Mitte", "Tall tile middle", "Pieza alta centro"), "skin:sunset", TILE),
            slot("cd", L("Breites Feld", "Wide tile", "Pieza ancha"), "skin:countdown", WIDE),
            slot("wx", L("Kleines Feld 1", "Small tile 1", "Pieza pequeña 1"), "skin:weather", TILE),
            slot("net", L("Kleines Feld 2", "Small tile 2", "Pieza pequeña 2"), "skin:wifi", TILE),
        ],
        "fields": [
            F("tint", "select", L("Farbe des Displays", "Display colour", "Color de la pantalla"), "mint", options=[
                opt("mint", "Mintgrün", "Mint green", "Verde menta"), opt("ice", "Eisblau", "Ice blue", "Azul hielo"),
                opt("amber", "Bernstein", "Amber", "Ámbar"), opt("paper", "Weiß", "White", "Blanco")]),
            F("seconds", "bool", L("Sekunden zeigen", "Show seconds", "Mostrar segundos"), True),
            F("countdown", "text", L("Countdown bis (Uhrzeit)", "Countdown to (time)", "Cuenta atrás hasta (hora)"),
              "17:00", hint=L("Zum Beispiel 17:00 für den Feierabend, für das Feld „Countdown“.",
                              "For example 17:00 for the end of work, for the “Countdown” widget.",
                              "Por ejemplo 17:00 para el fin de la jornada, para el widget «Cuenta atrás».")),
            F("countdownLabel", "text", L("Name des Countdowns", "Countdown name", "Nombre de la cuenta atrás"),
              "", hint=L("Leer = „Noch“.", "Empty = “Left”.", "Vacío = «Faltan».")),
        ],
    },
    "mosaic": {
        "name": L("Farbraster", "Colour grid", "Cuadrícula de colores"),
        "description": L("Bunte Felder mit dicken schwarzen Linien wie ein Mondrian-Bild: Monat und Tag, Zeigeruhr, "
                         "das Wetter, eine große Uhr und ein großes Bild. Jedes Feld lässt sich anders belegen.",
                         "Bright blocks with thick black lines like a Mondrian painting: month and day, analogue "
                         "clock, the weather, a big clock and a big picture. Each field can show something else.",
                         "Bloques de colores con gruesas líneas negras como un cuadro de Mondrian: mes y día, reloj "
                         "de agujas, el tiempo, un reloj grande y una imagen grande. Cada campo se puede cambiar."),
        "fetch": fetch_skin, "every": 600, "place": True,
        "own": OWN_WIDGETS,
        "slots": [
            slot("date", L("Streifen oben", "Top strip", "Franja superior"), "skin:date", STRIP + ["time", "year", "weather"]),
            slot("clock", L("Quadrat links", "Left square", "Cuadrado izquierdo"), "skin:analog", BIG),
            slot("wx", L("Quadrat rechts", "Right square", "Cuadrado derecho"), "skin:weather", BIG),
            slot("time", L("Breites Feld", "Wide panel", "Panel ancho"), "skin:time", WIDE),
            slot("pic", L("Großes Bild", "Big picture", "Imagen grande"), "skin:weatherpicture", BIG),
        ],
        "fields": [
            F("palette", "select", L("Farben", "Colours", "Colores"), "classic", options=[
                opt("classic", "Klassisch (Rot, Blau, Gelb, Türkis)", "Classic (red, blue, yellow, teal)",
                    "Clásico (rojo, azul, amarillo, turquesa)"),
                opt("pastel", "Pastell", "Pastel", "Pastel"), opt("night", "Nacht (dunkel)", "Night (dark)", "Noche (oscuro)")]),
        ],
    },
}


# Zusatzmodule und Zusatz-Skins (addons.py) landen hier, solange sie installiert sind.
EXTRA = {}


def get(module_type):
    spec = MODULES.get(module_type) or EXTRA.get(module_type)
    return None if spec is None or spec.get("skin") else spec


def skin(skin_type):
    if skin_type in SKINS:
        return SKINS[skin_type]
    spec = EXTRA.get(skin_type)
    return spec if spec and spec.get("skin") else None


def spec_of(kind):
    """Modul oder Skin: für Abfragen und Einstellungen."""
    return get(kind) or skin(kind)


def known(module_type):
    return get(module_type) is not None


def catalog():
    """Was die Plugin-Seite braucht, ohne die Funktionen."""
    rows, skins = [], []
    for name, spec in list(MODULES.items()) + list(SKINS.items()) + sorted(EXTRA.items()):
        addon = spec.get("addon")
        row = {"type": name, "name": spec["name"], "description": spec["description"], "region": spec.get("region"),
               "place": bool(spec.get("place")), "fields": spec["fields"], "widgets": spec.get("widgets") or [],
               "slots": spec.get("slots") or [], "own": spec.get("own") or [],
               "addon": {k: addon[k] for k in ("origin", "version", "author", "url")} if addon else None}
        (skins if name in SKINS or spec.get("skin") else rows).append(row)
    names = dict(WIDGET_NAMES)
    for spec in EXTRA.values():
        names.update({k: v for k, v in (spec.get("widgetNames") or {}).items() if k not in WIDGET_NAMES})
    return {"regions": [{"id": r[0], "label": list(r[1:])} for r in REGIONS], "modules": rows, "skins": skins,
            "widgetNames": names}


SLOT_VALUE = re.compile(r"^(skin|[a-z0-9]{2,16}):([a-z][a-z0-9_.-]{1,31})$")


def slot_value(row, value):
    """"quelle:typ", bei Feldern mit "max" > 1 auch mehrere mit Komma; None, wenn etwas nicht passt."""
    parts = [p for p in str(value).split(",") if p]
    if len(parts) > max(1, int(row.get("max") or 1)):
        return None
    for part in parts:
        match = SLOT_VALUE.match(part)
        if not match or match.group(2) not in row["accepts"]:
            return None
    return ",".join(parts)


def clean_slots(skin_type, raw):
    """{Feld: "quelle:typ", mehrere mit Komma, oder ""} - nur Felder, die der Skin hat, und Typen, die hineinpassen."""
    spec = skin(skin_type)
    out = {}
    if not spec or not isinstance(raw, dict):
        return out
    for row in spec.get("slots") or []:
        value = raw.get(row["id"])
        if value is None:
            continue
        value = slot_value(row, value)
        if value is not None:
            out[row["id"]] = value
    return out


SLOT_SIZES = (50, 60, 70, 80, 90, 100, 110, 125, 150, 175, 200)


def clean_sizes(skin_type, raw):
    """{Feld oder "feld#n": Prozent} - Schriftgröße je Feld bzw. Eintrag, nur erlaubte Stufen."""
    spec = skin(skin_type)
    out = {}
    if not spec or not isinstance(raw, dict):
        return out
    for row in spec.get("slots") or []:
        if not row.get("size"):
            continue   # der Skin erlaubt hier keine eigene Schriftgröße
        for part in range(max(1, int(row.get("max") or 1))):
            key = f"{row['id']}#{part}" if part else row["id"]
            try:
                value = int(raw.get(key))
            except (TypeError, ValueError):
                continue
            if value in SLOT_SIZES:
                out[key] = value
    return out


def resolve_slots(skin_type, saved):
    """Gespeicherte Belegung, sonst die Vorgabe des Skins."""
    spec = skin(skin_type) or {}
    saved = saved if isinstance(saved, dict) else {}
    return {row["id"]: saved.get(row["id"], row["default"]) for row in spec.get("slots") or []}


def defaults(module_type):
    return {field["key"]: field["default"] for field in spec_of(module_type)["fields"]}


def secret_keys(module_type):
    spec = spec_of(module_type)
    return [field["key"] for field in spec["fields"] if field["kind"] == "secret"] if spec else []


def coerce(module_type, config):
    """Nur bekannte Felder, mit den richtigen Typen und Grenzen."""
    out = defaults(module_type)
    for field in spec_of(module_type)["fields"]:
        key, kind = field["key"], field["kind"]
        if key not in (config or {}):
            continue
        raw = config[key]
        if kind == "bool":
            out[key] = raw is True or str(raw).lower() in ("1", "true", "on", "yes")
        elif kind == "number":
            try:
                number = int(float(str(raw).replace(",", ".")))
            except (TypeError, ValueError):
                continue
            out[key] = max(field.get("min", number), min(field.get("max", number), number))
        elif kind == "select":
            values = [o["value"] for o in field["options"]]
            out[key] = str(raw) if str(raw) in values else field["default"]

        elif kind == "stop":
            if isinstance(raw, dict) and raw.get("id"):
                out[key] = {"id": str(raw["id"])[:120], "name": str(raw.get("name") or "")[:80]}
            else:
                out[key] = None
        elif kind == "textarea":
            out[key] = str(raw or "")[:4000]
        else:
            out[key] = str(raw or "").strip()[:2000]
    return out


# Mitgelieferte Sprüche, wie die Komplimente von MagicMirror. Die Szene wählt
# nach Tageszeit: morning 5-12, afternoon 12-18, evening 18-23, night sonst.
COMPLIMENTS = {
    "de": {
        "any": ["Schön, dass du da bist.", "Heute wird ein guter Tag.", "Du schaffst das.", "Einfach mal durchatmen."],
        "morning": ["Guten Morgen!", "Genieß deinen Kaffee.", "Hast du gut geschlafen?", "Auf geht's!"],
        "afternoon": ["Hallo!", "Läuft bei dir.", "Zeit für eine kleine Pause?"],
        "evening": ["Guten Abend!", "Schön, dass du zu Hause bist.", "Feierabend!"],
        "night": ["Gute Nacht.", "Schlaf gut.", "Morgen ist auch noch ein Tag."],
    },
    "en": {
        "any": ["Nice to see you.", "Today is going to be a good day.", "You've got this.", "Take a deep breath."],
        "morning": ["Good morning!", "Enjoy your coffee.", "Did you sleep well?", "Let's go!"],
        "afternoon": ["Hello there!", "You're doing great.", "Time for a little break?"],
        "evening": ["Good evening!", "Welcome home.", "Time to relax."],
        "night": ["Good night.", "Sleep well.", "Tomorrow is another day."],
    },
    "es": {
        "any": ["Qué bien verte.", "Hoy va a ser un buen día.", "Tú puedes.", "Respira hondo."],
        "morning": ["¡Buenos días!", "Disfruta tu café.", "¿Has dormido bien?", "¡Vamos allá!"],
        "afternoon": ["¡Hola!", "Lo estás haciendo genial.", "¿Una pausa?"],
        "evening": ["¡Buenas tardes!", "Bienvenido a casa.", "Hora de descansar."],
        "night": ["Buenas noches.", "Que duermas bien.", "Mañana será otro día."],
    },
}
