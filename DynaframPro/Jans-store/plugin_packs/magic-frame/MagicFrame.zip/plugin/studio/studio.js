"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/MagicFrame/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
let state = null;          // Antwort von /api/state
let rows = [];             // die Module, wie sie gespeichert werden
let lang = "de";
let saveTimer = null;
let portrait = false;
const secretsTyped = {};   // id -> {key: value}, nur was gerade getippt wurde

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Wie <a href=\"https://github.com/MagicMirrorOrg/MagicMirror\" target=\"_blank\" rel=\"noopener\">MagicMirror²</a>, nur auf dem DynaFrame: Wähle Module aus (Uhr, Wetter, Termine, Nachrichten, Abfahrten, Home Assistant …) und setz sie dahin, wo sie stehen sollen: oben, unten, links, rechts oder in die Mitte. Jedes Modul darf mehrmals vorkommen. Jede Änderung wird sofort gespeichert und ist nach ein paar Sekunden auf dem Bildschirm.",
    "Like <a href=\"https://github.com/MagicMirrorOrg/MagicMirror\" target=\"_blank\" rel=\"noopener\">MagicMirror²</a>, on your DynaFrame: pick modules (clock, weather, calendar, news, departures, Home Assistant …) and put them where you want them: top, bottom, left, right or centre. Every module can appear more than once. Changes are saved immediately and show up on the screen within seconds.",
    "Como <a href=\"https://github.com/MagicMirrorOrg/MagicMirror\" target=\"_blank\" rel=\"noopener\">MagicMirror²</a>, en tu DynaFrame: elige módulos (reloj, tiempo, calendario, noticias, salidas, Home Assistant …) y colócalos donde quieras: arriba, abajo, izquierda, derecha o centro. Cada módulo puede aparecer varias veces. Los cambios se guardan al instante y se ven en la pantalla en unos segundos."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  playlist: ["Playlist „Dynaframe's Magic Mirror“ anlegen", "Create playlist “Dynaframe's Magic Mirror”", "Crear lista «Dynaframe's Magic Mirror»"],
  factScene: ["Szene", "Scene", "Escena"],
  factModules: ["Module", "Modules", "Módulos"],
  factVersion: ["Version", "Version", "Versión"],
  sceneSeen: ["zu sehen", "on screen", "en pantalla"],
  sceneLast: ["zuletzt {time}", "last {time}", "última vez {time}"],
  sceneNever: ["noch nicht gezeigt", "not shown yet", "aún no se ha mostrado"],
  generalTitle: ["Allgemein", "General", "General"],
  placeHint: ["Der Ort für Wetter, Regen, Warnungen und die Haltestellen in der Nähe. Er wird einmal bei OpenStreetMap nachgeschlagen.",
    "The location for weather, rain, warnings and nearby stops. It is looked up once on OpenStreetMap.",
    "La ubicación para el tiempo, la lluvia, los avisos y las paradas cercanas. Se consulta una vez en OpenStreetMap."],
  place: ["Ort", "Location", "Ubicación"],
  placePh: ["z. B. Mainz oder Hauptstraße 1, Mainz", "e.g. London or 10 Downing St, London", "p. ej. Madrid o Gran Vía 1, Madrid"],
  find: ["Suchen", "Find", "Buscar"],
  finding: ["Suche …", "Searching …", "Buscando …"],
  placeNow: ["Eingestellt: {name}", "Set: {name}", "Configurada: {name}"],
  placeNone: ["Noch kein Ort eingestellt.", "No location set yet.", "Aún no hay ubicación."],
  units: ["Einheiten", "Units", "Unidades"],
  metric: ["°C, km/h", "°C, km/h", "°C, km/h"],
  imperial: ["°F, mph", "°F, mph", "°F, mph"],
  background: ["Hintergrund", "Background", "Fondo"],
  bgBlack: ["Schwarz (für Spiegel)", "Black (for mirrors)", "Negro (para espejos)"],
  bgNight: ["Nachtblau", "Night blue", "Azul noche"],
  bgColor: ["Eigene Farbe", "Own colour", "Color propio"],
  bgImage: ["Bild", "Image", "Imagen"],
  bgColorLabel: ["Farbe", "Colour", "Color"],
  bgDim: ["Bild abdunkeln", "Darken image", "Oscurecer imagen"],
  bgLink: ["Link zum Bild", "Link to the image", "Enlace a la imagen"],
  bgUseLink: ["Link übernehmen", "Use link", "Usar enlace"],
  bgUpload: ["Bild hochladen …", "Upload image …", "Subir imagen …"],
  bgRemove: ["Bild entfernen", "Remove image", "Quitar imagen"],
  bgHint: ["Ein Link (z. B. auf ein Foto in deiner Cloud) oder ein Bild vom Gerät, höchstens 15 MB. Damit die Module lesbar bleiben, wird das Bild abgedunkelt und die Schrift bekommt einen Schatten.",
    "A link (e.g. to a photo in your cloud) or an image from your device, 15 MB at most. To keep the modules readable, the image is darkened and the text gets a shadow.",
    "Un enlace (p. ej. a una foto en tu nube) o una imagen de tu dispositivo, 15 MB como máximo. Para que los módulos se lean bien, la imagen se oscurece y el texto lleva sombra."],
  bgUploaded: ["Hochgeladenes Bild in Verwendung.", "Uploaded image in use.", "Imagen subida en uso."],
  bgLinked: ["Bild per Link in Verwendung.", "Image from link in use.", "Imagen de enlace en uso."],
  bgNone: ["Noch kein Bild gewählt.", "No image chosen yet.", "Aún no hay imagen."],
  bgUploading: ["Lade hoch …", "Uploading …", "Subiendo …"],
  bgBadLink: ["Der Link muss mit http:// oder https:// beginnen.", "The link must start with http:// or https://.", "El enlace debe empezar por http:// o https://."],
  scale: ["Schriftgröße (%)", "Text size (%)", "Tamaño de letra (%)"],
  clock24: ["24-Stunden-Uhr", "24-hour clock", "Reloj de 24 horas"],
  layoutTitle: ["Anordnung", "Layout", "Distribución"],
  skinTitle: ["Aussehen (Skin)", "Look (skin)", "Aspecto (skin)"],
  skinHint: ["Ein Skin gestaltet die ganze Szene neu, zum Beispiel als Retro-LCD-Uhr oder als buntes Farbraster. Deine Module bleiben gespeichert und sind wieder zu sehen, sobald du „Standard“ wählst. Weitere Skins installierst du wie Module unter „Weitere Module“.",
    "A skin redesigns the whole scene, for example as a retro LCD clock or a colourful grid. Your modules stay saved and come back as soon as you pick “Standard”. Install more skins like modules under “More modules”.",
    "Un skin rediseña toda la escena, por ejemplo como reloj LCD retro o como cuadrícula de colores. Tus módulos se guardan y vuelven en cuanto eliges «Estándar». Instala más skins como los módulos en «Más módulos»."],
  skinLabel: ["Skin", "Skin", "Skin"],
  skinActive: ["Gerade zeigt der Rahmen den Skin „{name}“. Die Module bleiben gespeichert, sind aber erst mit dem Skin „Standard“ wieder zu sehen.",
    "The frame currently shows the skin “{name}”. Your modules stay saved but only appear again with the skin “Standard”.",
    "El marco muestra ahora el skin «{name}». Los módulos se guardan, pero solo vuelven a verse con el skin «Estándar»."],
  skinNoPlace: ["Für Wetter und Sonnenzeiten oben unter Allgemein einen Ort suchen.", "Search for a place under General above for weather and sun times.",
    "Busca un lugar en General para el tiempo y las horas de sol."],
  skinTag: ["Skin", "skin", "skin"],
  slotsTitle: ["Was in welchem Feld steht", "What goes in which field", "Qué va en cada campo"],
  slotsHint: ["Jedes Feld hat eine Vorgabe. Du kannst stattdessen etwas anderes vom Skin wählen oder eines deiner Module (unten unter „Module“), sofern es für dieses Feld eine passende Darstellung gibt. Ein Modul, das nur hier stehen soll, kannst du unten hinzufügen; seine Region spielt mit Skin keine Rolle.",
    "Each field has a default. Pick something else from the skin instead, or one of your modules (below under “Modules”) if there is a fitting look for that field. Add a module below if you only want it here; its region does not matter while a skin is on.",
    "Cada campo tiene un valor por defecto. Elige otra cosa del skin o uno de tus módulos (abajo en «Módulos») si hay una vista adecuada para ese campo. Añade abajo un módulo si solo lo quieres aquí; con skin su región no importa."],
  default: ["Vorgabe", "default", "por defecto"],
    slotEmpty: ["– leer –", "– empty –", "– vacío –"],
  slotSkinGroup: ["Vom Skin", "From the skin", "Del skin"],
  slotModuleGroup: ["Aus deinen Modulen", "From your modules", "De tus módulos"],
  toTitle: ["Über die Playlist legen", "Show over the playlist", "Mostrar sobre la lista"],
  toHint: ["Der Magic Mirror kommt nach Zeitplan von selbst über das, was gerade läuft, und gibt den Bildschirm danach zurück. Dafür auf der Plugins-Seite bei Dynaframe's Magic Mirror „Allow takeover“ einschalten. Ein ausgeschalteter Bildschirm wird nicht geweckt.",
    "The Magic Mirror comes on screen by itself over whatever is playing, on a schedule, and hands the screen back afterwards. Switch on “Allow takeover” for Dynaframe's Magic Mirror on the Plugins page. A screen that is off is not woken.",
    "El Magic Mirror aparece solo sobre lo que se esté reproduciendo, según un horario, y luego devuelve la pantalla. Activa «Allow takeover» para Dynaframe's Magic Mirror en la página de plugins. No enciende una pantalla apagada."],
  toShow: ["Jetzt zeigen", "Show now", "Mostrar ahora"],
  toStop: ["Beenden", "Stop", "Terminar"],
  toMode: ["Automatisch zeigen", "Show automatically", "Mostrar automáticamente"],
  toModeOff: ["nie", "never", "nunca"],
  toModeEvery: ["regelmäßig", "regularly", "regularmente"],
  toModeAlways: ["durchgehend", "all the time", "todo el tiempo"],
  toFrom: ["Von", "From", "Desde"],
  toTo: ["Bis", "Until", "Hasta"],
  toEvery: ["Alle … Minuten", "Every … minutes", "Cada … minutos"],
  toFor: ["Für … Sekunden", "For … seconds", "Durante … segundos"],
  toDayNames: [["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"], ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], ["Lu", "Ma", "Mi", "Ju", "Vi", "Sá", "Do"]],
  layoutHint: ["So ungefähr sieht der Bildschirm aus. Zieh ein Modul in eine andere Region oder tipp es an, um es einzustellen.",
    "Roughly how the screen looks. Drag a module to another region, or tap it to set it up.",
    "Así se ve la pantalla más o menos. Arrastra un módulo a otra región o tócalo para configurarlo."],
  portrait: ["Hochformat", "Portrait", "Vertical"],
  landscape: ["Querformat", "Landscape", "Horizontal"],
  modulesTitle: ["Module", "Modules", "Módulos"],
  modulesHint: ["Die Reihenfolge innerhalb einer Region ist die Reihenfolge hier in der Liste.",
    "Within a region, modules appear in the order of this list.", "Dentro de una región, los módulos aparecen en el orden de esta lista."],
  region: ["Region", "Region", "Región"],
  addModule: ["Modul hinzufügen", "Add module", "Añadir módulo"],
  add: ["Hinzufügen", "Add", "Añadir"],
  up: ["Nach oben", "Move up", "Subir"],
  down: ["Nach unten", "Move down", "Bajar"],
  remove: ["Entfernen", "Remove", "Quitar"],
  fetch: ["Jetzt abrufen", "Fetch now", "Consultar ahora"],
  fetching: ["Rufe ab …", "Fetching …", "Consultando …"],
  fetchOk: ["Abgerufen.", "Fetched.", "Consultado."],
  stAt: ["zuletzt {time}", "last {time}", "última vez {time}"],
  stWait: ["wartet", "waiting", "en espera"],
  stVisible: ["holt nur, solange die Szene zu sehen ist", "fetches only while the scene is on screen", "solo consulta con la escena en pantalla"],
  saved: ["gespeichert", "saved", "guardado"],
  secretSet: ["gespeichert, leer lassen zum Behalten", "saved, leave empty to keep", "guardado, déjalo vacío para mantenerlo"],
  stopNone: ["Noch keine Haltestelle.", "No stop yet.", "Aún no hay parada."],
  stopNow: ["Haltestelle: {name}", "Stop: {name}", "Parada: {name}"],
  stopSearch: ["Haltestelle suchen", "Search stop", "Buscar parada"],
  stopNearby: ["In der Nähe", "Nearby", "Cerca"],
  stopEmpty: ["Nichts gefunden.", "Nothing found.", "No se encontró nada."],
  haLoad: ["Entitäten aus Home Assistant laden", "Load entities from Home Assistant", "Cargar entidades de Home Assistant"],
  haFilter: ["Suchen, z. B. temperatur oder fenster", "Search, e.g. temperature or window", "Buscar, p. ej. temperatura o ventana"],
  haAll: ["alle Arten", "all kinds", "todos los tipos"],
  haOnly: ["nur gewählte", "only chosen", "solo elegidas"],
  haCount: ["{n} Entitäten geladen. Hak an, was angezeigt werden soll.", "{n} entities loaded. Tick what should be shown.", "{n} entidades cargadas. Marca lo que quieras mostrar."],
  haChosen: ["{n} gewählt", "{n} chosen", "{n} elegidas"],
  haMore: ["… und {n} weitere. Grenz die Suche ein.", "… and {n} more. Narrow the search.", "… y {n} más. Acota la búsqueda."],
  haRaw: ["Liste von Hand bearbeiten (eigene Namen: Name = entität)", "Edit the list by hand (own names: Name = entity)", "Editar la lista a mano (nombres propios: Nombre = entidad)"],
  addonsTitle: ["Weitere Module", "More modules", "Más módulos"],
  addonsHint: ["Module aus dem Katalog werden in Dynaframe's Magic Mirror selbst installiert und tauchen nicht in der Plugins-Übersicht auf. Danach findest du sie oben unter „Modul hinzufügen“. Module laufen mit denselben Rechten wie Dynaframe's Magic Mirror; installiere nur, was du kennst.",
    "Modules from the catalog are installed inside Dynaframe's Magic Mirror itself and do not appear in the Plugins overview. Afterwards they are listed under “Add module” above. Modules run with the same rights as Dynaframe's Magic Mirror; only install what you trust.",
    "Los módulos del catálogo se instalan dentro de Dynaframe's Magic Mirror y no aparecen en la vista de plugins. Después están arriba en «Añadir módulo». Los módulos tienen los mismos permisos que Dynaframe's Magic Mirror; instala solo lo que conozcas."],
  catalogRefresh: ["Katalog neu laden", "Reload catalog", "Recargar catálogo"],
  catalogEmpty: ["Der Katalog ist gerade leer oder nicht erreichbar.", "The catalog is empty or can't be reached right now.", "El catálogo está vacío o no está disponible."],
  installedTitle: ["Installiert", "Installed", "Instalados"],
  moreSources: ["Andere Quellen", "Other sources", "Otras fuentes"],
  catalogUrls: ["Weitere Modul-Kataloge (ein Link pro Zeile)", "More module catalogs (one link per line)", "Más catálogos de módulos (un enlace por línea)"],
  devHint: ["Eigene Module bauen oder Module von MagicMirror² umbauen (die Anleitung kann man direkt einer KI geben): <a href=\"https://github.com/Archonw/Jans-DynaframePro-Store/blob/main/plugin_packs/magic-frame/MODULES.md\" target=\"_blank\" rel=\"noopener\">MODULES.md</a>. Ein Modul kann auch als eigenes Plugin kommen; dann erkennt Dynaframe's Magic Mirror es ebenfalls, es steht aber in der Plugins-Übersicht.",
    "Build your own module or port one from MagicMirror² (you can hand the guide straight to an AI): <a href=\"https://github.com/Archonw/Jans-DynaframePro-Store/blob/main/plugin_packs/magic-frame/MODULES.md\" target=\"_blank\" rel=\"noopener\">MODULES.md</a>. A module can also come as its own plugin; Dynaframe's Magic Mirror detects it too, but it then shows up in the Plugins overview.",
    "Crea tu propio módulo o adapta uno de MagicMirror² (puedes darle la guía directamente a una IA): <a href=\"https://github.com/Archonw/Jans-DynaframePro-Store/blob/main/plugin_packs/magic-frame/MODULES.md\" target=\"_blank\" rel=\"noopener\">MODULES.md</a>. Un módulo también puede venir como plugin propio; Dynaframe's Magic Mirror lo detecta igualmente, pero aparece en la vista de plugins."],
  addonUrl: ["ZIP-Link eines Moduls", "ZIP link of a module", "Enlace ZIP de un módulo"],
  install: ["Installieren", "Install", "Instalar"],
  update: ["Aktualisieren", "Update", "Actualizar"],
  installedOk: ["installiert", "installed", "instalado"],
  installing: ["Installiere …", "Installing …", "Instalando …"],
  addonNone: ["Noch keine weiteren Module installiert.", "No extra modules installed yet.", "Aún no hay módulos adicionales."],
  addonFrom: ["aus Plugin {name}", "from plugin {name}", "del plugin {name}"],
  addonLink: ["im Magic Mirror installiert", "installed in Magic Mirror", "instalado en Magic Mirror"],
  addonStore: ["aus dem Store (dort auch entfernen)", "from the store (remove it there)", "de la tienda (elimínalo allí)"],
  addonTag: ["Zusatz", "add-on", "adicional"],
  addonMissing: ["nicht installiert", "not installed", "no instalado"],
  credits: ["Daten: Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), Deutscher Wetterdienst über Bright Sky, OpenStreetMap/Nominatim. Die Idee stammt von <a href=\"https://github.com/MagicMirrorOrg/MagicMirror\" target=\"_blank\" rel=\"noopener\">MagicMirror²</a>; Dynaframe's Magic Mirror ist ein eigenständiger Nachbau für DynaFrame.",
    "Data: Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), German Weather Service via Bright Sky, OpenStreetMap/Nominatim. The idea comes from <a href=\"https://github.com/MagicMirrorOrg/MagicMirror\" target=\"_blank\" rel=\"noopener\">MagicMirror²</a>; Dynaframe's Magic Mirror is an independent take for DynaFrame.",
    "Datos: Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), servicio meteorológico alemán vía Bright Sky, OpenStreetMap/Nominatim. La idea viene de <a href=\"https://github.com/MagicMirrorOrg/MagicMirror\" target=\"_blank\" rel=\"noopener\">MagicMirror²</a>; Dynaframe's Magic Mirror es una versión independiente para DynaFrame."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
};

const li = () => Math.max(0, ["de", "en", "es"].indexOf(lang));
function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? row[li()] ?? row[0] : key;
  return String(text).replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}
const L = (list) => (Array.isArray(list) ? list[li()] ?? list[0] : String(list ?? ""));

function esc(text) {
  return String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}

function applyI18n() {
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  el("orientButton").textContent = t(portrait ? "landscape" : "portrait");
}

async function api(path, body) {
  const response = await fetch(`./api/${path}`, body === undefined ? { cache: "no-store" } : {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  return response.json();
}

function note(id, text, kind = "") {
  const node = el(id);
  node.textContent = text || "";
  node.className = `status ${kind}`;
}

// ------------------------------------------------------------ Laden

const specOf = (type) => state.catalog.modules.find((m) => m.type === type);
const regionLabel = (id) => L(state.catalog.regions.find((r) => r.id === id)?.label || id);

async function load() {
  state = await api("state");
  lang = state.settings.Language || "de";
  rows = state.modules.map((m) => ({ ...m, config: { ...m.config } }));
  renderSkinSelect();
  for (const node of document.querySelectorAll("[data-setting]")) {
    const value = state.settings[node.dataset.setting];
    if (node.type === "checkbox") node.checked = !!value; else node.value = value ?? "";
  }
  el("Place").value = state.settings.Place || "";
  applyI18n();
  renderAll();
  renderBackground();
  renderTakeover();
  renderSkin();
}

// ------------------------------------------------------------ Skin

const widgetName = (type) => L(state.catalog.widgetNames?.[type] || type);

// Felder des Skins: je Feld eine Auswahl aus dem, was der Skin selbst liefert,
// und den Modulen, die einen passenden Widget-Typ haben (oder "wie im Standard-Skin").
function renderSkinSlots(type, spec, row) {
  const slots = spec?.slots || [];
  el("skinSlotsBox").hidden = !slots.length;
  if (!slots.length) { el("skinSlots").innerHTML = ""; return; }
  const chosen = { ...Object.fromEntries(slots.map((s) => [s.id, s.default])), ...(row.config.slots || {}) };
  el("skinSlots").innerHTML = slots.map((slot) => {
    const own = (spec.own || []).filter((w) => slot.accepts.includes(w))
      .map((w) => [`skin:${w}`, widgetName(w) + (`skin:${w}` === slot.default ? ` (${t("default")})` : "")]);
    const fromModules = rows.flatMap((m) => {
      const mspec = specOf(m.type);
      const types = [...(mspec?.widgets || []), "module"].filter((w) => slot.accepts.includes(w));
      return types.map((w) => [`${m.id}:${w}`, `${moduleTitle(m)} · ${widgetName(w)}`]);
    });
    const value = chosen[slot.id] ?? "";
    const known = value === "" || [...own, ...fromModules].some(([v]) => v === value);
    const opt = ([v, label]) => `<option value="${esc(v)}" ${v === value ? "selected" : ""}>${esc(label)}</option>`;
    return `<label class="field"><span>${esc(L(slot.name))}</span><select data-slot="${esc(slot.id)}">
      <option value="" ${value === "" ? "selected" : ""}>${esc(t("slotEmpty"))}</option>
      ${own.length ? `<optgroup label="${esc(t("slotSkinGroup"))}">${own.map(opt).join("")}</optgroup>` : ""}
      ${fromModules.length ? `<optgroup label="${esc(t("slotModuleGroup"))}">${fromModules.map(opt).join("")}</optgroup>` : ""}
      ${known ? "" : `<option value="${esc(value)}" selected>${esc(t("addonMissing"))}</option>`}
    </select></label>`;
  }).join("");
  el("skinSlots").querySelectorAll("select[data-slot]").forEach((select) => select.addEventListener("change", async () => {
    const all = (state.settings.SkinConfig ||= {});
    const config = (all[type] ||= { ...row.config });
    config.slots = { ...(config.slots || chosen), [select.dataset.slot]: select.value };
    row.config.slots = config.slots;
    await api("settings", { SkinConfig: { [type]: { slots: { [select.dataset.slot]: select.value } } } });
  }));
}

const skinSpec = (type) => (state.catalog.skins || []).find((s) => s.type === type);
let skinTimer = null;

function renderSkinSelect() {
  const select = el("Skin");
  const current = state.settings.Skin || "standard";
  const skins = state.catalog.skins || [];
  select.innerHTML = skins.map((s) => `<option value="${esc(s.type)}">${esc(L(s.name))}${s.addon ? ` (${esc(t("addonTag"))})` : ""}</option>`).join("")
    + (skinSpec(current) ? "" : `<option value="${esc(current)}">${esc(current)} (${esc(t("addonMissing"))})</option>`);
  select.value = current;
}

function skinConfig(type) {
  const spec = skinSpec(type);
  const saved = (state.settings.SkinConfig || {})[type] || {};
  const config = {};
  (spec?.fields || []).forEach((f) => { config[f.key] = f.key in saved ? saved[f.key] : f.default; });
  Object.keys(saved).filter((k) => k.startsWith("has_")).forEach((k) => { config[k] = saved[k]; });
  if (saved.slots) config.slots = { ...saved.slots };
  return config;
}

function renderSkin() {
  const type = state.settings.Skin || "standard";
  const spec = skinSpec(type);
  el("skinDescription").textContent = spec ? L(spec.description) : "";
  const row = { id: "skin", type, config: skinConfig(type) };
  el("skinFields").innerHTML = spec ? spec.fields.map((f) => fieldHtml(row, f)).join("") : "";
  el("skinFields").hidden = !spec || !spec.fields.length;
  updateShowIf();
  el("skinFields").querySelectorAll("[data-key]").forEach((input) => {
    const event = input.tagName === "SELECT" || input.type === "checkbox" ? "change" : "input";
    input.addEventListener(event, () => {
      const kind = input.dataset.kind;
      if (kind === "secret") (secretsTyped.skin ||= {})[input.dataset.key] = input.value;
      else row.config[input.dataset.key] = kind === "bool" ? input.checked : kind === "number" ? Number(input.value) : input.value;
      const all = (state.settings.SkinConfig ||= {});
      all[type] = { ...row.config };
      updateShowIf();
      clearTimeout(skinTimer);
      skinTimer = setTimeout(() => {
        const config = { ...row.config, ...(secretsTyped.skin || {}) };
        Object.keys(config).filter((k) => k.startsWith("has_")).forEach((k) => delete config[k]);
        api("settings", { SkinConfig: { [type]: config } });
      }, 700);
    });
  });
  renderSkinSlots(type, spec, row);
  const active = type !== "standard" && spec;
  note("skinNote", active && spec.place && !state.settings.PlaceName ? t("skinNoPlace") : "", "bad");
  el("skinActive").hidden = !active;
  el("skinActive").textContent = active ? t("skinActive", { name: L(spec.name) }) : "";
}

// ------------------------------------------------------------ Takeover

function renderTakeover() {
  const s = state.settings;
  const mode = s.ShowMode || "off";
  document.querySelectorAll(".to-opt").forEach((n) => { n.hidden = mode === "off"; });
  document.querySelectorAll(".to-every").forEach((n) => { n.hidden = mode !== "every"; });
  el("ShowForSeconds").closest("label").hidden = mode === "always";
  const names = I18N.toDayNames[li()] || I18N.toDayNames[0];
  const days = s.ShowDays || [];
  el("toDays").innerHTML = names.map((name, i) =>
    `<label class="day"><input type="checkbox" value="${i}" ${days.includes(i) ? "checked" : ""}><span>${esc(name)}</span></label>`).join("");
  el("toDays").querySelectorAll("input").forEach((box) => box.addEventListener("change", async () => {
    const picked = [...el("toDays").querySelectorAll("input:checked")].map((b) => Number(b.value));
    await api("settings", { ShowDays: picked });
    state.settings.ShowDays = picked;
    refreshStatus();
  }));
  renderTakeoverStatus();
}

function renderTakeoverStatus() {
  const info = state.takeover || {};
  const line = [info.line, info.note].filter(Boolean).join(" ");
  note("toLine", line, info.showing ? "ok" : "");
  note("toProblem", info.problem || info.stalled || "", "bad");
  el("toStop").disabled = !info.showing;
}

el("toShow").addEventListener("click", async () => {
  const result = await api("show", {});
  note("toLine", result.message || result.error, result.success ? "busy" : "bad");
  setTimeout(refreshStatus, 4000);
  setTimeout(refreshStatus, 12000);
});
el("toStop").addEventListener("click", async () => {
  const result = await api("stop", {});
  note("toLine", result.message || result.error, result.success ? "ok" : "bad");
  setTimeout(refreshStatus, 1500);
});

// ------------------------------------------------------------ Hintergrund

function renderBackground() {
  const s = state.settings;
  const mode = s.Background || "black";
  el("bgColorField").hidden = mode !== "color" && mode !== "image";
  el("bgDimField").hidden = mode !== "image";
  el("bgImageBox").hidden = mode !== "image";
  el("bgDimValue").textContent = `${s.BackgroundDim ?? 55} %`;
  const image = String(s.BackgroundImage || "");
  el("bgRemove").hidden = !image;
  if (/^https?:/.test(image) && document.activeElement !== el("bgLink")) el("bgLink").value = image;
  if (!image || image.startsWith("upload:")) el("bgLink").value = "";
  if (!el("bgNote").classList.contains("busy") && !el("bgNote").classList.contains("bad")) {
    note("bgNote", t(image.startsWith("upload:") ? "bgUploaded" : image ? "bgLinked" : "bgNone"), image ? "ok" : "");
  }
  const screen = el("screen");
  const src = image.startsWith("upload:") ? `./background?v=${image.slice(7)}` : image;
  const dim = (s.BackgroundDim ?? 55) / 100;
  screen.style.background = mode === "image" && src
    ? `linear-gradient(rgba(0,0,0,${dim}), rgba(0,0,0,${dim})), center / cover no-repeat url("${src.replace(/"/g, "%22")}"), ${s.BackgroundColor}`
    : mode === "color" ? s.BackgroundColor : mode === "night" ? "radial-gradient(ellipse at 30% 0%, #16233a 0%, #070b14 55%, #000 100%)" : "";
}

async function setBackgroundImage(value) {
  await api("settings", { BackgroundImage: value, Background: "image" });
  Object.assign(state.settings, { BackgroundImage: value, Background: "image" });
  el("Background").value = "image";
  note("bgNote", "", "");
  renderBackground();
}

el("bgUseLink").addEventListener("click", () => {
  const link = el("bgLink").value.trim();
  if (!/^https?:\/\/\S+$/.test(link)) { note("bgNote", t("bgBadLink"), "bad"); return; }
  setBackgroundImage(link);
});
el("bgFile").addEventListener("change", () => {
  const file = el("bgFile").files[0];
  if (!file) return;
  if (file.size > 15 * 1024 * 1024) { note("bgNote", t("bgHint"), "bad"); return; }
  note("bgNote", t("bgUploading"), "busy");
  const reader = new FileReader();
  reader.onload = async () => {
    const result = await api("background-upload", { data: reader.result });
    el("bgFile").value = "";
    if (!result.success) { note("bgNote", result.error, "bad"); return; }
    Object.assign(state.settings, { BackgroundImage: result.BackgroundImage, Background: "image" });
    el("Background").value = "image";
    note("bgNote", "", "");
    renderBackground();
  };
  reader.readAsDataURL(file);
});
el("bgRemove").addEventListener("click", async () => {
  if (String(state.settings.BackgroundImage || "").startsWith("upload:")) await api("background-remove", {});
  else await api("settings", { BackgroundImage: "" });
  state.settings.BackgroundImage = "";
  note("bgNote", "", "");
  renderBackground();
});
el("BackgroundDim").addEventListener("input", () => {
  el("bgDimValue").textContent = `${el("BackgroundDim").value} %`;
});

function renderAll() {
  renderStatus();
  renderPreview();
  renderModules();
  renderAddSelect();
  renderAddons();
}

function renderStatus() {
  el("factVersion").textContent = state.version;
  el("factModules").textContent = String(rows.length);
  const seen = el("factScene");
  seen.textContent = state.visible ? t("sceneSeen") : state.sceneSeen ? t("sceneLast", { time: clock(state.sceneSeen) }) : t("sceneNever");
  seen.className = state.visible ? "ok" : "";
  note("statusNote", state.note, state.note ? "bad" : "");
  note("placeNote", state.settings.PlaceName ? t("placeNow", { name: state.settings.PlaceName }) : t("placeNone"),
    state.settings.PlaceName ? "" : "bad");
}

function clock(iso) {
  const d = new Date(iso);
  const sameDay = d.toDateString() === new Date().toDateString();
  return d.toLocaleString(lang === "en" ? "en-GB" : lang === "es" ? "es-ES" : "de-DE",
    sameDay ? { hour: "2-digit", minute: "2-digit" } : { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

// ------------------------------------------------------------ Vorschau

const LAYOUT = [
  ["bar", ["top_bar"]], ["top", ["top_left", "top_center", "top_right"]],
  ["middle", ["middle_left", "middle_center", "middle_right"]],
  ["bottom", ["bottom_left", "bottom_center", "bottom_right"]], ["bar", ["bottom_bar"]],
];
let dragId = null;

function renderPreview() {
  const screen = el("screen");
  screen.classList.toggle("portrait", portrait);
  screen.innerHTML = LAYOUT.map(([kind, regions]) => `<div class="prow ${kind}">${regions.map((r) => {
    const side = r.endsWith("_left") ? "left" : r.endsWith("_right") ? "right" : r.endsWith("_bar") ? "bar" : "center";
    const chips = rows.filter((m) => m.region === r).map((m) => {
      const err = state.status[m.id]?.error;
      return `<span class="chip ${err ? "err" : ""}" draggable="true" data-id="${m.id}" title="${esc(err || "")}">${esc(moduleTitle(m))}</span>`;
    }).join("");
    return `<div class="preg ${side}" data-region="${r}">${chips || `<span class="rname">${esc(regionLabel(r))}</span>`}</div>`;
  }).join("")}</div>`).join("");
  screen.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => openModule(chip.dataset.id));
    chip.addEventListener("dragstart", (e) => { dragId = chip.dataset.id; chip.classList.add("dragging"); e.dataTransfer.setData("text/plain", dragId); });
    chip.addEventListener("dragend", () => { dragId = null; chip.classList.remove("dragging"); });
  });
  screen.querySelectorAll(".preg").forEach((region) => {
    region.addEventListener("dragover", (e) => { e.preventDefault(); region.classList.add("drop"); });
    region.addEventListener("dragleave", () => region.classList.remove("drop"));
    region.addEventListener("drop", (e) => {
      e.preventDefault();
      region.classList.remove("drop");
      const row = rows.find((m) => m.id === (dragId || e.dataTransfer.getData("text/plain")));
      if (!row || row.region === region.dataset.region) return;
      // ans Ende der neuen Region
      rows = rows.filter((m) => m !== row);
      row.region = region.dataset.region;
      rows.push(row);
      changed(true);
    });
  });
}

function moduleTitle(m) {
  const spec = specOf(m.type);
  return m.config.header || (spec ? L(spec.name) : m.type);
}

// ------------------------------------------------------------ Module

function openModule(id) {
  const node = document.querySelector(`.module[data-id="${id}"]`);
  if (!node) return;
  node.open = true;
  node.scrollIntoView({ behavior: "smooth", block: "center" });
  node.classList.add("flash");
  setTimeout(() => node.classList.remove("flash"), 1200);
}

function statusText(m) {
  const spec = specOf(m.type);
  const st = state.status[m.id];
  if (!spec || !spec.fields) return ["", ""];
  if (st?.error) return [st.error, "bad"];
  if (st?.at) return [t("stAt", { time: clock(st.at) }), "ok"];
  if (m.type === "departures" || m.type === "homeassistant") return [state.visible ? t("stWait") : t("stVisible"), ""];
  return ["", ""];
}

function renderModules() {
  const open = new Set([...document.querySelectorAll(".module[open]")].map((n) => n.dataset.id));
  el("modules").innerHTML = rows.map((m, index) => {
    const spec = specOf(m.type);
    const [stText, stKind] = statusText(m);
    const regionSelect = `<select data-region="${m.id}">${state.catalog.regions.map((r) =>
      `<option value="${r.id}" ${r.id === m.region ? "selected" : ""}>${esc(L(r.label))}</option>`).join("")}</select>`;
    const tag = spec?.addon ? `<span class="tag">${esc(t("addonTag"))}</span>` : "";
    return `<details class="module" data-id="${m.id}" ${open.has(m.id) ? "open" : ""}>
      <summary><span class="mname">${esc(moduleTitle(m))}</span>${tag}
        <span class="mregion">${esc(regionLabel(m.region))}</span>
        <span class="mstate ${stKind}">${esc(spec ? stText : t("addonMissing"))}</span></summary>
      <div class="module-body">
        ${spec ? `<p class="hint">${esc(L(spec.description))}</p>` : ""}
        <div class="grid">
          <label class="field"><span>${esc(t("region"))}</span>${regionSelect}</label>
          ${spec ? spec.fields.map((f) => fieldHtml(m, f)).join("") : ""}
        </div>
        <div class="module-tools">
          <button type="button" class="secondary icon-btn" data-up="${m.id}" ${index === 0 ? "disabled" : ""} title="${esc(t("up"))}">↑</button>
          <button type="button" class="secondary icon-btn" data-down="${m.id}" ${index === rows.length - 1 ? "disabled" : ""} title="${esc(t("down"))}">↓</button>
          ${spec && hasFetch(m.type) ? `<button type="button" class="secondary" data-fetch="${m.id}">${esc(t("fetch"))}</button>` : ""}
          <button type="button" class="danger" data-remove="${m.id}">${esc(t("remove"))}</button>
          <span class="status" id="note-${m.id}"></span>
        </div>
      </div>
    </details>`;
  }).join("");
  bindModules();
  updateShowIf();
}

const NO_FETCH = new Set(["clock", "compliments", "webpage"]);
const hasFetch = (type) => !NO_FETCH.has(type);

function fieldHtml(m, f) {
  const value = m.config[f.key];
  const name = `data-mid="${m.id}" data-key="${f.key}" data-kind="${f.kind}"`;
  const label = `<span>${esc(L(f.label))}</span>`;
  const hint = f.hint ? `<p class="hint">${esc(L(f.hint))}</p>` : "";
  const showIf = f.showIf ? `data-show-if='${esc(JSON.stringify(f.showIf))}'` : "";
  switch (f.kind) {
    case "bool":
      return `<label class="field check" ${showIf}><input type="checkbox" ${name} ${value ? "checked" : ""}>${label}</label>`;
    case "number":
      return `<label class="field" ${showIf}>${label}<input type="number" ${name} value="${esc(value)}"
        ${f.min != null ? `min="${f.min}"` : ""} ${f.max != null ? `max="${f.max}"` : ""}>${hint}</label>`;
    case "select":
      return `<label class="field" ${showIf}>${label}<select ${name}>${f.options.map((o) =>
        `<option value="${esc(o.value)}" ${String(o.value) === String(value) ? "selected" : ""}>${esc(L(o.label))}</option>`).join("")}</select>${hint}</label>`;
    case "textarea":
      if (f.picker === "homeassistant") {
        return `<div class="field wide" ${showIf}>${label}
          <div class="row-actions" style="margin:0 0 6px"><button type="button" class="secondary" data-ha-load="${m.id}">${esc(t("haLoad"))}</button>
            <span class="status" id="haNote-${m.id}" style="margin:0"></span></div>
          <div class="ha-picker" id="haPick-${m.id}" hidden>
            <div class="search-row"><input type="text" data-ha-filter="${m.id}" placeholder="${esc(t("haFilter"))}">
              <select data-ha-domain="${m.id}"></select>
              <label class="field check" style="padding:0"><input type="checkbox" data-ha-only="${m.id}"><span>${esc(t("haOnly"))}</span></label></div>
            <div class="ha-list" id="haList-${m.id}"></div>
          </div>
          <details class="ha-raw"><summary class="small muted">${esc(t("haRaw"))}</summary>
            <textarea ${name} rows="4">${esc(value)}</textarea>${hint}</details></div>`;
      }
      return `<label class="field wide" ${showIf}>${label}<textarea ${name} rows="3">${esc(value)}</textarea>${hint}</label>`;
    case "secret":
      return `<label class="field" ${showIf}>${label}<input type="password" ${name} autocomplete="new-password"
        placeholder="${m.config[`has_${f.key}`] ? esc(t("secretSet")) : ""}" value="${esc(secretsTyped[m.id]?.[f.key] || "")}">${hint}</label>`;
    case "stop":
      return `<div class="field wide" ${showIf}>${label}
        <p class="status" id="stopNow-${m.id}">${esc(value?.name ? t("stopNow", { name: value.name }) : t("stopNone"))}</p>
        <div class="search-row"><input type="text" data-stop-q="${m.id}" placeholder="${esc(t("stopSearch"))}">
          <button type="button" class="secondary" data-stop-search="${m.id}">${esc(t("find"))}</button>
          <button type="button" class="secondary" data-stop-near="${m.id}">${esc(t("stopNearby"))}</button></div>
        <div class="stops" id="stops-${m.id}"></div>${hint}</div>`;
    default:
      return `<label class="field ${f.key === "url" || f.key === "header" ? "" : ""}" ${showIf}>${label}<input type="text" ${name} value="${esc(value)}">${hint}</label>`;
  }
}

function updateShowIf() {
  document.querySelectorAll("[data-show-if]").forEach((node) => {
    const id = node.closest(".module")?.dataset.id;
    const row = id ? rows.find((m) => m.id === id) : { config: skinConfig(state.settings.Skin) };
    const cond = JSON.parse(node.dataset.showIf);
    node.hidden = !Object.entries(cond).every(([k, v]) => String(row.config[k]) === String(v));
  });
}

function bindModules() {
  const box = el("modules");
  box.querySelectorAll("[data-key]").forEach((input) => {
    const event = input.tagName === "SELECT" || input.type === "checkbox" ? "change" : "input";
    input.addEventListener(event, () => {
      const row = rows.find((m) => m.id === input.dataset.mid);
      const kind = input.dataset.kind;
      if (kind === "secret") {
        (secretsTyped[row.id] ||= {})[input.dataset.key] = input.value;
      } else {
        row.config[input.dataset.key] = kind === "bool" ? input.checked : kind === "number" ? Number(input.value) : input.value;
      }
      if (input.dataset.key === "header") {
        input.closest(".module").querySelector(".mname").textContent = moduleTitle(row);
        renderPreview();
      }
      updateShowIf();
      changed(false);
    });
  });
  box.querySelectorAll("[data-region]").forEach((select) => select.addEventListener("change", () => {
    const row = rows.find((m) => m.id === select.dataset.region);
    row.region = select.value;
    select.closest(".module").querySelector(".mregion").textContent = regionLabel(row.region);
    changed(true);
  }));
  const move = (id, step) => {
    const i = rows.findIndex((m) => m.id === id);
    const j = i + step;
    if (j < 0 || j >= rows.length) return;
    [rows[i], rows[j]] = [rows[j], rows[i]];
    changed(true, true);
  };
  box.querySelectorAll("[data-up]").forEach((b) => b.addEventListener("click", () => move(b.dataset.up, -1)));
  box.querySelectorAll("[data-down]").forEach((b) => b.addEventListener("click", () => move(b.dataset.down, 1)));
  box.querySelectorAll("[data-remove]").forEach((b) => b.addEventListener("click", () => {
    rows = rows.filter((m) => m.id !== b.dataset.remove);
    changed(true, true);
  }));
  box.querySelectorAll("[data-fetch]").forEach((b) => b.addEventListener("click", async () => {
    const id = b.dataset.fetch;
    await saveNow();
    note(`note-${id}`, t("fetching"), "busy");
    const result = await api("fetch", { id });
    note(`note-${id}`, result.success ? t("fetchOk") : result.error, result.success ? "ok" : "bad");
    refreshStatus();
  }));
  box.querySelectorAll("[data-stop-search]").forEach((b) => b.addEventListener("click", () =>
    findStops(b.dataset.stopSearch, box.querySelector(`[data-stop-q="${b.dataset.stopSearch}"]`).value)));
  box.querySelectorAll("[data-stop-q]").forEach((input) => input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") findStops(input.dataset.stopQ, input.value);
  }));
  box.querySelectorAll("[data-ha-load]").forEach((b) => b.addEventListener("click", () => loadHaEntities(b.dataset.haLoad)));
  box.querySelectorAll("[data-stop-near]").forEach((b) => b.addEventListener("click", () => findStops(b.dataset.stopNear, "")));
}

// ------------------------------------------------------------ Home Assistant: Entitäten wählen

const haCache = {};   // Modul-id -> Liste aus Home Assistant

function haLines(row) {
  // "Name = sensor.x" oder "sensor.x" je Zeile -> [{id, line}]
  return String(row.config.entities || "").split("\n").map((line) => line.trim()).filter(Boolean)
    .map((line) => ({ id: line.split("=").pop().trim(), line }));
}

async function loadHaEntities(id) {
  const row = rows.find((m) => m.id === id);
  note(`haNote-${id}`, t("finding"), "busy");
  const result = await api("ha-entities", { id, url: row.config.url, token: secretsTyped[id]?.token || "" });
  if (!result.success) { note(`haNote-${id}`, result.error, "bad"); return; }
  haCache[id] = result.entities;
  note(`haNote-${id}`, t("haCount", { n: result.entities.length }), "ok");
  const domains = [...new Set(result.entities.map((e) => e.id.split(".")[0]))].sort();
  const select = document.querySelector(`[data-ha-domain="${id}"]`);
  select.innerHTML = `<option value="">${esc(t("haAll"))}</option>` + domains.map((d) => `<option>${esc(d)}</option>`).join("");
  el(`haPick-${id}`).hidden = false;
  const redraw = () => drawHaList(id);
  document.querySelector(`[data-ha-filter="${id}"]`).oninput = redraw;
  select.onchange = redraw;
  document.querySelector(`[data-ha-only="${id}"]`).onchange = redraw;
  redraw();
}

function drawHaList(id) {
  const row = rows.find((m) => m.id === id);
  const chosen = new Set(haLines(row).map((l) => l.id));
  const words = document.querySelector(`[data-ha-filter="${id}"]`).value.toLowerCase().split(/\s+/).filter(Boolean);
  const domain = document.querySelector(`[data-ha-domain="${id}"]`).value;
  const only = document.querySelector(`[data-ha-only="${id}"]`).checked;
  const list = (haCache[id] || []).filter((e) => (!domain || e.id.startsWith(domain + ".")) && (!only || chosen.has(e.id)) &&
    words.every((w) => e.id.toLowerCase().includes(w) || e.name.toLowerCase().includes(w)));
  const shown = list.slice(0, 300);
  el(`haList-${id}`).innerHTML = shown.map((e) => `<label class="ha-item"><input type="checkbox" value="${esc(e.id)}" ${chosen.has(e.id) ? "checked" : ""}>
      <span><b>${esc(e.name)}</b> <span class="muted small">${esc(e.id)}</span></span><span class="muted small">${esc(e.state)}</span></label>`).join("") +
    (list.length > shown.length ? `<p class="hint">${esc(t("haMore", { n: list.length - shown.length }))}</p>` : "") +
    (!list.length ? `<p class="hint">${esc(t("stopEmpty"))}</p>` : "");
  el(`haList-${id}`).querySelectorAll("input").forEach((box) => box.addEventListener("change", () => {
    let lines = haLines(row);
    if (box.checked) {
      if (!lines.some((l) => l.id === box.value)) lines.push({ id: box.value, line: box.value });
    } else {
      lines = lines.filter((l) => l.id !== box.value);
    }
    row.config.entities = lines.map((l) => l.line).join("\n");
    const area = document.querySelector(`textarea[data-mid="${id}"][data-key="entities"]`);
    if (area) area.value = row.config.entities;
    note(`haNote-${id}`, t("haChosen", { n: lines.length }), "ok");
    changed(false);
  }));
}

async function findStops(id, query) {
  const list = el(`stops-${id}`);
  list.innerHTML = `<span class="status busy">${esc(t("finding"))}</span>`;
  const result = await api("stop-search", { q: query });
  if (!result.success) { list.innerHTML = `<span class="status bad">${esc(result.error)}</span>`; return; }
  if (!result.stops.length) { list.innerHTML = `<span class="status">${esc(t("stopEmpty"))}</span>`; return; }
  list.innerHTML = result.stops.map((s, i) => `<button type="button" class="secondary" data-i="${i}">${esc(s.name)}${
    s.meters != null ? ` <span class="muted small">· ${s.meters} m</span>` : ""}</button>`).join("");
  list.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => {
    const stop = result.stops[Number(b.dataset.i)];
    const row = rows.find((m) => m.id === id);
    row.config.stop = { id: stop.id, name: stop.name };
    el(`stopNow-${id}`).textContent = t("stopNow", { name: stop.name });
    list.innerHTML = "";
    changed(false);
  }));
}

function renderAddSelect() {
  const select = el("addType");
  const current = select.value;
  select.innerHTML = state.catalog.modules.map((m) =>
    `<option value="${m.type}">${esc(L(m.name))}${m.addon ? ` (${esc(t("addonTag"))})` : ""}</option>`).join("");
  if (current && state.catalog.modules.some((m) => m.type === current)) select.value = current;
  el("addDescription").textContent = L(specOf(select.value)?.description || "");
}

function newId() {
  return "m" + Math.random().toString(16).slice(2, 10);
}

function addModule() {
  const spec = specOf(el("addType").value);
  if (!spec) return;
  const config = {};
  spec.fields.forEach((f) => { config[f.key] = f.default; });
  const row = { id: newId(), type: spec.type, region: spec.region, config };
  rows.push(row);
  changed(true, true);
  setTimeout(() => openModule(row.id), 50);
}

// ------------------------------------------------------------ Speichern

function changed(layout, rebuild = false) {
  el("factModules").textContent = String(rows.length);
  if (layout) renderPreview();
  if (rebuild) { renderModules(); renderSkin(); }
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 700);
}

async function saveNow() {
  clearTimeout(saveTimer);
  const payload = rows.map((m) => {
    const config = { ...m.config, ...(secretsTyped[m.id] || {}) };
    Object.keys(config).filter((k) => k.startsWith("has_")).forEach((k) => delete config[k]);
    return { id: m.id, type: m.type, region: m.region, config };
  });
  const result = await api("settings", { Modules: payload });
  if (result.success && result.modules) {
    // Die gespeicherte Fassung (mit has_*-Flags) übernehmen, ohne die Seite neu zu bauen
    const byId = Object.fromEntries(result.modules.map((m) => [m.id, m]));
    rows.forEach((m) => {
      const saved = byId[m.id];
      if (saved) Object.keys(saved.config).filter((k) => k.startsWith("has_")).forEach((k) => { m.config[k] = saved.config[k]; });
    });
  }
}

async function saveSetting(node) {
  const value = node.type === "checkbox" ? node.checked : node.type === "number" ? Number(node.value) : node.value;
  await api("settings", { [node.dataset.setting]: value });
  state.settings[node.dataset.setting] = value;
  if (node.dataset.setting.startsWith("Background")) { note("bgNote", "", ""); renderBackground(); }
  if (node.dataset.setting.startsWith("Show") || node.dataset.setting === "EveryMinutes") {
    renderTakeover();
    setTimeout(refreshStatus, 800);
  }
  if (node.dataset.setting === "Language") {
    lang = value;
    applyI18n();
    renderAll();
    renderCatalog();
    renderBackground();
    renderTakeover();
    renderSkinSelect();
    renderSkin();
  }
  if (node.dataset.setting === "ModuleCatalogs") loadCatalog(true);
  if (node.dataset.setting === "Skin") { secretsTyped.skin = {}; renderSkin(); }
}

async function refreshStatus() {
  const next = await api("state");
  state.status = next.status;
  state.visible = next.visible;
  state.sceneSeen = next.sceneSeen;
  state.note = next.note;
  state.takeover = next.takeover;
  renderTakeoverStatus();
  const catalogChanged = JSON.stringify(next.catalog) !== JSON.stringify(state.catalog) ||
    JSON.stringify(next.addonProblems) !== JSON.stringify(state.addonProblems);
  state.catalog = next.catalog;
  state.addonProblems = next.addonProblems;
  renderStatus();
  document.querySelectorAll(".module").forEach((node) => {
    const row = rows.find((m) => m.id === node.dataset.id);
    if (!row) return;
    const [text, kind] = statusText(row);
    const span = node.querySelector(".mstate");
    if (specOf(row.type)) { span.textContent = text; span.className = `mstate ${kind}`; }
  });
  if (catalogChanged) { renderAddSelect(); renderAddons(); renderModules(); renderSkinSelect(); renderSkin(); }
  renderPreview();
}

// ------------------------------------------------------------ Zusatzmodule

function renderAddons() {
  const list = [...state.catalog.modules, ...(state.catalog.skins || [])].filter((m) => m.addon);
  const problems = state.addonProblems || [];
  el("addons").innerHTML = (list.length || problems.length) ? list.map((m) => `<li>
      <span class="grow"><b>${esc(L(m.name))}</b> <span class="muted small">${esc(m.addon.version || "")}${m.addon.author ? ` · ${esc(m.addon.author)}` : ""}
      · ${esc(m.addon.origin === "link" ? t("addonLink") : m.addon.origin === "store" ? t("addonStore") : t("addonFrom", { name: m.addon.origin }))}</span></span>
      ${m.addon.url ? `<a href="${esc(m.addon.url)}" target="_blank" rel="noopener" class="small">Info</a>` : ""}
      ${m.addon.origin === "link" ? `<button type="button" class="danger" data-addon-remove="${esc(m.type)}">${esc(t("remove"))}</button>` : ""}
    </li>`).join("") + problems.map((p) => `<li class="problem small">${esc(p.origin)}: ${esc(p.error)}</li>`).join("")
    : `<li class="muted">${esc(t("addonNone"))}</li>`;
  el("addons").querySelectorAll("[data-addon-remove]").forEach((b) => b.addEventListener("click", async () => {
    await api("addon-remove", { type: b.dataset.addonRemove });
    await refreshStatus();
    await loadCatalog();
  }));
}

let catalog = null;

async function loadCatalog(refresh = false) {
  const result = await api(`module-catalog${refresh ? "?refresh=1" : ""}`);
  catalog = result;
  renderCatalog();
}

function renderCatalog() {
  if (!catalog) return;
  const items = catalog.modules || [];
  el("catalog").innerHTML = items.length ? items.map((m, i) => {
    const action = m.builtin ? "" : m.update ? `<button type="button" data-cat="${i}">${esc(t("update"))} ${esc(m.version)}</button>`
      : m.installed ? `<span class="status ok" style="margin:0">✓ ${esc(t("installedOk"))}</span>`
      : `<button type="button" data-cat="${i}">${esc(t("install"))}</button>`;
    return `<li><span class="grow"><b>${esc(L(m.name))}</b> <span class="muted small">${esc(m.version)}${m.author ? ` · ${esc(m.author)}` : ""}</span>
      <br><span class="muted small">${esc(L(m.description))}</span></span>${m.url ? `<a href="${esc(m.url)}" target="_blank" rel="noopener" class="small">Info</a>` : ""}${action}</li>`;
  }).join("") : `<li class="muted">${esc(t("catalogEmpty"))}</li>`;
  el("catalog").innerHTML += (catalog.errors || []).map((e) => `<li class="problem small">${esc(e.catalog)}: ${esc(e.error)}</li>`).join("");
  el("catalog").querySelectorAll("[data-cat]").forEach((b) => b.addEventListener("click", () => installAddon(items[Number(b.dataset.cat)].zip)));
}

async function installAddon(fromCatalog) {
  const url = typeof fromCatalog === "string" ? fromCatalog : el("addonUrl").value.trim();
  if (!url) return;
  note("addonNote", t("installing"), "busy");
  const result = await api("addon-install", { url });
  note("addonNote", result.success ? result.message : result.error, result.success ? "ok" : "bad");
  if (result.success) {
    if (typeof fromCatalog !== "string") el("addonUrl").value = "";
    await refreshStatus();
    await loadCatalog();
    el("addType").value = result.type;
    el("addDescription").textContent = L(specOf(result.type)?.description || "");
  }
}

// ------------------------------------------------------------ Start

document.querySelectorAll("[data-setting]").forEach((node) =>
  node.addEventListener("change", () => saveSetting(node)));
el("placeButton").addEventListener("click", async () => {
  note("placeNote", t("finding"), "busy");
  const result = await api("place", { Place: el("Place").value });
  if (result.success) {
    state.settings.PlaceName = result.name;
    note("placeNote", result.message, "ok");
  } else {
    note("placeNote", result.error, "bad");
  }
});
el("Place").addEventListener("keydown", (e) => { if (e.key === "Enter") el("placeButton").click(); });
el("addType").addEventListener("change", () => { el("addDescription").textContent = L(specOf(el("addType").value)?.description || ""); });
el("addButton").addEventListener("click", addModule);
el("addonButton").addEventListener("click", () => installAddon());
el("catalogRefresh").addEventListener("click", () => loadCatalog(true));
el("orientButton").addEventListener("click", () => { portrait = !portrait; applyI18n(); renderPreview(); });
el("playlistButton").addEventListener("click", async () => {
  const result = await api("playlist", {});
  note("statusNote", result.success ? result.message : result.error, result.success ? "ok" : "bad");
});
window.addEventListener("beforeunload", () => { if (saveTimer) saveNow(); });

load().then(() => { loadCatalog(); setInterval(refreshStatus, 10000); });
