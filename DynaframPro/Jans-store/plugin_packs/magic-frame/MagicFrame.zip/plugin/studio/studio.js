"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/MagicFrame/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
let state = null;          // Antwort von /api/state
let rows = [];             // die Module, wie sie gespeichert werden
let lang = "de";
let saveTimer = null;
let portrait = false;
const secretsTyped = {};   // id -> {key: value}, nur was gerade getippt wurde

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Wie MagicMirror, nur auf dem DynaFrame: Wähle Module aus (Uhr, Wetter, Termine, Nachrichten, Abfahrten, Home Assistant …) und setz sie dahin, wo sie stehen sollen: oben, unten, links, rechts oder in die Mitte. Jedes Modul darf mehrmals vorkommen. Jede Änderung wird sofort gespeichert und ist nach ein paar Sekunden auf dem Bildschirm.",
    "Like MagicMirror, on your DynaFrame: pick modules (clock, weather, calendar, news, departures, Home Assistant …) and put them where you want them: top, bottom, left, right or centre. Every module can appear more than once. Changes are saved immediately and show up on the screen within seconds.",
    "Como MagicMirror, en tu DynaFrame: elige módulos (reloj, tiempo, calendario, noticias, salidas, Home Assistant …) y colócalos donde quieras: arriba, abajo, izquierda, derecha o centro. Cada módulo puede aparecer varias veces. Los cambios se guardan al instante y se ven en la pantalla en unos segundos."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  playlist: ["Playlist „Magic Frame“ anlegen", "Create playlist “Magic Frame”", "Crear lista «Magic Frame»"],
  factScene: ["Szene", "Scene", "Escena"],
  factModules: ["Module", "Modules", "Módulos"],
  factVersion: ["Version", "Version", "Versión"],
  sceneSeen: ["zu sehen", "on screen", "en pantalla"],
  sceneLast: ["zuletzt {time}", "last {time}", "última vez {time}"],
  sceneNever: ["noch nicht gezeigt", "not shown yet", "aún no se ha mostrado"],
  generalTitle: ["Allgemein", "General", "General"],
  placeHint: ["Der Ort für Wetter, Regen, Warnungen und die Haltestellen in der Nähe. Er wird einmal bei OpenStreetMap nachgeschlagen.",
    "The location for weather, rain, warnings and nearby stops. It is looked up once on OpenStreetMap.",
    "La ubicación para el tiempo, la lluvia, los avisos y las paradas cercanas. Se consulta una vez en OpenStreetMap."],
  place: ["Ort", "Location", "Ubicación"],
  placePh: ["z. B. Mainz oder Hauptstraße 1, Mainz", "e.g. London or 10 Downing St, London", "p. ej. Madrid o Gran Vía 1, Madrid"],
  find: ["Suchen", "Find", "Buscar"],
  finding: ["Suche …", "Searching …", "Buscando …"],
  placeNow: ["Eingestellt: {name}", "Set: {name}", "Configurada: {name}"],
  placeNone: ["Noch kein Ort eingestellt.", "No location set yet.", "Aún no hay ubicación."],
  units: ["Einheiten", "Units", "Unidades"],
  metric: ["°C, km/h", "°C, km/h", "°C, km/h"],
  imperial: ["°F, mph", "°F, mph", "°F, mph"],
  background: ["Hintergrund", "Background", "Fondo"],
  bgBlack: ["Schwarz (für Spiegel)", "Black (for mirrors)", "Negro (para espejos)"],
  bgNight: ["Nachtblau", "Night blue", "Azul noche"],
  scale: ["Schriftgröße (%)", "Text size (%)", "Tamaño de letra (%)"],
  clock24: ["24-Stunden-Uhr", "24-hour clock", "Reloj de 24 horas"],
  layoutTitle: ["Anordnung", "Layout", "Distribución"],
  layoutHint: ["So ungefähr sieht der Bildschirm aus. Zieh ein Modul in eine andere Region oder tipp es an, um es einzustellen.",
    "Roughly how the screen looks. Drag a module to another region, or tap it to set it up.",
    "Así se ve la pantalla más o menos. Arrastra un módulo a otra región o tócalo para configurarlo."],
  portrait: ["Hochformat", "Portrait", "Vertical"],
  landscape: ["Querformat", "Landscape", "Horizontal"],
  modulesTitle: ["Module", "Modules", "Módulos"],
  modulesHint: ["Die Reihenfolge innerhalb einer Region ist die Reihenfolge hier in der Liste.",
    "Within a region, modules appear in the order of this list.", "Dentro de una región, los módulos aparecen en el orden de esta lista."],
  region: ["Region", "Region", "Región"],
  addModule: ["Modul hinzufügen", "Add module", "Añadir módulo"],
  add: ["Hinzufügen", "Add", "Añadir"],
  up: ["Nach oben", "Move up", "Subir"],
  down: ["Nach unten", "Move down", "Bajar"],
  remove: ["Entfernen", "Remove", "Quitar"],
  fetch: ["Jetzt abrufen", "Fetch now", "Consultar ahora"],
  fetching: ["Rufe ab …", "Fetching …", "Consultando …"],
  fetchOk: ["Abgerufen.", "Fetched.", "Consultado."],
  stAt: ["zuletzt {time}", "last {time}", "última vez {time}"],
  stWait: ["wartet", "waiting", "en espera"],
  stVisible: ["holt nur, solange die Szene zu sehen ist", "fetches only while the scene is on screen", "solo consulta con la escena en pantalla"],
  saved: ["gespeichert", "saved", "guardado"],
  secretSet: ["gespeichert, leer lassen zum Behalten", "saved, leave empty to keep", "guardado, déjalo vacío para mantenerlo"],
  stopNone: ["Noch keine Haltestelle.", "No stop yet.", "Aún no hay parada."],
  stopNow: ["Haltestelle: {name}", "Stop: {name}", "Parada: {name}"],
  stopSearch: ["Haltestelle suchen", "Search stop", "Buscar parada"],
  stopNearby: ["In der Nähe", "Nearby", "Cerca"],
  stopEmpty: ["Nichts gefunden.", "Nothing found.", "No se encontró nada."],
  addonsTitle: ["Zusatzmodule", "Add-on modules", "Módulos adicionales"],
  addonsHint: ["Module von anderen. Sie kommen auf zwei Wegen: als eigenes Plugin aus einem Store (Magic Frame findet sie von selbst) oder als ZIP-Link hier. Wie man selbst eines baut, steht in <a href=\"https://github.com/Archonw/Dynaframe-Testing/blob/main/DynaframPro/Jans-store/plugin_packs/magic-frame/MODULES.md\" target=\"_blank\" rel=\"noopener\">MODULES.md</a>. Zusatzmodule laufen mit denselben Rechten wie Magic Frame; installiere nur, was du kennst.",
    "Modules made by others. They arrive in two ways: as their own plugin from a store (Magic Frame finds them by itself) or as a ZIP link here. How to build one is in <a href=\"https://github.com/Archonw/Dynaframe-Testing/blob/main/DynaframPro/Jans-store/plugin_packs/magic-frame/MODULES.md\" target=\"_blank\" rel=\"noopener\">MODULES.md</a>. Add-ons run with the same rights as Magic Frame; only install what you trust.",
    "Módulos de otras personas. Llegan de dos formas: como plugin propio desde una tienda (Magic Frame los encuentra solo) o como enlace ZIP aquí. Cómo crear uno está en <a href=\"https://github.com/Archonw/Dynaframe-Testing/blob/main/DynaframPro/Jans-store/plugin_packs/magic-frame/MODULES.md\" target=\"_blank\" rel=\"noopener\">MODULES.md</a>. Los módulos adicionales tienen los mismos permisos que Magic Frame; instala solo lo que conozcas."],
  addonUrl: ["ZIP-Link eines Zusatzmoduls", "ZIP link of an add-on module", "Enlace ZIP de un módulo adicional"],
  install: ["Installieren", "Install", "Instalar"],
  installing: ["Installiere …", "Installing …", "Instalando …"],
  addonNone: ["Noch keine Zusatzmodule installiert.", "No add-on modules installed yet.", "Aún no hay módulos adicionales."],
  addonFrom: ["aus Plugin {name}", "from plugin {name}", "del plugin {name}"],
  addonLink: ["per Link", "via link", "por enlace"],
  addonTag: ["Zusatz", "add-on", "adicional"],
  addonMissing: ["nicht installiert", "not installed", "no instalado"],
  credits: ["Daten: Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), Deutscher Wetterdienst über Bright Sky, OpenStreetMap/Nominatim. Die Idee stammt von MagicMirror² (magicmirror.builders); Magic Frame ist ein eigenständiger Nachbau für DynaFrame.",
    "Data: Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), German Weather Service via Bright Sky, OpenStreetMap/Nominatim. The idea comes from MagicMirror² (magicmirror.builders); Magic Frame is an independent take for DynaFrame.",
    "Datos: Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), servicio meteorológico alemán vía Bright Sky, OpenStreetMap/Nominatim. La idea viene de MagicMirror² (magicmirror.builders); Magic Frame es una versión independiente para DynaFrame."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
};

const li = () => Math.max(0, ["de", "en", "es"].indexOf(lang));
function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? row[li()] ?? row[0] : key;
  return String(text).replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}
const L = (list) => (Array.isArray(list) ? list[li()] ?? list[0] : String(list ?? ""));

function esc(text) {
  return String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}

function applyI18n() {
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  el("orientButton").textContent = t(portrait ? "landscape" : "portrait");
}

async function api(path, body) {
  const response = await fetch(`./api/${path}`, body === undefined ? { cache: "no-store" } : {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  return response.json();
}

function note(id, text, kind = "") {
  const node = el(id);
  node.textContent = text || "";
  node.className = `status ${kind}`;
}

// ------------------------------------------------------------ Laden

const specOf = (type) => state.catalog.modules.find((m) => m.type === type);
const regionLabel = (id) => L(state.catalog.regions.find((r) => r.id === id)?.label || id);

async function load() {
  state = await api("state");
  lang = state.settings.Language || "de";
  rows = state.modules.map((m) => ({ ...m, config: { ...m.config } }));
  for (const node of document.querySelectorAll("[data-setting]")) {
    const value = state.settings[node.dataset.setting];
    if (node.type === "checkbox") node.checked = !!value; else node.value = value ?? "";
  }
  el("Place").value = state.settings.Place || "";
  applyI18n();
  renderAll();
}

function renderAll() {
  renderStatus();
  renderPreview();
  renderModules();
  renderAddSelect();
  renderAddons();
}

function renderStatus() {
  el("factVersion").textContent = state.version;
  el("factModules").textContent = String(rows.length);
  const seen = el("factScene");
  seen.textContent = state.visible ? t("sceneSeen") : state.sceneSeen ? t("sceneLast", { time: clock(state.sceneSeen) }) : t("sceneNever");
  seen.className = state.visible ? "ok" : "";
  note("statusNote", state.note, state.note ? "bad" : "");
  note("placeNote", state.settings.PlaceName ? t("placeNow", { name: state.settings.PlaceName }) : t("placeNone"),
    state.settings.PlaceName ? "" : "bad");
}

function clock(iso) {
  const d = new Date(iso);
  const sameDay = d.toDateString() === new Date().toDateString();
  return d.toLocaleString(lang === "en" ? "en-GB" : lang === "es" ? "es-ES" : "de-DE",
    sameDay ? { hour: "2-digit", minute: "2-digit" } : { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

// ------------------------------------------------------------ Vorschau

const LAYOUT = [
  ["bar", ["top_bar"]], ["top", ["top_left", "top_center", "top_right"]],
  ["middle", ["middle_left", "middle_center", "middle_right"]],
  ["bottom", ["bottom_left", "bottom_center", "bottom_right"]], ["bar", ["bottom_bar"]],
];
let dragId = null;

function renderPreview() {
  const screen = el("screen");
  screen.classList.toggle("portrait", portrait);
  screen.innerHTML = LAYOUT.map(([kind, regions]) => `<div class="prow ${kind}">${regions.map((r) => {
    const side = r.endsWith("_left") ? "left" : r.endsWith("_right") ? "right" : r.endsWith("_bar") ? "bar" : "center";
    const chips = rows.filter((m) => m.region === r).map((m) => {
      const err = state.status[m.id]?.error;
      return `<span class="chip ${err ? "err" : ""}" draggable="true" data-id="${m.id}" title="${esc(err || "")}">${esc(moduleTitle(m))}</span>`;
    }).join("");
    return `<div class="preg ${side}" data-region="${r}">${chips || `<span class="rname">${esc(regionLabel(r))}</span>`}</div>`;
  }).join("")}</div>`).join("");
  screen.querySelectorAll(".chip").forEach((chip) => {
    chip.addEventListener("click", () => openModule(chip.dataset.id));
    chip.addEventListener("dragstart", (e) => { dragId = chip.dataset.id; chip.classList.add("dragging"); e.dataTransfer.setData("text/plain", dragId); });
    chip.addEventListener("dragend", () => { dragId = null; chip.classList.remove("dragging"); });
  });
  screen.querySelectorAll(".preg").forEach((region) => {
    region.addEventListener("dragover", (e) => { e.preventDefault(); region.classList.add("drop"); });
    region.addEventListener("dragleave", () => region.classList.remove("drop"));
    region.addEventListener("drop", (e) => {
      e.preventDefault();
      region.classList.remove("drop");
      const row = rows.find((m) => m.id === (dragId || e.dataTransfer.getData("text/plain")));
      if (!row || row.region === region.dataset.region) return;
      // ans Ende der neuen Region
      rows = rows.filter((m) => m !== row);
      row.region = region.dataset.region;
      rows.push(row);
      changed(true);
    });
  });
}

function moduleTitle(m) {
  const spec = specOf(m.type);
  return m.config.header || (spec ? L(spec.name) : m.type);
}

// ------------------------------------------------------------ Module

function openModule(id) {
  const node = document.querySelector(`.module[data-id="${id}"]`);
  if (!node) return;
  node.open = true;
  node.scrollIntoView({ behavior: "smooth", block: "center" });
  node.classList.add("flash");
  setTimeout(() => node.classList.remove("flash"), 1200);
}

function statusText(m) {
  const spec = specOf(m.type);
  const st = state.status[m.id];
  if (!spec || !spec.fields) return ["", ""];
  if (st?.error) return [st.error, "bad"];
  if (st?.at) return [t("stAt", { time: clock(st.at) }), "ok"];
  if (m.type === "departures" || m.type === "homeassistant") return [state.visible ? t("stWait") : t("stVisible"), ""];
  return ["", ""];
}

function renderModules() {
  const open = new Set([...document.querySelectorAll(".module[open]")].map((n) => n.dataset.id));
  el("modules").innerHTML = rows.map((m, index) => {
    const spec = specOf(m.type);
    const [stText, stKind] = statusText(m);
    const regionSelect = `<select data-region="${m.id}">${state.catalog.regions.map((r) =>
      `<option value="${r.id}" ${r.id === m.region ? "selected" : ""}>${esc(L(r.label))}</option>`).join("")}</select>`;
    const tag = spec?.addon ? `<span class="tag">${esc(t("addonTag"))}</span>` : "";
    return `<details class="module" data-id="${m.id}" ${open.has(m.id) ? "open" : ""}>
      <summary><span class="mname">${esc(moduleTitle(m))}</span>${tag}
        <span class="mregion">${esc(regionLabel(m.region))}</span>
        <span class="mstate ${stKind}">${esc(spec ? stText : t("addonMissing"))}</span></summary>
      <div class="module-body">
        ${spec ? `<p class="hint">${esc(L(spec.description))}</p>` : ""}
        <div class="grid">
          <label class="field"><span>${esc(t("region"))}</span>${regionSelect}</label>
          ${spec ? spec.fields.map((f) => fieldHtml(m, f)).join("") : ""}
        </div>
        <div class="module-tools">
          <button type="button" class="secondary icon-btn" data-up="${m.id}" ${index === 0 ? "disabled" : ""} title="${esc(t("up"))}">↑</button>
          <button type="button" class="secondary icon-btn" data-down="${m.id}" ${index === rows.length - 1 ? "disabled" : ""} title="${esc(t("down"))}">↓</button>
          ${spec && hasFetch(m.type) ? `<button type="button" class="secondary" data-fetch="${m.id}">${esc(t("fetch"))}</button>` : ""}
          <button type="button" class="danger" data-remove="${m.id}">${esc(t("remove"))}</button>
          <span class="status" id="note-${m.id}"></span>
        </div>
      </div>
    </details>`;
  }).join("");
  bindModules();
  updateShowIf();
}

const NO_FETCH = new Set(["clock", "compliments", "webpage"]);
const hasFetch = (type) => !NO_FETCH.has(type);

function fieldHtml(m, f) {
  const value = m.config[f.key];
  const name = `data-mid="${m.id}" data-key="${f.key}" data-kind="${f.kind}"`;
  const label = `<span>${esc(L(f.label))}</span>`;
  const hint = f.hint ? `<p class="hint">${esc(L(f.hint))}</p>` : "";
  const showIf = f.showIf ? `data-show-if='${esc(JSON.stringify(f.showIf))}'` : "";
  switch (f.kind) {
    case "bool":
      return `<label class="field check" ${showIf}><input type="checkbox" ${name} ${value ? "checked" : ""}>${label}</label>`;
    case "number":
      return `<label class="field" ${showIf}>${label}<input type="number" ${name} value="${esc(value)}"
        ${f.min != null ? `min="${f.min}"` : ""} ${f.max != null ? `max="${f.max}"` : ""}>${hint}</label>`;
    case "select":
      return `<label class="field" ${showIf}>${label}<select ${name}>${f.options.map((o) =>
        `<option value="${esc(o.value)}" ${String(o.value) === String(value) ? "selected" : ""}>${esc(L(o.label))}</option>`).join("")}</select>${hint}</label>`;
    case "textarea":
      return `<label class="field wide" ${showIf}>${label}<textarea ${name} rows="3">${esc(value)}</textarea>${hint}</label>`;
    case "secret":
      return `<label class="field" ${showIf}>${label}<input type="password" ${name} autocomplete="new-password"
        placeholder="${m.config[`has_${f.key}`] ? esc(t("secretSet")) : ""}" value="${esc(secretsTyped[m.id]?.[f.key] || "")}">${hint}</label>`;
    case "stop":
      return `<div class="field wide" ${showIf}>${label}
        <p class="status" id="stopNow-${m.id}">${esc(value?.name ? t("stopNow", { name: value.name }) : t("stopNone"))}</p>
        <div class="search-row"><input type="text" data-stop-q="${m.id}" placeholder="${esc(t("stopSearch"))}">
          <button type="button" class="secondary" data-stop-search="${m.id}">${esc(t("find"))}</button>
          <button type="button" class="secondary" data-stop-near="${m.id}">${esc(t("stopNearby"))}</button></div>
        <div class="stops" id="stops-${m.id}"></div>${hint}</div>`;
    default:
      return `<label class="field ${f.key === "url" || f.key === "header" ? "" : ""}" ${showIf}>${label}<input type="text" ${name} value="${esc(value)}">${hint}</label>`;
  }
}

function updateShowIf() {
  document.querySelectorAll("[data-show-if]").forEach((node) => {
    const id = node.closest(".module").dataset.id;
    const row = rows.find((m) => m.id === id);
    const cond = JSON.parse(node.dataset.showIf);
    node.hidden = !Object.entries(cond).every(([k, v]) => String(row.config[k]) === String(v));
  });
}

function bindModules() {
  const box = el("modules");
  box.querySelectorAll("[data-key]").forEach((input) => {
    const event = input.tagName === "SELECT" || input.type === "checkbox" ? "change" : "input";
    input.addEventListener(event, () => {
      const row = rows.find((m) => m.id === input.dataset.mid);
      const kind = input.dataset.kind;
      if (kind === "secret") {
        (secretsTyped[row.id] ||= {})[input.dataset.key] = input.value;
      } else {
        row.config[input.dataset.key] = kind === "bool" ? input.checked : kind === "number" ? Number(input.value) : input.value;
      }
      if (input.dataset.key === "header") {
        input.closest(".module").querySelector(".mname").textContent = moduleTitle(row);
        renderPreview();
      }
      updateShowIf();
      changed(false);
    });
  });
  box.querySelectorAll("[data-region]").forEach((select) => select.addEventListener("change", () => {
    const row = rows.find((m) => m.id === select.dataset.region);
    row.region = select.value;
    select.closest(".module").querySelector(".mregion").textContent = regionLabel(row.region);
    changed(true);
  }));
  const move = (id, step) => {
    const i = rows.findIndex((m) => m.id === id);
    const j = i + step;
    if (j < 0 || j >= rows.length) return;
    [rows[i], rows[j]] = [rows[j], rows[i]];
    changed(true, true);
  };
  box.querySelectorAll("[data-up]").forEach((b) => b.addEventListener("click", () => move(b.dataset.up, -1)));
  box.querySelectorAll("[data-down]").forEach((b) => b.addEventListener("click", () => move(b.dataset.down, 1)));
  box.querySelectorAll("[data-remove]").forEach((b) => b.addEventListener("click", () => {
    rows = rows.filter((m) => m.id !== b.dataset.remove);
    changed(true, true);
  }));
  box.querySelectorAll("[data-fetch]").forEach((b) => b.addEventListener("click", async () => {
    const id = b.dataset.fetch;
    await saveNow();
    note(`note-${id}`, t("fetching"), "busy");
    const result = await api("fetch", { id });
    note(`note-${id}`, result.success ? t("fetchOk") : result.error, result.success ? "ok" : "bad");
    refreshStatus();
  }));
  box.querySelectorAll("[data-stop-search]").forEach((b) => b.addEventListener("click", () =>
    findStops(b.dataset.stopSearch, box.querySelector(`[data-stop-q="${b.dataset.stopSearch}"]`).value)));
  box.querySelectorAll("[data-stop-q]").forEach((input) => input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") findStops(input.dataset.stopQ, input.value);
  }));
  box.querySelectorAll("[data-stop-near]").forEach((b) => b.addEventListener("click", () => findStops(b.dataset.stopNear, "")));
}

async function findStops(id, query) {
  const list = el(`stops-${id}`);
  list.innerHTML = `<span class="status busy">${esc(t("finding"))}</span>`;
  const result = await api("stop-search", { q: query });
  if (!result.success) { list.innerHTML = `<span class="status bad">${esc(result.error)}</span>`; return; }
  if (!result.stops.length) { list.innerHTML = `<span class="status">${esc(t("stopEmpty"))}</span>`; return; }
  list.innerHTML = result.stops.map((s, i) => `<button type="button" class="secondary" data-i="${i}">${esc(s.name)}${
    s.meters != null ? ` <span class="muted small">· ${s.meters} m</span>` : ""}</button>`).join("");
  list.querySelectorAll("button").forEach((b) => b.addEventListener("click", () => {
    const stop = result.stops[Number(b.dataset.i)];
    const row = rows.find((m) => m.id === id);
    row.config.stop = { id: stop.id, name: stop.name };
    el(`stopNow-${id}`).textContent = t("stopNow", { name: stop.name });
    list.innerHTML = "";
    changed(false);
  }));
}

function renderAddSelect() {
  const select = el("addType");
  const current = select.value;
  select.innerHTML = state.catalog.modules.map((m) =>
    `<option value="${m.type}">${esc(L(m.name))}${m.addon ? ` (${esc(t("addonTag"))})` : ""}</option>`).join("");
  if (current && state.catalog.modules.some((m) => m.type === current)) select.value = current;
  el("addDescription").textContent = L(specOf(select.value)?.description || "");
}

function newId() {
  return "m" + Math.random().toString(16).slice(2, 10);
}

function addModule() {
  const spec = specOf(el("addType").value);
  if (!spec) return;
  const config = {};
  spec.fields.forEach((f) => { config[f.key] = f.default; });
  const row = { id: newId(), type: spec.type, region: spec.region, config };
  rows.push(row);
  changed(true, true);
  setTimeout(() => openModule(row.id), 50);
}

// ------------------------------------------------------------ Speichern

function changed(layout, rebuild = false) {
  el("factModules").textContent = String(rows.length);
  if (layout) renderPreview();
  if (rebuild) renderModules();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 700);
}

async function saveNow() {
  clearTimeout(saveTimer);
  const payload = rows.map((m) => {
    const config = { ...m.config, ...(secretsTyped[m.id] || {}) };
    Object.keys(config).filter((k) => k.startsWith("has_")).forEach((k) => delete config[k]);
    return { id: m.id, type: m.type, region: m.region, config };
  });
  const result = await api("settings", { Modules: payload });
  if (result.success && result.modules) {
    // Die gespeicherte Fassung (mit has_*-Flags) übernehmen, ohne die Seite neu zu bauen
    const byId = Object.fromEntries(result.modules.map((m) => [m.id, m]));
    rows.forEach((m) => {
      const saved = byId[m.id];
      if (saved) Object.keys(saved.config).filter((k) => k.startsWith("has_")).forEach((k) => { m.config[k] = saved.config[k]; });
    });
  }
}

async function saveSetting(node) {
  const value = node.type === "checkbox" ? node.checked : node.type === "number" ? Number(node.value) : node.value;
  await api("settings", { [node.dataset.setting]: value });
  if (node.dataset.setting === "Language") {
    lang = value;
    applyI18n();
    renderAll();
  }
}

async function refreshStatus() {
  const next = await api("state");
  state.status = next.status;
  state.visible = next.visible;
  state.sceneSeen = next.sceneSeen;
  state.note = next.note;
  const catalogChanged = JSON.stringify(next.catalog) !== JSON.stringify(state.catalog) ||
    JSON.stringify(next.addonProblems) !== JSON.stringify(state.addonProblems);
  state.catalog = next.catalog;
  state.addonProblems = next.addonProblems;
  renderStatus();
  document.querySelectorAll(".module").forEach((node) => {
    const row = rows.find((m) => m.id === node.dataset.id);
    if (!row) return;
    const [text, kind] = statusText(row);
    const span = node.querySelector(".mstate");
    if (specOf(row.type)) { span.textContent = text; span.className = `mstate ${kind}`; }
  });
  if (catalogChanged) { renderAddSelect(); renderAddons(); renderModules(); }
  renderPreview();
}

// ------------------------------------------------------------ Zusatzmodule

function renderAddons() {
  const list = state.catalog.modules.filter((m) => m.addon);
  const problems = state.addonProblems || [];
  el("addons").innerHTML = (list.length || problems.length) ? list.map((m) => `<li>
      <span class="grow"><b>${esc(L(m.name))}</b> <span class="muted small">${esc(m.addon.version || "")}${m.addon.author ? ` · ${esc(m.addon.author)}` : ""}
      · ${esc(m.addon.origin === "link" ? t("addonLink") : t("addonFrom", { name: m.addon.origin }))}</span></span>
      ${m.addon.url ? `<a href="${esc(m.addon.url)}" target="_blank" rel="noopener" class="small">Info</a>` : ""}
      ${m.addon.origin === "link" ? `<button type="button" class="danger" data-addon-remove="${esc(m.type)}">${esc(t("remove"))}</button>` : ""}
    </li>`).join("") + problems.map((p) => `<li class="problem small">${esc(p.origin)}: ${esc(p.error)}</li>`).join("")
    : `<li class="muted">${esc(t("addonNone"))}</li>`;
  el("addons").querySelectorAll("[data-addon-remove]").forEach((b) => b.addEventListener("click", async () => {
    await api("addon-remove", { type: b.dataset.addonRemove });
    await refreshStatus();
  }));
}

async function installAddon() {
  const url = el("addonUrl").value.trim();
  if (!url) return;
  note("addonNote", t("installing"), "busy");
  const result = await api("addon-install", { url });
  note("addonNote", result.success ? result.message : result.error, result.success ? "ok" : "bad");
  if (result.success) {
    el("addonUrl").value = "";
    await refreshStatus();
    el("addType").value = result.type;
    el("addDescription").textContent = L(specOf(result.type)?.description || "");
  }
}

// ------------------------------------------------------------ Start

document.querySelectorAll("[data-setting]").forEach((node) =>
  node.addEventListener("change", () => saveSetting(node)));
el("placeButton").addEventListener("click", async () => {
  note("placeNote", t("finding"), "busy");
  const result = await api("place", { Place: el("Place").value });
  if (result.success) {
    state.settings.PlaceName = result.name;
    note("placeNote", result.message, "ok");
  } else {
    note("placeNote", result.error, "bad");
  }
});
el("Place").addEventListener("keydown", (e) => { if (e.key === "Enter") el("placeButton").click(); });
el("addType").addEventListener("change", () => { el("addDescription").textContent = L(specOf(el("addType").value)?.description || ""); });
el("addButton").addEventListener("click", addModule);
el("addonButton").addEventListener("click", installAddon);
el("orientButton").addEventListener("click", () => { portrait = !portrait; applyI18n(); renderPreview(); });
el("playlistButton").addEventListener("click", async () => {
  const result = await api("playlist", {});
  note("statusNote", result.success ? result.message : result.error, result.success ? "ok" : "bad");
});
window.addEventListener("beforeunload", () => { if (saveTimer) saveNow(); });

load().then(() => setInterval(refreshStatus, 10000));
