"""Die Datenquellen von Magic Frame.

Jede Funktion holt genau eine Sache und gibt ein schlichtes dict zurück, das
die Szene so verwenden kann. Fehler kommen als SourceError mit einem kurzen
Code, den plugin.py in einen Satz für die Plugin-Seite übersetzt.

Übernommen aus dem Pendler-Cockpit: Abfahrten (Transitous), Termine (ICS),
Nachrichten (RSS), DWD-Warnungen (Bright Sky), Adresssuche (Nominatim).
Neu: Wetter (Open-Meteo, weltweit, ohne Schlüssel) und Home Assistant.

Für Tests lassen sich alle Adressen über Umgebungsvariablen umbiegen
(MF_OPENMETEO_URL, MF_TRANSITOUS_URL, MF_BRIGHTSKY_URL, MF_NOMINATIM_URL).
"""

import math
import os
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

import requests

USER_AGENT = "DynaFrame-MagicFrame/0.1 (+https://github.com/Archonw/Dynaframe-Stuff)"
TIMEOUT = (8, 20)

OPENMETEO_URL = os.environ.get("MF_OPENMETEO_URL", "https://api.open-meteo.com/v1")
TRANSITOUS_URL = os.environ.get("MF_TRANSITOUS_URL", "https://api.transitous.org/api")
BRIGHTSKY_URL = os.environ.get("MF_BRIGHTSKY_URL", "https://api.brightsky.dev")
NOMINATIM_URL = os.environ.get("MF_NOMINATIM_URL", "https://nominatim.openstreetmap.org")

NEWS_FEEDS = {
    "tagesschau": "https://www.tagesschau.de/index~rss2.xml",
    "bbc": "https://feeds.bbci.co.uk/news/world/rss.xml",
    "elpais": "https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada",
}


class SourceError(Exception):
    """code ist kurz und maschinenlesbar, z. B. "key", "quota", "http:503"."""

    def __init__(self, code, detail=""):
        super().__init__(code if not detail else f"{code}: {detail}")
        self.code = code
        self.detail = detail


def _session():
    session = requests.Session()
    session.headers["User-Agent"] = USER_AGENT
    return session


_http = _session()


def _get(url, params=None, headers=None, expect="json"):
    try:
        response = _http.get(url, params=params, headers=headers, timeout=TIMEOUT)
    except requests.exceptions.SSLError as exc:
        raise SourceError("ssl", str(exc)) from exc
    except requests.RequestException as exc:
        raise SourceError("unreachable", str(exc)) from exc
    if response.status_code in (401, 403):
        raise SourceError("key", f"HTTP {response.status_code}")
    if response.status_code == 429:
        raise SourceError("quota", "HTTP 429")
    if response.status_code >= 400:
        raise SourceError(f"http:{response.status_code}")
    if expect == "text":
        return response.content
    try:
        return response.json()
    except ValueError as exc:
        raise SourceError("format", "keine JSON-Antwort") from exc


def utc_now():
    return datetime.now(timezone.utc)


def parse_time(value):
    """ISO-Zeit (mit Z oder Offset) -> Epoche, sonst None."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


# --------------------------------------------------------------------------
# Adresse -> Koordinaten (Nominatim, nur auf Knopfdruck)
# --------------------------------------------------------------------------

LATLON = re.compile(r"^\s*(-?\d{1,2}(?:\.\d+)?)\s*[,; ]\s*(-?\d{1,3}(?:\.\d+)?)\s*$")


def geocode(address, language="de"):
    """{"lat", "lon", "name"} für eine Adresse. "50.11, 8.68" geht auch."""
    address = str(address or "").strip()
    if not address:
        raise SourceError("no-address")
    match = LATLON.match(address)
    if match:
        lat, lon = float(match.group(1)), float(match.group(2))
        return {"lat": lat, "lon": lon, "name": f"{lat:.4f}, {lon:.4f}"}
    rows = _get(f"{NOMINATIM_URL}/search", params={"q": address, "format": "jsonv2", "limit": 1,
                                                    "accept-language": language})
    if not isinstance(rows, list) or not rows:
        raise SourceError("not-found")
    row = rows[0]
    try:
        return {"lat": float(row["lat"]), "lon": float(row["lon"]),
                "name": str(row.get("display_name") or address)[:160]}
    except (KeyError, TypeError, ValueError) as exc:
        raise SourceError("format") from exc


# --------------------------------------------------------------------------
# Abfahrten (Transitous)
# --------------------------------------------------------------------------

MOTIS_KIND = {"BUS": "bus", "COACH": "bus", "ODM": "bus", "FLEX": "bus", "TRAM": "tram", "CABLE_CAR": "tram",
              "FUNICULAR": "tram", "AERIAL_LIFT": "tram", "SUBWAY": "ubahn", "METRO": "ubahn",
              "SUBURBAN": "sbahn", "FERRY": "ferry", "RAIL": "train", "REGIONAL_RAIL": "train",
              "REGIONAL_FAST_RAIL": "train", "HIGHSPEED_RAIL": "train", "LONG_DISTANCE": "train",
              "NIGHT_RAIL": "train"}
NEARBY_KM = 2.0


def _km_between(lat1, lon1, lat2, lon2):
    rad = math.radians
    a = math.sin(rad(lat2 - lat1) / 2) ** 2 + \
        math.cos(rad(lat1)) * math.cos(rad(lat2)) * math.sin(rad(lon2 - lon1) / 2) ** 2
    return 6371.0 * 2 * math.asin(math.sqrt(min(1.0, a)))


def _motis_kinds(modes):
    return sorted({MOTIS_KIND.get(str(m), "bus") for m in modes or []})


def _motis_stops(rows, lat=None, lon=None):
    """Haltestellen aus Transitous (geocode oder map/stops); gleiche Namen nur einmal."""
    stops, seen = [], {}
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        stop_id = str(row.get("stopId") or row.get("id") or "")
        name = str(row.get("name") or "").strip()[:80]
        if not stop_id or not name or row.get("type") not in (None, "STOP"):
            continue
        meters = None
        if lat is not None and isinstance(row.get("lat"), (int, float)) and isinstance(row.get("lon"), (int, float)):
            meters = int(round(_km_between(lat, lon, row["lat"], row["lon"]) * 1000))
        stop = {"id": stop_id, "name": name, "meters": meters, "kinds": _motis_kinds(row.get("modes"))}
        if name in seen:
            other = seen[name]
            other["kinds"] = sorted(set(other["kinds"]) | set(stop["kinds"]))
            if meters is not None and (other["meters"] is None or meters < other["meters"]):
                other["meters"] = meters
            continue
        seen[name] = stop
        stops.append(stop)
    return stops


def transitous_nearby(lat, lon):
    dlat = NEARBY_KM / 111.0
    dlon = NEARBY_KM / (111.0 * max(0.2, math.cos(math.radians(lat))))
    rows = _get(f"{TRANSITOUS_URL}/v6/map/stops",
                params={"min": f"{lat - dlat:.5f},{lon - dlon:.5f}", "max": f"{lat + dlat:.5f},{lon + dlon:.5f}",
                        "grouped": "true"})
    stops = [s for s in _motis_stops(rows, lat, lon) if s["meters"] is None or s["meters"] <= NEARBY_KM * 1000]
    stops.sort(key=lambda s: s["meters"] if s["meters"] is not None else 99999)
    return stops[:12]


def transitous_search(query, lat=None, lon=None):
    query = str(query or "").strip()
    if not query:
        return []
    params = {"text": query[:80], "type": "STOP", "numResults": 12, "language": "de"}
    if lat is not None and lon is not None:
        params["place"] = f"{lat:.5f},{lon:.5f}"
    return _motis_stops(_get(f"{TRANSITOUS_URL}/v1/geocode", params=params), lat, lon)


def transitous_departures(stop_id, language="de"):
    payload = _get(f"{TRANSITOUS_URL}/v6/stoptimes",
                   params={"stopId": str(stop_id), "n": 30, "language": language})
    rows = payload.get("stopTimes") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        raise SourceError("format", "keine Abfahrten in der Antwort")
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        place = row.get("place") or {}
        planned = parse_time(place.get("scheduledDeparture"))
        actual = parse_time(place.get("departure")) if row.get("realTime") else None
        if planned is None:
            continue
        planned = int(planned)
        actual = int(actual) if actual is not None else None
        remarks = []
        for alert in place.get("alerts") or []:
            text = str((alert or {}).get("headerText") or (alert or {}).get("descriptionText") or "").strip()
            if text and text not in remarks:
                remarks.append(text[:140])
        line = str(row.get("routeShortName") or row.get("displayName") or "").strip()
        line = re.sub(r"^(Bus|STR|Tram|Str)\s+", "", line)[:12]
        out.append({
            "id": str(row.get("tripId") or f"{line}-{planned}")[:120],
            "line": line,
            "kind": MOTIS_KIND.get(str(row.get("mode")), "bus"),
            "direction": str(row.get("headsign") or "").strip()[:60],
            "planned": planned,
            "when": actual or planned,
            "delayMin": round((actual - planned) / 60) if actual is not None else None,
            "cancelled": bool(row.get("cancelled") or row.get("tripCancelled") or place.get("cancelled")),
            "platform": str(place.get("track") or place.get("scheduledTrack") or "")[:8],
            "remarks": remarks[:2],
        })
    out.sort(key=lambda d: d["when"])
    return out


# --------------------------------------------------------------------------
# Unwetterwarnungen des DWD (Bright Sky, nur Deutschland)
# --------------------------------------------------------------------------

SEVERITY = {"minor": 1, "moderate": 2, "severe": 3, "extreme": 4}


def dwd_alerts(lat, lon, language="de"):
    payload = _get(f"{BRIGHTSKY_URL}/alerts", params={"lat": f"{lat:.4f}", "lon": f"{lon:.4f}"})
    suffix = "de" if language == "de" else "en"
    alerts = []
    for row in (payload or {}).get("alerts") or []:
        if not isinstance(row, dict):
            continue
        level = SEVERITY.get(str(row.get("severity") or "").lower(), 1)
        alerts.append({
            "id": f"dwd:{row.get('alert_id') or row.get('id')}",
            "source": "DWD",
            "level": level,
            "title": str(row.get(f"headline_{suffix}") or row.get("headline_de") or row.get(f"event_{suffix}")
                         or "")[:120],
            "event": str(row.get(f"event_{suffix}") or row.get("event_de") or "")[:60],
            "text": str(row.get(f"description_{suffix}") or row.get("description_de") or "")[:400],
            "from": parse_time(row.get("onset") or row.get("effective")),
            "until": parse_time(row.get("expires")),
        })
    location = (payload or {}).get("location") or {}
    return {"alerts": alerts, "place": str(location.get("name") or location.get("district") or "")[:60]}


# --------------------------------------------------------------------------
# Termine aus ICS-Links (Nextcloud, Google, ...)
# Wiederkehrende Termine löst recurring_ical_events auf.
# --------------------------------------------------------------------------

NC_PUBLIC = re.compile(r"^(https?://.+?)/(?:index\.php/)?apps/calendar/(?:embed|p)/([A-Za-z0-9]+)")


def calendar_url(url):
    url = str(url or "").strip()
    if url.startswith("webcal://"):
        url = "https://" + url[len("webcal://"):]
    match = NC_PUBLIC.match(url)
    if match:
        return f"{match.group(1)}/remote.php/dav/public-calendars/{match.group(2)}?export"
    if re.search(r"/remote\.php/dav/(public-)?calendars/", url) and "export" not in url:
        return url.rstrip("/") + "?export"
    return url


def _calendar_text(url, user="", password=""):
    try:
        response = _http.get(calendar_url(url), timeout=TIMEOUT, auth=(user, password) if user else None,
                             headers={"Accept": "text/calendar, */*"})
    except requests.exceptions.SSLError as exc:
        raise SourceError("ssl", str(exc)) from exc
    except requests.RequestException as exc:
        raise SourceError("unreachable", str(exc)) from exc
    if response.status_code in (401, 403):
        raise SourceError("login", f"HTTP {response.status_code}")
    if response.status_code == 404:
        raise SourceError("not-found", "HTTP 404")
    if response.status_code >= 400:
        raise SourceError(f"http:{response.status_code}")
    if b"BEGIN:VCALENDAR" not in response.content[:2000]:
        raise SourceError("not-ics", response.headers.get("Content-Type", "")[:60])
    return response.content


def calendar_events(urls, user="", password="", days=7, now_epoch=None):
    """Termine ab jetzt bis Ende des n-ten Tages, sortiert. Ein Kalender, der nicht
    antwortet, fällt weg; nur wenn keiner antwortet, gibt es einen Fehler."""
    try:
        import icalendar
        import recurring_ical_events
    except ImportError as exc:
        raise SourceError("missing-lib", str(exc)) from exc
    start = datetime.fromtimestamp(now_epoch, timezone.utc).astimezone() if now_epoch else datetime.now().astimezone()
    day0 = start.replace(hour=0, minute=0, second=0, microsecond=0)
    end = day0 + timedelta(days=max(1, int(days)))
    events, errors = [], []
    for index, url in enumerate(urls[:5]):
        try:
            calendar = icalendar.Calendar.from_ical(_calendar_text(url, user, password))
        except SourceError as exc:
            errors.append(exc)
            continue
        except ValueError as exc:
            errors.append(SourceError("not-ics", str(exc)[:80]))
            continue
        name = str(calendar.get("X-WR-CALNAME") or "")[:40]
        for item in recurring_ical_events.of(calendar).between(day0, end):
            if str(item.get("STATUS") or "").upper() == "CANCELLED":
                continue
            begin, finish = item.get("DTSTART"), item.get("DTEND")
            if begin is None:
                continue
            begin = begin.dt
            finish = finish.dt if finish is not None else None
            all_day = not isinstance(begin, datetime)
            if all_day:
                first = datetime(begin.year, begin.month, begin.day).astimezone()
                last = datetime(finish.year, finish.month, finish.day).astimezone() if finish else first + timedelta(days=1)
            else:
                first = begin if begin.tzinfo else begin.astimezone()
                last = finish if isinstance(finish, datetime) else first
                last = last if last.tzinfo else last.astimezone()
            if last.timestamp() <= start.timestamp() and not (all_day and last > start):
                continue
            events.append({
                "title": str(item.get("SUMMARY") or "").strip()[:80] or "–",
                "location": str(item.get("LOCATION") or "").strip().split("\n")[0][:60],
                "start": int(first.timestamp()),
                "end": int(last.timestamp()),
                "allDay": all_day,
                "calendar": index,
                "calendarName": name,
            })
    if errors and len(errors) == len(urls[:5]):
        raise errors[0]
    events.sort(key=lambda e: (e["start"], not e["allDay"]))
    return events


# --------------------------------------------------------------------------
# Nachrichten (RSS oder Atom)
# --------------------------------------------------------------------------

def news(url):
    body = _get(url, expect="text")
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise SourceError("format", "kein RSS") from exc
    items = []
    for node in root.iter():
        tag = node.tag.rsplit("}", 1)[-1]
        if tag not in ("item", "entry"):
            continue
        title = published = ""
        for child in node:
            name = child.tag.rsplit("}", 1)[-1]
            if name == "title":
                title = "".join(child.itertext()).strip()
            elif name in ("pubDate", "published", "updated") and not published:
                published = (child.text or "").strip()
        if not title:
            continue
        at = None
        if published:
            try:
                at = parsedate_to_datetime(published).timestamp()
            except (TypeError, ValueError):
                at = parse_time(published)
        items.append({"title": re.sub(r"\s+", " ", title)[:200], "at": at})
        if len(items) >= 15:
            break
    if not items:
        raise SourceError("format", "keine Meldungen")
    return {"items": items}


# --------------------------------------------------------------------------
# Wetter (Open-Meteo: weltweit, ohne Schlüssel, frei für nicht-kommerzielle Nutzung)
# Eine Abfrage liefert alles für die Module Wetter, Vorhersage und Regen.
# --------------------------------------------------------------------------

def _num(value, digits=1):
    return round(float(value), digits) if isinstance(value, (int, float)) else None


def weather(lat, lon, imperial=False):
    params = {
        "latitude": f"{lat:.4f}", "longitude": f"{lon:.4f}",
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,is_day,weather_code,"
                   "wind_speed_10m,wind_direction_10m,precipitation",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,"
                 "precipitation_sum,sunrise,sunset",
        "minutely_15": "precipitation",
        "forecast_days": 7, "forecast_minutely_15": 12,
        "timezone": "auto", "timeformat": "unixtime",
    }
    if imperial:
        params.update(temperature_unit="fahrenheit", wind_speed_unit="mph", precipitation_unit="inch")
    payload = _get(f"{OPENMETEO_URL}/forecast", params=params)
    if not isinstance(payload, dict) or not isinstance(payload.get("current"), dict):
        raise SourceError("format", "kein Wetter in der Antwort")
    cur = payload["current"]
    current = {
        "temp": _num(cur.get("temperature_2m")),
        "feels": _num(cur.get("apparent_temperature")),
        "humidity": _num(cur.get("relative_humidity_2m"), 0),
        "code": int(cur.get("weather_code") or 0),
        "isDay": bool(cur.get("is_day", 1)),
        "wind": _num(cur.get("wind_speed_10m"), 0),
        "windDir": _num(cur.get("wind_direction_10m"), 0),
        "precip": _num(cur.get("precipitation")),
    }
    daily = []
    block = payload.get("daily") or {}
    times = block.get("time") or []
    for index, day in enumerate(times):
        def pick(name, digits=1):
            values = block.get(name) or []
            return _num(values[index], digits) if index < len(values) else None
        codes = block.get("weather_code") or []
        daily.append({
            "day": int(day),
            "code": int(codes[index] or 0) if index < len(codes) else 0,
            "max": pick("temperature_2m_max"), "min": pick("temperature_2m_min"),
            "pop": pick("precipitation_probability_max", 0), "sum": pick("precipitation_sum"),
            "sunrise": int((block.get("sunrise") or [0] * len(times))[index] or 0),
            "sunset": int((block.get("sunset") or [0] * len(times))[index] or 0),
        })
    rain = []
    block = payload.get("minutely_15") or {}
    for at, value in zip(block.get("time") or [], block.get("precipitation") or []):
        if isinstance(value, (int, float)):
            rain.append({"at": int(at), "mm": round(float(value), 2)})
    return {"current": current, "daily": daily, "rain": rain,
            "utcOffset": int(payload.get("utc_offset_seconds") or 0), "imperial": bool(imperial)}


# --------------------------------------------------------------------------
# Home Assistant: Zustände einzelner Entitäten (Langzeit-Token)
# --------------------------------------------------------------------------

def ha_states(base_url, token, entity_ids):
    base_url = str(base_url or "").strip().rstrip("/")
    if not base_url or not token:
        raise SourceError("no-key")
    if not re.match(r"^https?://", base_url):
        base_url = "http://" + base_url
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    out, missing = [], 0
    for entity_id in entity_ids[:20]:
        try:
            row = _get(f"{base_url}/api/states/{entity_id}", headers=headers)
        except SourceError as exc:
            if exc.code == "http:404":
                missing += 1
                out.append({"id": entity_id, "missing": True})
                continue
            raise
        if not isinstance(row, dict):
            raise SourceError("format", "keine Entität in der Antwort")
        attributes = row.get("attributes") or {}
        out.append({
            "id": entity_id,
            "state": str(row.get("state") or "")[:40],
            "name": str(attributes.get("friendly_name") or entity_id)[:60],
            "unit": str(attributes.get("unit_of_measurement") or "")[:12],
            "deviceClass": str(attributes.get("device_class") or "")[:30],
            "changed": parse_time(row.get("last_changed")),
        })
    if entity_ids and missing == len(entity_ids[:20]):
        raise SourceError("ha-none")
    return {"entities": out}
