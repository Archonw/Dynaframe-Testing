#!/usr/bin/env python3
"""Magic Frame: Pegelstand - nur der Träger für das Zusatzmodul.

Das Modul selbst liegt im Ordner magicframe/. Magic Frame findet es dort von
selbst; dieses Plugin muss nur installiert sein und meldet sich bereit.
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

plugin = create_plugin()
plugin.connect_sse()
plugin.ready()
plugin.log("Zusatzmodul Pegelstand für Magic Frame bereit.")
while True:  # das SDK beendet den Prozess bei SIGTERM
    time.sleep(3600)
