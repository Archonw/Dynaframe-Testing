# Weltkarte Live

Weltkarte Live zeigt eine ruhige Weltkarte mit Ländergrenzen, Tag und Nacht (die Tagseite leicht aufgehellt) und der Tag-Nacht-Grenze als warmer Linie. Darauf sind echte Live-Daten zu sehen:

- **Flugzeuge** (kleine gelbe Flugzeuge in Flugrichtung) vom OpenSky Network,
- **Schiffe** (kleine türkise Schiffe in Fahrtrichtung; dunkler, wenn sie stehen) von AISStream.io,
- **Blitze** von Blitzortung.org: ein neuer Blitz leuchtet kurz auf und verblasst dann von Gelb über Orange zu Rot.
- **Die ISS** mit ihrer Bahn: gestrichelt, wo sie in den nächsten 45 Minuten entlangfliegt, blasser, wo sie herkam.

Weltkarte Live besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene Weltkarte Live** zeichnet die Karte. Sie kommt wie ein Bild in eine Playlist (empfohlene Dauer 5 Minuten).
- **Das Plugin** holt die Daten und hält die Einstellungen.

## Einrichten

1. Paket installieren (Plugins > Hochladen, oder über den Store).
2. **Weltkarte Live öffnen**. Flugzeuge und Blitze laufen sofort, ohne Anmeldung.
3. Für Schiffe einen kostenlosen API-Key von [aisstream.io](https://aisstream.io) eintragen (Anmeldung mit GitHub, dann *API Keys* > *Create New API Key*).
4. **Playlist anlegen** drücken, oder die Szene selbst in eine Playlist aufnehmen.

## Einstellungen

- **Ausschnitt:** ganze Welt, Europa, Deutschland/Österreich/Schweiz, Nordamerika oder Ostasien. Im Hochformat zeigt die ganze Welt drei Globen: oben groß Europa und Afrika, darunter Amerika und Asien mit Australien.
- **Ebenen:** Flugzeuge, Schiffe, Blitze, Tag und Nacht, ISS, Legende und Uhr lassen sich einzeln ausschalten.
- **Blitze zeigen für … Minuten** (Standard 30).
- **Sprache** der Plugin-Seite und der Szene: Deutsch, Englisch, Spanisch.

## Woher die Daten kommen

- **OpenSky Network** (opensky-network.org): Ohne Konto gibt es 400 Abfragen-Credits am Tag; ein Blick auf die ganze Welt kostet 4, also aktualisiert das Plugin etwa alle 16 Minuten. Dazwischen rechnet die Szene jedes Flugzeug mit Kurs und Geschwindigkeit weiter. Mit einem kostenlosen OpenSky-Konto und einem *API Client* (Client-ID und Secret auf der Plugin-Seite eintragen) sind es 4000 Credits, also etwa alle 2 Minuten. Kleinere Ausschnitte kosten weniger und werden öfter geladen. Die Daten sind für nicht kommerzielle Nutzung frei.
- **AISStream.io**: Schiffe melden ihre Position per AIS; AISStream sammelt die Meldungen von Küstenstationen. Weltweit sind das sehr viele Meldungen pro Sekunde, darum hört das Plugin nur 45 Sekunden alle 10 Minuten zu (einstellbar unter *Datenmenge*) und behält jedes Schiff bis zu einer Stunde. Auf hoher See ohne Küstenstation sieht man keine Schiffe.
- **Blitzortung.org**: ein Netz von Freiwilligen mit eigenen Empfängern. Das Plugin ist mit der Live-Karte verbunden und bekommt jeden Blitz innerhalb weniger Sekunden. Die Daten sind nur für den privaten, nicht kommerziellen Gebrauch freigegeben.
- **ISS:** Die Bahndaten (wie ein TLE) holt das Plugin alle 6 Stunden von CelesTrak (Ersatz: wheretheiss.at), ohne Key. Position und Bahn rechnet die Szene daraus selbst; auf einen Tag ist das auf etwa 10 km genau.
- **Küsten und Grenzen:** Natural Earth (gemeinfrei), in der Szene enthalten.

## Wenn etwas nicht stimmt

- Die Plugin-Seite zeigt unter *Status* für jede Quelle, wie viele Objekte gerade da sind und wann die nächsten Daten kommen, oder warum nicht (keine Verbindung, Key abgelehnt, Tageskontingent erschöpft).
- **„Weltkarte Live antwortet nicht“ unten links in der Szene:** Das Plugin läuft nicht. Prüfe es auf der Plugins-Seite.
- **„Flugdaten von … Uhr“:** OpenSky hat länger als 30 Minuten nichts geliefert, meist weil das Tageskontingent aufgebraucht ist. Mit einem kostenlosen Konto passiert das nicht.
- Das Log steht auf dem Rahmen in `~/.local/share/dfr/logs/plugins.log`.
