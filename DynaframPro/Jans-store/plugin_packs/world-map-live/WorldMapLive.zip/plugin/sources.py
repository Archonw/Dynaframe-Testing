"""Die drei Datenquellen von Weltkarte Live.

- Flugzeuge: OpenSky Network, REST (/api/states/all). Ohne Konto reichen die
  400 Credits am Tag für etwa alle 16 Minuten die ganze Welt; mit einem
  kostenlosen API-Client (OAuth2, Client-ID und Secret) 4000 Credits, also
  etwa alle 2 Minuten. Dazwischen rechnet die Szene die Flugzeuge mit Kurs
  und Geschwindigkeit weiter.
- Schiffe: AISStream.io, Websocket, braucht einen kostenlosen API-Key. Das
  Plugin hört nur kurze Fenster lang zu (Standard 45 s alle 10 Minuten), weil
  der weltweite Strom sonst viele GB am Tag wären; Schiffe bleiben bis zu
  einer Stunde stehen, wenn sie nichts mehr melden.
- ISS: Bahnelemente (OMM/TLE) von CelesTrak, sonst wheretheiss.at, alle
  6 Stunden. Die Szene rechnet Position und Bahn daraus selbst.
- Blitze: Blitzortung.org, Websocket der Live-Karte, ohne Key. Die
  Nachrichten sind LZW-komprimiertes JSON (siehe decode_lzw).

Jede Quelle läuft in einem eigenen Thread und hat einen Status, den die
Plugin-Seite zeigt. Alle Adressen lassen sich über Umgebungsvariablen
umbiegen (für die Tests mit nachgebauten Servern).
"""

import calendar
import json
import math
import os
import random
import threading
import time
from collections import deque

import requests

try:
    import websocket  # Paket websocket-client
except ImportError:  # pragma: no cover - die Plugin-Seite sagt es
    websocket = None

OPENSKY_STATES = os.environ.get("WML_OPENSKY_URL", "https://opensky-network.org/api/states/all")
OPENSKY_TOKEN = os.environ.get(
    "WML_OPENSKY_TOKEN_URL",
    "https://auth.opensky-network.org/auth/realms/opensky-network/protocol/openid-connect/token")
AIS_URL = os.environ.get("WML_AIS_URL", "wss://stream.aisstream.io/v0/stream")
BLITZ_URLS = [u for u in os.environ.get("WML_BLITZ_URLS", "").split(",") if u] or [
    f"wss://ws{n}.blitzortung.org/" for n in (1, 7, 8, 5, 6, 3, 2)]
BLITZ_ORIGIN = "https://map.blitzortung.org"
ISS_URLS = [u for u in os.environ.get("WML_ISS_URLS", "").split(",") if u] or [
    "https://celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=json",
    "https://api.wheretheiss.at/v1/satellites/25544/tles?format=json"]
USER_AGENT = "DynaFrame-WorldMapLive/1.0 (+https://github.com/Archonw/Dynaframe-Stuff)"


def now():
    return time.time()


def in_box(box, lon, lat, margin=0.0):
    """box = (west, south, east, north); None heißt die ganze Welt."""
    if box is None:
        return True
    west, south, east, north = box
    return (south - margin) <= lat <= (north + margin) and (west - margin) <= lon <= (east + margin)


class Source:
    """Gemeinsamer Teil: Status, Thread, Aufwecken."""

    name = "source"

    def __init__(self, log):
        self.log = log
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.stopped = threading.Event()
        self.enabled = True
        self.box = None
        self.status = {"state": "off", "error": "", "at": 0.0, "next": 0.0, "count": 0}
        self.version = 0
        self.thread = None

    def set_status(self, state, error="", **extra):
        with self.lock:
            self.status.update(state=state, error=error, **extra)

    def start(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self._run, name=f"WorldMapLive-{self.name}", daemon=True)
            self.thread.start()

    def stop(self):
        self.stopped.set()
        self.wake.set()

    def poke(self):
        self.wake.set()

    def sleep(self, seconds):
        """Schläft, bis die Zeit um ist, jemand poke() ruft oder stop()."""
        self.wake.wait(max(0.0, seconds))
        self.wake.clear()
        return not self.stopped.is_set()

    def _run(self):
        while not self.stopped.is_set():
            try:
                pause = self.step()
            except Exception as exc:  # pragma: no cover - darf den Thread nie beenden
                self.log(f"{self.name}: {exc}", "warning")
                self.set_status("error", str(exc))
                pause = 60
            if not self.sleep(pause):
                break

    def step(self):  # pragma: no cover
        raise NotImplementedError


# --------------------------------------------------------------------------
# Flugzeuge: OpenSky Network
# --------------------------------------------------------------------------

class OpenSky(Source):
    name = "planes"
    MAX_AGE = 120          # Positionen, die älter sind, fallen weg
    BUDGET_ANON = 400      # Credits am Tag ohne Konto
    BUDGET_ACCOUNT = 4000  # mit kostenlosem Konto

    def __init__(self, log):
        super().__init__(log)
        self.client_id = ""
        self.client_secret = ""
        self.token = ""
        self.token_until = 0.0
        self.planes = []    # flach: lon, lat, kurs, m/s, je Flugzeug
        self.time = 0
        self.retry_at = 0.0

    def configure(self, enabled, box, client_id, client_secret):
        changed = (enabled, box, client_id, client_secret) != (self.enabled, self.box, self.client_id,
                                                               self.client_secret)
        if client_id != self.client_id or client_secret != self.client_secret:
            self.token, self.token_until = "", 0.0
        self.enabled, self.box, self.client_id, self.client_secret = enabled, box, client_id, client_secret
        if changed:
            self.retry_at = 0.0
            self.poke()

    def credits(self):
        if self.box is None:
            return 4
        west, south, east, north = self.box
        area = (east - west) * (north - south)
        return 1 if area <= 25 else 2 if area <= 100 else 3 if area <= 400 else 4

    def interval(self):
        """So oft, dass das Tageskontingent mit 10 % Reserve reicht."""
        budget = self.BUDGET_ACCOUNT if self.client_id and self.client_secret else self.BUDGET_ANON
        return max(90.0, 86400.0 * self.credits() / (budget * 0.9))

    def headers(self):
        headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        if not (self.client_id and self.client_secret):
            return headers
        if not self.token or now() > self.token_until - 60:
            response = requests.post(OPENSKY_TOKEN, data={
                "grant_type": "client_credentials", "client_id": self.client_id,
                "client_secret": self.client_secret}, timeout=(10, 20), headers={"User-Agent": USER_AGENT})
            if response.status_code in (400, 401):
                raise PermissionError("login")
            response.raise_for_status()
            body = response.json()
            self.token = body.get("access_token") or ""
            self.token_until = now() + float(body.get("expires_in") or 1800)
            if not self.token:
                raise PermissionError("login")
        headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def step(self):
        if not self.enabled:
            with self.lock:
                self.planes, self.status["count"] = [], 0
                self.version += 1
            self.set_status("off")
            return 3600
        wait = self.retry_at - now()
        if wait > 0:
            return wait
        params = {}
        if self.box is not None:
            west, south, east, north = self.box
            params = {"lamin": south, "lomin": west, "lamax": north, "lomax": east}
        self.set_status("loading", self.status["error"])
        try:
            headers = self.headers()
            response = requests.get(OPENSKY_STATES, params=params, headers=headers, timeout=(10, 60))
        except PermissionError:
            self.set_status("error", "login")
            self.retry_at = now() + 1800
            return 1800
        except requests.RequestException as exc:
            self.set_status("error", "network", detail=str(exc))
            self.retry_at = now() + 120
            return 120
        if response.status_code == 401 and self.token:
            self.token = ""
            self.retry_at = now() + 30
            return 30
        if response.status_code == 429:
            retry = float(response.headers.get("X-Rate-Limit-Retry-After-Seconds") or 900)
            retry = min(max(retry, 60.0), 6 * 3600.0)
            self.retry_at = now() + retry
            self.set_status("error", "limit", next=self.retry_at)
            self.log(f"OpenSky: Tageskontingent erschöpft, nächster Versuch in {round(retry / 60)} Minuten.",
                     "warning")
            return retry
        if response.status_code >= 400:
            self.set_status("error", f"http {response.status_code}")
            self.retry_at = now() + 300
            return 300
        body = response.json() or {}
        stamp = int(body.get("time") or now())
        flat = []
        for row in body.get("states") or []:
            try:
                lon, lat, on_ground = row[5], row[6], row[8]
                if lon is None or lat is None or on_ground:
                    continue
                seen = row[3] or row[4] or stamp
                if stamp - seen > self.MAX_AGE:
                    continue
                speed = float(row[9] or 0.0)
                track = float(row[10] or 0.0)
                # Auf den Zeitpunkt der Antwort vorrechnen.
                lon, lat = advance(lon, lat, track, speed, stamp - seen)
                flat.extend((round(lon, 3), round(lat, 3), int(round(track)) % 360, int(round(speed))))
            except (IndexError, TypeError, ValueError):
                continue
        interval = self.interval()
        with self.lock:
            self.planes, self.time = flat, stamp
            self.version += 1
            self.status.update(state="ok", error="", at=now(), next=now() + interval, count=len(flat) // 4,
                               detail="")
        self.retry_at = now() + interval
        return interval

    def snapshot(self):
        with self.lock:
            return {"ver": self.version, "t": self.time, "data": self.planes}


def advance(lon, lat, track_deg, speed_ms, seconds):
    """Auf der Kugel geradeaus weiter (für kurze Zeiten genau genug)."""
    if not speed_ms or seconds <= 0:
        return lon, lat
    distance = speed_ms * seconds / 6371000.0
    track = math.radians(track_deg)
    lat2 = lat + math.degrees(distance * math.cos(track))
    lat2 = max(-89.9, min(89.9, lat2))
    lon2 = lon + math.degrees(distance * math.sin(track) / max(0.01, math.cos(math.radians(lat))))
    lon2 = ((lon2 + 180.0) % 360.0) - 180.0
    return lon2, lat2


# --------------------------------------------------------------------------
# Schiffe: AISStream.io
# --------------------------------------------------------------------------

class AisStream(Source):
    name = "ships"
    KEEP = 3600        # so lange bleibt ein Schiff ohne neue Meldung
    PUBLISH = 20       # alle so viele Sekunden eine neue Version für die Szene
    MAX_SHIPS = 40000

    def __init__(self, log):
        super().__init__(log)
        self.key = ""
        self.listen = 45
        self.period = 600
        self.ships = {}     # mmsi -> (lon, lat, kurs, knoten, zeit)
        self.cache = {"ver": 0, "t": 0, "data": []}
        self.backoff = 30
        self.restart = threading.Event()

    def configure(self, enabled, box, key, listen, period):
        changed = (enabled, box, key) != (self.enabled, self.box, self.key)
        moved = box != self.box
        self.enabled, self.box, self.key = enabled, box, key
        self.listen, self.period = listen, max(period, listen + 30)
        if changed:
            if moved or not enabled:
                with self.lock:
                    self.ships.clear()
            self.backoff = 30
            self.restart.set()
            self.poke()

    def step(self):
        if not self.enabled:
            with self.lock:
                self.ships.clear()
            self.publish()
            self.set_status("off")
            return 3600
        if not self.key:
            self.set_status("nokey")
            return 3600
        if websocket is None:
            self.set_status("error", "nolib")
            return 3600
        self.restart.clear()
        started = now()
        error = self.listen_once()
        self.prune()
        self.publish()
        if error == "key":
            self.set_status("error", "key", next=now() + 6 * 3600)
            return 6 * 3600
        if error:
            self.set_status("error", error, next=now() + self.backoff)
            pause, self.backoff = self.backoff, min(self.backoff * 2, 1800)
            return pause
        self.backoff = 30
        pause = max(10.0, self.period - (now() - started))
        with self.lock:
            self.status.update(state="ok", error="", at=now(), next=now() + pause, detail="")
        return pause

    def subscription(self):
        if self.box is None:
            boxes = [[[-90, -180], [90, 180]]]
        else:
            west, south, east, north = self.box
            boxes = [[[south - 1, west - 1], [north + 1, east + 1]]]
        return json.dumps({"APIKey": self.key, "BoundingBoxes": boxes,
                           "FilterMessageTypes": ["PositionReport", "StandardClassBPositionReport"]})

    def listen_once(self):
        self.set_status("loading", self.status["error"])
        try:
            ws = websocket.create_connection(AIS_URL, timeout=15, header=[f"User-Agent: {USER_AGENT}"])
        except Exception as exc:
            self.status["detail"] = str(exc)
            return "network"
        received = 0
        last_publish = now()
        try:
            ws.send(self.subscription())
            ws.settimeout(10)
            until = now() + self.listen
            while now() < until and not self.stopped.is_set() and not self.restart.is_set():
                try:
                    raw = ws.recv()
                except websocket.WebSocketTimeoutException:
                    continue
                if not raw:
                    return "closed" if not received else ""
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8", "replace")
                try:
                    message = json.loads(raw)
                except ValueError:
                    continue
                if not isinstance(message, dict):
                    continue
                if message.get("error"):
                    text = str(message["error"])
                    self.log(f"AISStream: {text}", "warning")
                    return "key" if "key" in text.lower() else "server"
                if self.take(message):
                    received += 1
                if now() - last_publish > self.PUBLISH:
                    self.publish()
                    last_publish = now()
        except websocket.WebSocketConnectionClosedException:
            return "" if received else "closed"
        except Exception as exc:
            self.status["detail"] = str(exc)
            return "network" if not received else ""
        finally:
            try:
                ws.close()
            except Exception:
                pass
        return ""

    def take(self, message):
        meta = message.get("MetaData") or {}
        kind = message.get("MessageType") or ""
        body = (message.get("Message") or {}).get(kind) or {}
        mmsi = meta.get("MMSI") or body.get("UserID")
        lat = meta.get("latitude", body.get("Latitude"))
        lon = meta.get("longitude", body.get("Longitude"))
        try:
            lat, lon = float(lat), float(lon)
        except (TypeError, ValueError):
            return False
        if not mmsi or abs(lat) > 90 or abs(lon) > 180 or (abs(lat) < 0.01 and abs(lon) < 0.01):
            return False
        if not in_box(self.box, lon, lat, 1.0):
            return False
        cog = body.get("Cog")
        heading = body.get("TrueHeading")
        sog = body.get("Sog")
        try:
            sog = float(sog) if sog is not None and float(sog) < 102 else 0.0
        except (TypeError, ValueError):
            sog = 0.0
        try:
            course = float(cog) if cog is not None and float(cog) < 360 else None
        except (TypeError, ValueError):
            course = None
        if course is None:
            try:
                course = float(heading) if heading is not None and float(heading) < 360 else 0.0
            except (TypeError, ValueError):
                course = 0.0
        with self.lock:
            if len(self.ships) < self.MAX_SHIPS or mmsi in self.ships:
                self.ships[mmsi] = (lon, lat, course, sog, now())
        return True

    def prune(self):
        limit = now() - self.KEEP
        with self.lock:
            for mmsi in [m for m, s in self.ships.items() if s[4] < limit]:
                del self.ships[mmsi]

    def publish(self):
        """Alle Schiffe auf jetzt vorgerechnet, flach: lon, lat, kurs, knoten."""
        t = now()
        flat = []
        with self.lock:
            rows = list(self.ships.values())
        for lon, lat, course, sog, seen in rows:
            age = min(t - seen, 1800)
            if sog >= 0.5:
                lon, lat = advance(lon, lat, course, sog * 0.514444, age)
            flat.extend((round(lon, 3), round(lat, 3), int(round(course)) % 360, round(sog, 1)))
        with self.lock:
            self.version += 1
            self.cache = {"ver": self.version, "t": int(t), "data": flat}
            self.status["count"] = len(rows)

    def snapshot(self):
        with self.lock:
            return dict(self.cache)


# --------------------------------------------------------------------------
# Blitze: Blitzortung.org
# --------------------------------------------------------------------------

def decode_lzw(text):
    """Die Nachrichten der Live-Karte von Blitzortung sind LZW-gepackt."""
    if not text:
        return ""
    table = {}
    chars = list(text)
    current = chars[0]
    previous = current
    out = [current]
    code = 256
    for ch in chars[1:]:
        value = ord(ch)
        if value < 256:
            entry = ch
        else:
            entry = table.get(value, previous + current)
        out.append(entry)
        current = entry[0]
        table[code] = previous + current
        code += 1
        previous = entry
    return "".join(out)


class Blitzortung(Source):
    name = "lightning"
    MAX_STRIKES = 30000

    def __init__(self, log):
        super().__init__(log)
        self.minutes = 30
        self.strikes = deque()   # (id, lon, lat, zeit)
        self.next_id = 1
        self.host = random.randrange(len(BLITZ_URLS))
        self.boot = random.randrange(1, 1 << 30)   # erkennt die Szene einen Neustart
        self.backoff = 10
        self.restart = threading.Event()

    def configure(self, enabled, box, minutes):
        changed = (enabled, box) != (self.enabled, self.box)
        self.enabled, self.box, self.minutes = enabled, box, minutes
        if changed:
            with self.lock:
                self.strikes.clear()
                self.version += 1
            self.restart.set()
            self.poke()

    def step(self):
        if not self.enabled:
            self.set_status("off")
            return 3600
        if websocket is None:
            self.set_status("error", "nolib")
            return 3600
        self.restart.clear()
        url = BLITZ_URLS[self.host % len(BLITZ_URLS)]
        error = self.listen(url)
        if self.stopped.is_set() or self.restart.is_set():
            return 0
        # Nächstes Mal den nächsten Server, mit wachsender Pause.
        self.host += 1
        self.set_status("error", error or "closed", next=now() + self.backoff)
        pause, self.backoff = self.backoff, min(self.backoff * 2, 600)
        return pause

    def listen(self, url):
        self.set_status("loading", self.status["error"])
        try:
            ws = websocket.create_connection(url, timeout=15, origin=BLITZ_ORIGIN,
                                             header=[f"User-Agent: {USER_AGENT}"])
            ws.send('{"a":111}')
            ws.settimeout(20)
        except Exception as exc:
            self.status["detail"] = f"{url}: {exc}"
            return "network"
        self.log(f"Blitzortung: verbunden ({url}).")
        silent_since = now()
        try:
            while not self.stopped.is_set() and not self.restart.is_set():
                try:
                    raw = ws.recv()
                except websocket.WebSocketTimeoutException:
                    raw = None
                if raw:
                    if isinstance(raw, bytes):
                        raw = raw.decode("utf-8", "replace")
                    if self.take(raw):
                        silent_since = now()
                        self.backoff = 10
                        with self.lock:
                            if self.status["state"] != "ok":
                                self.status.update(state="ok", error="", detail="")
                            self.status["at"] = now()
                elif raw == "":
                    return "closed"
                # Weltweit blitzt es praktisch immer; 10 Minuten Stille heißt:
                # die Verbindung hängt.
                if now() - silent_since > 600:
                    return "silent"
                self.prune()
        except websocket.WebSocketConnectionClosedException:
            return "closed"
        except Exception as exc:
            self.status["detail"] = str(exc)
            return "network"
        finally:
            try:
                ws.close()
            except Exception:
                pass
        return ""

    def take(self, raw):
        try:
            try:
                data = json.loads(raw)
            except ValueError:
                data = json.loads(decode_lzw(raw))
            lat, lon = float(data["lat"]), float(data["lon"])
        except (KeyError, TypeError, ValueError, IndexError):
            return False
        stamp = data.get("time")
        try:
            stamp = float(stamp) / 1e9 if stamp and float(stamp) > 1e12 else float(stamp or now())
        except (TypeError, ValueError):
            stamp = now()
        if abs(stamp - now()) > 3600:
            stamp = now()
        if not in_box(self.box, lon, lat, 2.0):
            return True   # die Verbindung lebt, der Blitz ist nur woanders
        with self.lock:
            self.strikes.append((self.next_id, round(lon, 3), round(lat, 3), round(stamp, 1)))
            self.next_id += 1
            while len(self.strikes) > self.MAX_STRIKES:
                self.strikes.popleft()
        return True

    def prune(self):
        limit = now() - self.minutes * 60
        with self.lock:
            while self.strikes and self.strikes[0][3] < limit:
                self.strikes.popleft()
            self.status["count"] = len(self.strikes)

    def generation(self):
        return f"{self.boot}-{self.version}"

    def since(self, last_id):
        """Blitze mit id > last_id. Fängt die Szene neu an (0), alle im Fenster."""
        self.prune()
        with self.lock:
            rows = [s for s in self.strikes if s[0] > last_id]
            return {"last": self.next_id - 1, "gen": self.generation(),
                    "data": [v for s in rows for v in s[1:]]}


# --------------------------------------------------------------------------
# ISS: Bahnelemente
# --------------------------------------------------------------------------

def tle_epoch(field):
    """TLE-Epoche "26291.51234567" -> Unix-Zeit."""
    year = int(field[:2])
    year += 2000 if year < 57 else 1900
    day = float(field[2:])
    return calendar.timegm((year, 1, 1, 0, 0, 0, 0, 0, 0)) + (day - 1) * 86400


def parse_tle(line1, line2):
    return {
        "epoch": tle_epoch(line1[18:32].strip()),
        "ndot": float(line1[33:43]),
        "i": float(line2[8:16]), "raan": float(line2[17:25]), "e": float("0." + line2[26:33].strip()),
        "argp": float(line2[34:42]), "M": float(line2[43:51]), "n": float(line2[52:63]),
    }


def parse_omm(row):
    from datetime import datetime, timezone
    stamp = datetime.fromisoformat(row["EPOCH"].replace("Z", "")).replace(tzinfo=timezone.utc).timestamp()
    return {"epoch": stamp, "ndot": float(row.get("MEAN_MOTION_DOT") or 0), "i": float(row["INCLINATION"]),
            "raan": float(row["RA_OF_ASC_NODE"]), "e": float(row["ECCENTRICITY"]),
            "argp": float(row["ARG_OF_PERICENTER"]), "M": float(row["MEAN_ANOMALY"]),
            "n": float(row["MEAN_MOTION"])}


class Iss(Source):
    name = "iss"
    EVERY = 6 * 3600

    def __init__(self, log):
        super().__init__(log)
        self.elements = None

    def configure(self, enabled):
        if enabled != self.enabled:
            self.enabled = enabled
            self.poke()

    def step(self):
        if not self.enabled:
            self.set_status("off")
            return 3600
        for url in ISS_URLS:
            try:
                response = requests.get(url, timeout=(10, 20), headers={"User-Agent": USER_AGENT})
                response.raise_for_status()
                body = response.json()
                if isinstance(body, list):
                    body = body[0]
                elements = parse_omm(body) if "EPOCH" in body else parse_tle(body["line1"], body["line2"])
                if not 15 < elements["n"] < 17:
                    raise ValueError(f"unerwartete Bahn: {elements}")
            except Exception as exc:
                self.status["detail"] = f"{url}: {exc}"
                continue
            with self.lock:
                self.elements = elements
                self.version += 1
                self.status.update(state="ok", error="", at=now(), next=now() + self.EVERY, count=1, detail="")
            return self.EVERY
        # Alte Elemente bleiben ein paar Tage brauchbar.
        self.set_status("error", "network", next=now() + 1800)
        return 1800

    def snapshot(self):
        with self.lock:
            return self.elements
