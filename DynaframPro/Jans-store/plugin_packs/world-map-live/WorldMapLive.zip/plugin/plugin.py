#!/usr/bin/env python3
"""Weltkarte Live - der Plugin-Teil des Pakets.

Die Szene "world-map-live" zeichnet eine ruhige Weltkarte mit Tag und Nacht.
Dieses Plugin liefert ihr die Live-Daten:

- Flugzeuge vom OpenSky Network (ohne Konto, oder schneller mit einem
  kostenlosen API-Client),
- Schiffe von AISStream.io (kostenloser API-Key),
- Blitze von Blitzortung.org (ohne Key).

Die Quellen stehen in sources.py. Die Szene holt die Daten über den Proxy
der Weboberfläche auf :8003 (der Proxy der Engine lehnt lokale Adressen ab),
wie bei Fußball Live und Home Assistant Live. Die Szene kommt wie ein Bild
in eine Playlist; die Plugin-Seite kann dafür eine Playlist anlegen.
"""

import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import sources  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "WorldMapLive"
DISPLAY_NAME = "Weltkarte Live"
SCENE_ID = "world-map-live"        # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen; bleibt bei Updates

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30

# Kartenausschnitte: west, süd, ost, nord. Die Szene kennt dieselben.
REGIONS = {
    "world": None,
    "europe": (-25.0, 33.0, 45.0, 71.5),
    "dach": (4.5, 45.0, 18.0, 55.5),
    "north_america": (-130.0, 13.0, -55.0, 60.0),
    "east_asia": (90.0, -5.0, 150.0, 50.0),
}


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält die Keys
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SCHEMA = {
    "Language":            {"kind": "choice", "default": "de", "choices": texts.LANGUAGES},
    "Region":              {"kind": "choice", "default": "world", "choices": tuple(REGIONS)},
    "ShowPlanes":          {"kind": "bool", "default": True},
    "ShowShips":           {"kind": "bool", "default": True},
    "ShowLightning":       {"kind": "bool", "default": True},
    "ShowNight":           {"kind": "bool", "default": True},
    "ShowIss":             {"kind": "bool", "default": True},
    "ShowLegend":          {"kind": "bool", "default": True},
    "LightningMinutes":    {"kind": "int", "default": 30, "min": 5, "max": 120},
    "OpenSkyClientId":     {"kind": "text", "default": ""},
    "OpenSkyClientSecret": {"kind": "secret", "default": ""},
    "AisKey":              {"kind": "secret", "default": ""},
    "AisListenSeconds":    {"kind": "int", "default": 45, "min": 15, "max": 600},
    "AisEveryMinutes":     {"kind": "int", "default": 10, "min": 2, "max": 60},
    "PlaylistSeconds":     {"kind": "int", "default": 300, "min": 10, "max": 86400},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Die Quellen
# --------------------------------------------------------------------------

planes = sources.OpenSky(log)
ships = sources.AisStream(log)
lightning = sources.Blitzortung(log)
iss = sources.Iss(log)
ALL_SOURCES = (planes, ships, lightning, iss)


def apply_settings():
    values = settings()
    box = REGIONS[values["Region"]]
    planes.configure(values["ShowPlanes"], box, values["OpenSkyClientId"], values["OpenSkyClientSecret"])
    ships.configure(values["ShowShips"], box, values["AisKey"], values["AisListenSeconds"],
                    values["AisEveryMinutes"] * 60)
    lightning.configure(values["ShowLightning"], box, values["LightningMinutes"])
    iss.configure(values["ShowIss"])


def refresh_now():
    if planes.status["error"] != "limit":   # ein Kontingent-Stopp bleibt
        planes.retry_at = 0.0
    for source in ALL_SOURCES:
        source.poke()
    return {"success": True, "message": tr("Die Daten werden neu geladen.")}


# --------------------------------------------------------------------------
# Die Engine: eine Playlist für die Szene
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def make_playlist():
    """Legt die Playlist "Weltkarte Live" mit der Szene an (oder sagt, dass es
    sie schon gibt)."""
    name = DISPLAY_NAME if settings()["Language"] == "de" else "World Map Live"
    scene = find_scene()
    if scene is None:
        return {"success": False, "error": tr("Die Szene Weltkarte Live ist auf diesem Rahmen nicht installiert. "
                                              "Installiere das Paket noch einmal.")}
    try:
        existing = next((p for p in all_playlists() if p.get("name") in (DISPLAY_NAME, "World Map Live")), None)
        if existing:
            return {"success": True, "message": tr("Die Playlist {name} gibt es schon.", name=existing["name"])}
        created = engine_call("POST", "/playlists", {
            "name": name, "description": tr("Die Weltkarte mit Flugzeugen, Schiffen und Blitzen.")}) or {}
        playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
        if not playlist_id:
            raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
        engine_call("POST", f"/playlists/{playlist_id}/items",
                    {"dynamicSceneId": scene["id"], "customDurationSeconds": settings()["PlaylistSeconds"]})
    except EngineError as exc:
        log(f"Playlist: {exc}", "warning")
        return {"success": False, "error": tr("Konnte die Playlist nicht anlegen: {exc}", exc=exc)}
    log(f"Playlist {name} angelegt ({playlist_id}).")
    return {"success": True, "message": tr("Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens "
                                           "oder nimm die Szene in eine andere Playlist auf.", name=name)}


# --------------------------------------------------------------------------
# Was die Szene und die Seite bekommen
# --------------------------------------------------------------------------

def scene_payload(query):
    """Die Szene fragt alle paar Sekunden. Flugzeuge und Schiffe kommen nur
    mit, wenn sich ihre Version geändert hat; Blitze nur die neuen."""
    values = settings()
    have_planes = as_int((query.get("p") or ["-1"])[0], -1)
    have_ships = as_int((query.get("s") or ["-1"])[0], -1)
    gen = (query.get("g") or [""])[0]
    since = as_int((query.get("l") or ["0"])[0], 0)
    # Eine andere Generation (Neustart, anderer Ausschnitt): alles von vorn.
    strikes = lightning.since(since if gen == lightning.generation() else 0)
    plane_data = planes.snapshot()
    ship_data = ships.snapshot()
    if plane_data["ver"] == have_planes:
        plane_data = {"ver": plane_data["ver"]}
    if ship_data["ver"] == have_ships:
        ship_data = {"ver": ship_data["ver"]}
    return {
        "success": True,
        "now": now(),
        "settings": {k: values[k] for k in ("Language", "Region", "ShowPlanes", "ShowShips", "ShowLightning",
                                             "ShowNight", "ShowIss", "ShowLegend", "LightningMinutes")},
        "planes": plane_data,
        "ships": ship_data,
        "strikes": strikes,
        "iss": iss.snapshot(),
        "status": {name: source.status["state"] for name, source in
                   (("planes", planes), ("ships", ships), ("lightning", lightning))},
    }


ERRORS = {
    "network": "Keine Verbindung.",
    "limit": "Tageskontingent erschöpft; es geht später von selbst weiter.",
    "login": "Anmeldung abgelehnt. Stimmen Client-ID und Secret?",
    "key": "Der API-Key wird nicht angenommen.",
    "nolib": "Das Paket websocket-client fehlt. Installiere Weltkarte Live noch einmal.",
    "closed": "Der Server hat die Verbindung beendet.",
    "silent": "Keine Daten mehr; verbinde neu.",
    "server": "Der Server meldet einen Fehler.",
}


def clock(epoch):
    return time.strftime("%H:%M", time.localtime(epoch)) if epoch else ""


def source_payload(source):
    with source.lock:
        status = dict(source.status)
    state = status["state"]
    if state == "off":
        text = tr("Ausgeschaltet")
    elif state == "nokey":
        text = tr("Noch kein API-Key")
    elif state == "error":
        code = status["error"]
        text = tr(ERRORS.get(code, "Fehler: {code}"), code=code)
    elif state == "loading" and not status["at"]:
        text = tr("Lädt …")
    else:
        text = tr("{n} um {time}", n=texts.number(settings()["Language"], status["count"]), time=clock(status["at"]))
        if source is lightning:
            text = tr("{n} in {m} Min.", n=texts.number(settings()["Language"], status["count"]),
                      m=lightning.minutes)
        if source is iss:
            text = tr("Bahndaten von {time}", time=clock(status["at"]))
    next_text = ""
    if status.get("next") and status["next"] > now() and source is not lightning:
        next_text = tr("nächste um {time}", time=clock(status["next"]))
    tone = {"ok": "ok", "error": "bad", "loading": "busy"}.get(state, "")
    if state == "loading" and status["at"]:
        tone = "ok"
    return {"state": state, "tone": tone, "text": text, "next": next_text,
            "detail": status.get("detail") or ""}


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "planes": source_payload(planes),
        "planesEvery": round(planes.interval() / 60, 1),
        "ships": source_payload(ships),
        "lightning": source_payload(lightning),
        "iss": source_payload(iss),
        "theme": {"id": theme_id()},
    }


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(parse_qs(parsed.query)), cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if changed:
                    apply_settings()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(refresh_now())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None
_stop_requested = threading.Event()


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: refresh_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    apply_settings()
    for source in ALL_SOURCES:
        source.start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    for source in ALL_SOURCES:
        source.stop()
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
