"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/WorldMapLive/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["LightningMinutes", "PlaylistSeconds", "AisListenSeconds", "AisEveryMinutes"];
const CHECK_FIELDS = ["ShowPlanes", "ShowShips", "ShowLightning", "ShowNight", "ShowLegend"];
let current = null;

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  title: ["Weltkarte Live", "World Map Live", "Mapa del mundo en vivo"],
  lede: ["Eine ruhige Weltkarte mit Tag und Nacht, auf der echte Flugzeuge, Schiffe und Blitze zu sehen sind. Nimm die Szene Weltkarte Live wie ein Bild in eine Playlist. Jede Änderung hier wird sofort gespeichert.",
    "A calm world map with day and night, showing real aircraft, ships and lightning. Add the World Map Live scene to a playlist like a picture. Every change here is saved immediately.",
    "Un mapa del mundo tranquilo con el día y la noche, con aviones, barcos y rayos reales. Añade la escena Mapa del mundo en vivo a una lista como una imagen. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Jetzt neu laden", "Reload now", "Recargar ahora"],
  playlist: ["Playlist anlegen", "Create playlist", "Crear lista"],
  factPlanes: ["Flugzeuge", "Aircraft", "Aviones"],
  factShips: ["Schiffe", "Ships", "Barcos"],
  factLightning: ["Blitze", "Lightning", "Rayos"],
  factVersion: ["Version", "Version", "Versión"],
  mapTitle: ["Karte", "Map", "Mapa"],
  region: ["Ausschnitt", "Area", "Zona"],
  rWorld: ["Ganze Welt", "Whole world", "Todo el mundo"],
  rEurope: ["Europa", "Europe", "Europa"],
  rDach: ["Deutschland, Österreich, Schweiz", "Germany, Austria, Switzerland", "Alemania, Austria, Suiza"],
  rNA: ["Nordamerika", "North America", "Norteamérica"],
  rAsia: ["Ostasien", "East Asia", "Asia oriental"],
  minutes: ["Blitze zeigen für … Minuten", "Show lightning for … minutes", "Mostrar rayos durante … minutos"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  showPlanes: ["Flugzeuge", "Aircraft", "Aviones"],
  showShips: ["Schiffe", "Ships", "Barcos"],
  showLightning: ["Blitze", "Lightning", "Rayos"],
  showNight: ["Tag und Nacht", "Day and night", "Día y noche"],
  showLegend: ["Legende und Uhr", "Legend and clock", "Leyenda y reloj"],
  playlistHint: ["„Playlist anlegen“ macht eine Playlist „Weltkarte Live“ mit der Szene und der Dauer von oben. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "“Create playlist” makes a playlist “World Map Live” with the scene and the duration above. You can also add the scene to any playlist yourself.",
    "«Crear lista» crea una lista «World Map Live» con la escena y la duración de arriba. También puedes añadir la escena tú mismo a cualquier lista."],
  planesTitle: ["Flugzeuge", "Aircraft", "Aviones"],
  planesHint: ["Funktioniert ohne Anmeldung. Ohne Konto erlaubt OpenSky aber nur etwa alle 16 Minuten einen Blick auf die ganze Welt; dazwischen fliegen die Flugzeuge auf der Karte mit ihrem Kurs und ihrer Geschwindigkeit weiter. Mit einem kostenlosen Konto geht es etwa alle 2 Minuten.",
    "Works without signing in. Without an account, OpenSky only allows a look at the whole world about every 16 minutes; in between, the aircraft keep flying on the map with their course and speed. With a free account it is about every 2 minutes.",
    "Funciona sin registrarse. Sin cuenta, OpenSky solo permite ver todo el mundo cada 16 minutos aproximadamente; entre medias, los aviones siguen volando en el mapa con su rumbo y velocidad. Con una cuenta gratuita es cada 2 minutos aproximadamente."],
  planesEvery: ["Mit diesen Einstellungen: alle {n} Minuten.", "With these settings: every {n} minutes.", "Con esta configuración: cada {n} minutos."],
  save: ["Speichern", "Save", "Guardar"],
  osHowto: ["So bekommst du einen kostenlosen OpenSky-Zugang (optional)", "How to get free OpenSky access (optional)", "Cómo obtener acceso gratuito a OpenSky (opcional)"],
  os1: ['Auf <a href="https://opensky-network.org" target="_blank" rel="noopener">opensky-network.org</a> rechts oben auf <b>Login</b> und ein kostenloses Konto anlegen.',
    'On <a href="https://opensky-network.org" target="_blank" rel="noopener">opensky-network.org</a>, click <b>Login</b> at the top right and create a free account.',
    'En <a href="https://opensky-network.org" target="_blank" rel="noopener">opensky-network.org</a>, pulsa <b>Login</b> arriba a la derecha y crea una cuenta gratuita.'],
  os2: ["Angemeldet oben rechts auf deinen Namen, dann <b>Account</b>.", "Once signed in, click your name at the top right, then <b>Account</b>.",
    "Con la sesión iniciada, pulsa tu nombre arriba a la derecha y luego <b>Account</b>."],
  os3: ["Unter <b>API Client</b> einen neuen Client anlegen. Du bekommst eine <b>client_id</b> und ein <b>client_secret</b> (oder eine credentials.json mit beidem).",
    "Under <b>API Client</b>, create a new client. You get a <b>client_id</b> and a <b>client_secret</b> (or a credentials.json with both).",
    "En <b>API Client</b>, crea un cliente nuevo. Recibes un <b>client_id</b> y un <b>client_secret</b> (o un credentials.json con ambos)."],
  os4: ["Beides oben eintragen und Speichern.", "Enter both above and save.", "Introduce ambos arriba y guarda."],
  shipsTitle: ["Schiffe", "Ships", "Barcos"],
  shipsHint: ["Schiffe melden ihre Position über AIS. AISStream.io verteilt diese Meldungen kostenlos, braucht aber einen API-Key. Gezeigt werden die Schiffe in Reichweite der Küstenstationen, also vor allem in Küstennähe.",
    "Ships report their position via AIS. AISStream.io distributes these reports for free but needs an API key. You see the ships within range of the coastal stations, so mostly near the coast.",
    "Los barcos informan de su posición por AIS. AISStream.io distribuye estos mensajes gratis, pero necesita una clave API. Se ven los barcos al alcance de las estaciones costeras, sobre todo cerca de la costa."],
  aisHowto: ["So bekommst du den kostenlosen API-Key", "How to get the free API key", "Cómo obtener la clave API gratuita"],
  ais1: ['Öffne <a href="https://aisstream.io/authenticate" target="_blank" rel="noopener">aisstream.io</a> und melde dich mit deinem <b>GitHub</b>-Konto an.',
    'Open <a href="https://aisstream.io/authenticate" target="_blank" rel="noopener">aisstream.io</a> and sign in with your <b>GitHub</b> account.',
    'Abre <a href="https://aisstream.io/authenticate" target="_blank" rel="noopener">aisstream.io</a> e inicia sesión con tu cuenta de <b>GitHub</b>.'],
  ais2: ["Links auf <b>API Keys</b>, dann <b>Create New API Key</b>.", "Click <b>API Keys</b> on the left, then <b>Create New API Key</b>.",
    "Pulsa <b>API Keys</b> a la izquierda y luego <b>Create New API Key</b>."],
  ais3: ["Den Key kopieren, oben einfügen und Speichern.", "Copy the key, paste it above and save.", "Copia la clave, pégala arriba y guarda."],
  aisMore: ["Datenmenge", "Data volume", "Volumen de datos"],
  aisMoreText: ["Weltweit kommen über AISStream viele Meldungen pro Sekunde. Damit die Internetleitung nicht dauernd belastet wird, hört das Plugin nur kurz zu und sammelt die Schiffe; wer länger nichts meldet, verschwindet nach einer Stunde.",
    "Worldwide, AISStream sends many reports per second. So that your internet line is not busy all the time, the plugin only listens briefly and collects the ships; a ship that has not reported for an hour disappears.",
    "En todo el mundo, AISStream envía muchos mensajes por segundo. Para no cargar la conexión todo el tiempo, el plugin solo escucha un rato y reúne los barcos; el que no informa en una hora desaparece."],
  aisListen: ["Zuhören für … Sekunden", "Listen for … seconds", "Escuchar durante … segundos"],
  aisEvery: ["alle … Minuten", "every … minutes", "cada … minutos"],
  lightningTitle: ["Blitze", "Lightning", "Rayos"],
  lightningHint: ['Ohne Anmeldung. Die Blitze kommen live aus dem Netz von <a href="https://www.blitzortung.org" target="_blank" rel="noopener">Blitzortung.org</a>, das Freiwillige mit eigenen Empfängern betreiben. Die Daten sind nur für den privaten, nicht kommerziellen Gebrauch freigegeben. Neue Blitze leuchten auf der Karte kurz auf und verblassen dann von Gelb über Orange zu Rot.',
    'No sign-in needed. The lightning comes live from the <a href="https://www.blitzortung.org" target="_blank" rel="noopener">Blitzortung.org</a> network, run by volunteers with their own receivers. The data is for private, non-commercial use only. New strikes flash briefly on the map and then fade from yellow through orange to red.',
    'Sin registro. Los rayos llegan en directo de la red de <a href="https://www.blitzortung.org" target="_blank" rel="noopener">Blitzortung.org</a>, que mantienen voluntarios con sus propios receptores. Los datos son solo para uso privado y no comercial. Los rayos nuevos destellan en el mapa y luego pasan de amarillo a naranja y rojo.'],
  secretSet: ["gespeichert – zum Ändern neu eingeben, „-“ löscht", "saved – type a new one to change, “-” deletes", "guardado – escribe uno nuevo para cambiarlo, «-» lo borra"],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin is not responding.", "El plugin no responde."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return false;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  return true;
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "") {
  const node = el("statusNote");
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes, quiet = false) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    if (!quiet) setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function renderSource(name, info) {
  const dd = el(`fact${name}`);
  dd.textContent = info.text;
  dd.className = info.tone;
  dd.title = info.detail || "";
  el(`sub${name}`).textContent = info.next || "";
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  renderSource("Planes", state.planes);
  renderSource("Ships", state.ships);
  renderSource("Lightning", state.lightning);
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Dynaframe-Stuff/issues/new?title=" +
    encodeURIComponent(`[Weltkarte Live ${state.version}] `);
  el("planesEvery").textContent = s.ShowPlanes ? t("planesEvery", { n: String(state.planesEvery).replace(".", lang === "en" ? "." : ",") }) : "";
  el("Language").value = lang;
  if (document.activeElement !== el("Region")) el("Region").value = s.Region;
  for (const name of NUMBER_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
  for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
  if (document.activeElement !== el("OpenSkyClientId")) el("OpenSkyClientId").value = s.OpenSkyClientId;
  for (const name of ["OpenSkyClientSecret", "AisKey"]) {
    el(name).placeholder = state.secretsSet[name] ? t("secretSet") : "";
  }
  el("aisHowto").open = !state.secretsSet.AisKey;
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

async function post(path) {
  try {
    const result = await api(path, { method: "POST", body: "{}" });
    setStatus(result.message || t("saved"), "ok");
  } catch (error) {
    setStatus(error.message, "bad");
  }
  refresh();
}

el("Language").addEventListener("change", () => save({ Language: el("Language").value }, true));
el("Region").addEventListener("change", () => save({ Region: el("Region").value }));
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", () => save({ [name]: el(name).value }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", () => save({ [name]: el(name).checked }));
el("openSkySave").addEventListener("click", async () => {
  await save({ OpenSkyClientId: el("OpenSkyClientId").value.trim(), OpenSkyClientSecret: el("OpenSkyClientSecret").value.trim() });
  el("OpenSkyClientSecret").value = "";
});
el("aisSave").addEventListener("click", async () => {
  await save({ AisKey: el("AisKey").value.trim() });
  el("AisKey").value = "";
});
el("refreshButton").addEventListener("click", () => post("./api/refresh"));
el("playlistButton").addEventListener("click", () => post("./api/playlist"));

refresh();
setInterval(refresh, 5000);
