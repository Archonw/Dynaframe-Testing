/* Weltkarte Live - die Szene.
 *
 * Zeichnet eine ruhige Weltkarte (Miller-Projektion) mit Tag und Nacht und
 * legt die Live-Daten des Plugins Weltkarte Live darüber: Flugzeuge, Schiffe
 * und Blitze. Die Daten kommen über den Proxy der Weboberfläche auf :8003
 * (der Proxy der Engine lehnt lokale Adressen ab).
 *
 * Zwei Canvas: "map" (Meer, Land, Nacht; einmal pro Minute neu) und "live"
 * (Punkte; einmal pro Sekunde, flüssig nur solange ein Blitz aufleuchtet).
 * Flugzeuge und Schiffe werden zwischen zwei Datenständen mit Kurs und
 * Geschwindigkeit weitergerechnet.
 *
 * ?demo=1 zeigt erfundene Daten, ?region=europe einen Ausschnitt, ?lang=en.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "WorldMapLive";
  const POLL_MS = 2000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  const pluginBase = params.get("plugin") ||
    `${location.protocol}//${location.hostname}:8003/Plugins/Advanced/${PLUGIN_ID}/`;

  // west, süd, ost, nord - wie REGIONS im Plugin.
  const REGIONS = {
    world: null,
    europe: [-25, 33, 45, 71.5],
    dach: [4.5, 45, 18, 55.5],
    north_america: [-130, 13, -55, 60],
    east_asia: [90, -5, 150, 50],
  };
  const WORLD = { west: -180, south: -58, east: 180, north: 80, center: 11 };  // Naht in der Beringstraße

  const TEXT = {
    de: { planes: "Flugzeuge", ships: "Schiffe", strikes: "Blitze ({m} Min.)", nokey: "Schiffe: API-Key fehlt",
      offline: "Weltkarte Live antwortet nicht", stale: "Flugdaten von {time} Uhr" },
    en: { planes: "aircraft", ships: "ships", strikes: "lightning ({m} min)", nokey: "Ships: API key missing",
      offline: "World Map Live is not responding", stale: "Flight data from {time}" },
    es: { planes: "aviones", ships: "barcos", strikes: "rayos ({m} min)", nokey: "Barcos: falta la clave API",
      offline: "Mapa del mundo en vivo no responde", stale: "Datos de vuelo de las {time}" },
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };

  const RAD = Math.PI / 180;
  const el = (id) => document.getElementById(id);
  const mapCanvas = el("map");
  const liveCanvas = el("live");
  const mapCtx = mapCanvas.getContext("2d");
  const liveCtx = liveCanvas.getContext("2d");

  const state = {
    lang: params.get("lang") || "de",
    region: params.get("region") || "world",
    show: { planes: true, ships: true, lightning: true, night: true, legend: true },
    minutes: 30,
    skew: 0,                  // Uhr des Plugins minus Uhr der Szene, Sekunden
    planes: null,             // {t, lon, lat, vx, vy, n}
    ships: null,
    planesVer: -1, shipsVer: -1,
    strikes: [],              // {lon, lat, t, show}
    strikeGen: "", strikeLast: 0,
    status: {},
    reachable: true, failures: 0,
  };
  let view = null;
  let dpr = 1;
  let W = 0, H = 0;
  let readySent = false;
  let lastMapDraw = 0;
  let animating = false;

  const tx = (key, values = {}) => ((TEXT[state.lang] || TEXT.de)[key] || key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const now = () => Date.now() / 1000 + state.skew;
  const fmt = (n) => n.toLocaleString(LOCALES[state.lang] || "de-DE");

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  // ------------------------------------------------------------ Projektion

  const MILLER_MAX = miller(85);
  function miller(lat) {
    return 1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * lat * RAD));
  }
  function millerInverse(y) {
    return (2.5 * Math.atan(Math.exp(0.8 * y)) - 0.625 * Math.PI) / RAD;
  }

  function computeView() {
    const box = REGIONS[state.region];
    const world = !box;
    const center = world ? WORLD.center : (box[0] + box[2]) / 2;
    const west = world ? center - 180 : box[0];
    const east = world ? center + 180 : box[2];
    const south = world ? WORLD.south : box[1];
    const north = world ? WORLD.north : box[3];
    const x0 = (west - center) * RAD, x1 = (east - center) * RAD;
    const y0 = miller(south), y1 = miller(north);
    let scale = Math.min(W / (x1 - x0), H / (y1 - y0));
    if (world && W / H < 1.3) scale = H / (y1 - y0);      // Hochformat: Höhe füllen, Länge beschneiden
    let cy = (y0 + y1) / 2;
    const half = H / 2 / scale;
    if (half < MILLER_MAX) cy = Math.max(-MILLER_MAX + half, Math.min(MILLER_MAX - half, cy));
    else cy = 0;
    view = { world, center, scale, cx: 0, cy };
  }

  // Grad -> Bildschirm (CSS-Pixel). lon wird um die Mitte gewickelt.
  function px(lon) {
    const d = ((lon - view.center + 540) % 360) - 180;
    return W / 2 + d * RAD * view.scale;
  }
  function py(lat) {
    return H / 2 - (miller(lat) - view.cy) * view.scale;
  }
  // Ohne Wickeln, für die Küsten (die Kopien links und rechts zeichnet drawLand).
  function pxRaw(lon) {
    return W / 2 + (lon - view.center) * RAD * view.scale;
  }

  // ------------------------------------------------------------ Karte

  const COLORS = {
    sea: "#0d2340", seaDeep: "#081629", land: "#2b3e55", landEdge: "rgba(170, 200, 235, .25)",
    grid: "rgba(140, 170, 210, .07)", night: [1, 4, 12],
  };

  function ringPath(ctx, flat, shift) {
    let lon = flat[0] / 100, lat = flat[1] / 100;
    ctx.moveTo(pxRaw(lon) + shift, py(lat));
    for (let i = 2; i < flat.length; i += 2) {
      lon += flat[i] / 100;
      lat += flat[i + 1] / 100;
      ctx.lineTo(pxRaw(lon) + shift, py(lat));
    }
    ctx.closePath();
  }

  function drawLand(ctx) {
    const data = window.WORLD_MAP || { land: [], lakes: [] };
    const span = 2 * Math.PI * view.scale;
    const shifts = view.world || span < W * 3 ? [-span, 0, span] : [0];
    const land = new Path2D();
    for (const shift of shifts) for (const ring of data.land) ringPath(land, ring, shift);
    ctx.fillStyle = COLORS.land;
    ctx.fill(land);
    ctx.lineWidth = Math.max(0.6, Math.min(1.4, view.scale / 900));
    ctx.strokeStyle = COLORS.landEdge;
    ctx.stroke(land);
    const lakes = new Path2D();
    for (const shift of shifts) for (const ring of data.lakes) ringPath(lakes, ring, shift);
    ctx.fillStyle = COLORS.sea;
    ctx.fill(lakes);
    ctx.stroke(lakes);
  }

  function drawGrid(ctx) {
    ctx.beginPath();
    const step = view.world ? 30 : 10;
    for (let lat = -80; lat <= 80; lat += step) {
      const y = py(lat);
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
    }
    for (let lon = -180; lon < 180; lon += step) {
      const x = px(lon);
      ctx.moveTo(x, 0);
      ctx.lineTo(x, H);
    }
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;
    ctx.stroke();
  }

  // Sonnenstand (NOAA-Näherung): Deklination und Länge des Subsolarpunkts.
  function sun(epochSeconds) {
    const d = epochSeconds / 86400 - 10957.5;   // Tage seit J2000
    const g = (357.529 + 0.98560028 * d) * RAD;
    const q = 280.459 + 0.98564736 * d;
    const L = (q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * RAD;
    const e = (23.439 - 0.00000036 * d) * RAD;
    const ra = Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L)) / RAD;
    const dec = Math.asin(Math.sin(e) * Math.sin(L));
    let eqt = (q - ra) / 15;                         // Zeitgleichung in Stunden
    eqt -= 24 * Math.round(eqt / 24);
    const utcHours = ((epochSeconds / 3600) % 24 + 24) % 24;
    const lon = -15 * (utcHours - 12 + eqt);
    return { dec, lon: ((lon + 540) % 360) - 180 };
  }

  // Die Nachtseite auf einer kleinen Leinwand rechnen und weich hochskalieren.
  const nightCanvas = document.createElement("canvas");
  function drawNight(ctx) {
    const cols = Math.max(64, Math.min(360, Math.round(W / 5)));
    const rows = Math.max(36, Math.round(cols * H / W));
    nightCanvas.width = cols;
    nightCanvas.height = rows;
    const nctx = nightCanvas.getContext("2d");
    const image = nctx.createImageData(cols, rows);
    const s = sun(now());
    const sinDec = Math.sin(s.dec), cosDec = Math.cos(s.dec);
    const [r, g, b] = COLORS.night;
    for (let j = 0; j < rows; j++) {
      const y = H / 2 - ((j + 0.5) / rows) * H;          // Bildschirm -> Projektion
      const lat = millerInverse(y / view.scale + view.cy) * RAD;
      const sinLat = Math.sin(lat), cosLat = Math.cos(lat);
      for (let i = 0; i < cols; i++) {
        const x = ((i + 0.5) / cols) * W - W / 2;
        const lon = x / view.scale / RAD + view.center;
        const h = (lon - s.lon) * RAD;
        const alt = Math.asin(sinLat * sinDec + cosLat * cosDec * Math.cos(h)) / RAD;
        // Tag 0, bürgerliche bis astronomische Dämmerung weich bis 0.62
        let f = Math.max(0, Math.min(1, (0.5 - alt) / 15.5));
        f = f * f * (3 - 2 * f);                          // weiche Kante
        const a = 0.7 * f;
        const k = (j * cols + i) * 4;
        image.data[k] = r; image.data[k + 1] = g; image.data[k + 2] = b;
        image.data[k + 3] = Math.round(a * 255);
      }
    }
    nctx.putImageData(image, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(nightCanvas, 0, 0, W, H);

    // Die Sonne selbst, ganz leise.
    const sx = px(s.lon), sy = py(s.dec / RAD);
    const glow = ctx.createRadialGradient(sx, sy, 0, sx, sy, Math.min(W, H) * 0.22);
    glow.addColorStop(0, "rgba(255, 220, 150, .10)");
    glow.addColorStop(1, "rgba(255, 220, 150, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);
  }

  function drawMap() {
    const ctx = mapCtx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const sea = ctx.createLinearGradient(0, 0, 0, H);
    sea.addColorStop(0, COLORS.seaDeep);
    sea.addColorStop(0.5, COLORS.sea);
    sea.addColorStop(1, COLORS.seaDeep);
    ctx.fillStyle = sea;
    ctx.fillRect(0, 0, W, H);
    drawGrid(ctx);
    drawLand(ctx);
    if (state.show.night) drawNight(ctx);
    // Ränder leicht abdunkeln, damit Legende und Uhr ruhig stehen.
    const vignette = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.45, W / 2, H / 2, Math.max(W, H) * 0.75);
    vignette.addColorStop(0, "rgba(3, 7, 14, 0)");
    vignette.addColorStop(1, "rgba(3, 7, 14, .45)");
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, W, H);
    lastMapDraw = Date.now();
  }

  // ------------------------------------------------------------ Live-Punkte

  // Flach gespeichert, damit 10 000 Flugzeuge billig bleiben.
  function unpack(data, t, knots) {
    const n = Math.floor((data || []).length / 4);
    const out = { t, n, lon: new Float32Array(n), lat: new Float32Array(n), vx: new Float32Array(n),
      vy: new Float32Array(n), dx: new Float32Array(n), dy: new Float32Array(n), moving: new Uint8Array(n) };
    for (let i = 0; i < n; i++) {
      const lon = data[i * 4], lat = data[i * 4 + 1], course = data[i * 4 + 2] * RAD;
      const speed = data[i * 4 + 3] * (knots ? 0.514444 : 1);         // m/s
      out.lon[i] = lon; out.lat[i] = lat;
      out.dx[i] = Math.sin(course); out.dy[i] = Math.cos(course);
      out.vy[i] = speed * out.dy[i] / 111320;                          // Grad/s
      out.vx[i] = speed * out.dx[i] / (111320 * Math.max(0.05, Math.cos(lat * RAD)));
      out.moving[i] = speed > 0.5 ? 1 : 0;
    }
    return out;
  }

  function glyphSize() {
    return Math.max(2.2, Math.min(7, view.scale / 260));
  }

  function drawPlanes(ctx, t) {
    const p = state.planes;
    if (!p || !p.n) return;
    const dt = Math.max(0, Math.min(1800, t - p.t));
    const s = glyphSize();
    const path = new Path2D();
    for (let i = 0; i < p.n; i++) {
      const x = px(p.lon[i] + p.vx[i] * dt);
      const y = py(p.lat[i] + p.vy[i] * dt);
      if (x < -10 || x > W + 10 || y < -10 || y > H + 10) continue;
      // Ein schmaler Pfeil in Flugrichtung.
      const fx = p.dx[i], fy = -p.dy[i];
      path.moveTo(x + fx * s * 1.5, y + fy * s * 1.5);
      path.lineTo(x - fx * s + fy * s * 0.75, y - fy * s - fx * s * 0.75);
      path.lineTo(x - fx * s * 0.45, y - fy * s * 0.45);
      path.lineTo(x - fx * s - fy * s * 0.75, y - fy * s + fx * s * 0.75);
      path.closePath();
    }
    ctx.fillStyle = "rgba(255, 210, 127, .88)";
    ctx.fill(path);
  }

  function drawShips(ctx, t) {
    const p = state.ships;
    if (!p || !p.n) return;
    const dt = Math.max(0, Math.min(1800, t - p.t));
    const r = Math.max(1.1, glyphSize() * 0.5);
    const moving = new Path2D(), still = new Path2D();
    for (let i = 0; i < p.n; i++) {
      const x = px(p.lon[i] + p.vx[i] * dt);
      const y = py(p.lat[i] + p.vy[i] * dt);
      if (x < -5 || x > W + 5 || y < -5 || y > H + 5) continue;
      const path = p.moving[i] ? moving : still;
      path.moveTo(x + r, y);
      path.arc(x, y, r, 0, 2 * Math.PI);
    }
    ctx.fillStyle = "rgba(82, 214, 200, .38)";
    ctx.fill(still);
    ctx.fillStyle = "rgba(82, 214, 200, .85)";
    ctx.fill(moving);
  }

  // Blitze: frisch weiß-gelb, dann orange, dann ein leiser roter Punkt.
  const STRIKE_DELAY = 6;     // Sekunden; so erscheinen sie im echten Abstand
  const PULSE = 1.8;
  const AGE_STEPS = [
    [60, "rgba(255, 246, 200, .95)", 1.25],
    [300, "rgba(255, 200, 90, .85)", 1.0],
    [900, "rgba(255, 140, 60, .6)", 0.85],
    [Infinity, "rgba(240, 80, 60, .38)", 0.75],
  ];

  function drawStrikes(ctx, t) {
    if (!state.strikes.length) return false;
    const limit = t - state.minutes * 60;
    if (state.strikes[0].show < limit) state.strikes = state.strikes.filter((s) => s.show >= limit);
    const r = Math.max(1.4, glyphSize() * 0.6);
    const buckets = AGE_STEPS.map(() => new Path2D());
    const pulses = [];
    for (const s of state.strikes) {
      const age = t - s.show;
      if (age < 0) continue;
      const x = px(s.lon), y = py(s.lat);
      if (x < -20 || x > W + 20 || y < -20 || y > H + 20) continue;
      if (age < PULSE) pulses.push([x, y, age / PULSE]);
      let k = 0;
      while (age > AGE_STEPS[k][0]) k++;
      const rr = r * AGE_STEPS[k][2];
      buckets[k].moveTo(x + rr, y);
      buckets[k].arc(x, y, rr, 0, 2 * Math.PI);
    }
    for (let k = AGE_STEPS.length - 1; k >= 0; k--) {
      ctx.fillStyle = AGE_STEPS[k][1];
      ctx.fill(buckets[k]);
    }
    const ring = Math.max(10, glyphSize() * 6);
    for (const [x, y, f] of pulses) {
      const a = 1 - f;
      const flash = ctx.createRadialGradient(x, y, 0, x, y, ring * 0.9);
      flash.addColorStop(0, `rgba(255, 255, 235, ${0.85 * a * a})`);
      flash.addColorStop(1, "rgba(255, 255, 235, 0)");
      ctx.fillStyle = flash;
      ctx.beginPath();
      ctx.arc(x, y, ring * 0.9, 0, 2 * Math.PI);
      ctx.fill();
      ctx.strokeStyle = `rgba(255, 236, 160, ${0.8 * a})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(x, y, 2 + ring * f, 0, 2 * Math.PI);
      ctx.stroke();
    }
    // Läuft noch ein Aufleuchten, oder kommt gleich eins?
    return pulses.length > 0 || state.strikes.some((s) => s.show > t && s.show - t < 1.2);
  }

  function drawLive() {
    const ctx = liveCtx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const t = now();
    if (state.show.ships) drawShips(ctx, t);
    if (state.show.planes) drawPlanes(ctx, t);
    return state.show.lightning ? drawStrikes(ctx, t) : false;
  }

  function frame() {
    if (document.hidden) { animating = false; return; }
    const busy = drawLive();
    if (busy) requestAnimationFrame(frame);
    else animating = false;
  }

  function kick() {
    if (!animating && !document.hidden) {
      animating = true;
      requestAnimationFrame(frame);
    }
  }

  // ------------------------------------------------------------ Legende

  function renderLegend() {
    el("legend").classList.toggle("hidden", !state.show.legend);
    el("clockBox").classList.toggle("hidden", !state.show.legend);
    el("rowPlanes").classList.toggle("off", !state.show.planes);
    el("rowShips").classList.toggle("off", !state.show.ships);
    el("rowStrikes").classList.toggle("off", !state.show.lightning);
    el("lPlanes").textContent = tx("planes");
    el("lShips").textContent = tx("ships");
    el("lStrikes").textContent = tx("strikes", { m: state.minutes });
    const nokey = state.status.ships === "nokey";
    el("rowShips").classList.toggle("dim", nokey);
    el("nPlanes").textContent = state.planes ? fmt(state.planes.n) : "–";
    el("nShips").textContent = state.ships && !nokey ? fmt(state.ships.n) : "–";
    const t = now();
    el("nStrikes").textContent = fmt(state.strikes.filter((s) => s.show <= t).length);
    const notes = [];
    if (!state.reachable) notes.push(tx("offline"));
    else if (nokey && state.show.ships) notes.push(tx("nokey"));
    if (state.planes && state.show.planes && t - state.planes.t > 1800) {
      notes.push(tx("stale", { time: new Date(state.planes.t * 1000).toLocaleTimeString(LOCALES[state.lang],
        { hour: "2-digit", minute: "2-digit" }) }));
    }
    el("note").textContent = notes.join(" · ");
  }

  function renderClock() {
    const d = new Date(now() * 1000);
    const locale = LOCALES[state.lang] || "de-DE";
    el("clock").textContent = d.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" });
    el("date").textContent = d.toLocaleDateString(locale, { weekday: "long", day: "numeric", month: "long" });
  }

  // ------------------------------------------------------------ Daten

  function apply(payload) {
    state.skew = (payload.now || Date.now() / 1000) - Date.now() / 1000;
    const s = payload.settings || {};
    const before = JSON.stringify([state.region, state.show.night]);
    if (s.Language) state.lang = s.Language;
    if (s.Region && !params.get("region")) state.region = s.Region;
    state.show = { planes: s.ShowPlanes !== false, ships: s.ShowShips !== false, lightning: s.ShowLightning !== false,
      night: s.ShowNight !== false, legend: s.ShowLegend !== false };
    state.minutes = s.LightningMinutes || 30;
    state.status = payload.status || {};
    if (JSON.stringify([state.region, state.show.night]) !== before) {
      computeView();
      drawMap();
    }
    const planes = payload.planes || {};
    if (planes.data) state.planes = unpack(planes.data, planes.t, false);
    if (planes.ver !== undefined) state.planesVer = planes.ver;
    const ships = payload.ships || {};
    if (ships.data) state.ships = unpack(ships.data, ships.t, true);
    if (ships.ver !== undefined) state.shipsVer = ships.ver;
    const strikes = payload.strikes || {};
    if (strikes.gen !== state.strikeGen) {
      state.strikes = [];
      state.strikeGen = strikes.gen;
    }
    const data = strikes.data || [];
    const t = now();
    const first = state.strikeLast === 0;
    for (let i = 0; i + 2 < data.length; i += 3) {
      const stamp = data[i + 2];
      // Ältere erscheinen sofort und still; neue im Abstand, in dem sie fielen.
      const show = first || stamp + STRIKE_DELAY < t - 30 ? stamp : Math.max(t, stamp + STRIKE_DELAY);
      state.strikes.push({ lon: data[i], lat: data[i + 1], t: stamp, show });
    }
    if (data.length) state.strikes.sort((a, b) => a.show - b.show);
    if (strikes.last !== undefined) state.strikeLast = strikes.last;
  }

  async function poll() {
    if (DEMO) return;
    const url = new URL("api/scene", pluginBase);
    url.searchParams.set("p", state.planesVer);
    url.searchParams.set("s", state.shipsVer);
    url.searchParams.set("g", state.strikeGen);
    url.searchParams.set("l", state.strikeLast);
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 15000);
    try {
      const response = await fetch(url, { cache: "no-store", signal: abort.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      apply(await response.json());
      state.failures = 0;
      state.reachable = true;
    } catch (_) {
      state.failures += 1;
      if (state.failures >= 3) state.reachable = false;
    } finally {
      clearTimeout(timer);
    }
    renderLegend();
    kick();
  }

  // ------------------------------------------------------------ Demo

  function demo() {
    const rand = (a, b) => a + Math.random() * (b - a);
    const hubs = [[8.6, 50.0], [-0.4, 51.5], [2.5, 49.0], [-73.8, 40.6], [-118.4, 33.9], [139.8, 35.5],
      [103.9, 1.4], [55.4, 25.2], [-46.5, -23.4], [151.2, -33.9], [28.8, 41.3], [116.6, 40.1], [-87.9, 41.9],
      [77.1, 28.6], [-3.6, 40.5], [12.2, 41.8], [-79.6, 43.7], [18.6, -33.9], [-99.1, 19.4], [37.4, 55.9]];
    const planes = [];
    for (let i = 0; i < 5200; i++) {
      const a = hubs[Math.floor(Math.random() * hubs.length)];
      const b = hubs[Math.floor(Math.random() * hubs.length)];
      if (a === b) continue;
      const f = Math.random();
      const lon = a[0] + (b[0] - a[0]) * f + rand(-2, 2), lat = a[1] + (b[1] - a[1]) * f + rand(-1.5, 1.5);
      const course = (Math.atan2(b[0] - a[0], b[1] - a[1]) / RAD + 360) % 360;
      planes.push(+lon.toFixed(3), +lat.toFixed(3), Math.round(course), Math.round(rand(200, 260)));
    }
    const lanes = [[[-5.6, 36], [32, 31.5]], [[32.5, 29.9], [43.4, 12.6]], [[43.4, 12.6], [80, 6]],
      [[80, 6], [103.8, 1.3]], [[103.8, 1.3], [121, 25]], [[121, 25], [139.7, 35]], [[-5, 48.5], [4, 52]],
      [[4, 52], [10, 54.5]], [[-74, 40.5], [-5, 48.5]], [[-80, 25], [-74, 40.5]], [[-79.5, 9], [-118, 33.7]],
      [[18.5, -34.4], [55, -20]], [[-43, -23], [-5, 36]]];
    const ships = [];
    for (let i = 0; i < 3800; i++) {
      const [a, b] = lanes[Math.floor(Math.random() * lanes.length)];
      const f = Math.random();
      ships.push(+(a[0] + (b[0] - a[0]) * f + rand(-1.2, 1.2)).toFixed(3),
        +(a[1] + (b[1] - a[1]) * f + rand(-1.2, 1.2)).toFixed(3), Math.round(rand(0, 359)),
        Math.random() < 0.7 ? +rand(8, 20).toFixed(1) : 0);
    }
    const cells = [[12, 48.5], [-90, 33], [-60, -5], [25, -2], [100, 15], [130, -15], [77, 22]];
    const t = Date.now() / 1000;
    const strikes = [];
    for (let i = 0; i < 1400; i++) {
      const c = cells[i % cells.length];
      const r = Math.sqrt(Math.random()) * 3, a = rand(0, 2 * Math.PI);
      strikes.push(+(c[0] + r * Math.cos(a) * 1.4).toFixed(3), +(c[1] + r * Math.sin(a)).toFixed(3), t - rand(0, 1700));
    }
    apply({ now: t, settings: { Language: state.lang, Region: state.region, LightningMinutes: 30 },
      planes: { ver: 1, t, data: planes }, ships: { ver: 1, t, data: ships },
      strikes: { gen: "demo", last: 1, data: strikes }, status: {} });
    setInterval(() => {
      const c = cells[Math.floor(Math.random() * cells.length)];
      const n = Date.now() / 1000;
      apply({ now: n, settings: { Language: state.lang, Region: state.region, LightningMinutes: 30 },
        strikes: { gen: "demo", last: 2, data: [c[0] + rand(-3, 3), c[1] + rand(-2, 2), n - 6] } });
      renderLegend();
      kick();
    }, 900);
  }

  // ------------------------------------------------------------ Start

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    for (const canvas of [mapCanvas, liveCanvas]) {
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
    }
    computeView();
    drawMap();
    drawLive();
  }

  window.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { drawMap(); kick(); } });
  resize();
  renderClock();
  renderLegend();
  ready();

  if (DEMO) demo();
  else poll();
  setInterval(() => { if (!DEMO) poll(); }, POLL_MS);
  setInterval(() => {
    renderClock();
    if (Date.now() - lastMapDraw > 60000) drawMap();   // Nachtgrenze wandert
  }, 1000);
  setInterval(() => { renderLegend(); kick(); }, 1000);
})();
