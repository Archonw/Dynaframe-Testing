/* YouTube Cast - die Szene.
 *
 * Spielt das Video, das das Plugin YouTube Cast vorgibt, mit dem
 * eingebetteten Player von YouTube. Das Plugin holt die Szene nur auf den
 * Bildschirm, solange ein Video laufen soll. Sie fragt jede halbe Sekunde,
 * was laufen soll (Video, Pause, Spulen, Lautstärke), und meldet jede
 * Sekunde zurück, wo der Player steht; das Plugin gibt es an die YouTube-App
 * weiter.
 *
 * Das Plugin erreicht sie direkt über seinen eigenen Port (8090) oder, falls
 * der nicht geht, über den Proxy der Weboberfläche.
 * Mit ?demo=<videoId> spielt sie ohne Plugin ein Video (zum Ausprobieren).
 */
(function () {
  "use strict";

  const PLUGIN_ID = "YouTubeCast";
  const POLL_MS = 500;
  const REPORT_MS = 1000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.get("demo");
  const host = location.hostname || "localhost";
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const BASES = [params.get("plugin"),
    `http://${host}:8090/`, `http://${host}:8091/`,
    `${location.protocol}//${host}:8003${advanced}`,
    `${location.protocol}//${host}${advanced}`,
    `${location.origin}${advanced}`].filter(Boolean);

  const el = (id) => document.getElementById(id);
  const ui = { stage: el("stage"), idleTitle: el("idleTitle"), idleText: el("idleText"), idleUrl: el("idleUrl"),
    info: el("info"), from: el("from"), title: el("title"), note: el("note"), bar: el("bar"), fill: el("fill") };

  const TEXT = {
    de: { ready: "Bereit", hint: "In der YouTube-App auf Streamen tippen und „{name}“ wählen.",
      phone: "Oder einen Link senden:", from: "Gestreamt von {who}", link: "Von deinem Handy",
      unreachable: "YouTube Cast antwortet nicht.", muted: "Ohne Ton gestartet: der Rahmen erlaubt Ton erst nach einer Berührung.",
      noapi: "Der YouTube-Player lädt nicht. Ist der Rahmen mit dem Internet verbunden?",
      e2: "Der Link ist ungültig.", e5: "Dieses Video kann der Player nicht abspielen.",
      e100: "Das Video gibt es nicht mehr oder es ist privat.",
      e101: "Der Kanal erlaubt dieses Video nur auf YouTube selbst, nicht eingebettet.",
      e153: "YouTube lehnt den Player ab (Fehler 153)." },
    en: { ready: "Ready", hint: "Tap cast in the YouTube app and choose “{name}”.",
      phone: "Or send a link:", from: "Cast from {who}", link: "From your phone",
      unreachable: "YouTube Cast is not responding.", muted: "Started without sound: the frame only allows sound after a touch.",
      noapi: "The YouTube player does not load. Is the frame connected to the internet?",
      e2: "The link is not valid.", e5: "The player cannot play this video.",
      e100: "The video no longer exists or is private.",
      e101: "The channel only allows this video on YouTube itself, not embedded.",
      e153: "YouTube refuses the player (error 153)." },
    es: { ready: "Listo", hint: "Pulsa enviar en la app de YouTube y elige «{name}».",
      phone: "O envía un enlace:", from: "Enviado desde {who}", link: "Desde tu móvil",
      unreachable: "YouTube Cast no responde.", muted: "Empezó sin sonido: el marco solo permite sonido tras un toque.",
      noapi: "El reproductor de YouTube no carga. ¿Está el marco conectado a internet?",
      e2: "El enlace no es válido.", e5: "El reproductor no puede reproducir este vídeo.",
      e100: "El vídeo ya no existe o es privado.",
      e101: "El canal solo permite este vídeo en YouTube, no insertado.",
      e153: "YouTube rechaza el reproductor (error 153)." }
  };
  let lang = "de";
  const tx = (key, values = {}) => ((TEXT[lang] || TEXT.de)[key] || TEXT.de[key] || key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");

  let base = null;
  let data = null;
  let failures = 0;
  let readySent = false;

  let player = null;
  let apiReady = false;
  let loadedSeq = null;
  let loadedVideo = "";
  let seekSeq = null;
  let volSeq = null;
  let lastState = "unstarted";
  let errorCode = "";
  let blocked = false;
  let loadAt = 0;
  let infoUntil = 0;
  let noteTimer = null;

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 1500);

  // ------------------------------------------------------------------
  // Verbindung zum Plugin
  // ------------------------------------------------------------------

  async function fetchJson(url, init) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 2500);
    try {
      const response = await fetch(url, { cache: "no-store", ...init, signal: controller.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } finally {
      clearTimeout(timer);
    }
  }

  async function poll() {
    if (DEMO) {
      data = data || { showing: true, seq: 1, videoId: DEMO, position: 0, desired: "play", seekSeq: 0, volSeq: 0,
        volume: 100, muted: false, title: "", sender: "", source: "link", lang: params.get("lang") || "de", name: "DynaFrame" };
      apply();
      return;
    }
    const candidates = base ? [base] : BASES;
    for (const candidate of candidates) {
      try {
        data = await fetchJson(candidate + "api/scene");
        base = candidate;
        failures = 0;
        apply();
        return;
      } catch (_) { /* nächste Adresse */ }
    }
    failures += 1;
    if (failures >= 4) base = null;  // nochmal alle Adressen probieren
    if (failures === 6) showNote(tx("unreachable"), true);
  }

  function report(force) {
    if (!player || !loadedVideo || DEMO || !base) return;
    const body = {
      seq: loadedSeq, videoId: loadedVideo, state: errorCode ? "error" : lastState, error: errorCode,
      time: safe(() => player.getCurrentTime(), 0), duration: safe(() => player.getDuration(), 0),
      blocked
    };
    const video = safe(() => player.getVideoData(), null);
    if (video) { body.title = video.title || ""; body.author = video.author || ""; }
    // text/plain, damit der Browser keine Vorab-Anfrage (CORS) schickt.
    fetch(base + "api/report", { method: "POST", body: JSON.stringify(body), headers: { "Content-Type": "text/plain" },
      cache: "no-store", keepalive: !!force }).catch(() => {});
  }

  function safe(fn, fallback) {
    try { const value = fn(); return value ?? fallback; } catch (_) { return fallback; }
  }

  // ------------------------------------------------------------------
  // Der YouTube-Player
  // ------------------------------------------------------------------

  const STATES = { "-1": "unstarted", "0": "ended", "1": "playing", "2": "paused", "3": "buffering", "5": "cued" };

  function loadApi() {
    window.onYouTubeIframeAPIReady = () => { apiReady = true; apply(); };
    const script = document.createElement("script");
    script.src = "https://www.youtube.com/iframe_api";
    script.onerror = () => showNote(tx("noapi"), true);
    document.head.appendChild(script);
    setTimeout(() => { if (!apiReady && data && data.showing) showNote(tx("noapi"), true); }, 15000);
  }

  function createPlayer(videoId, start) {
    // Das iframe selbst bauen, damit es Autoplay ausdrücklich erlauben darf.
    const query = new URLSearchParams({ enablejsapi: "1", autoplay: "1", controls: "0", disablekb: "1", fs: "0",
      iv_load_policy: "3", rel: "0", playsinline: "1", start: String(Math.floor(start || 0)),
      origin: location.origin, hl: lang });
    const frame = document.createElement("iframe");
    frame.id = "player";
    frame.allow = "autoplay; encrypted-media; picture-in-picture";
    frame.referrerPolicy = "strict-origin-when-cross-origin";
    frame.src = `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?${query}`;
    el("player").replaceWith(frame);
    player = new YT.Player(frame, {
      events: {
        onReady: () => { applyVolume(true); safe(() => player.playVideo()); ready(); },
        onStateChange: (event) => onState(event.data),
        onError: (event) => onError(event.data)
      }
    });
  }

  function onState(code) {
    const state = STATES[String(code)] || "unstarted";
    if (state === lastState) return;
    lastState = state;
    if (state === "playing") {
      if (Date.now() - loadAt < 4000) infoUntil = Date.now() + 7000;
    }
    render();
    report();
  }

  function onError(code) {
    errorCode = String(code);
    const key = code === 101 || code === 150 ? "e101" : code === 100 ? "e100" : code === 2 ? "e2" :
      code === 153 ? "e153" : "e5";
    showNote(tx(key), true);
    report();
  }

  function load(videoId, start) {
    loadedVideo = videoId;
    hideNote(true);
    errorCode = "";
    blocked = false;
    lastState = "unstarted";
    loadAt = Date.now();
    infoUntil = Date.now() + 8000;
    if (!player) {
      createPlayer(videoId, start);
    } else {
      safe(() => player.loadVideoById({ videoId, startSeconds: start || 0 }));
    }
    // Ohne Berührung verbieten manche Browser Ton: dann stumm starten.
    setTimeout(() => {
      if (loadedVideo !== videoId || !player || errorCode) return;
      if (data && data.desired === "play" && (lastState === "unstarted" || lastState === "cued")) {
        blocked = true;
        safe(() => player.mute());
        safe(() => player.playVideo());
        showNote(tx("muted"), false, 8000);
        report();
      }
    }, 3500);
  }

  function applyVolume(force) {
    if (!player || !data) return;
    if (!force && data.volSeq === volSeq) return;
    volSeq = data.volSeq;
    safe(() => player.setVolume(Math.max(0, Math.min(100, data.volume))));
    if (data.muted || blocked) safe(() => player.mute()); else safe(() => player.unMute());
  }

  // ------------------------------------------------------------------
  // Abgleich: was das Plugin will, was der Player tut
  // ------------------------------------------------------------------

  function apply() {
    if (!data) return;
    if (data.lang && TEXT[data.lang]) lang = data.lang;
    ready();
    if (!data.showing || !data.videoId) {
      if (player && loadedVideo) safe(() => player.stopVideo());
      loadedVideo = "";
      loadedSeq = null;
      render();
      return;
    }
    if (!apiReady) { render(); return; }
    if (data.seq !== loadedSeq) {
      loadedSeq = data.seq;
      seekSeq = data.seekSeq;
      load(data.videoId, data.position);
      applyVolume(true);
      render();
      return;
    }
    if (data.seekSeq !== seekSeq) {
      seekSeq = data.seekSeq;
      safe(() => player.seekTo(data.seekTo, true));
      infoUntil = Date.now() + 4000;
    }
    applyVolume(false);
    if (!errorCode && player) {
      if (data.desired === "pause" && (lastState === "playing" || lastState === "buffering")) safe(() => player.pauseVideo());
      if (data.desired === "play" && (lastState === "paused" || lastState === "cued")) safe(() => player.playVideo());
    }
    render();
  }

  function render() {
    const showing = !!(data && data.showing && data.videoId);
    let mode = "idle";
    if (showing) mode = lastState === "paused" ? "paused" : "video";
    ui.stage.dataset.mode = mode;
    if (!showing) {
      ui.idleTitle.textContent = tx("ready");
      ui.idleText.textContent = tx("hint", { name: (data && data.name) || "DynaFrame" });
      ui.idleUrl.textContent = data && data.phoneUrl ? `${tx("phone")} ${data.phoneUrl}` : "";
      ui.info.classList.remove("show");
      ui.bar.classList.remove("show");
      return;
    }
    const video = player ? safe(() => player.getVideoData(), null) : null;
    const title = (video && video.title) || data.title || "";
    ui.title.textContent = title;
    ui.from.textContent = data.source === "cast" && data.sender ? tx("from", { who: data.sender }) :
      data.source === "cast" ? "YouTube" : (data.sender && data.sender !== "Handy" && data.sender !== "Phone" &&
        data.sender !== "Móvil" ? data.sender : tx("link"));
    const showInfo = title && (mode === "paused" || Date.now() < infoUntil);
    ui.info.classList.toggle("show", !!showInfo);
    ui.bar.classList.toggle("show", mode === "paused" || Date.now() < infoUntil);
    const duration = player ? safe(() => player.getDuration(), 0) : 0;
    const time = player ? safe(() => player.getCurrentTime(), 0) : 0;
    ui.fill.style.width = duration ? `${Math.min(100, (time / duration) * 100)}%` : "0";
  }

  function showNote(text, bad, ms) {
    ui.note.textContent = text;
    ui.note.classList.toggle("bad", !!bad);
    ui.note.hidden = false;
    clearTimeout(noteTimer);
    if (ms) noteTimer = setTimeout(() => hideNote(true), ms);
  }

  function hideNote(all) {
    if (all || !ui.note.classList.contains("bad")) ui.note.hidden = true;
  }

  loadApi();
  poll();
  setInterval(poll, POLL_MS);
  setInterval(() => { report(); render(); }, REPORT_MS);
  window.addEventListener("pagehide", () => report(true));
})();
