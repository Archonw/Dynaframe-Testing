"""Die Verbindung zu YouTube, über die die YouTube-App den Rahmen steuert.

Wenn man in der YouTube-App auf "Streamen" tippt, spricht die App nicht
direkt mit dem Fernseher, sondern mit dem Lounge-Dienst von YouTube. Ein
Fernseher (hier: der Rahmen) meldet sich dort als "Bildschirm" an und hält
eine lange offene Anfrage, über die die Befehle der App kommen (Video
abspielen, Pause, Spulen, Lautstärke). Zurück meldet er, was er gerade
spielt.

Das ist dasselbe Protokoll, das Smart-TVs benutzen. Der Ablauf folgt dem
quelloffenen Empfänger yt-cast-receiver (MIT-Lizenz, Patrick Kan), der es
für Node.js umsetzt.

Diese Datei kennt nur YouTube; was ein Befehl auf dem Rahmen bedeutet,
entscheidet plugin.py über den Rückruf on_message(name, payload, aid).
"""

import json
import os
import random
import re
import secrets
import threading
import time
import uuid
from urllib.parse import urlencode

import requests

# YTCAST_YOUTUBE_BASE nur für Tests mit einer Attrappe.
BASE = os.environ.get("YTCAST_YOUTUBE_BASE", "https://www.youtube.com")
GENERATE_SCREEN_ID = BASE + "/api/lounge/pairing/generate_screen_id"
GET_LOUNGE_TOKEN = BASE + "/api/lounge/pairing/get_lounge_token_batch"
REGISTER_PAIRING_CODE = BASE + "/api/lounge/pairing/register_pairing_code"
GET_PAIRING_CODE = BASE + "/api/lounge/pairing/get_pairing_code?ctx=pair"
BIND = BASE + "/api/lounge/bc/bind"

SCREEN_APP = "ytcr"
THEME = "cl"   # die normale YouTube-App ("m" wäre YouTube Music)

# Zustände, wie die App sie versteht.
IDLE, PLAYING, PAUSED, LOADING, STOPPED = -1, 1, 2, 3, 4

USER_AGENT = ("Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/124.0 Safari/537.36")
CONNECT_TIMEOUT = 10
REQUEST_TIMEOUT = 20
# Die offene Anfrage schließt YouTube von sich aus nach ein paar Minuten;
# kommt so lange gar nichts (nicht einmal ein noop), ist sie tot.
RPC_READ_TIMEOUT = 330

_LINE = re.compile(r'\[(\d+),\["(.+?)"(?:,(.*?))?\]\]')


class LoungeError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def _flag(value):
    return "true" if value else "false"


def _text(value):
    if isinstance(value, bool):
        return _flag(value)
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.3f}".rstrip("0").rstrip(".") or "0"
    return str(value)


def _rows_to_messages(rows):
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not (isinstance(row, list) and len(row) == 2 and isinstance(row[1], list) and row[1]):
            continue
        name, args = row[1][0], row[1][1:]
        payload = args[0] if len(args) == 1 else (args or None)
        out.append((int(row[0]), str(name), payload))
    return out


def _regex_messages(text):
    """Wie der Node-Empfänger: Stück für Stück, falls der Text kein ganzes JSON ist."""
    out = []
    for match in _LINE.finditer(text.replace("\n", "").replace("\r", "")):
        payload = None
        if match.group(3) is not None:
            try:
                args = json.loads(f"[{match.group(3)}]")
                payload = args[0] if len(args) == 1 else args
            except ValueError:
                payload = None
        out.append((int(match.group(1)), match.group(2), payload))
    return out


class Framer:
    """Setzt die Antwort von YouTube in Nachrichten um. Sie kommt als
    "Länge, Zeilenumbruch, JSON-Feld", und das Feld steht oft über mehrere
    Zeilen verteilt. feed() bekommt Zeile für Zeile und gibt fertige
    Nachrichten [(aid, name, payload), ...] zurück."""

    def __init__(self):
        self.buffer = []
        self.depth = 0

    def feed(self, line):
        if not self.buffer:
            stripped = line.strip()
            if not stripped or stripped.isdigit():
                return []
            if not stripped.startswith("["):
                return []
        self.buffer.append(line)
        self.depth += _depth_change(line)
        if self.depth > 0:
            if len(self.buffer) > 2000:  # etwas stimmt nicht: verwerfen
                self.buffer, self.depth = [], 0
            return []
        text = "\n".join(self.buffer)
        self.buffer, self.depth = [], 0
        try:
            return _rows_to_messages(json.loads(text))
        except ValueError:
            return _regex_messages(text)


def _depth_change(line):
    depth, in_string, escaped = 0, False, False
    for char in line:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
        elif char == '"':
            in_string = True
        elif char == "[":
            depth += 1
        elif char == "]":
            depth -= 1
    return depth


def parse_messages(text):
    """Ein ganzer Antworttext -> [(aid, name, payload), ...]."""
    framer, out = Framer(), []
    for line in text.splitlines():
        out.extend(framer.feed(line))
    return out


class Lounge:
    """Ein Bildschirm beim Lounge-Dienst. start() läuft im Hintergrund,
    bis stop(). store(key[, value]) liest und schreibt Werte, die einen
    Neustart überleben sollen (screenId, deviceId)."""

    def __init__(self, name, store, log, on_message, on_status=None, brand="DynaFrame", model="Frame"):
        self.name = name
        self.store = store
        self.log = log
        self.on_message = on_message
        self.on_status = on_status or (lambda *_a: None)
        self.brand = brand
        self.model = model
        self.http = requests.Session()
        self.http.headers["User-Agent"] = USER_AGENT
        self.screen_id = store("screenId") or ""
        self.device_id = store("deviceId") or str(uuid.uuid4())
        store("deviceId", self.device_id)
        self.status = "off"          # off, connecting, ready, error
        self.error = ""
        self._lock = threading.RLock()
        self._send_lock = threading.Lock()
        self._stop = threading.Event()
        self._restart = threading.Event()
        self._thread = None
        self._rpc_response = None
        self._reset_bind()

    # ------------------------------------------------------------------
    # Zustand der Sitzung
    # ------------------------------------------------------------------

    def _reset_bind(self):
        with self._lock:
            self.lounge_token = ""
            self.token_until = 0.0
            self.sid = ""
            self.gsessionid = ""
            self.rid = random.randint(41000, 49999)
            self.aid = 3
            self.ofs = 0

    def _set_status(self, status, error=""):
        if status != self.status or error != self.error:
            self.status, self.error = status, error
            self.on_status(status, error)

    def _common(self):
        return {
            "device": "LOUNGE_SCREEN",
            "id": self.device_id,
            "obfuscatedGaiaId": "",
            "name": self.name,
            "app": SCREEN_APP,
            "theme": THEME,
            "capabilities": "dsp,mic,dpa,ntb",
            "cst": "m",
            "mdxVersion": 2,
            "loungeIdToken": self.lounge_token,
            "VER": 8,
            "v": 2,
            "zx": secrets.token_hex(6),
            "t": 1,
        }

    def _device_info(self):
        return json.dumps({
            "brand": self.brand, "model": self.model, "year": 0, "os": "Linux", "osVersion": "",
            "chipset": "", "clientName": "TVHTML5", "dialAdditionalDataSupportLevel": "unsupported",
            "mdxDialServerType": "MDX_DIAL_SERVER_TYPE_UNKNOWN"}, separators=(",", ":"))

    # ------------------------------------------------------------------
    # Anmelden
    # ------------------------------------------------------------------

    def _post(self, url, data, params=None, timeout=REQUEST_TIMEOUT):
        try:
            response = self.http.post(url, data=data, params=params, timeout=(CONNECT_TIMEOUT, timeout))
        except requests.RequestException as exc:
            raise LoungeError(f"YouTube nicht erreichbar: {exc}") from exc
        if response.status_code >= 400:
            raise LoungeError(f"YouTube antwortete mit HTTP {response.status_code}", response.status_code)
        return response

    def _generate_screen_id(self):
        try:
            response = self.http.get(GENERATE_SCREEN_ID, timeout=(CONNECT_TIMEOUT, REQUEST_TIMEOUT))
        except requests.RequestException as exc:
            raise LoungeError(f"YouTube nicht erreichbar: {exc}") from exc
        screen_id = response.text.strip()
        if response.status_code >= 400 or not re.fullmatch(r"[A-Za-z0-9_-]{8,}", screen_id):
            raise LoungeError(f"Keine Bildschirm-Kennung von YouTube (HTTP {response.status_code})",
                              response.status_code)
        return screen_id

    def _fetch_token(self):
        response = self._post(GET_LOUNGE_TOKEN, {"screen_ids": self.screen_id})
        try:
            screen = (response.json().get("screens") or [None])[0] or {}
        except ValueError as exc:
            raise LoungeError("Unerwartete Antwort von YouTube beim Lounge-Token") from exc
        token = screen.get("loungeToken")
        if not token:
            raise LoungeError("YouTube hat keinen Lounge-Token geliefert")
        refresh_ms = screen.get("refreshIntervalInMillis") or screen.get("refreshIntervalMs") or 0
        try:
            refresh = float(refresh_ms) / 1000.0
        except (TypeError, ValueError):
            refresh = 0.0
        return token, time.time() + (refresh if refresh > 60 else 13 * 86400)

    def _begin(self):
        """screenId (einmal, dann gespeichert), Lounge-Token, Sitzung."""
        self._reset_bind()
        if not self.screen_id:
            self.screen_id = self._generate_screen_id()
            self.store("screenId", self.screen_id)
            self.log(f"Neue Bildschirm-Kennung bei YouTube: {self.screen_id[:6]}…")
        try:
            token, until = self._fetch_token()
        except LoungeError:
            # Die gespeicherte Kennung kennt YouTube nicht mehr: eine neue.
            self.screen_id = self._generate_screen_id()
            self.store("screenId", self.screen_id)
            token, until = self._fetch_token()
        with self._lock:
            self.lounge_token, self.token_until = token, until
            params = dict(self._common(), deviceInfo=self._device_info(), RID=self.rid, CVER=1)
            self.rid += 1
        response = self._post(BIND + "?" + urlencode(params), {"count": "0"})
        messages = parse_messages(response.text)
        for aid, name, payload in messages:
            self._bookkeeping(aid, name, payload)
        if not self.sid or not self.gsessionid:
            raise LoungeError("YouTube hat keine Sitzung eröffnet")
        for aid, name, payload in messages:
            if name not in ("c", "S"):
                self._dispatch(aid, name, payload)

    def _bookkeeping(self, aid, name, payload):
        with self._lock:
            self.aid = max(self.aid, aid)
            if name == "c":
                self.sid = payload[0] if isinstance(payload, list) and payload else str(payload or "")
            elif name == "S":
                self.gsessionid = payload[0] if isinstance(payload, list) and payload else str(payload or "")

    def _dispatch(self, aid, name, payload):
        if name in ("noop", "c", "S"):
            return
        try:
            self.on_message(name, payload, aid)
        except Exception as exc:  # ein Fehler im Plugin darf die Verbindung nicht beenden
            self.log(f"Befehl {name} aus der YouTube-App nicht verarbeitet: {exc}", "warning")

    # ------------------------------------------------------------------
    # Die offene Anfrage
    # ------------------------------------------------------------------

    def _rpc_once(self):
        with self._lock:
            params = dict(self._common(), RID="rpc", SID=self.sid, CI=0, AID=self.aid,
                          gsessionid=self.gsessionid, TYPE="xmlhttp")
        try:
            response = self.http.get(BIND + "?" + urlencode(params), stream=True,
                                     timeout=(CONNECT_TIMEOUT, RPC_READ_TIMEOUT))
        except requests.RequestException as exc:
            raise LoungeError(f"Verbindung zu YouTube unterbrochen: {exc}") from exc
        if response.status_code >= 400:
            response.close()
            raise LoungeError(f"YouTube hat die Sitzung beendet (HTTP {response.status_code})",
                              response.status_code)
        self._rpc_response = response
        self._set_status("ready")
        framer = Framer()
        try:
            for raw in response.iter_lines(decode_unicode=True):
                if self._stop.is_set() or self._restart.is_set():
                    break
                if raw is None:
                    continue
                for aid, name, payload in framer.feed(raw):
                    self._bookkeeping(aid, name, payload)
                    self._dispatch(aid, name, payload)
        except (requests.RequestException, AttributeError, ValueError) as exc:
            if not self._stop.is_set():
                raise LoungeError(f"Verbindung zu YouTube unterbrochen: {exc}") from exc
        finally:
            self._rpc_response = None
            response.close()

    def _run(self):
        backoff = 5
        while not self._stop.is_set():
            self._restart.clear()
            self._set_status("connecting")
            try:
                self._begin()
                self.log("Bei YouTube als Bildschirm angemeldet; die YouTube-App kann jetzt streamen.")
                backoff = 5
                failures = 0
                while not self._stop.is_set() and not self._restart.is_set():
                    if time.time() > self.token_until:
                        break  # neuer Token, neue Sitzung
                    try:
                        self._rpc_once()
                        failures = 0
                    except LoungeError as exc:
                        if exc.status in (400, 401, 404, 410):
                            raise  # Sitzung ungültig: neu anmelden
                        failures += 1
                        if failures > 3:
                            raise
                        self._stop.wait(2 * failures)
            except LoungeError as exc:
                if self._stop.is_set():
                    break
                self._set_status("error", str(exc))
                self.log(f"YouTube: {exc}; neuer Versuch in {backoff} s.", "warning")
                self._stop.wait(backoff)
                backoff = min(backoff * 2, 300)
            except Exception as exc:  # nichts darf den Faden beenden
                self._set_status("error", str(exc))
                self.log(f"YouTube: unerwarteter Fehler {exc!r}; neuer Versuch in {backoff} s.", "warning")
                self._stop.wait(backoff)
                backoff = min(backoff * 2, 300)
        self._set_status("off")

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="lounge", daemon=True)
        self._thread.start()

    def restart(self, name=None):
        """Neu anmelden, z. B. mit einem neuen Namen."""
        if name:
            self.name = name
        self._restart.set()
        self._close_rpc()

    def stop(self):
        if self.status == "ready":
            try:
                self.send([("loungeScreenDisconnected", {})])
            except LoungeError:
                pass
        self._stop.set()
        self._close_rpc()

    def _close_rpc(self):
        response = self._rpc_response
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Senden
    # ------------------------------------------------------------------

    def send(self, messages, aid=None):
        """messages: [(name, {key: value}), ...]."""
        if not messages:
            return
        with self._send_lock:
            with self._lock:
                if not self.sid or not self.gsessionid or not self.lounge_token:
                    return
                use_aid = max(aid, self.aid) if aid else self.aid
                params = dict(self._common(), deviceInfo=self._device_info(), SID=self.sid, RID=self.rid,
                              AID=use_aid, gsessionid=self.gsessionid)
                self.rid += 1
                data = {"count": str(len(messages)), "ofs": str(self.ofs)}
                self.ofs += len(messages)
            for index, (name, payload) in enumerate(messages):
                prefix = f"req{index}_"
                data[prefix + "_sc"] = name
                for key, value in (payload or {}).items():
                    data[prefix + key] = _text(value)
            self._post(BIND + "?" + urlencode(params), data)

    # ------------------------------------------------------------------
    # Mit TV-Code verknüpfen
    # ------------------------------------------------------------------

    def pairing_code(self):
        """Ein zwölfstelliger Code für "Mit TV-Code verknüpfen" in der App."""
        if self.status != "ready" or not self.screen_id or not self.lounge_token:
            raise LoungeError("Noch nicht bei YouTube angemeldet")
        response = self._post(GET_PAIRING_CODE, {
            "access_type": "permanent", "app": SCREEN_APP, "lounge_token": self.lounge_token,
            "screen_id": self.screen_id, "screen_name": self.name, "device_id": self.device_id})
        code = re.sub(r"\D", "", response.text)
        if len(code) < 8:
            raise LoungeError("YouTube hat keinen TV-Code geliefert")
        return code

    def register_pairing_code(self, code):
        """Die App hat den Rahmen im WLAN gefunden (DIAL) und schickt einen
        Code; damit verbindet YouTube die App mit diesem Bildschirm."""
        if not self.screen_id:
            raise LoungeError("Noch nicht bei YouTube angemeldet")
        self._post(REGISTER_PAIRING_CODE, {
            "access_type": "permanent", "app": SCREEN_APP, "pairing_code": code,
            "screen_id": self.screen_id, "screen_name": self.name, "device_id": self.device_id})
