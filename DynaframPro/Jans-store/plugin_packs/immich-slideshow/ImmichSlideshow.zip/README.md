# Immich Slideshow

Immich Slideshow bringt Fotos von deinem eigenen Immich-Server in die Diashow von DynaFrame. **DynaFrame spielt sie ab**, mit deiner Anzeigedauer, deinen Übergängen und Overlays, wie jedes andere Bild.

**Die Fotos bleiben auf dem Server.** Das Plugin liest von Immich nur die Liste der passenden Fotos (Kennung, Aufnahmedatum, Ort). Auf dem Rahmen liegen immer nur die nächsten paar Fotos (Standard 10). Sobald DynaFrame sie alle gezeigt hat, holt das Plugin die nächsten und löscht die alten.

## Einrichten

1. Plugin installieren (Plugins > Hochladen, oder über den Store).
2. In Immich einen API-Schlüssel anlegen: Profilbild oben rechts > **Kontoeinstellungen > API-Schlüssel > Neuer API-Schlüssel**. Es reichen die Berechtigungen `asset.read`, `asset.view`, `album.read` und `person.read`.
3. Auf der Plugins-Seite **Open Immich Slideshow** öffnen, Adresse (z. B. `http://192.168.178.10:2283`) und Schlüssel eintragen, **Verbindung testen**.
4. Alben wählen oder auf **Alle Fotos** stellen, nach Wunsch eingrenzen.
5. In DynaFrame die Quelle **Immich Slideshow** abspielen, oder unter *Eine Playlist dafür* die Playlist „Immich Slideshow“ anlegen lassen.

## Welche Fotos

- **Quelle:** ein oder mehrere Alben (auch mit dir geteilte) oder alle Fotos.
- **Sterne:** genau so viele oder so viele oder mehr, z. B. alles mit 4 Sternen.
- **Nur Favoriten.**
- **Personen:** Fotos, auf denen mindestens eine der gewählten Personen ist (nur Personen mit Namen).
- **Freie Suche:** Immichs Smart Search, z. B. „Strand“ oder „Hund im Schnee“. Braucht das Machine Learning von Immich; es zählen die besten Treffer bis zur eingestellten Grenze.

Alles lässt sich kombinieren. Videos werden übersprungen.

## Reihenfolge

- **Zufall:** jedes Foto einmal, in zufälliger Reihenfolge; danach wird neu gemischt.
- **Nach Aufnahmedatum**, älteste oder neueste zuerst. Dafür DynaFrame auf die Reihenfolge der Dateinamen stellen, nicht auf Zufall.

Zu jedem Foto gibt das Plugin DynaFrame Datum (als Titel) und Ort (als Beschreibung) mit, für Overlays.

**Bildgröße:** Die Vorschau von Immich (meist 1440 Pixel) reicht für Full HD. Volle Größe ist für 4K-Bildschirme.

## Wenn etwas nicht stimmt

- **„Immich lehnt den API-Schlüssel ab“:** Schlüssel neu eintragen; er wurde in Immich vielleicht gelöscht.
- **„Dem API-Schlüssel fehlt eine Berechtigung“:** dem Schlüssel in Immich die oben genannten Berechtigungen geben (oder „Alle“).
- **„Immich ist nicht erreichbar“:** Adresse und Port prüfen; der Rahmen muss den Server im Netz erreichen.
- **Es kommen keine neuen Fotos:** Das Plugin tauscht erst, wenn DynaFrame alle Fotos auf dem Rahmen gezeigt hat. Die Plugin-Seite zeigt unter *Auf dem Rahmen*, wie viele schon dran waren.
