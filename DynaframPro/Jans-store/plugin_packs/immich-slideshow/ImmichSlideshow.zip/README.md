# Immich Slideshow

Immich Slideshow zeigt Fotos von deinem eigenen Immich-Server als Diashow auf dem Rahmen.

**Die Fotos bleiben auf dem Server.** Das Plugin liest von Immich nur die Liste der passenden Fotos (Kennung, Aufnahmedatum, Ort), keine Bilder. Die Szene holt immer nur das Foto, das sie gerade zeigt, und das nächste im Voraus; beide liegen nur im Arbeitsspeicher und werden nicht gespeichert.

Das Paket besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene Immich Slideshow** zeigt die Fotos mit Überblendung, auf Wunsch mit Datum und Ort.
- **Das Plugin** hält die Einstellungen und den API-Schlüssel, wählt die Fotos aus, legt die Reihenfolge fest und reicht jedes Foto von Immich an die Szene durch.

## Einrichten

1. Paket installieren (Plugins > Hochladen, oder über den Store).
2. In Immich einen API-Schlüssel anlegen: Profilbild oben rechts > **Kontoeinstellungen > API-Schlüssel > Neuer API-Schlüssel**. Es reichen die Berechtigungen `asset.read`, `asset.view`, `album.read` und `person.read`.
3. Auf der Plugins-Seite **Open Immich Slideshow** öffnen, Adresse (z. B. `http://192.168.178.10:2283`) und Schlüssel eintragen, **Verbindung testen**.
4. Alben wählen oder auf **Alle Fotos** stellen, nach Wunsch eingrenzen.
5. Die Szene **Immich Slideshow** in eine Playlist aufnehmen, oder unter *Eine Playlist dafür* die Playlist „Immich Slideshow“ anlegen lassen.

## Welche Fotos

- **Quelle:** ein oder mehrere Alben (auch mit dir geteilte) oder alle Fotos.
- **Sterne:** genau so viele oder so viele oder mehr, z. B. alles mit 4 Sternen.
- **Nur Favoriten.**
- **Personen:** Fotos, auf denen mindestens eine der gewählten Personen ist (nur Personen mit Namen).
- **Freie Suche:** Immichs Smart Search, z. B. „Strand“ oder „Hund im Schnee“. Braucht das Machine Learning von Immich; es zählen die besten Treffer bis zur eingestellten Grenze.

Alles lässt sich kombinieren. Videos werden übersprungen.

## Wiedergabe

- **Zufall:** jedes Foto einmal, in zufälliger Reihenfolge; danach wird neu gemischt.
- **Nach Aufnahmedatum**, älteste oder neueste zuerst. Nach einem Neustart geht es beim zuletzt gezeigten Foto weiter.
- Sekunden je Foto, Überblenden, Format (ganzes Foto mit unscharfem Hintergrund, mit schwarzem Rand, oder bildschirmfüllend), langsamer Zoom, Datum und Ort.
- **Bildgröße:** Die Vorschau von Immich (meist 1440 Pixel) reicht für Full HD und lädt schnell. Volle Größe ist für 4K-Bildschirme.
- Neue Fotos in der Auswahl findet das Plugin beim nächsten Lesen (Standard: jede Stunde, oder mit **Fotos neu lesen**).

Die Reihenfolge führt das Plugin: Steht die Szene in einer gemischten Playlist, macht die Diashow beim nächsten Mal dort weiter, wo sie war.

## Wenn etwas nicht stimmt

- **„Immich lehnt den API-Schlüssel ab“:** Schlüssel neu eintragen; er wurde in Immich vielleicht gelöscht.
- **„Dem API-Schlüssel fehlt eine Berechtigung“:** dem Schlüssel in Immich die oben genannten Berechtigungen geben (oder „Alle“).
- **„Immich ist nicht erreichbar“:** Adresse und Port prüfen; der Rahmen muss den Server im Netz erreichen.
- **Die Szene zeigt „Das Plugin Immich Slideshow antwortet nicht“:** Läuft das Plugin auf der Plugins-Seite?
