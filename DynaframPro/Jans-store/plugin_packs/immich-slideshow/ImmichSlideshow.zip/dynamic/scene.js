/* Immich Slideshow - die Szene.
 *
 * Die Fotos kommen einzeln vom Plugin Immich Slideshow, über den Proxy der
 * Weboberfläche auf :8003 (der Proxy der Engine lehnt lokale Adressen ab).
 * Das Plugin bestimmt Auswahl und Reihenfolge und reicht jedes Foto von
 * Immich durch; die Szene hält nur das gezeigte und das nächste Foto im
 * Speicher und speichert nichts.
 *
 * Die Szene braucht keine Eingabe. Mit ?plugin=<url> lässt sie sich im
 * Browser gegen ein anderes Plugin ansehen, mit ?lang=en auf Englisch.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "ImmichSlideshow";
  const CONFIG_MS = 60000;
  const RETRY_MS = 15000;
  const params = new URLSearchParams(location.search);
  const pluginBase = params.get("plugin") ||
    `${location.protocol}//${location.hostname}:8003/Plugins/Advanced/${PLUGIN_ID}/`;

  const el = (id) => document.getElementById(id);
  const ui = { stage: el("stage"), info: el("info"), when: el("when"), where: el("where"),
    message: el("message"), note: el("note") };

  const TEXT = {
    de: { title: "Immich Slideshow", loading: "Die Fotos werden geladen …",
      unreachable: "Das Plugin Immich Slideshow antwortet nicht.", check: "Läuft es auf der Plugins-Seite?",
      stale: "Immich gerade nicht erreichbar" },
    en: { title: "Immich Slideshow", loading: "Loading the photos …",
      unreachable: "The Immich Slideshow plugin is not responding.", check: "Is it running on the Plugins page?",
      stale: "Immich not reachable right now" },
    es: { title: "Immich Slideshow", loading: "Cargando las fotos …",
      unreachable: "El plugin Immich Slideshow no responde.", check: "¿Está en marcha en la página de plugins?",
      stale: "Immich no está disponible ahora" }
  };
  const LOCALE = { de: "de-DE", en: "en-GB", es: "es-ES" };

  let config = { seconds: 15, fade: 2, fit: "blur", motion: false, showInfo: true,
    language: TEXT[params.get("lang")] ? params.get("lang") : "de" };
  let T = TEXT[config.language];
  let dateFmt = null;
  let readySent = false;
  let shownAny = false;
  let upcoming = null;     // Promise auf das nächste, schon geladene Foto
  let timer = null;

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function esc(text) {
    return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

  class PluginError extends Error {
    constructor(message, status) { super(message); this.status = status; }
  }

  async function call(path, init = {}) {
    const controller = new AbortController();
    const stop = setTimeout(() => controller.abort(), init.timeout || 20000);
    let response;
    try {
      response = await fetch(new URL(path, pluginBase), { cache: "no-store", signal: controller.signal });
    } catch (_) {
      throw new PluginError(T.unreachable, 0);
    } finally {
      clearTimeout(stop);
    }
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new PluginError(body.error || `HTTP ${response.status}`, response.status);
    }
    return response;
  }

  // ---------------------------------------------------------------- Einstellungen

  function applyConfig(next) {
    config = Object.assign(config, next || {});
    const lang = TEXT[config.language] ? config.language : "de";
    T = TEXT[lang];
    document.documentElement.lang = lang;
    dateFmt = new Intl.DateTimeFormat(LOCALE[lang], { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
    document.body.classList.toggle("fit-cover", config.fit === "cover");
    document.body.classList.toggle("fit-contain", config.fit === "contain");
    document.body.classList.toggle("motion", Boolean(config.motion));
    if (!config.showInfo) ui.info.classList.remove("shown");
  }

  async function loadConfig() {
    try {
      const payload = await (await call("api/scene", { timeout: 10000 })).json();
      applyConfig(payload);
      return payload;
    } catch (error) {
      return null;
    }
  }

  // ---------------------------------------------------------------- Anzeige

  function showMessage(title, text) {
    ui.message.innerHTML = `<div><b>${esc(title)}</b>${esc(text || "")}</div>`;
    ui.message.hidden = false;
  }

  function showNote(text) {
    ui.note.textContent = text || "";
    ui.note.hidden = !text;
  }

  function seconds(value, fallback) {
    const n = Number(value);
    return Number.isFinite(n) && n >= 0 ? n : fallback;
  }

  function takenText(taken) {
    // Immich nennt die Ortszeit der Aufnahme; als UTC gelesen und so formatiert,
    // bleibt das Datum, wie es auf der Kamera stand.
    if (!taken) return "";
    const date = new Date(`${String(taken).slice(0, 19)}Z`);
    return Number.isNaN(date.getTime()) ? "" : dateFmt.format(date);
  }

  /** Das nächste Foto holen und dekodieren, ohne es zu zeigen. */
  async function prepare() {
    let lastError = null;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      const meta = await (await call("api/next")).json();
      try {
        const blob = await (await call(meta.url, { timeout: 60000 })).blob();
        const url = URL.createObjectURL(blob);
        const img = new Image();
        img.className = "photo";
        img.alt = "";
        img.src = url;
        try {
          await img.decode();
        } catch (error) {
          URL.revokeObjectURL(url);
          throw new PluginError("decode", 415);
        }
        return { meta, url, img };
      } catch (error) {
        // Ein einzelnes Foto, das nicht kommt (gelöscht, kaputt): das nächste nehmen.
        lastError = error;
        if (error.status === 0) throw error;
      }
    }
    throw lastError || new PluginError("?", 500);
  }

  function show(photo) {
    const fade = seconds(config.fade, 2);
    const slide = document.createElement("div");
    slide.className = "slide";
    slide.style.transitionDuration = `${fade}s`;
    slide.style.setProperty("--drift", `${seconds(config.seconds, 15) + fade * 2}s`);
    const backdrop = document.createElement("img");
    backdrop.className = "backdrop";
    backdrop.alt = "";
    backdrop.src = photo.url;
    slide.append(backdrop, photo.img);
    slide.dataset.url = photo.url;
    ui.stage.append(slide);
    void slide.offsetWidth;           // erst zeichnen, dann einblenden
    slide.classList.add("shown");
    ui.message.hidden = true;
    shownAny = true;

    const old = [...ui.stage.children].filter((node) => node !== slide);
    setTimeout(() => {
      for (const node of old) {
        URL.revokeObjectURL(node.dataset.url);
        node.remove();
      }
    }, fade * 1000 + 300);

    const when = takenText(photo.meta.taken);
    const where = photo.meta.place || "";
    ui.info.classList.remove("shown");
    if (config.showInfo && (when || where)) {
      setTimeout(() => {
        ui.when.textContent = when || where;
        ui.where.textContent = when ? where : "";
        ui.info.hidden = false;
        ui.info.classList.add("shown");
      }, Math.min(fade, 1.2) * 500);
    }
  }

  // ---------------------------------------------------------------- Ablauf

  function preload() {
    upcoming = prepare();
    upcoming.catch(() => {});        // der Fehler wird beim Zeigen behandelt
  }

  async function advance() {
    clearTimeout(timer);
    try {
      const photo = await upcoming;
      show(photo);
      showNote("");
      ready();
      preload();
      timer = setTimeout(advance, seconds(config.seconds, 15) * 1000);
    } catch (error) {
      if (!shownAny) {
        if (error.status === 404) showMessage(T.title, error.message);
        else showMessage(T.unreachable, error.status === 0 ? T.check : error.message);
        ready();
      } else {
        showNote(error.status === 0 ? T.unreachable : T.stale);
      }
      await wait(RETRY_MS);
      await loadConfig();
      preload();
      advance();
    }
  }

  async function start() {
    applyConfig({});
    showMessage(T.title, T.loading);
    await loadConfig();
    showMessage(T.title, T.loading);
    preload();
    advance();
    setInterval(loadConfig, CONFIG_MS);
  }

  start();
})();
