#!/usr/bin/env python3
"""Immich Slideshow - Fotos von einem Immich-Server für die Diashow von DynaFrame.

DynaFrame spielt die Fotos selbst ab, mit seiner Anzeigedauer, seinen
Übergängen und Overlays. Die Fotos bleiben trotzdem auf dem Immich-Server:
Das Plugin liest nur die Liste der passenden Fotos (ids, Aufnahmedatum, Ort),
legt die Reihenfolge fest (Zufall ohne Wiederholung oder nach Datum) und hält
davon immer nur ein kleines Fenster (Standard 10 Fotos) im Cache auf dem
Rahmen. Hat DynaFrame die Fotos des Fensters gezeigt, kommt das nächste
Fenster, und die alten Dateien werden gelöscht.

Welche Fotos: gewählte Alben oder alle Fotos, wahlweise eingegrenzt auf
Sterne, Favoriten, Personen und eine freie Suche (Immichs Smart Search).
Alle Einstellungen liegen auf einer Seite (Plugins > Immich Slideshow öffnen).
Der API-Schlüssel bleibt im Plugin.
"""

import json
import os
import random
import re
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlencode, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "ImmichSlideshow"
DISPLAY_NAME = "Immich Slideshow"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"    # Einstellungen und Zustand; bleibt bei Updates
CACHE_DIR = PLUGIN_DIR / "cache"  # nur das aktuelle und das letzte Fenster
WATCH_SECONDS = 2

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
PHOTO_TIMEOUT = 60
PAGE_SIZE = 1000                  # das Maximum der Immich-Suche
MAX_PHOTOS = 100000               # mehr ids hält das Plugin nicht im Speicher
MAX_QUERIES = 200                 # Alben × Sterne × Personen
OWNER_PLAYLIST_NAME = "Immich Slideshow"
OWNER_PLAYLIST_DESCRIPTION = "Made by the Immich Slideshow plugin: your Immich photos as a slideshow."
UUID = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def ensure_dirs():
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    ensure_dirs()
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "ServerUrl":      {"kind": "text", "default": ""},
    "ApiKey":         {"kind": "secret", "default": ""},
    # Welche Fotos: gewählte Alben oder alle, dazu die Filter.
    "Source":         {"kind": "choice", "default": "albums", "options": ["albums", "all"]},
    "Albums":         {"kind": "ids", "default": []},
    "Rating":         {"kind": "number", "default": 0, "min": 0, "max": 5},
    "RatingMode":     {"kind": "choice", "default": "exact", "options": ["exact", "atleast"]},
    "FavoritesOnly":  {"kind": "bool", "default": False},
    "People":         {"kind": "ids", "default": []},
    "Query":          {"kind": "text", "default": ""},
    "QueryLimit":     {"kind": "number", "default": 300, "min": 20, "max": 5000},
    # Wiedergabe
    "Order":          {"kind": "choice", "default": "random", "options": ["random", "oldest", "newest"]},
    "Window":         {"kind": "number", "default": 10, "min": 3, "max": 50},
    "Quality":        {"kind": "choice", "default": "preview", "options": ["preview", "fullsize"]},
    "RefreshMinutes": {"kind": "number", "default": 60, "min": 5, "max": 1440},
    "MakePlaylist":   {"kind": "bool", "default": False},
    # Sprache der Plugin-Seite, der Hinweise und von Datum/Ort zu den Fotos.
    "Language":       {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "ids":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        chosen = []
        for item in items:
            value = str(item).strip().lower()
            if UUID.match(value) and value not in chosen:
                chosen.append(value)
        return chosen[:500]
    return str(raw).strip()[:500]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def public_settings(values):
    """Was die Plugin-Seite sehen darf: alles außer dem Schlüssel."""
    shown = {k: v for k, v in values.items() if k != "ApiKey"}
    shown["ApiKeySet"] = bool(values["ApiKey"])
    return shown


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            if name == "ApiKey" and not str(raw or "").strip() and not (changes or {}).get("ClearApiKey"):
                continue  # ein leeres Feld heißt: Schlüssel behalten
            value = coerce(name, raw)
            if name == "ServerUrl":
                value = normalize_url(value)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


# --------------------------------------------------------------------------
# Immich
# --------------------------------------------------------------------------

class ImmichError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def normalize_url(url):
    url = str(url or "").strip().rstrip("/")
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    if url.lower().endswith("/api"):
        url = url[:-4]
    return url


_session = requests.Session()


def immich(method, path, payload=None, params=None, raw=False, timeout=None, values=None):
    values = values or settings()
    base, key = values["ServerUrl"], values["ApiKey"]
    if not base:
        raise ImmichError(tr("Trag die Adresse deines Immich-Servers ein."))
    if not key:
        raise ImmichError(tr("Trag einen API-Schlüssel von Immich ein."))
    headers = {"x-api-key": key, "Accept": "application/json" if not raw else "image/*"}
    try:
        response = _session.request(method, f"{base}/api{path}", json=payload, params=params, headers=headers,
                                    timeout=(CONNECT_TIMEOUT, timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise ImmichError(tr("Immich ist nicht erreichbar: {exc}", exc=short_error(exc))) from exc
    if response.status_code == 401:
        raise ImmichError(tr("Immich lehnt den API-Schlüssel ab."), 401)
    if response.status_code == 403:
        raise ImmichError(tr("Dem API-Schlüssel fehlt eine Berechtigung ({path}).", path=path.split("?")[0]), 403)
    if response.status_code >= 400:
        detail = ""
        try:
            body = response.json()
            detail = body.get("message") if isinstance(body, dict) else ""
            if isinstance(detail, list):
                detail = "; ".join(str(d) for d in detail)
        except ValueError:
            pass
        raise ImmichError(f"{method} {path}: HTTP {response.status_code} {detail or ''}".strip(),
                          response.status_code)
    if raw:
        return response
    if not response.content.strip():
        return None
    try:
        return response.json()
    except ValueError as exc:
        raise ImmichError(tr("Unter dieser Adresse antwortet kein Immich-Server.")) from exc


def short_error(exc):
    text = str(exc)
    for marker in ("Failed to establish a new connection: ", "Read timed out", "Name or service not known"):
        if marker in text:
            tail = text.split(marker, 1)[1] if marker.endswith(": ") else marker
            return tail.split("'))")[0].strip(" )") or marker
    return text[:200]


def server_info(values=None):
    about = {}
    try:
        about = immich("GET", "/server/about", values=values) or {}
    except ImmichError as exc:
        if exc.status in (401, 403):
            raise
    found = about.get("version") or ""
    if not found:
        try:
            v = immich("GET", "/server/version", values=values) or {}
            found = f"v{v.get('major')}.{v.get('minor')}.{v.get('patch')}"
        except ImmichError:
            found = "?"
    me = immich("GET", "/users/me", values=values) or {}
    return {"version": found, "user": me.get("name") or me.get("email") or ""}


def list_albums():
    albums = {}
    for query in ({}, {"shared": "true"}):
        rows = immich("GET", "/albums", params=query) or []
        for row in rows if isinstance(rows, list) else []:
            if isinstance(row, dict) and row.get("id"):
                albums[row["id"]] = {
                    "id": row["id"], "name": row.get("albumName") or "?",
                    "count": row.get("assetCount") or 0,
                    "thumb": row.get("albumThumbnailAssetId") or "",
                    "shared": bool(row.get("shared")),
                }
    return sorted(albums.values(), key=lambda a: a["name"].lower())


def list_people():
    people, page = [], 1
    while page <= 20:
        data = immich("GET", "/people", params={"page": page, "size": 500, "withHidden": "false"}) or {}
        for row in data.get("people") or []:
            if row.get("name") and not row.get("isHidden"):
                people.append({"id": row["id"], "name": row["name"]})
        if not data.get("hasNextPage"):
            break
        page += 1
    return sorted(people, key=lambda p: p["name"].lower())


def search_bodies(values):
    """Je Album, Sternzahl und Person eine Suche: Immich verknüpft mehrere
    Alben oder Personen in einer Suche mit UND, gemeint ist aber ODER."""
    albums = values["Albums"] if values["Source"] == "albums" else [None]
    rating = values["Rating"]
    ratings = [None] if not rating else ([rating] if values["RatingMode"] == "exact" else list(range(rating, 6)))
    people = values["People"] or [None]
    bodies = []
    for album in albums:
        for stars in ratings:
            for person in people:
                body = {"type": "IMAGE", "withExif": True}
                if values["FavoritesOnly"]:
                    body["isFavorite"] = True
                if album:
                    body["albumIds"] = [album]
                if stars:
                    body["rating"] = stars
                if person:
                    body["personIds"] = [person]
                bodies.append(body)
    return bodies[:MAX_QUERIES]


def search_pages(path, body, limit):
    """Alle Treffer einer Suche, Seite für Seite. Neuere Server blättern mit
    einem Cursor, ältere mit Seitenzahlen; beides geht."""
    page, cursor, count = 1, None, 0
    while count < limit:
        request = dict(body, size=min(PAGE_SIZE, limit - count) if path == "/search/smart" else PAGE_SIZE)
        if cursor:
            request["cursor"] = cursor
        else:
            request["page"] = page
        data = immich("POST", path, request, timeout=60) or {}
        assets = data.get("assets") or {}
        items = assets.get("items") or []
        for item in items:
            yield item
            count += 1
            if count >= limit:
                return
        cursor = assets.get("nextCursor")
        next_page = assets.get("nextPage")
        if cursor:
            continue
        if next_page and items:
            page = as_int(next_page, page + 1)
            continue
        return


def photo_row(item):
    exif = item.get("exifInfo") or {}
    taken = str(item.get("localDateTime") or exif.get("dateTimeOriginal") or item.get("fileCreatedAt") or "")
    place = ", ".join(p for p in (exif.get("city"), exif.get("country")) if p)
    return (item["id"], taken[:19], place[:80])


def collect(values):
    """Die passenden Fotos: [(id, Aufnahmezeit, Ort)], ohne doppelte."""
    if values["Source"] == "albums" and not values["Albums"]:
        raise ImmichError(tr("Wähle mindestens ein Album."))
    query = values["Query"]
    rows, seen = [], set()
    for body in search_bodies(values):
        if query:
            source = search_pages("/search/smart", dict(body, query=query), values["QueryLimit"])
        else:
            source = search_pages("/search/metadata", body, MAX_PHOTOS)
        for item in source:
            if not isinstance(item, dict) or not item.get("id") or item["id"] in seen:
                continue
            if item.get("type") not in (None, "IMAGE") or item.get("isTrashed"):
                continue
            seen.add(item["id"])
            rows.append(photo_row(item))
            if len(rows) >= MAX_PHOTOS:
                return rows
    return rows


# --------------------------------------------------------------------------
# Reihenfolge
# --------------------------------------------------------------------------

_queue_lock = threading.Lock()
_queue = {
    "rows": {},          # id -> (id, taken, place)
    "order": [],         # ids in Abspielreihenfolge
    "pos": 0,            # nächster Index in order
    "played": set(),     # Zufall: in dieser Runde schon gezeigt
    "signature": "",     # welche Einstellungen zur Liste geführt haben
    "at": 0.0, "error": "", "busy": False, "current": None,
}

ORDER_KEYS = ("Source", "Albums", "Rating", "RatingMode", "FavoritesOnly", "People", "Query", "QueryLimit",
              "ServerUrl", "ApiKey")


def signature(values):
    return json.dumps([values[k] for k in ORDER_KEYS], sort_keys=True)


def arrange(rows, values, keep_round, resume=False):
    """Die Abspielreihenfolge. Bei Zufall wird erst gezeigt, was in dieser
    Runde noch nicht dran war; nach Datum geht es hinter dem letzten Foto
    weiter (nach einem Neustart hinter dem zuletzt gemerkten)."""
    ids = [r[0] for r in rows]
    mode = values["Order"]
    if mode == "random":
        played = _queue["played"] if keep_round else set()
        played &= set(ids)
        rest = [i for i in ids if i not in played]
        random.shuffle(rest)
        _queue["played"] = played
        return rest, 0
    ordered = sorted(rows, key=lambda r: r[1], reverse=(mode == "newest"))
    ids = [r[0] for r in ordered]
    last = None
    if keep_round:
        last = _queue["current"]
    elif resume:
        last = load_state().get("lastId")
    pos = ids.index(last) + 1 if last in ids else 0
    return ids, pos % len(ids) if ids else 0


def rebuild(reason=""):
    values = settings()
    with _queue_lock:
        if _queue["busy"]:
            return False
        _queue["busy"] = True
    try:
        if not values["ServerUrl"] or not values["ApiKey"]:
            raise ImmichError(tr("Trag Adresse und API-Schlüssel deines Immich-Servers ein."))
        started = now()
        rows = collect(values)
        sig = signature(values)
        with _queue_lock:
            order, pos = arrange(rows, values, keep_round=sig == _queue["signature"],
                                 resume=not _queue["signature"])
            _queue.update(rows={r[0]: r for r in rows}, order=order, pos=pos, signature=sig,
                          at=now(), error="" if rows else tr("Keine Fotos passen zu deiner Auswahl."))
        plugin.log(f"{len(rows)} Fotos aus Immich gelesen ({now() - started:.1f} s){' - ' + reason if reason else ''}.")
        save_state(lastCount=len(rows), lastReadAt=now())
        return True
    except ImmichError as exc:
        with _queue_lock:
            _queue.update(error=str(exc), at=now())
            if signature(values) != _queue["signature"]:
                _queue.update(rows={}, order=[], pos=0, signature="")
        plugin.log(f"Immich: {exc}", level="warning")
        return False
    finally:
        with _queue_lock:
            _queue["busy"] = False


def reorder():
    """Nur die Reihenfolge hat sich geändert: die Liste neu ordnen, ohne Immich zu fragen."""
    values = settings()
    with _queue_lock:
        rows = list(_queue["rows"].values())
        if rows:
            _queue["order"], _queue["pos"] = arrange(rows, values, keep_round=False)


def next_photo():
    with _queue_lock:
        order = _queue["order"]
        if not order:
            return None
        if _queue["pos"] >= len(order):
            if settings()["Order"] == "random":
                last = _queue["current"]
                _queue["played"] = set()
                fresh = list(_queue["rows"].keys())
                random.shuffle(fresh)
                if len(fresh) > 1 and fresh[0] == last:  # nicht dasselbe Foto zweimal hintereinander
                    fresh.append(fresh.pop(0))
                _queue["order"] = order = fresh
            _queue["pos"] = 0
        photo_id = order[_queue["pos"]]
        _queue["pos"] += 1
        _queue["played"].add(photo_id)
        _queue["current"] = photo_id
        row = _queue["rows"].get(photo_id) or (photo_id, "", "")
        position, total = _queue["pos"], len(order)
    _remember_position(photo_id)
    return {"id": row[0], "taken": row[1], "place": row[2], "position": position, "total": total}


_last_saved = {"at": 0.0}


def _remember_position(photo_id):
    """Für die Reihenfolge nach Datum: wo es nach einem Neustart weitergeht.
    Höchstens alle fünf Minuten, der SD-Karte zuliebe."""
    if now() - _last_saved["at"] > 300:
        _last_saved["at"] = now()
        save_state(lastId=photo_id)


def photo_bytes(photo_id, size):
    """Ein Foto von Immich in der eingestellten Größe."""
    sizes = ["fullsize", "preview"] if size == "fullsize" else [size]  # ältere Server kennen kein fullsize
    last = None
    for wanted in sizes:
        try:
            response = immich("GET", f"/assets/{photo_id}/thumbnail", params={"size": wanted}, raw=True,
                              timeout=PHOTO_TIMEOUT)
            kind = response.headers.get("Content-Type", "image/jpeg").split(";")[0]
            if kind.startswith("image/"):
                return response.content, kind
            last = ImmichError(f"Immich lieferte {kind} statt eines Bildes")
        except ImmichError as exc:
            last = exc
            if exc.status in (401, 403, 404):
                break
    raise last or ImmichError("Kein Bild")


def face_bytes(person_id):
    response = immich("GET", f"/people/{person_id}/thumbnail", raw=True)
    return response.content, response.headers.get("Content-Type", "image/jpeg").split(";")[0]


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


# --------------------------------------------------------------------------
# Das Fenster: die wenigen Fotos, die gerade auf dem Rahmen liegen
# --------------------------------------------------------------------------
#
# DynaFrame spielt nur Dateien ab, die auf dem Rahmen liegen. Deshalb hält das
# Plugin immer nur ein kleines Fenster (Standard 10 Fotos) im Cache und gibt
# es DynaFrame als seinen Katalog. DynaFrame zeigt sie mit seiner eigenen
# Anzeigedauer und seinen Übergängen. Das Plugin schaut mit, welches Foto
# gerade läuft; sind alle Fotos des Fensters einmal gezeigt, kommt das
# nächste Fenster, und die Dateien des vorletzten werden gelöscht.

_window_lock = threading.RLock()
_window = {
    "files": [],        # Pfade des aktuellen Fensters
    "previous": [],     # Pfade des letzten Fensters (eins wird evtl. noch gezeigt)
    "seen": set(),      # Dateinamen, die DynaFrame aus diesem Fenster schon gezeigt hat
    "last": "",         # Dateiname, der zuletzt auf dem Bildschirm war
    "detected": False,  # hat DynaFrame schon einmal eines unserer Fotos gezeigt?
    "loggedItem": False, "note": "", "at": 0.0, "busy": False,
}


def _date_text(taken, language):
    if not taken or len(taken) < 10:
        return ""
    year, month, day = taken[:4], as_int(taken[5:7]), as_int(taken[8:10])
    months = texts.MONTHS.get(language) or texts.MONTHS["de"]
    if not 1 <= month <= 12:
        return taken[:10]
    if language == "en":
        return f"{day} {months[month - 1]} {year}"
    if language == "es":
        return f"{day} de {months[month - 1]} de {year}"
    return f"{day}. {months[month - 1]} {year}"


def download(photo, seq, values):
    """Ein Foto von Immich in den Cache, mit Datum und Ort für DynaFrame."""
    body, kind = photo_bytes(photo["id"], values["Quality"])
    ext = {"image/png": ".png", "image/webp": ".webp"}.get(kind, ".jpg")
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    # Die laufende Nummer vorne hält die Reihenfolge, wenn DynaFrame nach Namen spielt.
    path = CACHE_DIR / f"immich_{seq:07d}_{photo['id'][:8]}{ext}"
    path.write_bytes(body)
    title = _date_text(photo["taken"], values["Language"])
    sidecar = {"title": title or photo["place"], "description": photo["place"] if title else "",
               "provider": "Immich", "original_url": f"{values['ServerUrl']}/photos/{photo['id']}"}
    path.with_suffix(path.suffix + ".json").write_text(json.dumps(sidecar, ensure_ascii=False), encoding="utf-8")
    return path


def _delete(paths):
    for path in paths:
        for f in (Path(path), Path(str(path) + ".json")):
            try:
                f.unlink()
            except OSError:
                pass


def clear_cache():
    if CACHE_DIR.exists():
        _delete(p for p in CACHE_DIR.glob("immich_*") if not p.name.endswith(".json"))
        _delete(CACHE_DIR.glob("immich_*.json"))


def fill_window(reason=""):
    """Das nächste Fenster holen und DynaFrame geben."""
    values = settings()
    with _window_lock:
        if _window["busy"]:
            return False
        _window["busy"] = True
    try:
        seq = as_int(load_state().get("seq"), 0)
        fresh, ids, failures = [], set(), 0
        while len(fresh) < values["Window"] and failures < 5 and not _stop_requested.is_set():
            photo = next_photo()
            if photo is None or photo["id"] in ids:
                break  # nichts ausgewählt, oder die Auswahl ist kleiner als das Fenster
            ids.add(photo["id"])
            seq = seq % 9999999 + 1
            try:
                fresh.append(download(photo, seq, values))
            except ImmichError as exc:
                if exc.status in (401, 403):
                    raise
                failures += 1
                plugin.log(f"Foto {photo['id']} nicht geladen: {exc}", level="warning")
        save_state(seq=seq)
        if not fresh:
            return False
        plugin.submit_media([str(p) for p in fresh], replace_catalog=True)
        with _window_lock:
            _delete(_window["previous"])
            _window.update(previous=_window["files"], files=fresh, seen=set(), at=now(), note="")
        plugin.log(f"{len(fresh)} Fotos an DynaFrame gegeben{' - ' + reason if reason else ''}.")
        if values["MakePlaylist"]:
            threading.Thread(target=maintain_playlist, args=(fresh,), daemon=True).start()
        return True
    except ImmichError as exc:
        with _window_lock:
            _window["note"] = str(exc)
        plugin.log(f"Immich: {exc}", level="warning")
        return False
    finally:
        with _window_lock:
            _window["busy"] = False


def current_file_name():
    """Der Dateiname, den DynaFrame gerade zeigt, oder ""."""
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return ""
    item = status.get("currentItem") or {}
    if item and not _window["loggedItem"]:
        _window["loggedItem"] = True
        plugin.log("DynaFrame meldet das laufende Bild mit: " + ", ".join(sorted(item.keys())))
    for key in ("filePath", "path", "fullPath", "fileName", "name"):
        value = item.get(key)
        if value:
            return Path(str(value)).name
    return ""


def watch_tick():
    """Alle paar Sekunden: welches Foto zeigt DynaFrame? Sind alle Fotos des
    Fensters gezeigt und kommt eines davon noch einmal, ist das nächste Fenster dran."""
    name = current_file_name()
    rotate = False
    with _window_lock:
        names = {p.name for p in _window["files"]}
        if name and name != _window["last"]:
            if name in names:
                _window["detected"] = True
                rotate = name in _window["seen"] and _window["seen"] >= names
                _window["seen"].add(name)
            _window["last"] = name
    if rotate:
        fill_window()


# --------------------------------------------------------------------------
# Die Playlist "Immich Slideshow"
# --------------------------------------------------------------------------

_playlist = {"note": ""}
_playlist_lock = threading.Lock()


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def find_media_id(path, wait_seconds=30):
    """Die id, unter der die Engine ein gerade gemeldetes Foto führt (das dauert einen Moment).
    Plugin-Bilder stehen in keinem Ordner; die Suche der Engine findet sie über den Dateinamen."""
    query = urlencode({"query": Path(path).stem})
    deadline = now() + wait_seconds
    while not _stop_requested.is_set():
        try:
            found = engine_call("GET", f"/media/database/search?{query}")
            if isinstance(found, dict):
                found = found.get("items") or found.get("results") or []
            for row in found or []:
                if isinstance(row, dict) and Path(str(row.get("filePath") or "")).name == Path(path).name:
                    for key in ("id", "mediaFileId"):
                        if row.get(key) is not None:
                            return row[key]
        except EngineError as exc:
            plugin.log(f"Foto in der Engine suchen: {exc}", level="warning")
        if now() >= deadline:
            return None
        _stop_requested.wait(1.5)
    return None


def ensure_playlist():
    """Die id der Playlist; legt sie an, wenn es sie noch nicht gibt. None, wenn
    der Besitzer sie gelöscht hat (dann bleibt sie weg und die Einstellung geht aus)."""
    playlist_id = load_state().get("ownerPlaylistId")
    if playlist_id:
        if get_playlist(playlist_id) is not None:
            return playlist_id
        save_state(ownerPlaylistId=None)
        save_settings({"MakePlaylist": False})
        plugin.log("Die Playlist Immich Slideshow wurde gelöscht; sie wird nicht neu angelegt.")
        return None
    created = engine_call("POST", "/playlists", {"name": OWNER_PLAYLIST_NAME,
                                                 "description": OWNER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=OWNER_PLAYLIST_NAME))
    save_state(ownerPlaylistId=playlist_id)
    plugin.log(f"Playlist {OWNER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlist(files=None):
    """Die Playlist enthält genau die Fotos des aktuellen Fensters, ohne eigene
    Dauer: Anzeigedauer und Übergang bestimmt DynaFrame."""
    if not settings()["MakePlaylist"]:
        return
    with _playlist_lock:
        try:
            with _window_lock:
                files = list(files or _window["files"])
            playlist_id = ensure_playlist()
            if playlist_id is None or not files:
                _playlist["note"] = "" if playlist_id else _playlist["note"]
                return
            media = [m for m in (find_media_id(p) for p in files) if m is not None]
            if not media:
                _playlist["note"] = tr("Die Engine hat die Fotos noch nicht übernommen; gleich noch einmal.")
                return
            items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
            if isinstance(items, dict):
                items = items.get("items") or []
            # Erst die neuen Fotos dazu, dann die alten heraus: so ist die Playlist nie leer.
            for media_id in media:
                try:
                    engine_call("POST", f"/playlists/{playlist_id}/items", {"mediaFileId": media_id})
                except EngineError:
                    engine_call("POST", f"/playlists/{playlist_id}/items",
                                {"contentType": "media", "mediaFileId": media_id})
            for item in items:
                if isinstance(item, dict) and item.get("id") is not None:
                    try:
                        engine_call("DELETE", f"/playlists/{playlist_id}/items/{item['id']}")
                    except EngineError as exc:
                        plugin.log(f"Altes Foto aus der Playlist nehmen: {exc}", level="warning")
            _playlist["note"] = ""
        except EngineError as exc:
            _playlist["note"] = tr("Konnte die Playlist Immich Slideshow nicht pflegen: {exc}", exc=exc)
            plugin.log(_playlist["note"], level="warning")


def playlist_text(values):
    if _playlist["note"]:
        return _playlist["note"]
    if load_state().get("ownerPlaylistId"):
        return tr("Angelegt: die Playlist Immich Slideshow steht unter Playlists.")
    if values["MakePlaylist"]:
        return tr("Wird mit den nächsten Fotos angelegt.")
    return ""


# --------------------------------------------------------------------------
# Ablauf
# --------------------------------------------------------------------------

_stop_requested = threading.Event()
_wake = threading.Event()
_loop = {"lastError": ""}


def status_line():
    with _queue_lock:
        total, busy, error, at = len(_queue["rows"]), _queue["busy"], _queue["error"], _queue["at"]
    with _window_lock:
        note = _window["note"]
    if note and total:
        return note
    if busy:
        return tr("Liest die Fotos aus Immich …")
    if error and not total:
        return error
    if not at:
        return tr("Noch nicht gelesen.")
    return tr("{n} Fotos ausgewählt.", n=f"{total:,}".replace(",", "."))


_refill = threading.Event()   # neue Auswahl, Reihenfolge oder Fenstergröße: gleich neue Fotos


def main_loop():
    while not _stop_requested.is_set():
        values = settings()
        with _queue_lock:
            due = now() - _queue["at"] >= values["RefreshMinutes"] * 60 or \
                (_queue["error"] and now() - _queue["at"] >= 120)
            changed = _queue["signature"] != signature(values)
        if due or changed:
            if rebuild("geänderte Auswahl" if changed and _queue["signature"] else "") and changed:
                _refill.set()
        with _window_lock:
            empty = not _window["files"]
        if _refill.is_set() or empty:
            _refill.clear()
            fill_window()
        _wake.wait(30)
        _wake.clear()


def watch_loop():
    while not _stop_requested.is_set():
        try:
            watch_tick()
        except Exception as exc:  # noqa: BLE001
            plugin.log(f"Mitschauen: {exc}", level="warning")
        _stop_requested.wait(WATCH_SECONDS)


def check_now():
    def run():
        rebuild("von Hand")
    threading.Thread(target=run, daemon=True).start()
    return {"success": True, "message": tr("Liest die Fotos aus Immich …")}


def test_connection(values=None):
    values = values or settings()
    try:
        info = server_info(values)
    except ImmichError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden mit Immich {version} als {user}.", version=info["version"], user=info["user"])}


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def state_payload():
    values = settings()
    with _queue_lock:
        info = {"total": len(_queue["rows"]), "busy": _queue["busy"], "error": _queue["error"],
                "at": local_text(_queue["at"])}
    with _window_lock:
        names = [p.name for p in _window["files"]]
        current = next((n for n in names if n == _window["last"]), "")
        info.update(window=len(names), seen=len(_window["seen"] & set(names)), detected=_window["detected"],
                    current=current.split("_")[-1].split(".")[0] if current else "",
                    showing=bool(current))
    return {
        "success": True,
        "version": version(),
        "settings": public_settings(values),
        "status": status_line(),
        "photos": info,
        "playlist": playlist_text(values),
        "theme": {"id": theme_id()},
    }


def settings_saved(changed):
    if "MakePlaylist" in changed:
        threading.Thread(target=maintain_playlist, daemon=True).start()
    if "Order" in changed and not set(changed) & set(ORDER_KEYS):
        reorder()
        _refill.set()
    if set(changed) & {"Window", "Quality", "Language"}:
        _refill.set()
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _image(self, loader, cache, cors):
        try:
            body, kind = loader()
        except ImmichError as exc:
            self._json({"success": False, "error": str(exc)}, 404 if exc.status == 404 else 502, cors=cors)
            return
        self._send(body, kind, cache=cache, cors=cors)

    def do_GET(self):
        url = urlparse(self.path)
        path = unquote(url.path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            parts = path.strip("/").split("/")
            if len(parts) == 3 and parts[0] == "api" and UUID.match(parts[2]):
                kind, item = parts[1], parts[2]
                if kind == "thumb":
                    self._image(lambda: photo_bytes(item, "thumbnail"), "private, max-age=3600", False)
                    return
                if kind == "face":
                    self._image(lambda: face_bytes(item), "private, max-age=3600", False)
                    return
            if path == "/api/albums":
                self._json({"success": True, "albums": list_albums()})
                return
            if path == "/api/people":
                self._json({"success": True, "people": list_people()})
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except ImmichError as exc:
            self._json({"success": False, "error": str(exc)}, 502)
        except (BrokenPipeError, ConnectionResetError):
            pass  # die Seite hat das Laden abgebrochen
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                changed = save_settings(self._body())
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/test":
                self._json(test_connection())
                return
            if path == "/api/refresh":
                self._json(check_now())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    ensure_dirs()
    plugin.log(f"Starte {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: check_now())
    plugin.on_action("test-connection", lambda _context=None: plugin.log(test_connection()["message"]))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    clear_cache()  # Reste von früher; das erste Fenster kommt gleich
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    threading.Thread(target=watch_loop, name=f"{PLUGIN_ID}-watch", daemon=True).start()
    try:
        while not _stop_requested.is_set() and getattr(plugin, "is_running", lambda: True)():
            _stop_requested.wait(5)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _wake.set()
    with _queue_lock:
        current = _queue["current"]
    if current:
        save_state(lastId=current)
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
