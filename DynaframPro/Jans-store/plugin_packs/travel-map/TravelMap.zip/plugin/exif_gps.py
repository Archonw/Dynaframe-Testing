"""GPS-Position und Aufnahmezeit aus Fotos lesen, ohne Zusatzpakete.

Kennt JPEG (APP1/Exif), TIFF und Raw-Formate auf TIFF-Basis (DNG, NEF, CR2,
ARW), HEIC/HEIF/AVIF (Exif-Item im meta-Kasten), PNG (eXIf) und WebP (EXIF).
Gelesen wird nur der Kopf der Datei, nie das ganze Bild.

read(path) -> (lat, lon, taken) oder (None, None, taken); taken ist
"YYYY-MM-DDTHH:MM:SS" oder "".
"""

import struct

EXTENSIONS = {".jpg", ".jpeg", ".jpe", ".heic", ".heif", ".hif", ".avif", ".tif", ".tiff", ".dng", ".nef",
              ".cr2", ".arw", ".orf", ".rw2", ".pef", ".srw", ".png", ".webp"}
HEAD = 256 * 1024
MAX_EXIF = 4 * 1024 * 1024


class _Tiff:
    def __init__(self, data):
        if data[:2] == b"II":
            self.e = "<"
        elif data[:2] == b"MM":
            self.e = ">"
        else:
            raise ValueError("kein TIFF")
        if struct.unpack(self.e + "H", data[2:4])[0] not in (42, 0x4F52, 0x5352, 0x55):  # TIFF, ORF, RW2
            raise ValueError("kein TIFF")
        self.d = data

    def u16(self, at):
        return struct.unpack_from(self.e + "H", self.d, at)[0]

    def u32(self, at):
        return struct.unpack_from(self.e + "I", self.d, at)[0]

    def ifd(self, at):
        """{tag: (type, count, value_offset_field_position)}"""
        out = {}
        if at <= 0 or at + 2 > len(self.d):
            return out
        n = self.u16(at)
        for i in range(min(n, 512)):
            p = at + 2 + 12 * i
            if p + 12 > len(self.d):
                break
            out[self.u16(p)] = (self.u16(p + 2), self.u32(p + 4), p + 8)
        return out

    def first_ifd(self):
        return self.ifd(self.u32(4))

    def _where(self, entry, size):
        typ, count, field = entry
        total = size * count
        return field if total <= 4 else self.u32(field)

    def long(self, entry):
        typ, count, field = entry
        return self.u16(field) if typ == 3 else self.u32(field)

    def rationals(self, entry):
        typ, count, _ = entry
        if typ not in (5, 10):
            return []
        at = self._where(entry, 8)
        out = []
        for i in range(min(count, 8)):
            p = at + 8 * i
            if p + 8 > len(self.d):
                break
            fmt = self.e + ("ii" if typ == 10 else "II")
            num, den = struct.unpack_from(fmt, self.d, p)
            out.append(num / den if den else 0.0)
        return out

    def text(self, entry):
        typ, count, _ = entry
        if typ not in (2, 7) or count > 4096:
            return ""
        at = self._where(entry, 1)
        return self.d[at:at + count].split(b"\x00")[0].decode("latin-1", "replace").strip()


def _degrees(values):
    if not values:
        return None
    deg = values[0] + (values[1] / 60 if len(values) > 1 else 0) + (values[2] / 3600 if len(values) > 2 else 0)
    return deg


def _taken(text):
    # "2023:07:14 18:22:05" -> "2023-07-14T18:22:05"
    text = (text or "").strip()
    if len(text) < 10 or not text[:4].isdigit() or text.startswith("0000"):
        return ""
    date = text[:10].replace(":", "-")
    clock = text[11:19] if len(text) >= 19 else "00:00:00"
    return f"{date}T{clock}"


def parse_tiff(data):
    """(lat, lon, taken) aus einem TIFF-Block (dem Inhalt nach "Exif\\0\\0")."""
    tiff = _Tiff(data)
    ifd0 = tiff.first_ifd()
    taken = ""
    if 0x8769 in ifd0:
        exif = tiff.ifd(tiff.long(ifd0[0x8769]))
        for tag in (0x9003, 0x9004):
            if tag in exif:
                taken = _taken(tiff.text(exif[tag]))
                if taken:
                    break
    if not taken and 0x0132 in ifd0:
        taken = _taken(tiff.text(ifd0[0x0132]))
    lat = lon = None
    if 0x8825 in ifd0:
        gps = tiff.ifd(tiff.long(ifd0[0x8825]))
        if 2 in gps and 4 in gps:
            lat = _degrees(tiff.rationals(gps[2]))
            lon = _degrees(tiff.rationals(gps[4]))
            if lat is not None and 1 in gps and tiff.text(gps[1]).upper().startswith("S"):
                lat = -lat
            if lon is not None and 3 in gps and tiff.text(gps[3]).upper().startswith("W"):
                lon = -lon
    if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180) or (lat == 0 and lon == 0):
        lat = lon = None
    return lat, lon, taken


def _strip_exif_header(block):
    if block[:6] == b"Exif\x00\x00":
        return block[6:]
    return block


def _jpeg(handle):
    head = handle.read(2)
    if head != b"\xff\xd8":
        return None
    while True:
        marker = handle.read(2)
        if len(marker) < 2 or marker[0] != 0xFF:
            return None
        kind = marker[1]
        if kind in (0xD9, 0xDA):   # Ende oder Bilddaten: kein Exif davor
            return None
        if kind == 0x01 or 0xD0 <= kind <= 0xD7:
            continue
        size = struct.unpack(">H", handle.read(2))[0]
        if kind == 0xE1:
            block = handle.read(size - 2)
            if block[:6] == b"Exif\x00\x00":
                return block[6:]
        else:
            handle.seek(size - 2, 1)


def _boxes(data, start, end):
    at = start
    while at + 8 <= end:
        size, kind = struct.unpack_from(">I4s", data, at)
        head = 8
        if size == 1:
            if at + 16 > end:
                return
            size = struct.unpack_from(">Q", data, at + 8)[0]
            head = 16
        elif size == 0:
            size = end - at
        if size < head:
            return
        yield kind, at + head, min(at + size, end)
        at += size


def _heif(handle):
    data = handle.read(HEAD)
    meta = next(((s, e) for k, s, e in _boxes(data, 0, len(data)) if k == b"meta"), None)
    if not meta:
        return None
    start, end = meta[0] + 4, meta[1]   # meta ist eine "full box"
    exif_ids, locations = set(), {}
    for kind, s, e in _boxes(data, start, end):
        if kind == b"iinf":
            version = data[s]
            count_size = 2 if version == 0 else 4
            pos = s + 4 + count_size
            for ik, is_, ie in _boxes(data, pos, e):
                if ik != b"infe":
                    continue
                v = data[is_]
                if v >= 2:
                    item_id = struct.unpack_from(">H" if v == 2 else ">I", data, is_ + 4)[0]
                    off = is_ + 4 + (2 if v == 2 else 4) + 2
                    if data[off:off + 4] == b"Exif":
                        exif_ids.add(item_id)
        elif kind == b"iloc":
            version = data[s]
            p = s + 4
            sizes = struct.unpack_from(">H", data, p)[0]
            off_size, len_size, base_size = sizes >> 12, (sizes >> 8) & 15, (sizes >> 4) & 15
            idx_size = sizes & 15 if version in (1, 2) else 0
            p += 2
            count = struct.unpack_from(">H" if version < 2 else ">I", data, p)[0]
            p += 2 if version < 2 else 4

            def num(width, at):
                if width == 0:
                    return 0, at
                fmt = {4: ">I", 8: ">Q", 2: ">H", 1: ">B"}[width]
                return struct.unpack_from(fmt, data, at)[0], at + width

            for _ in range(min(count, 4096)):
                item_id, p = num(2 if version < 2 else 4, p)
                if version in (1, 2):
                    p += 2
                p += 2   # data_reference_index
                base, p = num(base_size, p)
                extents, p = num(2, p)
                first = None
                for _e in range(extents):
                    if idx_size:
                        _, p = num(idx_size, p)
                    eo, p = num(off_size, p)
                    el, p = num(len_size, p)
                    if first is None:
                        first = (base + eo, el)
                if first:
                    locations[item_id] = first
    for item_id in exif_ids:
        if item_id in locations:
            offset, length = locations[item_id]
            if 0 < length <= MAX_EXIF:
                handle.seek(offset)
                block = handle.read(length)
                if len(block) > 4:
                    skip = struct.unpack(">I", block[:4])[0]
                    return _strip_exif_header(block[4 + skip:] if 4 + skip < len(block) else block[4:])
    return None


def _png(handle):
    if handle.read(8) != b"\x89PNG\r\n\x1a\n":
        return None
    for _ in range(4096):
        head = handle.read(8)
        if len(head) < 8:
            return None
        size, kind = struct.unpack(">I4s", head)
        if kind == b"eXIf" and size <= MAX_EXIF:
            return _strip_exif_header(handle.read(size))
        if kind in (b"IDAT", b"IEND"):
            return None
        handle.seek(size + 4, 1)
    return None


def _webp(handle):
    head = handle.read(12)
    if head[:4] != b"RIFF" or head[8:12] != b"WEBP":
        return None
    for _ in range(64):
        chunk = handle.read(8)
        if len(chunk) < 8:
            return None
        kind, size = struct.unpack("<4sI", chunk)
        if kind == b"EXIF" and size <= MAX_EXIF:
            return _strip_exif_header(handle.read(size))
        handle.seek(size + (size & 1), 1)
    return None


def read(path):
    """(lat, lon, taken) eines Fotos. Fehler im Foto ergeben (None, None, "")."""
    try:
        with open(path, "rb") as handle:
            magic = handle.read(16)
            handle.seek(0)
            block = None
            if magic[:2] == b"\xff\xd8":
                block = _jpeg(handle)
            elif magic[:2] in (b"II", b"MM"):
                block = handle.read(HEAD * 4)
            elif magic[4:8] == b"ftyp":
                block = _heif(handle)
            elif magic[:4] == b"\x89PNG":
                block = _png(handle)
            elif magic[:4] == b"RIFF":
                block = _webp(handle)
            if not block:
                return None, None, ""
            return parse_tiff(block)
    except (OSError, ValueError, struct.error, KeyError, IndexError):
        return None, None, ""
