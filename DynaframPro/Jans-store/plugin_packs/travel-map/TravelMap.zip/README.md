# Travel Map (Reisekarte)

A DynaFrame scene with a world map in the style of an old globe, studded with
push pins where your photos were taken.

## What it shows

- Landscape: an oval world map (Mollweide) or three globes; portrait: three
  globes stacked. "Only where pins are" zooms to the area with pins.
- Every collection of photos gets its own pin: colour and shape (push pin,
  thumbtack, flag, long pin). Pins that would overlap are merged into one
  with a count.
- When the scene starts, the pins are put in one by one, in the order the
  photos were taken. Afterwards a photo is shown at its pin now and then,
  with place and date.

## Where the photos come from

- **All photos in DynaFrame**: the plugin asks DynaFrame for its media
  library and media folders and reads the GPS position from each file
  (JPEG, HEIC, TIFF/raw, PNG, WebP). Extra folders (e.g. a mounted NAS) can
  be added on the plugin page. Positions are cached, so later runs only open
  new files.
- **A DynaFrame playlist**.
- **Immich**: all photos (the Immich map) or one album. Needs the server
  address and an API key (`asset.read`, `asset.view`, `album.read`,
  `map.read`).

Photos without GPS data get no pin.

## Setup

1. Install the package from the store.
2. Plugins > Travel Map > Open Travel Map: pick the collections.
3. Press "Create playlist" (or add the scene "Travel Map" to any playlist).

## Privacy and credits

- Place names for DynaFrame photos come from OpenStreetMap Nominatim (at most
  one request per second, remembered on the frame); switch it off on the page.
- Map data: Natural Earth (public domain). Font: IM FELL English by Igino
  Marini (SIL Open Font License).
