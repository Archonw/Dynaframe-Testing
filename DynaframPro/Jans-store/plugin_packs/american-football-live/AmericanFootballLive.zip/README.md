# American Football Live

American Football Live zeigt die Spiele der aktuellen Woche und die Tabelle deiner Ligen auf dem Rahmen: NFL und College Football (Top 25) sind voreingestellt. Die College-Conferences SEC, Big Ten, Big 12 und ACC (alle Spiele ihrer Teams und ihre Tabelle), UFL und CFL lassen sich dazuschalten.

American Football Live besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene American Football Live** zeichnet die Spiele und die Tabelle. Jede gewählte Liga ist eine eigene Seite; die Seiten wechseln im eingestellten Takt.
- **Das Plugin** liest die Ergebnisse, hält alle Einstellungen und legt die Szene nach Zeitplan über die laufende Playlist.

## Einrichten

1. Paket installieren (Plugins > Hochladen, oder über den Store).
2. Auf der Plugins-Seite bei American Football Live **Allow takeover** einschalten. Ohne das kann American Football Live die Playlist nicht kurz beiseiteschieben.
3. **American Football Live öffnen** und Ligen, Reihenfolge, Takt und Anzeigedauer wählen. Alles wird sofort gespeichert.
4. Zum Ausprobieren **Anzeigen** drücken.

## Wie die Szene über die Playlist kommt

Es gibt drei Wege, und sie lassen sich kombinieren:

- **Regelmäßig (Takeover):** Unter *Regelmäßig über die Playlist legen* stellst du ein, **wann** (immer, nur an Spieltagen, nur wenn ein Spiel läuft, oder nie), **alle wie viele Minuten** und **für wie viele Sekunden**. Mit **Von/Bis Uhr** bleibt es z. B. nachts ruhig; NFL-Spiele laufen in Europa oft bis tief in die Nacht. Ein ausgeschalteter Bildschirm wird nie geweckt.
- **Bei einem Touchdown:** Wenn eingeschaltet, kommt die Szene bei einem Touchdown sofort für die eingestellte Zeit, mit seiner Liga zuerst. Punkte werden einmal pro Minute erkannt.
- **In einer Playlist:** Die Szene American Football Live kann wie jedes Bild in eine Playlist (empfohlene Dauer 60 Sekunden). Mit *Eine Playlist dafür* legt das Plugin eine Playlist „American Football Live“ für dich an.

Die Playlist **American Football Live (takeover)** benutzt das Plugin selbst für die Übernahme. Lass sie ausgeschaltet; wird sie gelöscht, legt das Plugin sie neu an.

## Was die Szene zeigt

- Kopf: Liga, Woche (oder Play-off-Runde), Anzahl der Live-Spiele, Uhrzeit und Stand der Daten.
- Je Spiel: Anstoß oder Viertel und Spieluhr, beide Teams mit Logo und das Ergebnis. Im Spiel steht beim Team mit Ballbesitz 🏈 und der Down, sonst die Bilanz der Saison.
- Daneben (im Hochformat darunter) die Tabelle je Conference oder Division mit Bilanz, Punktdifferenz und Siegquote. Grün markiert sind die Play-off-Plätze, bei den College-Conferences die zwei Plätze fürs Championship Game.
- Unter *Mein Team* wählst du dein Team. Sein Logo erscheint im Hintergrund der Szene und der Plugin-Seite, auf Wunsch werden seine Teamfarben zur Akzentfarbe.

## Automationen

Aktionen: **Anzeigen**, **Beenden**, **Umschalten**, **Jetzt aktualisieren**.

Ereignisse:

- **football_punkte** mit liga, heim, gast, stand, team, art (touchdown, field_goal, safety, extrapunkt, punkte; aus den Punkten geschätzt) und punkte.
- **football_anzeige_gestartet** mit grund (show, zeitplan, touchdown).
- **football_anzeige_beendet** mit grund (fertig, abgebrochen, verdraengt, abgelaufen, fehlgeschlagen, gestoppt).

Der Overlay-Dienst **Live-Stand** liefert eine Zeile mit den laufenden Spielen, sonst das nächste Spiel.

## Woher die Daten kommen

Alle Ligen kommen von **ESPN** (site.api.espn.com), der öffentlichen Schnittstelle der ESPN-Webseite, ohne Konto, aber nicht offiziell dokumentiert. ESPN liefert immer die laufende oder die nächste Woche.

## Wenn etwas nicht stimmt

- **Die Szene kommt nicht von selbst.** Ist *Allow takeover* an? Die Plugin-Seite sagt unter Status, warum nicht.
- **Unten rechts steht „Plugin nicht erreichbar – Notbetrieb“.** Die Szene liest dann nur die NFL selbst, ohne Tabelle. Prüfe, ob das Plugin läuft.
- **„Stand“ oben rechts ist gelb.** Die Daten sind älter als 15 Minuten. Die Szene zeigt den letzten Stand weiter.
