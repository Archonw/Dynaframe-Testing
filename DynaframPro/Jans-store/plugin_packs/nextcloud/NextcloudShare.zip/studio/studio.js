(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var state = null, editing = null;

  function api(path, body) {
    var opt = body === undefined ? {} : {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    };
    return fetch("./api/" + path, opt).then(function (r) { return r.json(); });
  }
  function msg(el, text, ok) { el.textContent = text || ""; el.className = "msg" + (text ? (ok ? " ok" : " bad") : ""); }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function field(label, type, value) {
    var l = el("label", null, label), i = el("input"); i.type = type; i.value = value || ""; l.appendChild(i); return { l: l, i: i };
  }

  function load() {
    return api("state").then(function (s) { state = s; render(); }).catch(function () {});
  }

  function render() {
    var r = state.run;
    $("runInfo").textContent = r.running ? "Updating…" : (r.message + (r.last ? " · " + r.last : ""));
    $("refreshBtn").disabled = r.running;
    var list = $("list");
    if (editing && list.contains(document.activeElement) && document.activeElement.tagName === "INPUT") { return; }
    list.textContent = "";
    $("empty").hidden = state.sources.length > 0;
    state.sources.forEach(function (s) { list.appendChild(item(s)); });
    var o = state.options;
    if (!render.optsDone) {
      render.optsDone = true;
      $("oMax").value = o.MaxPictures; $("oPick").value = o.PickMode; $("oMB").value = o.MaxFileMB;
      $("oRef").value = o.RefreshMinutes; $("oRec").checked = !!o.Recursive; $("oVid").checked = !!o.IncludeVideos;
    }
  }

  function item(s) {
    var box = el("div", "item" + (s.enabled ? "" : " off"));
    var top = el("div", "top");
    var t = el("div", "title"); var dot = el("span", "dot" + (s.status.ok === true ? " ok" : s.status.ok === false ? " bad" : ""));
    t.appendChild(dot); t.appendChild(document.createTextNode(s.title)); top.appendChild(t);
    var acts = el("div", "row");
    var sw = el("label", "switch"); var cb = el("input"); cb.type = "checkbox"; cb.checked = s.enabled;
    cb.onchange = function () { api("toggle", { id: s.id, enabled: cb.checked }).then(load); };
    sw.appendChild(cb); sw.appendChild(document.createTextNode("On")); acts.appendChild(sw);
    var eb = el("button", "btn", "Edit"); eb.onclick = function () { editing = editing === s.id ? null : s.id; render.force = true; list_rebuild(); };
    var tb = el("button", "btn", "Test"); var tm = el("span", "msg");
    tb.onclick = function () { msg(tm, "Testing…"); api("test", draftOf(s)).then(function (r) { msg(tm, r.message || r.error, r.success); }); };
    var db = el("button", "btn danger", "Delete");
    db.onclick = function () { if (confirm("Remove this source?")) api("delete", { id: s.id }).then(load); };
    acts.appendChild(eb); acts.appendChild(tb); acts.appendChild(db); top.appendChild(acts); box.appendChild(top);
    var sub = s.type === "account" ? s.user + " · " + s.server + " · " + s.folders : s.url;
    box.appendChild(el("div", "sub", sub + (s.hasPassword ? " · password set" : "")));
    box.appendChild(el("div", "sub", "Playlist: " + s.playlist));
    box.appendChild(el("div", "sub", s.status.message + (s.status.checked ? " · " + s.status.checked : "")));
    box.appendChild(tm);
    if (editing === s.id) box.appendChild(editor(s));
    return box;
  }

  function draftOf(s) { return Object.assign({ id: s.id, type: s.type, name: s.name, url: s.url, server: s.server, user: s.user, folders: s.folders }, s.draft || {}); }
  function list_rebuild() { var list = $("list"); list.textContent = ""; state.sources.forEach(function (s) { list.appendChild(item(s)); }); }

  function editor(s) {
    var d = el("div", "edit"), grid = el("div", "grid2");
    var name = field("Name (playlist)", "text", s.name), pw = field("New password (empty = keep)", "password", "");
    pw.i.autocomplete = "new-password";
    var f = { name: name, pw: pw };
    grid.appendChild(name.l);
    if (s.type === "account") {
      f.server = field("Server", "text", s.server); f.user = field("User name", "text", s.user); f.folders = field("Folders (;)", "text", s.folders);
      grid.appendChild(f.server.l); grid.appendChild(f.user.l); grid.appendChild(f.folders.l);
    } else {
      f.url = field("Share link", "text", s.url); grid.appendChild(f.url.l);
    }
    grid.appendChild(pw.l); d.appendChild(grid);
    var clr = el("label", "check"); var cc = el("input"); cc.type = "checkbox"; clr.appendChild(cc); clr.appendChild(document.createTextNode("Remove stored password")); d.appendChild(clr);
    var row = el("div", "row"), save = el("button", "btn primary", "Save"), m = el("span", "msg");
    function body() {
      var b = { id: s.id, type: s.type, name: name.i.value, password: pw.i.value, clearPassword: cc.checked };
      if (s.type === "account") { b.server = f.server.i.value; b.user = f.user.i.value; b.folders = f.folders.i.value; } else { b.url = f.url.i.value; }
      return b;
    }
    save.onclick = function () {
      api("save", body()).then(function (r) { msg(m, r.message || r.error, r.success); if (r.success) { editing = null; load(); } });
    };
    var test = el("button", "btn", "Test");
    test.onclick = function () { msg(m, "Testing…"); api("test", body()).then(function (r) { msg(m, r.message || r.error, r.success); }); };
    row.appendChild(save); row.appendChild(test); row.appendChild(m); d.appendChild(row);
    return d;
  }

  $("refreshBtn").onclick = function () { api("refresh", {}).then(load); };

  var shareRows = $("shareRows");
  function addShareRow() {
    var r = el("div", "srow");
    var u = field("Share link", "text", ""), p = field("Password (if any)", "password", ""), n = field("Name (playlist)", "text", "");
    n.i.maxLength = 60; n.i.placeholder = "e.g. Family holiday";
    u.i.placeholder = "https://cloud.example.org/s/AbCdEf123"; u.i.autocomplete = "off";
    p.i.autocomplete = "new-password";
    var rm = el("button", "btn danger small", "Remove"); rm.type = "button";
    var tt = el("button", "btn small", "Test"); tt.type = "button";
    var m = el("span", "msg");
    rm.onclick = function () { shareRows.removeChild(r); if (!shareRows.children.length) addShareRow(); };
    tt.onclick = function () {
      msg(m, "Testing…");
      api("test", { type: "share", url: u.i.value, password: p.i.value }).then(function (x) { msg(m, x.message || x.error, x.success); });
    };
    var btns = el("div", "srowbtns"); btns.appendChild(tt); btns.appendChild(rm);
    r.appendChild(u.l); r.appendChild(p.l); r.appendChild(n.l); r.appendChild(btns); r.appendChild(m);
    r._get = function () { return { url: u.i.value.trim(), password: p.i.value, name: n.i.value.trim() }; };
    shareRows.appendChild(r);
    return u.i;
  }
  function shareBody() {
    var links = [].map.call(shareRows.children, function (r) { return r._get(); }).filter(function (x) { return x.url; });
    return { type: "share", links: links };
  }
  $("moreLink").onclick = function () { addShareRow().focus(); };
  $("addShare").onclick = function () {
    api("add", shareBody()).then(function (r) {
      msg($("shareMsg"), r.message || r.error, r.success);
      if (r.success) { shareRows.textContent = ""; addShareRow(); load(); }
    });
  };
  addShareRow();
  function accBody() {
    return { type: "account", server: $("accServer").value, user: $("accUser").value, password: $("accPw").value,
             folders: $("accFolders").value, name: $("accName").value };
  }
  $("addAcc").onclick = function () {
    api("add", accBody()).then(function (r) {
      msg($("accMsg"), r.message || r.error, r.success);
      if (r.success) { $("accPw").value = ""; load(); }
    });
  };
  $("testAcc").onclick = function () {
    msg($("accMsg"), "Testing…");
    api("test", accBody()).then(function (r) { msg($("accMsg"), r.message || r.error, r.success); });
  };
  $("saveOpts").onclick = function () {
    api("options", { options: {
      MaxPictures: $("oMax").value, PickMode: $("oPick").value, MaxFileMB: $("oMB").value,
      RefreshMinutes: $("oRef").value, Recursive: $("oRec").checked, IncludeVideos: $("oVid").checked } })
      .then(function (r) { msg($("optMsg"), r.message || r.error, r.success); });
  };

  load();
  setInterval(load, 4000);
})();
