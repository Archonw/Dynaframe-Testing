#!/usr/bin/env python3
"""Phone Photos - der Plugin-Teil des Pakets.

Zeigt ein Foto, das man gerade auf dem Handy anschaut, sofort auf dem
Rahmen:

- iPhone: im Teilen-Menü der Fotos-App ein Kurzbefehl, der das Bild an
  http://<rahmen>:8095/upload schickt.
- Android: die Handy-Seite http://<rahmen>:8095/ (Foto wählen) oder die App
  "HTTP Shortcuts" im Teilen-Menü, die dasselbe tut.
- Jeder Browser im WLAN: dieselbe Handy-Seite.

Gezeigt wird in der Szene "phone-photos". Das Plugin holt sie über die
laufende Playlist (Display-Takeover) für ein paar Minuten und gibt den
Bildschirm danach zurück. Mehrere Fotos kurz hintereinander bilden eine
kleine Reihe, die sich abwechselt. Was gerade zu sehen sein soll, weiß nur
das Plugin; die Szene fragt jede Sekunde nach.
"""

import io
import json
import os
import re
import secrets
import socket
import sys
import threading
import time
from datetime import datetime
from email.parser import BytesParser
from email.policy import HTTP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - dann werden Fotos unverändert gespeichert
    Image = ImageOps = None

try:  # HEIC vom iPhone, falls jemand pillow-heif nachinstalliert hat
    import pillow_heif  # type: ignore
    pillow_heif.register_heif_opener()
except Exception:  # pragma: no cover
    pillow_heif = None

plugin = create_plugin()

PLUGIN_ID = "PhonePhotos"
DISPLAY_NAME = "Phone Photos"
SCENE_ID = "phone-photos"           # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Zustand und Fotos; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"
# Handy-Seite und Upload. Der erste freie Port gilt; 8095 steht in der Anleitung.
PHONE_PORTS = (8095, 8096, 8097, 8098)
MAX_UPLOAD = 40 * 1024 * 1024
MAX_EDGE = 3840                     # längste Kante auf dem Rahmen
THUMB_EDGE = 360
BATCH_SECONDS = 120                 # so kurz hintereinander: zur Reihe dazu
MAX_BATCH = 50

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "Language":     {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
    # So lange bleibt ein Foto (eine Reihe) auf dem Rahmen.
    "ShowMinutes":  {"kind": "number", "default": 5, "min": 1, "max": 240},
    # Bei mehreren Fotos: so lange jedes.
    "SlideSeconds": {"kind": "number", "default": 10, "min": 3, "max": 300},
    # contain: ganzes Foto vor unscharfem Hintergrund; cover: bildschirmfüllend beschnitten.
    "Fit":          {"kind": "choice", "default": "contain", "options": ["contain", "cover"]},
    # Absender und Uhrzeit klein unten einblenden.
    "Caption":      {"kind": "bool", "default": True},
    # Einen ausgeschalteten Bildschirm einschalten, wenn ein Foto kommt.
    "WakeScreen":   {"kind": "bool", "default": True},
    # So viele zuletzt gesendete Fotos bleiben auf dem Rahmen (zum erneuten Zeigen).
    "KeepPhotos":   {"kind": "number", "default": 30, "min": 1, "max": 300},
    # Wer im WLAN Fotos schicken darf: leer = alle, sonst nur mit diesem Code.
    "Pin":          {"kind": "pin", "default": ""},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
INDEX_FILE = PHOTO_DIR / "index.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "pin":
        return re.sub(r"[^0-9A-Za-z]", "", str(raw))[:12]
    return str(raw)[:200]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Phone Photos ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Phone Photos ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Die Takeover-Playlist
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Phone Photos (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Phone Photos abgespielt, wenn ein Foto vom Handy kommt. "
                                 "Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 12 * 3600  # das Plugin beendet die Anzeige lange vorher

_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Die Playlist wird nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, zwölf Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")


# --------------------------------------------------------------------------
# Die Fotos
# --------------------------------------------------------------------------

class PhotoError(Exception):
    pass


PHOTO_ID = re.compile(r"^[A-Za-z0-9_-]{6,40}$")
_photo_lock = threading.RLock()


def photo_index():
    with _photo_lock:
        rows = read_json(INDEX_FILE, [])
    return [r for r in rows if isinstance(r, dict) and PHOTO_ID.match(str(r.get("id", "")))] \
        if isinstance(rows, list) else []


def find_photo(photo_id):
    return next((r for r in photo_index() if r["id"] == photo_id), None)


def sniff(data):
    """Bildformat an den ersten Bytes erkennen."""
    head = data[:16]
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[4:8] == b"ftyp":
        brand = head[8:12]
        if brand in (b"heic", b"heix", b"hevc", b"heim", b"heis", b"mif1", b"msf1"):
            return "heic"
        if brand in (b"avif", b"avis"):
            return "avif"
    return ""


def prepare(data):
    """Foto drehen wie aufgenommen, verkleinern, als JPEG. (full, thumb, w, h)"""
    kind = sniff(data)
    if not kind:
        raise PhotoError(tr("Das ist kein Foto, das der Rahmen lesen kann."))
    if Image is None or (kind == "heic" and pillow_heif is None):
        if kind in ("heic", "avif"):
            raise PhotoError(tr("HEIC-Fotos vom iPhone kann der Rahmen nicht lesen. Füge im Kurzbefehl "
                                "„Bild konvertieren“ in JPEG ein oder schick das Foto über die Handy-Seite."))
        if Image is None:
            return data, data, 0, 0, kind
    try:
        image = Image.open(io.BytesIO(data))
        image = ImageOps.exif_transpose(image)
        if image.mode not in ("RGB", "L"):
            background = Image.new("RGB", image.size, (0, 0, 0))
            rgba = image.convert("RGBA")
            background.paste(rgba, mask=rgba.split()[3])
            image = background
        image = image.convert("RGB")
        image.thumbnail((MAX_EDGE, MAX_EDGE), Image.LANCZOS)
        width, height = image.size
        full = io.BytesIO()
        image.save(full, "JPEG", quality=90, optimize=True)
        small = image.copy()
        small.thumbnail((THUMB_EDGE, THUMB_EDGE), Image.LANCZOS)
        thumb = io.BytesIO()
        small.save(thumb, "JPEG", quality=80)
        return full.getvalue(), thumb.getvalue(), width, height, "jpeg"
    except Exception as exc:
        raise PhotoError(tr("Konnte das Foto nicht lesen: {exc}", exc=exc)) from exc


EXTENSIONS = {"jpeg": ".jpg", "png": ".png", "webp": ".webp", "gif": ".gif"}
TYPES = {".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif"}


def store_photo(data, sender=""):
    full, thumb, width, height, kind = prepare(data)
    photo_id = time.strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(3)
    ext = EXTENSIONS.get(kind, ".jpg")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    (PHOTO_DIR / f"{photo_id}{ext}").write_bytes(full)
    (PHOTO_DIR / f"{photo_id}.thumb{ext}").write_bytes(thumb)
    row = {"id": photo_id, "ext": ext, "w": width, "h": height, "at": now(), "from": sender[:40],
           "bytes": len(full)}
    with _photo_lock:
        rows = photo_index()
        rows.insert(0, row)
        write_json(INDEX_FILE, rows)
    prune_photos()
    plugin.log(f"Foto {photo_id} empfangen ({len(data) // 1024} KB{', von ' + sender if sender else ''}).")
    return row


def delete_files(row):
    for name in (f"{row['id']}{row.get('ext', '.jpg')}", f"{row['id']}.thumb{row.get('ext', '.jpg')}"):
        try:
            (PHOTO_DIR / name).unlink()
        except FileNotFoundError:
            pass
        except OSError as exc:
            plugin.log(f"Konnte {name} nicht löschen: {exc}", level="warning")


def prune_photos():
    keep = settings()["KeepPhotos"]
    with _show_lock:
        showing = set(_show["ids"]) if _show["active"] else set()
    with _photo_lock:
        rows = photo_index()
        kept, gone = [], []
        for row in rows:
            (kept if len(kept) < keep or row["id"] in showing else gone).append(row)
        if gone:
            write_json(INDEX_FILE, kept)
    for row in gone:
        delete_files(row)


def delete_photo(photo_id):
    with _photo_lock:
        rows = photo_index()
        row = next((r for r in rows if r["id"] == photo_id), None)
        if row is None:
            return False
        write_json(INDEX_FILE, [r for r in rows if r["id"] != photo_id])
    delete_files(row)
    with _show_lock:
        if photo_id in _show["ids"]:
            _show["ids"].remove(photo_id)
            _show["seq"] += 1
            if not _show["ids"]:
                _show["active"] = False
                _show["endedAt"] = now()
    _wake.set()
    return True


def photo_public(row):
    return {"id": row["id"], "w": row.get("w", 0), "h": row.get("h", 0), "from": row.get("from", ""),
            "at": local_text(row.get("at")), "url": f"photo/{row['id']}", "thumb": f"thumb/{row['id']}"}


# --------------------------------------------------------------------------
# Was gerade gezeigt werden soll
# --------------------------------------------------------------------------

_show_lock = threading.Lock()
_show = {"active": False, "ids": [], "seq": 0, "focus": "", "until": 0.0, "lastAdd": 0.0, "endedAt": 0.0}


def show_photos(ids, append=False):
    """Fotos auf den Rahmen. Mit append kommen sie zur laufenden Reihe dazu,
    wenn die gerade erst gekommen ist."""
    ids = [i for i in ids if find_photo(i)]
    if not ids:
        return False
    minutes = settings()["ShowMinutes"]
    with _show_lock:
        t = now()
        if append and _show["active"] and t - _show["lastAdd"] < BATCH_SECONDS:
            for photo_id in ids:
                if photo_id not in _show["ids"]:
                    _show["ids"].append(photo_id)
            del _show["ids"][:-MAX_BATCH]
        else:
            _show["ids"] = list(ids)[-MAX_BATCH:]
        _show.update(active=True, seq=_show["seq"] + 1, focus=ids[-1], until=t + minutes * 60, lastAdd=t)
    _wake.set()
    return True


def hide_photos(reason="ausgeblendet"):
    with _show_lock:
        was = _show["active"]
        _show.update(active=False, seq=_show["seq"] + 1, endedAt=now())
    if was:
        plugin.log(f"Fotos aus ({reason}).")
    _wake.set()
    return was


def receive(data, sender=""):
    """Ein Foto vom Handy: speichern und zeigen."""
    if not data:
        raise PhotoError(tr("Es kam kein Foto an."))
    row = store_photo(data, sender)
    show_photos([row["id"]], append=True)
    return row


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "limit": 0, "token": 0, "note": "", "retryAt": 0.0, "busy": False}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Phone Photos ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Phone Photos auf der Plugins-Seite aus. Schalte es ein, "
                  "sonst kann kein Foto gezeigt werden.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None)
        renewing = new_state == "expired"
    plugin.log(f"Der Rahmen hat Phone Photos beendet: {new_state}.")
    if not renewing:
        # Jemand anderes hat den Bildschirm genommen oder ihn zurückgeholt.
        hide_photos(f"Bildschirm {new_state}")
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    _wake.set()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    if reason not in ("gestoppt", "neu"):
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def session_lengths():
    """Etwas länger als die Anzeigedauer; manche Rahmen erlauben nur kürzere."""
    wanted = settings()["ShowMinutes"] * 60 + 60
    return sorted({min(wanted, 4 * 3600), min(wanted, 3600), min(wanted, 300)}, reverse=True)


def show_scene():
    """Die Szene über alles legen. True, wenn der Rahmen den Bildschirm hergegeben hat."""
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Phone Photos wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    wake = settings()["WakeScreen"]
    if not wake and display_is_off():
        hide_photos("Bildschirm aus")
        return _note(tr("Der Bildschirm ist aus; das Foto wird nicht gezeigt."))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Bildunterschrift.
             "overlay": {"enabled": False}}
    handle, limit, last_error = None, 0, None
    for seconds in session_lengths():
        try:
            _leftover["askedAt"] = time.time()
            handle = plugin.acquire_display_session(
                session_key="photo", state=state, display_name=DISPLAY_NAME,
                max_duration_seconds=seconds, wake_if_off=wake)
            limit = seconds
            break
        except Exception as exc:
            last_error = exc
    if handle is None:
        if last_error is not None:
            return _note(tr("Konnte das Foto nicht anzeigen: {exc}", exc=last_error))
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), limit=limit, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=15):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat das Foto nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(tr("Konnte das Foto nicht anzeigen: {exc}", exc=exc))
    plugin.log("Phone Photos hat den Bildschirm.")
    return True


def decide_takeover():
    """Sollen Fotos zu sehen sein und hat das Plugin den Bildschirm nicht:
    holen. Ist die Zeit um oder wurde ausgeblendet: zurückgeben."""
    t = now()
    with _show_lock:
        active, until = _show["active"], _show["until"]
    if active and t >= until:
        hide_photos("Zeit abgelaufen")
        active = False
    with _takeover_lock:
        handle, since, limit = _takeover["handle"], _takeover["since"], _takeover["limit"]
        retry_at, busy = _takeover["retryAt"], _takeover["busy"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not active:
            end_takeover("fertig")
        elif since and limit and t - since >= limit - 20:
            end_takeover("neu")   # gleich wieder holen, frisch mit voller Zeit
            _wake.set()
        return
    if not active or t < retry_at or busy:
        return
    with _takeover_lock:
        _takeover["busy"] = True
    try:
        if not show_scene():
            # Nicht bekommen: in 20 Sekunden noch einmal, solange Fotos zu sehen sein sollen.
            with _takeover_lock:
                _takeover["retryAt"] = t + 20
    finally:
        with _takeover_lock:
            _takeover["busy"] = False


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach den Fotos nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

_loop = {"lastError": ""}


def tick():
    try:
        stop_leftover_takeover()
        maintain_playlists()
        decide_takeover()
        _loop["lastError"] = ""
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")


def main_loop():
    _stop_requested.wait(1)
    while not _stop_requested.is_set():
        _wake.clear()
        tick()
        busy = _takeover["handle"] is not None or _show["active"]
        _wake.wait(1 if busy else 5)


# --------------------------------------------------------------------------
# Die Seite (auf dem Rahmen und als Handy-Seite) und ihre API
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored_theme = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored_theme, dict):
        return ""
    value = next((str(v) for k, v in stored_theme.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html(phone=False):
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    if phone:
        # Auf dem Handy nur Senden und die letzten Fotos; das Einrichten bleibt auf dem Rahmen.
        return html.replace("<html", '<html data-phone="1"', 1)
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
    "/qrcode.js": ("studio/qrcode.js", "application/javascript; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
}


def lan_address():
    """Die Adresse des Rahmens im WLAN (es wird nichts gesendet)."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("192.0.2.1", 9))
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


def phone_url():
    if phone_server is None:
        return ""
    address = lan_address() or socket.gethostname()
    port = phone_server.server_address[1]
    return f"http://{address}:{port}/"


def scene_payload():
    values = settings()
    with _show_lock:
        show = dict(_show, ids=list(_show["ids"]))
    rows = {r["id"]: r for r in photo_index()}
    photos = [photo_public(rows[i]) for i in show["ids"] if i in rows] if show["active"] else []
    return {
        "at": now(), "lang": values["Language"], "showing": bool(photos), "seq": show["seq"],
        "focus": show["focus"], "photos": photos, "slideSeconds": values["SlideSeconds"],
        "fit": values["Fit"], "caption": values["Caption"], "phoneUrl": phone_url(),
    }


def state_payload(phone=False):
    values = settings()
    with _show_lock:
        show = dict(_show, ids=list(_show["ids"]))
    with _takeover_lock:
        on_screen = _takeover["handle"] is not None
        note = _takeover["note"]
    recent = [photo_public(r) for r in photo_index()]
    payload = {
        "success": True,
        "version": version(),
        "showing": show["active"], "onScreen": on_screen, "ids": show["ids"] if show["active"] else [],
        "remaining": max(0, int(show["until"] - now())) if show["active"] else 0,
        "recent": recent,
        "phoneUrl": phone_url(),
        "note": note or _playlists["note"] or _scene["note"],
        "permission": takeover_permission_note() if not phone else "",
        "lastError": _loop["lastError"] or load_state().get("playbackStalled") or "",
        "language": values["Language"],
        "needPin": bool(values["Pin"]),
    }
    if not phone:
        payload["settings"] = values
        payload["theme"] = {"id": theme_id()}
        payload["pillow"] = Image is not None
    return payload


def control(body):
    action = str(body.get("action") or "")
    if action == "hide":
        hide_photos("auf der Seite ausgeblendet")
        return {"success": True}
    if action == "show":
        ids = body.get("ids") or ([body.get("id")] if body.get("id") else [])
        ids = [str(i) for i in ids if PHOTO_ID.match(str(i))]
        return {"success": show_photos(ids)}
    if action == "last":
        rows = photo_index()
        return {"success": bool(rows) and show_photos([rows[0]["id"]])}
    if action == "delete":
        return {"success": delete_photo(str(body.get("id") or ""))}
    if action == "extend":
        with _show_lock:
            if _show["active"]:
                _show["until"] = now() + settings()["ShowMinutes"] * 60
        return {"success": True}
    return {"success": False, "error": "Unbekannt"}


def multipart_files(content_type, body):
    """Alle Dateien aus einem Formular (multipart/form-data)."""
    message = BytesParser(policy=HTTP).parsebytes(
        b"Content-Type: " + content_type.encode("latin-1") + b"\r\n\r\n" + body)
    files = []
    for part in message.iter_parts() if message.is_multipart() else []:
        payload = part.get_payload(decode=True) or b""
        if part.get_filename() is not None or sniff(payload):
            if payload:
                files.append(payload)
    return files


def upload(content_type, body, query):
    sender = re.sub(r"[\x00-\x1f<>&\"]", "", (query.get("from") or [""])[0]).strip()[:40]
    if not sender:
        sender = tr("Handy")
    if content_type.lower().startswith("multipart/"):
        files = multipart_files(content_type, body)
    else:
        files = [body] if body else []
    if not files:
        raise PhotoError(tr("Es kam kein Foto an."))
    rows = [receive(data, sender) for data in files]
    count = len(rows)
    message = tr("Auf dem Rahmen.") if count == 1 else tr("{count} Fotos auf dem Rahmen.", count=count)
    return {"success": True, "message": message, "ids": [r["id"] for r in rows]}


def pin_ok(query, headers):
    pin = settings()["Pin"]
    if not pin:
        return True
    given = (query.get("pin") or [""])[0] or headers.get("X-Pin") or ""
    return secrets.compare_digest(str(given), pin)


def api(method, path, query, body, content_type="", trusted=True, headers=None, phone=False):
    """Gemeinsame Antworten für die Plugin-Seite (127.0.0.1) und die
    Handy-Seite (Port 8095). (status, content_type, bytes) oder None."""
    def js(payload, status=200):
        return status, "application/json; charset=utf-8", json.dumps(payload, ensure_ascii=False).encode("utf-8")

    headers = headers or {}
    allowed = trusted or pin_ok(query, headers)

    if method == "GET":
        if path in ("/", "/index.html"):
            return 200, "text/html; charset=utf-8", page_html(phone).encode("utf-8")
        asset = STUDIO_FILES.get(path)
        if asset:
            return 200, asset[1], (PLUGIN_DIR / asset[0]).read_bytes()
        if path == "/manifest.webmanifest":
            return 200, "application/manifest+json", json.dumps({
                "name": DISPLAY_NAME, "short_name": "DynaFrame", "start_url": "./", "display": "standalone",
                "background_color": "#0e1116", "theme_color": "#0e1116",
                "icons": [{"src": "icon.png", "sizes": "256x256", "type": "image/png"}]}).encode("utf-8")
        if path == "/api/scene":
            return js(scene_payload())
        if path == "/api/state":
            if not allowed:
                return js({"success": False, "needPin": True, "language": settings()["Language"]}, 403)
            return js(state_payload(phone=phone))
        match = re.match(r"^/(photo|thumb)/([A-Za-z0-9_-]+)(?:\.\w+)?$", path)
        if match:
            if not allowed:
                return js({"success": False, "needPin": True}, 403)
            row = find_photo(match.group(2))
            if row is None:
                return None
            ext = row.get("ext", ".jpg")
            name = f"{row['id']}{'.thumb' if match.group(1) == 'thumb' else ''}{ext}"
            try:
                return 200, TYPES.get(ext, "image/jpeg"), (PHOTO_DIR / name).read_bytes()
            except FileNotFoundError:
                return None
        return None

    if method == "POST":
        if path in ("/upload", "/api/upload"):
            if not allowed:
                return js({"success": False, "needPin": True, "error": tr("Falscher Code.")}, 403)
            try:
                return js(upload(content_type, body, query))
            except PhotoError as exc:
                return js({"success": False, "error": str(exc)}, 400)
        data = {}
        if body:
            try:
                data = json.loads(body.decode("utf-8", "replace"))
            except ValueError:
                data = {k: v[0] for k, v in parse_qs(body.decode("utf-8", "replace")).items() if v}
        if not isinstance(data, dict):
            data = {}
        if path == "/api/control":
            if not allowed:
                return js({"success": False, "needPin": True, "error": tr("Falscher Code.")}, 403)
            return js(control(data))
        if path == "/api/settings" and not phone:
            changed = save_settings(data)
            if "KeepPhotos" in changed:
                prune_photos()
            _wake.set()
            return js({"success": True, "changed": changed})
        return None
    return None


class Handler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"
    phone = False

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "private, max-age=86400" if content_type.startswith("image/")
                         else "no-store")
        # Die Szene kommt vom Port der Engine, diese Seite über :8003.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        if length > MAX_UPLOAD:
            raise PhotoError(tr("Das Foto ist zu groß (höchstens {mb} MB).", mb=MAX_UPLOAD // 1048576))
        if length <= 0:
            return b""
        chunks, left = [], length
        while left > 0:
            chunk = self.rfile.read(min(left, 1 << 20))
            if not chunk:
                break
            chunks.append(chunk)
            left -= len(chunk)
        return b"".join(chunks)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Pin")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _route(self, method):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        trusted = not self.phone or self.client_address[0] in ("127.0.0.1", "::1")
        try:
            body = self._body() if method == "POST" else b""
            answer = api(method, path, parse_qs(parsed.query), body, self.headers.get("Content-Type") or "",
                         trusted, self.headers, self.phone)
        except PhotoError as exc:
            self.close_connection = True
            answer = (413, "application/json", json.dumps({"success": False, "error": str(exc)}).encode("utf-8"))
        except OSError as exc:
            answer = (500, "application/json", json.dumps(
                {"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}).encode("utf-8"))
        except Exception as exc:  # pragma: no cover
            answer = (500, "application/json", json.dumps({"success": False, "error": str(exc)}).encode("utf-8"))
        if answer is None:
            answer = (404, "application/json", b'{"success": false, "error": "Nicht gefunden"}')
        self._send(answer[2], answer[1], answer[0])

    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")


class PhoneHandler(Handler):
    phone = True


studio_server = None
phone_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


def start_phone():
    """Die Handy-Seite und der Upload, im ganzen WLAN erreichbar."""
    global phone_server
    for port in PHONE_PORTS:
        try:
            phone_server = ThreadingHTTPServer(("0.0.0.0", port), PhoneHandler)
            break
        except OSError as exc:
            plugin.log(f"Port {port} ist belegt ({exc}).", level="warning")
    if phone_server is None:
        _note(tr("Kein freier Port für die Handy-Seite (8095 bis 8098)."))
        return
    phone_server.daemon_threads = True
    threading.Thread(target=phone_server.serve_forever, name=f"{PLUGIN_ID}-phone", daemon=True).start()
    plugin.log(f"Handy-Seite: {phone_url()}")


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starte {PLUGIN_ID} {version()}" + ("" if Image else " (ohne Pillow)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("hide", lambda _context=None: control({"action": "hide"}))
    plugin.on_action("last", lambda _context=None: control({"action": "last"}))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    start_phone()
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set() and getattr(plugin, "is_running", lambda: True)():
            _stop_requested.wait(5)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    with _show_lock:
        _show["active"] = False
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    for server in (studio_server, phone_server):
        if server is not None:
            try:
                server.shutdown()
                server.server_close()
            except Exception:
                pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
