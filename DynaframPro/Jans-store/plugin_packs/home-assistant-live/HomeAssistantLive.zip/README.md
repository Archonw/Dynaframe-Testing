# Home Assistant Live

Home Assistant Live zeigt auf dem Rahmen, was zu Hause gerade passiert, in dem Moment, in dem es passiert: ein Fenster oder eine Tür geht auf, es klingelt an der Haustür (mit dem Bild der Kamera), die Waschmaschine ist fertig. Nach der eingestellten Zeit läuft die Playlist dort weiter, wo sie war. Eine regelmäßige Anzeige gibt es nicht; es kommt nur etwas, wenn etwas passiert.

Das Paket besteht aus zwei Teilen, die zusammen installiert werden:

- **Das Plugin** hält die Verbindung zu deinem Home Assistant, erkennt die Ereignisse und legt die Szene kurz über die Playlist.
- **Die Szene Home Assistant Live** zeigt das Ereignis groß, mit Symbol, Uhrzeit und, bei der Klingel, dem Kamerabild, das jede Sekunde neu geladen wird.

## Einrichten

1. Paket installieren (über den Store oder Plugins > Hochladen).
2. Auf der Plugins-Seite bei Home Assistant Live **Allow takeover** einschalten.
3. **Open Home Assistant Live** öffnen, die Adresse deines Home Assistant eintragen (z. B. `http://192.168.178.20:8123` oder `homeassistant.local`) und einen langlebigen Zugangstoken einfügen. Den bekommst du in Home Assistant unter *Profil > Sicherheit > Langlebige Zugangstoken > Token erstellen*.
4. **Verbinden** drücken. Das Plugin trägt Offensichtliches gleich selbst ein: alle Fenster und Türen, die einzige Klingel und Kamera, Waschmaschine, Trockner und Spülmaschine mit Leistungssensor.
5. Mit **Probe-Anzeige** ausprobieren.

Adresse und Token bleiben auf dem Rahmen; das Plugin spricht nur mit deinem Home Assistant.

## Was angezeigt wird

- **Fenster und Türen:** alle Kontakte, die Home Assistant als Fenster, Tür, Garagentor oder Öffnung kennt, oder nur ausgewählte. Angezeigt wird, wenn einer von zu auf offen wechselt.
- **Haustürklingel:** eine Klingel-Entität (event.*, binary_sensor, Taster), dazu auf Wunsch eine Kamera. Auf Wunsch schaltet die Klingel auch einen ausgeschalteten Bildschirm ein.
- **Geräte fertig:** ein Leistungssensor je Gerät. Fertig ist es, wenn es mindestens zwei Minuten über der Schwelle lief und die Leistung dann für die eingestellte Zeit (Standard 3 Minuten) unter der Schwelle (Standard 5 W) bleibt. Kurze Pausen im Waschgang zählen deshalb nicht.
- **Eigene Ereignisse:** eine beliebige Entität, die auf einen bestimmten Zustand wechselt (z. B. `sensor.trockner_status` auf `Fertig`), mit eigenem Text.
- **Aus einer Automation:** jede Automation in Home Assistant kann das Ereignis `dynaframe_live` auslösen:

  ```yaml
  actions:
    - event: dynaframe_live
      event_data:
        title: "Die Post ist da"
        message: "Der Briefkasten wurde geöffnet"
        icon: info          # window, door, garage, doorbell, appliance, alarm, info
        camera: camera.einfahrt
        seconds: 30
  ```

Kommen mehrere Ereignisse zugleich, steht die Klingel vorn, sonst das neueste; die anderen stehen klein darunter. Dasselbe Ereignis kommt höchstens einmal pro Minute. In der **Ruhezeit** wird nichts angezeigt, außer auf Wunsch die Klingel.

## Wenn etwas nicht stimmt

- **Es kommt nichts auf den Rahmen.** Ist *Allow takeover* an? Steht oben bei Home Assistant „Verbunden“? Die Plugin-Seite zeigt unter *Zuletzt*, welche Ereignisse erkannt wurden.
- **„Home Assistant lehnt den Zugangstoken ab“.** Den Token neu erstellen und einfügen; er wird in Home Assistant nur einmal angezeigt.
- **„Das Zertifikat wird nicht akzeptiert“.** Statt der https-Adresse die lokale Adresse mit `http://` und Port 8123 nehmen.
- **Ereignisse aus Automationen kommen nicht.** Das Abo von `dynaframe_live` braucht den Token eines Administrators.
- **Nach der Anzeige läuft die Playlist nicht weiter.** Das ist ein bekannter Fehler des Rahmens bei einem Quick Mix; das Plugin versucht ihn selbst zu beheben. Mit einer gespeicherten Playlist passiert es nicht.

Die Playlist **Home Assistant Live (takeover)** benutzt das Plugin selbst. Lass sie ausgeschaltet; wird sie gelöscht, legt das Plugin sie neu an.
