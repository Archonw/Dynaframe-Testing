/* Home Assistant Live - die Szene.
 *
 * Daten kommen vom Plugin Home Assistant Live, über den Proxy der
 * Weboberfläche auf :8003 (der Proxy der Engine lehnt lokale Adressen ab).
 * Das Plugin holt die Szene nur für ein Ereignis auf den Bildschirm; sie
 * fragt jede Sekunde nach, damit ein zweites Ereignis sofort erscheint.
 * Mit ?demo=doorbell (oder window, appliance, ...) zeigt sie ein Beispiel.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "HomeAssistantLive";
  const POLL_MS = 1000;
  const CAMERA_MS = 1000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.get("demo");
  const pluginBase = params.get("plugin") ||
    `${location.protocol}//${location.hostname}:8003/Plugins/Advanced/${PLUGIN_ID}/`;

  const el = (id) => document.getElementById(id);
  const ui = {
    stage: el("stage"), camera: el("camera"), cameraImage: el("cameraImage"), live: el("cameraLive"),
    icon: el("icon"), title: el("title"), text: el("text"), when: el("when"), more: el("more"),
    clock: el("clock"), fill: el("fill")
  };

  const TEXT = {
    de: { idle: "Gerade ist nichts los.", unreachable: "Home Assistant Live antwortet nicht.", ago: "vor {n} Min.",
      now: "gerade eben", at: "um {time} Uhr" },
    en: { idle: "Nothing is happening right now.", unreachable: "Home Assistant Live is not responding.", ago: "{n} min ago",
      now: "just now", at: "at {time}" },
    es: { idle: "Ahora mismo no pasa nada.", unreachable: "Home Assistant Live no responde.", ago: "hace {n} min",
      now: "ahora mismo", at: "a las {time}" }
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = params.get("lang") || "de";
  const tx = (key, values = {}) => ((TEXT[lang] || TEXT.de)[key] || key).replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");

  // Strichsymbole, 24er-Raster, in currentColor.
  const PATHS = {
    window: '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M12 3v18M4 12h16"/>',
    door: '<path d="M6 21V4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21M3 21h18"/><circle cx="14.5" cy="12.5" r="1" fill="currentColor"/>',
    garage: '<path d="M3 21V9l9-6 9 6v12"/><path d="M7 21v-9h10v9M7 15h10M7 18h10"/>',
    doorbell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2.5h-15z"/><path d="M10 21a2 2 0 0 0 4 0"/><path d="M12 3v2"/>',
    appliance: '<rect x="4" y="2.5" width="16" height="19" rx="2"/><circle cx="12" cy="13.5" r="5"/><path d="M7 6h.01M10 6h.01"/><path d="M9.5 14.5c1.2-1 3.8 1 5 0"/>',
    alarm: '<path d="M12 3 2.5 20h19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.5h.01"/>',
    custom: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 9.5V20h13V9.5"/><path d="M10 20v-5h4v5"/>',
    test: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 9.5V20h13V9.5"/><path d="m9 14.5 2 2 4-4"/>',
    idle: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 9.5V20h13V9.5"/><path d="M10 20v-5h4v5"/>'
  };
  const CHIP = { window: "#f5a524", door: "#f5a524", garage: "#f5a524", doorbell: "#4c9aff", appliance: "#3fb950",
    alarm: "#f85149", info: "#a371f7", custom: "#a371f7", test: "#2fb7c4" };
  const svg = (kind) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" ` +
    `stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${PATHS[kind] || PATHS.custom}</svg>`;

  let readySent = false;
  let shownId = null;
  let shownKind = null;
  let cameraUrl = "";
  let cameraTimer = null;
  let failures = 0;
  let data = null;

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function hhmm(epoch) {
    return new Date(epoch * 1000).toLocaleTimeString(LOCALES[lang] || "de-DE", { hour: "2-digit", minute: "2-digit" });
  }

  function whenText(epoch) {
    const minutes = Math.floor((Date.now() / 1000 - epoch) / 60);
    if (minutes < 1) return `<b>${tx("now")}</b> · ${tx("at", { time: hhmm(epoch) })}`;
    return `${tx("ago", { n: minutes })} · ${tx("at", { time: hhmm(epoch) })}`;
  }

  function esc(text) {
    return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  // ------------------------------------------------------------ Kamera

  function setCamera(url) {
    if (url === cameraUrl) return;
    cameraUrl = url;
    clearTimeout(cameraTimer);
    ui.camera.hidden = !url;
    ui.stage.classList.toggle("with-camera", Boolean(url));
    ui.cameraImage.removeAttribute("src");
    if (url) loadCamera();
  }

  function loadCamera() {
    const url = cameraUrl;
    if (!url) return;
    const next = new Image();
    const done = (ok) => {
      if (url !== cameraUrl) return;
      if (ok) ui.cameraImage.src = next.src;
      ui.live.classList.toggle("stale", !ok);
      cameraTimer = setTimeout(loadCamera, CAMERA_MS);
    };
    next.onload = () => done(true);
    next.onerror = () => done(false);
    next.src = DEMO ? url : new URL(url, pluginBase).href + `?t=${Date.now()}`;
  }

  // ------------------------------------------------------------ Anzeige

  function render() {
    ui.clock.textContent = hhmm(Date.now() / 1000);
    const events = (data && data.events) || [];
    const main = events[0];
    if (!main) {
      setCamera("");
      ui.stage.dataset.kind = "idle";
      if (shownId !== "idle") {
        shownId = "idle";
        ui.icon.innerHTML = svg("idle");
        ui.title.textContent = "Home Assistant Live";
      }
      ui.text.hidden = false;
      ui.text.textContent = failures >= 3 ? tx("unreachable") : tx("idle");
      ui.when.textContent = "";
      ui.more.replaceChildren();
      return;
    }
    if (main.id !== shownId) {
      shownId = main.id;
      ui.stage.dataset.kind = main.kind;
      if (main.kind !== shownKind) ui.icon.innerHTML = svg(main.kind);
      shownKind = main.kind;
      ui.title.textContent = main.title;
      ui.text.textContent = main.text || "";
      ui.text.hidden = !main.text;
      // Die Karte neu einblenden, damit ein neues Ereignis auffällt.
      const card = el("card");
      card.style.animation = "none";
      void card.offsetWidth;
      card.style.animation = "";
    }
    setCamera(main.camera || "");
    ui.when.innerHTML = whenText(main.at);
    const total = Math.max(1, main.until - main.at);
    const left = Math.max(0, main.until - Date.now() / 1000);
    ui.fill.style.width = `${Math.min(100, (left / total) * 100)}%`;

    ui.more.innerHTML = events.slice(1, 5).map((e) =>
      `<li style="--chip:${CHIP[e.kind] || CHIP.custom}">${svg(e.kind)}${esc(e.title)}` +
      (e.text ? ` <span>${esc(e.text)}</span>` : "") + "</li>").join("");
  }

  let polling = false;
  async function poll() {
    if (DEMO || polling) return;
    polling = true;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    try {
      const response = await fetch(new URL("api/scene", pluginBase), { signal: controller.signal, cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const next = await response.json();
      if (!next || !Array.isArray(next.events)) throw new Error("unerwartete Antwort");
      data = next;
      if (next.lang && TEXT[next.lang]) lang = next.lang;
      document.documentElement.lang = lang;
      failures = 0;
    } catch (_) {
      failures += 1;
      // Ein kurzer Aussetzer lässt das letzte Ereignis stehen.
      if (failures >= 3) data = null;
    } finally {
      clearTimeout(timer);
      polling = false;
    }
    render();
    ready();
  }

  // ------------------------------------------------------------ Beispiele

  function demo(kind) {
    const t = Date.now() / 1000;
    const pic = "data:image/svg+xml," + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0" stop-color="#5b6b7d"/><stop offset="1" stop-color="#2b333d"/></linearGradient></defs>' +
      '<rect width="640" height="480" fill="url(#g)"/><rect x="230" y="90" width="180" height="330" fill="#6e4b32"/>' +
      '<circle cx="385" cy="260" r="7" fill="#d9b25f"/><rect x="0" y="420" width="640" height="60" fill="#3a3f45"/>' +
      '<circle cx="140" cy="250" r="38" fill="#c9a98c"/><rect x="95" y="290" width="90" height="140" rx="30" fill="#2d5d8a"/>' +
      '<text x="20" y="30" font-family="monospace" font-size="18" fill="#fff">EINGANG  2026-10-18  18:42:07</text></svg>');
    const samples = {
      doorbell: [{ id: 1, kind: "doorbell", title: "Es klingelt", text: "Haustür", camera: pic }],
      window: [{ id: 1, kind: "window", title: "Fenster geöffnet", text: "Küche" },
        { id: 2, kind: "door", title: "Tür geöffnet", text: "Terrassentür" },
        { id: 3, kind: "appliance", title: "Trockner ist fertig", text: "" }],
      appliance: [{ id: 1, kind: "appliance", title: "Waschmaschine ist fertig", text: "" }],
      alarm: [{ id: 1, kind: "alarm", title: "Wassermelder", text: "Keller · nass" }],
      info: [{ id: 1, kind: "info", title: "Die Post ist da", text: "Der Briefkasten wurde geöffnet" }]
    };
    const events = (samples[kind] || samples.doorbell).map((e) => ({ at: t - 20, until: t + 40, ...e, camera: e.camera || "" }));
    data = { events, lang };
    render();
    ready();
    setInterval(render, 1000);
  }

  if (DEMO) {
    demo(DEMO);
  } else {
    render();
    poll();
    setInterval(poll, POLL_MS);
    // Falls das Plugin gar nicht antwortet, die Szene trotzdem freigeben.
    setTimeout(ready, 5000);
  }
})();
