#!/usr/bin/env python3
"""Home Assistant Live - der Plugin-Teil des Pakets.

Das Plugin hält eine Verbindung zu Home Assistant (Adresse und langlebiger
Zugangstoken, beides bleibt im eigenen Netz) und wartet auf Ereignisse:

- ein Fenster oder eine Tür geht auf,
- es klingelt an der Haustür (auf Wunsch mit dem Bild einer Kamera),
- ein Gerät wie die Waschmaschine ist fertig (die Leistung fällt ab),
- eine eigene Entität wechselt auf einen bestimmten Zustand,
- eine Automation in Home Assistant feuert das Ereignis dynaframe_live.

Dann holt es die Szene "home-assistant-live" für die eingestellte Zeit über
die laufende Playlist (Display-Takeover) und gibt den Bildschirm danach
zurück. Eine regelmäßige Anzeige gibt es bewusst nicht.

Die Szene erreicht die Seite dieses Plugins über den Proxy der Weboberfläche
auf :8003 (der Proxy der Engine lehnt lokale Adressen ab), wie Fußball Live.
"""

import json
import os
import re
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import ha  # noqa: E402
import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "HomeAssistantLive"
DISPLAY_NAME = "Home Assistant Live"
SCENE_ID = "home-assistant-live"   # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen und Zustand; bleibt bei Updates

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value):
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return None


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält das Token
        except OSError:
            pass


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


ENTITY_ID = re.compile(r"^[a-z_]+\.[a-z0-9_]+$")


def entity(raw):
    value = str(raw or "").strip().lower()
    return value if ENTITY_ID.match(value) else ""


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "Url":                {"kind": "url", "default": ""},
    "Token":              {"kind": "secret", "default": ""},
    "Language":           {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
    # Fenster und Türen: alle, die Home Assistant als solche kennt, oder eine Auswahl.
    "OpeningsEnabled":    {"kind": "bool", "default": True},
    "OpeningsAll":        {"kind": "bool", "default": True},
    "Openings":           {"kind": "entities", "default": []},
    "OpeningsSeconds":    {"kind": "number", "default": 20, "min": 5, "max": 600},
    # Die Haustürklingel, auf Wunsch mit Kamera.
    "Doorbell":           {"kind": "entity", "default": ""},
    "DoorbellCamera":     {"kind": "entity", "default": ""},
    "DoorbellSeconds":    {"kind": "number", "default": 60, "min": 10, "max": 600},
    "DoorbellWake":       {"kind": "bool", "default": False},
    # Geräte, die fertig werden: {name, entity} mit einem Leistungssensor.
    "Appliances":         {"kind": "appliances", "default": []},
    "ApplianceSeconds":   {"kind": "number", "default": 60, "min": 10, "max": 600},
    "ApplianceStopWatts": {"kind": "number", "default": 5, "min": 1, "max": 500},
    "ApplianceStopMinutes": {"kind": "number", "default": 3, "min": 1, "max": 30},
    # Eigene Ereignisse: {entity, to, title}.
    "Rules":              {"kind": "rules", "default": []},
    "RuleSeconds":        {"kind": "number", "default": 30, "min": 5, "max": 600},
    # Ruhezeit: dann bleibt alles außer der Klingel aus.
    "QuietEnabled":       {"kind": "bool", "default": False},
    "QuietFrom":          {"kind": "number", "default": 22, "min": 0, "max": 23},
    "QuietTo":            {"kind": "number", "default": 7, "min": 0, "max": 23},
    "DoorbellInQuiet":    {"kind": "bool", "default": True},
}

MAX_ROWS = 12
SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "url":
        return ha.normalize_url(raw)[:300]
    if kind == "secret":
        return re.sub(r"\s+", "", str(raw))[:1000]
    if kind == "entity":
        return entity(raw)
    if kind == "entities":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        return sorted({entity(i) for i in items} - {""})[:300]
    if kind == "appliances":
        rows = []
        for item in raw if isinstance(raw, list) else []:
            if isinstance(item, dict) and entity(item.get("entity")):
                rows.append({"entity": entity(item["entity"]), "name": str(item.get("name") or "").strip()[:60]})
        return rows[:MAX_ROWS]
    if kind == "rules":
        rows = []
        for item in raw if isinstance(raw, list) else []:
            if isinstance(item, dict) and entity(item.get("entity")):
                rows.append({"entity": entity(item["entity"]), "to": str(item.get("to") or "").strip()[:80],
                             "title": str(item.get("title") or "").strip()[:80]})
        return rows[:MAX_ROWS]
    return str(raw)[:200]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


def in_quiet_hours(values, moment=None):
    if not values["QuietEnabled"]:
        return False
    hour = (moment or datetime.now()).hour
    start, end = values["QuietFrom"], values["QuietTo"]
    if start == end:
        return False
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # über Mitternacht, z.B. 22 bis 7


# --------------------------------------------------------------------------
# Home Assistant: was es gibt, und die Liste für die Plugin-Seite
# --------------------------------------------------------------------------

OPENING_CLASSES = {"door", "window", "garage_door", "opening"}
DOORBELL_WORDS = re.compile(r"klingel|doorbell|door_bell|ring|timbre|bell|läut", re.I)
APPLIANCE_WORDS = re.compile(r"wasch|trockner|spül|geschirr|washer|washing|dryer|dishwasher|lavadora|secadora|lavavajillas",
                             re.I)


def rest(values=None):
    values = values or settings()
    return ha.Rest(values["Url"], values["Token"])


def friendly(row):
    attrs = row.get("attributes") or row.get("a") or {}
    return str(attrs.get("friendly_name") or row.get("entity_id") or "")


def power_watts(state, attrs):
    value = as_float(state)
    if value is None:
        return None
    unit = str((attrs or {}).get("unit_of_measurement") or "").strip()
    return value * 1000 if unit.lower() == "kw" else value


def is_power(row):
    attrs = row.get("attributes") or {}
    unit = str(attrs.get("unit_of_measurement") or "").strip().lower()
    return row["entity_id"].startswith("sensor.") and (attrs.get("device_class") == "power" or unit in {"w", "kw"})


def is_opening(row):
    return row["entity_id"].startswith("binary_sensor.") and \
        (row.get("attributes") or {}).get("device_class") in OPENING_CLASSES


def is_doorbell(row):
    attrs = row.get("attributes") or {}
    domain = row["entity_id"].split(".", 1)[0]
    if domain == "event" and attrs.get("device_class") == "doorbell":
        return True
    return domain in {"binary_sensor", "event", "input_boolean", "switch", "button", "input_button"} and \
        bool(DOORBELL_WORDS.search(row["entity_id"] + " " + friendly(row))) and \
        attrs.get("device_class") not in OPENING_CLASSES


_catalog = {"at": 0.0, "rows": [], "error": "", "config": {}}
_catalog_lock = threading.Lock()


def catalog(force=False):
    """Alle Entitäten aus /api/states, eine Minute lang zwischengespeichert."""
    with _catalog_lock:
        if not force and _catalog["rows"] and now() - _catalog["at"] < 60:
            return _catalog["rows"]
        values = settings()
        if not values["Url"] or not values["Token"]:
            _catalog.update(rows=[], error="", at=0.0)
            return []
        try:
            client = rest(values)
            _catalog["config"] = client.config() or {}
            rows = client.states()
            _catalog.update(rows=rows, error="", at=now())
        except ha.HaError as exc:
            _catalog.update(error=str(exc), at=now())
            return _catalog["rows"]
        return rows


def entities_payload():
    rows = catalog(force=True)
    if _catalog["error"] and not rows:
        return {"success": False, "error": error_text(_catalog["error"])}

    def item(row):
        attrs = row.get("attributes") or {}
        out = {"id": row["entity_id"], "name": friendly(row), "state": row.get("state")}
        if attrs.get("device_class"):
            out["class"] = attrs["device_class"]
        if isinstance(attrs.get("options"), list):
            out["options"] = [str(o) for o in attrs["options"]][:40]
        if attrs.get("unit_of_measurement"):
            out["unit"] = attrs["unit_of_measurement"]
        return out

    by_name = sorted(rows, key=lambda r: friendly(r).lower())
    doorbells = [item(r) for r in by_name if is_doorbell(r)]
    return {
        "success": True,
        "openings": [item(r) for r in by_name if is_opening(r)],
        "doorbells": doorbells,
        "triggers": [item(r) for r in by_name
                     if r["entity_id"].split(".", 1)[0] in {"binary_sensor", "event", "input_boolean", "input_button",
                                                            "button", "switch"} and not is_doorbell(r)],
        "cameras": [item(r) for r in by_name if r["entity_id"].startswith("camera.")],
        "power": [item(r) for r in by_name if is_power(r)],
        "all": [item(r) for r in by_name][:3000],
    }


def auto_setup():
    """Beim ersten Verbinden das Offensichtliche selbst eintragen: die
    einzige Klingel, die einzige Kamera, Waschmaschine & Co. mit
    Leistungssensor. Später ändert das Plugin nichts mehr von selbst."""
    if load_state().get("autoSetupDone"):
        return []
    rows = catalog(force=True)
    if not rows:
        return []
    values = settings()
    found, changes = [], {}
    bells = [r for r in rows if is_doorbell(r)]
    events = [r for r in bells if r["entity_id"].startswith("event.")]
    bells = events or bells
    if not values["Doorbell"] and len(bells) == 1:
        changes["Doorbell"] = bells[0]["entity_id"]
        found.append(friendly(bells[0]))
        cameras = [r for r in rows if r["entity_id"].startswith("camera.")]
        door_cams = [r for r in cameras if re.search(r"tür|tuer|door|klingel|bell|eingang|front|puerta",
                                                    r["entity_id"] + " " + friendly(r), re.I)]
        cams = door_cams if len(door_cams) == 1 else cameras
        if not values["DoorbellCamera"] and len(cams) == 1:
            changes["DoorbellCamera"] = cams[0]["entity_id"]
            found.append(friendly(cams[0]))
    if not values["Appliances"]:
        appliances = [{"entity": r["entity_id"], "name": appliance_name(friendly(r))}
                      for r in rows if is_power(r) and APPLIANCE_WORDS.search(r["entity_id"] + " " + friendly(r))]
        if appliances:
            changes["Appliances"] = appliances[:4]
            found.extend(a["name"] for a in appliances[:4])
    if changes:
        save_settings(changes)
    save_state(autoSetupDone=True, autoFound=found)
    if found:
        plugin.log("Automatisch eingetragen: " + ", ".join(found))
    return found


def appliance_name(name):
    """"Waschmaschine Leistung" -> "Waschmaschine"."""
    cleaned = name
    while True:
        shorter = re.sub(r"\s*\b(leistung|power|aktuelle?|current|potencia|verbrauch|consumption|w)\s*$", "", cleaned,
                         flags=re.I)
        if shorter == cleaned:
            break
        cleaned = shorter
    return (cleaned or name).strip()[:60]


ERRORS = {
    "no-url": "Trage zuerst die Adresse deines Home Assistant ein.",
    "no-token": "Trage zuerst einen langlebigen Zugangstoken ein.",
    "token": "Home Assistant lehnt den Zugangstoken ab. Erstelle einen neuen und füge ihn hier ein.",
    "not-found": "Unter dieser Adresse antwortet kein Home Assistant. Stimmt der Port (meist 8123)?",
    "no-websocket-client": "Das Paket websocket-client fehlt. Installiere Home Assistant Live noch einmal.",
}


def error_text(code):
    code = str(code or "")
    if code in ERRORS:
        return tr(ERRORS[code])
    if code.startswith("ssl:"):
        return tr("Das Zertifikat von Home Assistant wird nicht akzeptiert. Nimm die lokale Adresse mit http:// "
                  "und Port 8123, z. B. http://192.168.178.20:8123.")
    if code.startswith("unreachable:"):
        return tr("Home Assistant ist unter dieser Adresse nicht erreichbar. Prüfe Adresse und Port.")
    if code.startswith("http:"):
        return tr("Home Assistant antwortet mit Fehler {code}.", code=code[5:])
    return code


# --------------------------------------------------------------------------
# Ereignisse
# --------------------------------------------------------------------------

_events_lock = threading.Lock()
_events = []              # die letzten Ereignisse, neueste zuerst
_event_counter = {"n": 0}
_last_fired = {}          # Schlüssel -> Zeit, gegen Flattern
_seen_values = {}         # event.*: der letzte gültige Wert
_power = {}               # entity -> {"running": bool, "since": t, "lowSince": t}
REPEAT_SECONDS = 60
KEEP_EVENTS = 20


def add_event(kind, title, text="", seconds=30, camera="", key=None, priority=False, wake=False):
    t = now()
    key = key or f"{kind}:{title}"
    if t - _last_fired.get(key, 0) < REPEAT_SECONDS and kind != "test":
        return None
    _last_fired[key] = t
    values = settings()
    if in_quiet_hours(values) and not (kind == "doorbell" and values["DoorbellInQuiet"]) and kind != "test":
        plugin.log(f"Ruhezeit: {title} {text} wird nicht angezeigt.")
        return None
    with _events_lock:
        _event_counter["n"] += 1
        event = {"id": _event_counter["n"], "kind": kind, "title": title, "text": text, "camera": camera,
                 "at": t, "seconds": seconds, "until": t + seconds, "priority": priority, "wake": wake}
        _events.insert(0, event)
        del _events[KEEP_EVENTS:]
    plugin.log(f"Ereignis: {title}" + (f" – {text}" if text else ""))
    _wake.set()
    return event


def active_events(t=None):
    t = t or now()
    with _events_lock:
        return [dict(e) for e in _events if e["until"] > t]


def attributes_of(entity_id):
    row = stream.states.get(entity_id) or {}
    return row.get("a") or {}


def name_of(entity_id):
    name = attributes_of(entity_id).get("friendly_name")
    if not name:
        row = next((r for r in _catalog["rows"] if r["entity_id"] == entity_id), None)
        name = friendly(row) if row else ""
    return str(name or entity_id)


def opening_kind(attrs):
    cls = attrs.get("device_class")
    return {"window": "window", "door": "door", "garage_door": "garage"}.get(cls, "window")


def watched_entities(values=None):
    values = values or settings()
    ids = set()
    if values["OpeningsEnabled"]:
        if values["OpeningsAll"]:
            ids |= {r["entity_id"] for r in catalog() if is_opening(r)}
        else:
            ids |= set(values["Openings"])
    if values["Doorbell"]:
        ids.add(values["Doorbell"])
    ids |= {a["entity"] for a in values["Appliances"]}
    ids |= {r["entity"] for r in values["Rules"]}
    return ids


def on_change(entity_id, old, new, attrs, fresh=True):
    """Vom Websocket für jede Zustandsänderung einer beobachteten Entität."""
    values = settings()
    domain = entity_id.split(".", 1)[0]
    name = str(attrs.get("friendly_name") or name_of(entity_id))
    if domain == "event" and new not in ha.INVALID:
        before = _seen_values.get(entity_id)
        _seen_values[entity_id] = new
    else:
        before = None
    if not fresh:
        return
    # Fenster und Türen: von zu (off) nach offen (on).
    if values["OpeningsEnabled"] and old == "off" and new == "on" and \
            attrs.get("device_class") in OPENING_CLASSES and \
            (values["OpeningsAll"] or entity_id in values["Openings"]):
        kind = opening_kind(attrs)
        title = {"window": tr("Fenster geöffnet"), "door": tr("Tür geöffnet"),
                 "garage": tr("Garagentor geöffnet")}[kind]
        add_event(kind, title, name, values["OpeningsSeconds"], key=entity_id)
    # Klingel.
    if values["Doorbell"] == entity_id and doorbell_rang(domain, old, new, before):
        add_event("doorbell", tr("Es klingelt"), name, values["DoorbellSeconds"],
                  camera=values["DoorbellCamera"],
                  key=entity_id, priority=True, wake=values["DoorbellWake"])
    # Eigene Ereignisse.
    for rule in values["Rules"]:
        if rule["entity"] != entity_id or old in ha.INVALID or new in ha.INVALID:
            continue
        target = rule["to"].strip().lower()
        if target and (str(new).lower() != target or str(old).lower() == target):
            continue
        if rule["title"]:
            title, text = rule["title"], name
        else:
            title, text = name, state_text(new, attrs)
        add_event("custom", title, text, values["RuleSeconds"], key=f"rule:{entity_id}:{target}")
    # Geräte: nur merken; ob sie fertig sind, entscheidet die Schleife.
    for appliance in values["Appliances"]:
        if appliance["entity"] == entity_id:
            track_power(appliance, new, attrs, values)


def doorbell_rang(domain, old, new, before):
    if new in ha.INVALID:
        return False
    if domain == "event":
        # Der Zustand ist der Zeitpunkt des letzten Drückens. Nach einem
        # Neustart von HA kommt derselbe Zeitpunkt wieder; der zählt nicht.
        if new == before:
            return False
        if before is None:
            try:
                pressed = datetime.fromisoformat(str(new).replace("Z", "+00:00")).timestamp()
            except ValueError:
                return False
            return now() - pressed < 60
        return True
    if domain in {"button", "input_button"}:
        return old not in ha.INVALID
    return old == "off" and new == "on"


def state_text(state, attrs):
    unit = attrs.get("unit_of_measurement")
    if state in ("on", "off"):
        return tr("an") if state == "on" else tr("aus")
    return f"{state} {unit}" if unit else str(state)


def track_power(appliance, state, attrs, values):
    watts = power_watts(state, attrs)
    if watts is None:
        return
    row = _power.setdefault(appliance["entity"], {"running": False, "since": 0.0, "lowSince": 0.0, "watts": 0.0})
    row["watts"] = watts
    t = now()
    if watts > values["ApplianceStopWatts"]:
        row["lowSince"] = 0.0
        if not row["since"]:
            row["since"] = t
        # Erst "läuft", wenn es zwei Minuten über der Schwelle war: ein kurzer
        # Druck auf den Knopf ist noch kein Waschgang.
        if t - row["since"] >= 120:
            row["running"] = True
    else:
        row["since"] = 0.0
        if row["running"] and not row["lowSince"]:
            row["lowSince"] = t


def check_appliances():
    values = settings()
    t = now()
    for appliance in values["Appliances"]:
        row = _power.get(appliance["entity"])
        if not row:
            continue
        if row["since"] and not row["running"] and t - row["since"] >= 120:
            row["running"] = True
        if row["running"] and row["lowSince"] and t - row["lowSince"] >= values["ApplianceStopMinutes"] * 60:
            row.update(running=False, lowSince=0.0, since=0.0)
            name = appliance["name"] or name_of(appliance["entity"])
            add_event("appliance", tr("{name} ist fertig", name=name), "", values["ApplianceSeconds"],
                      key=appliance["entity"])
            save_state(lastApplianceDone={appliance["entity"]: t})


def on_custom(data):
    """Das Ereignis dynaframe_live aus einer Automation in Home Assistant."""
    if not isinstance(data, dict):
        return
    title = str(data.get("title") or data.get("message") or "Home Assistant").strip()[:120]
    text = str(data.get("message") or "").strip()[:300] if data.get("title") else ""
    kind = str(data.get("icon") or "custom").strip().lower()
    if kind not in KINDS:
        kind = "custom"
    seconds = max(5, min(600, as_int(data.get("seconds"), settings()["RuleSeconds"])))
    add_event(kind, title, text, seconds, camera=entity(data.get("camera")),
              key=f"ha:{title}:{text}", priority=kind == "doorbell")


KINDS = {"window", "door", "garage", "doorbell", "appliance", "custom", "info", "alarm", "test"}


def on_ws_status(state, error):
    if state == "connected":
        plugin.log("Mit Home Assistant verbunden.")
        save_state(lastConnectedAt=now())
    elif state == "error":
        plugin.log(f"Home Assistant: {error_text(error)} ({error})", level="warning")


stream = ha.Stream(plugin.log, on_change, on_custom, on_ws_status)


def reconnect():
    values = settings()
    stream.configure(values["Url"], values["Token"], watched_entities(values))


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Home Assistant Live ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Home Assistant Live ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Die Takeover-Playlist
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Home Assistant Live (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Home Assistant Live abgespielt, wenn es den Bildschirm "
                                 "übernimmt. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 6 * 3600  # das Plugin beendet die Anzeige lange vorher

_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Die Playlist wird nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, sechs Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
# Länger hält das Plugin den Bildschirm nicht am Stück. Kommen immer neue
# Ereignisse, holt es ihn danach einfach noch einmal.
MAX_SESSION_SECONDS = 300

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "started": False, "token": 0, "note": "", "retryAt": 0.0}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Home Assistant Live ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Home Assistant Live auf der Plugins-Seite aus. Schalte es ein, "
                  "sonst kann nichts angezeigt werden.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None, started=False)
        if new_state == "preempted":
            # Etwas Wichtigeres hat den Bildschirm: die laufenden Ereignisse
            # nicht gleich wieder dagegen drücken.
            _takeover["retryAt"] = now() + 30
    plugin.log(f"Der Rahmen hat Home Assistant Live beendet: {new_state}.")
    _wake.set()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None, started=False)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    if reason != "gestoppt":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_scene(events):
    """Die Szene über alles legen, solange `events` laufen. True, wenn der
    Rahmen den Bildschirm hergegeben hat."""
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Home Assistant Live wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    wake = any(e.get("wake") for e in events)
    if not wake and display_is_off():
        return _note(tr("Der Bildschirm ist aus; das Ereignis wird nicht angezeigt."))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Schrift; eine Bildunterschrift stört nur.
             "overlay": {"enabled": False}}
    try:
        handle = plugin.acquire_display_session(
            session_key="ereignis", state=state, display_name=DISPLAY_NAME,
            # Die Schleife unten ist das ordentliche Ende; die Grenze der
            # Engine greift nur, wenn das Plugin stirbt.
            # Immer die volle Grenze, damit ein zweites Ereignis die Anzeige
            # verlängern kann, ohne dass der Bildschirm kurz zurückspringt.
            max_duration_seconds=MAX_SESSION_SECONDS, wake_if_off=wake)
    except Exception as exc:
        return _note(tr("Konnte das Ereignis nicht anzeigen: {exc}", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), started=False, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat das Ereignis nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(tr("Konnte das Ereignis nicht anzeigen: {exc}", exc=exc))
    with _takeover_lock:
        if _takeover["token"] != token or _takeover["handle"] is None:
            return False
        _takeover["started"] = True
    plugin.log(f"Home Assistant Live auf dem Bildschirm ({events[0]['title']}).")
    return True


def decide_takeover():
    """Läuft ein Ereignis und hat das Plugin den Bildschirm nicht: holen.
    Läuft keines mehr: zurückgeben."""
    t = now()
    events = active_events(t)
    with _takeover_lock:
        handle = _takeover["handle"]
        since = _takeover["since"]
        retry_at = _takeover["retryAt"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not events:
            end_takeover("fertig")
        elif since and t - since >= MAX_SESSION_SECONDS - 5:
            end_takeover("neu")   # gleich wieder holen, frisch mit voller Zeit
            _wake.set()
        return
    if not events or t < retry_at:
        return
    if not show_scene(events):
        # Nicht bekommen (Bildschirm aus, anderes Plugin, keine Erlaubnis):
        # in 20 Sekunden noch einmal, solange das Ereignis läuft.
        with _takeover_lock:
            _takeover["retryAt"] = t + 20


def cancel_scene():
    """Alle laufenden Ereignisse beenden und den Bildschirm zurückgeben."""
    with _events_lock:
        for event in _events:
            event["until"] = min(event["until"], now())
    end_takeover("abgebrochen")
    _wake.set()


def test_event():
    values = settings()
    camera = values["DoorbellCamera"]
    add_event("test", tr("Probe-Anzeige"), tr("So sieht ein Ereignis auf dem Rahmen aus.") +
              (" " + tr("Mit dem Bild von {name}.", name=name_of(camera)) if camera else ""),
              15, camera=camera)
    return {"success": True, "message": tr("Bitte den Rahmen um den Bildschirm.")}


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach der Anzeige nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

_loop = {"lastError": "", "watchAt": 0.0}


def tick():
    try:
        maintain_playlists()
        check_appliances()
        decide_takeover()
        # "Alle Fenster und Türen": neue Sensoren alle zehn Minuten mitnehmen.
        if now() - _loop["watchAt"] > 600:
            _loop["watchAt"] = now()
            if settings()["OpeningsAll"]:
                catalog(force=True)
            reconnect()
        _loop["lastError"] = ""
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")


def main_loop():
    _stop_requested.wait(2)
    while not _stop_requested.is_set():
        _wake.clear()
        tick()
        # Schnell, solange etwas angezeigt wird, sonst alle 5 Sekunden.
        _wake.wait(1 if _takeover["handle"] is not None or active_events() else 5)


# --------------------------------------------------------------------------
# Kamerabilder für die Szene
# --------------------------------------------------------------------------

_camera_cache = {}
_camera_lock = threading.Lock()


def camera_image(entity_id):
    """(body, content type) oder None. Höchstens ein Abruf je Sekunde."""
    entity_id = entity(entity_id)
    if not entity_id.startswith("camera."):
        return None
    with _camera_lock:
        cached = _camera_cache.get(entity_id)
        if cached and now() - cached[0] < 0.8:
            return cached[1]
        try:
            found = rest().camera(entity_id)
        except ha.HaError as exc:
            plugin.log(f"Kamerabild {entity_id}: {exc}", level="warning")
            return cached[1] if cached else None
        _camera_cache[entity_id] = (now(), found)
        return found


# --------------------------------------------------------------------------
# Die Plugin-Seite und die Daten für die Szene
# --------------------------------------------------------------------------

def scene_payload():
    values = settings()
    t = now()
    events = active_events(t)
    # Die Klingel geht vor, sonst das neueste Ereignis.
    events.sort(key=lambda e: (not e["priority"], -e["at"]))
    return {"at": t, "lang": values["Language"],
            "events": [{"id": e["id"], "kind": e["kind"], "title": e["title"], "text": e["text"],
                        "at": e["at"], "until": e["until"], "seconds": e["seconds"],
                        "camera": f"api/camera/{e['camera']}" if e["camera"] else ""} for e in events]}


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def connection_payload(values):
    status = stream.status
    config = _catalog["config"] or {}
    if not values["Url"] or not values["Token"]:
        return {"state": "setup", "text": tr("Noch nicht eingerichtet.")}
    if status["state"] == "connected":
        name = config.get("location_name") or "Home Assistant"
        return {"state": "ok", "text": tr("Verbunden mit {name}", name=name) +
                (f" (Home Assistant {config['version']})" if config.get("version") else ""),
                "watching": len(watched_entities(values))}
    if status["state"] in {"connecting", "off"}:
        return {"state": "busy", "text": tr("Verbinde …")}
    return {"state": "bad", "text": error_text(status["error"])}


def state_payload():
    values = settings()
    state = load_state()
    with _takeover_lock:
        showing = _takeover["handle"] is not None
        note = _takeover["note"]
    with _events_lock:
        recent = [{"kind": e["kind"], "title": e["title"], "text": e["text"], "at": local_text(e["at"])}
                  for e in _events[:6]]
    public = dict(values)
    public["Token"] = ""
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "tokenSet": bool(values["Token"]),
        "connection": connection_payload(values),
        "showing": showing,
        "note": note or _playlists["note"] or _scene["note"],
        "permission": takeover_permission_note(),
        "recent": recent,
        "autoFound": state.get("autoFound") or [],
        "quietNow": in_quiet_hours(values),
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
    }


def connect_now():
    """Nach "Verbinden": prüfen, was eingetragen ist, Offensichtliches selbst
    eintragen und den Websocket neu aufbauen."""
    values = settings()
    try:
        config = rest(values).config()
    except ha.HaError as exc:
        reconnect()
        return {"success": False, "error": error_text(str(exc))}
    _catalog["config"] = config or {}
    found = auto_setup()
    catalog(force=True)
    reconnect()
    name = (config or {}).get("location_name") or "Home Assistant"
    message = tr("Verbunden mit {name}.", name=name)
    if found:
        message += " " + tr("Gleich eingetragen: {names}.", names=", ".join(found))
    return {"success": True, "message": message}


def settings_saved(changed):
    if set(changed) & {"Url", "Token"}:
        _catalog.update(rows=[], at=0.0, config={})
    reconnect()
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/entities":
                self._json(entities_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(), cors=True)
                return
            if path.startswith("/api/camera/"):
                found = camera_image(path.rsplit("/", 1)[-1])
                if found is None:
                    self._json({"success": False, "error": "Kein Bild"}, 404, cors=True)
                else:
                    self._send(found[0], found[1], cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                if "Token" in body and not str(body["Token"] or "").strip():
                    body.pop("Token")  # ein leeres Feld heißt: das alte behalten
                changed = save_settings(body)
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/connect":
                body = self._body()
                if not str(body.get("Token") or "").strip():
                    body.pop("Token", None)
                changed = save_settings({k: v for k, v in body.items() if k in ("Url", "Token")})
                if changed:
                    settings_saved(changed)
                self._json(connect_now())
                return
            if path == "/api/test":
                self._json(test_event())
                return
            if path == "/api/cancel":
                cancel_scene()
                self._json({"success": True, "message": tr("Gebe den Bildschirm zurück.")})
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starte {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("test", lambda _context=None: test_event())
    plugin.on_action("cancel", lambda _context=None: (cancel_scene(), {"success": True})[1])

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    reconnect()
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    stream.stop()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
