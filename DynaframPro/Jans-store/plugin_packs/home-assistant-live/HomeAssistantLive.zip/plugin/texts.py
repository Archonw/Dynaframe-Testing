"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Bitte den Rahmen um den Bildschirm.": (
        "Asking the frame for the screen.",
        "Pidiendo la pantalla al marco."),
    "Das Paket websocket-client fehlt. Installiere Home Assistant Live noch einmal.": (
        "The websocket-client package is missing. Install Home Assistant Live again.",
        "Falta el paquete websocket-client. Vuelve a instalar Home Assistant Live."),
    "Das Zertifikat von Home Assistant wird nicht akzeptiert. Nimm die lokale Adresse mit http:// und Port 8123, z. B. http://192.168.178.20:8123.": (
        "Home Assistant's certificate is not accepted. Use the local address with http:// and port 8123, e.g. http://192.168.1.20:8123.",
        "No se acepta el certificado de Home Assistant. Usa la dirección local con http:// y el puerto 8123, p. ej. http://192.168.1.20:8123."),
    "Der Bildschirm ist aus; das Ereignis wird nicht angezeigt.": (
        "The screen is off; the event is not shown.",
        "La pantalla está apagada; el evento no se muestra."),
    "Der Rahmen hat das Ereignis nicht rechtzeitig angezeigt.": (
        "The frame did not show the event in time.",
        "El marco no ha mostrado el evento a tiempo."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Der Rahmen ist nach der Anzeige nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.": (
        "The frame did not return to your playlist after the display. Start it again on the frame's home page. This does not happen with a saved playlist instead of a Quick Mix.",
        "El marco no ha vuelto a tu lista después de la visualización. Vuelve a iniciarla en la página principal del marco. Con una lista guardada en lugar de un Quick Mix no ocurre."),
    "Die Szene Home Assistant Live ist auf der Plugins-Seite ausgeschaltet.": (
        "The Home Assistant Live scene is switched off on the Plugins page.",
        "La escena Home Assistant Live está desactivada en la página de plugins."),
    "Die Szene Home Assistant Live ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The Home Assistant Live scene is not installed on this frame. Install the package again.",
        "La escena Home Assistant Live no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Szene Home Assistant Live wurde nicht gefunden.": (
        "The Home Assistant Live scene was not found.",
        "No se ha encontrado la escena Home Assistant Live."),
    "Die Takeover-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.",
        "La lista de takeover aún no se ha creado."),
    "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.": (
        "This frame is too old to hand the screen to a plugin.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "Es klingelt": ("Someone's at the door", "Llaman a la puerta"),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.",
        "Otra cosa tiene la pantalla ahora mismo."),
    "Fenster geöffnet": ("Window opened", "Ventana abierta"),
    "Garagentor geöffnet": ("Garage door opened", "Puerta del garaje abierta"),
    "Gebe den Bildschirm zurück.": ("Handing the screen back.", "Devolviendo la pantalla."),
    "Gleich eingetragen: {names}.": ("Already filled in: {names}.", "Ya configurado: {names}."),
    "Home Assistant Live ist auf der Plugins-Seite ausgeschaltet.": (
        "Home Assistant Live is switched off on the Plugins page.",
        "Home Assistant Live está desactivado en la página de plugins."),
    "Home Assistant antwortet mit Fehler {code}.": (
        "Home Assistant answers with error {code}.",
        "Home Assistant responde con el error {code}."),
    "Home Assistant ist unter dieser Adresse nicht erreichbar. Prüfe Adresse und Port.": (
        "Home Assistant cannot be reached at this address. Check the address and port.",
        "No se puede acceder a Home Assistant en esta dirección. Comprueba la dirección y el puerto."),
    "Home Assistant lehnt den Zugangstoken ab. Erstelle einen neuen und füge ihn hier ein.": (
        "Home Assistant rejects the access token. Create a new one and paste it here.",
        "Home Assistant rechaza el token de acceso. Crea uno nuevo y pégalo aquí."),
    "Konnte das Ereignis nicht anzeigen: {exc}": (
        "Could not show the event: {exc}",
        "No se pudo mostrar el evento: {exc}"),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}",
        "No se pudo crear la lista de takeover: {exc}"),
    "Mit dem Bild von {name}.": ("With the picture from {name}.", "Con la imagen de {name}."),
    "Noch nicht eingerichtet.": ("Not set up yet.", "Aún sin configurar."),
    "Probe-Anzeige": ("Test display", "Prueba"),
    "So sieht ein Ereignis auf dem Rahmen aus.": (
        "This is how an event looks on the frame.",
        "Así se ve un evento en el marco."),
    "Trage zuerst die Adresse deines Home Assistant ein.": (
        "First enter the address of your Home Assistant.",
        "Primero introduce la dirección de tu Home Assistant."),
    "Trage zuerst einen langlebigen Zugangstoken ein.": (
        "First enter a long-lived access token.",
        "Primero introduce un token de acceso de larga duración."),
    "Tür geöffnet": ("Door opened", "Puerta abierta"),
    "Unter dieser Adresse antwortet kein Home Assistant. Stimmt der Port (meist 8123)?": (
        "No Home Assistant answers at this address. Is the port right (usually 8123)?",
        "Ningún Home Assistant responde en esta dirección. ¿Es correcto el puerto (normalmente 8123)?"),
    "Verbinde …": ("Connecting …", "Conectando …"),
    "Verbunden mit {name}": ("Connected to {name}", "Conectado a {name}"),
    "Verbunden mit {name}.": ("Connected to {name}.", "Conectado a {name}."),
    "an": ("on", "encendido"),
    "aus": ("off", "apagado"),
    "{name} ist fertig": ("{name} is done", "{name} ha terminado"),
    "„Allow takeover“ ist für Home Assistant Live auf der Plugins-Seite aus. Schalte es ein, sonst kann nichts angezeigt werden.": (
        "“Allow takeover” is off for Home Assistant Live on the Plugins page. Switch it on, otherwise nothing can be shown.",
        "«Allow takeover» está desactivado para Home Assistant Live en la página de plugins. Actívalo; si no, no se puede mostrar nada."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
