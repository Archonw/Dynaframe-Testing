"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/HomeAssistantLive/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["OpeningsSeconds", "DoorbellSeconds", "ApplianceSeconds", "ApplianceStopWatts",
  "ApplianceStopMinutes", "RuleSeconds", "QuietFrom", "QuietTo"];
const CHECK_FIELDS = ["OpeningsEnabled", "DoorbellWake", "QuietEnabled", "DoorbellInQuiet"];
let current = null;
let entities = null;      // Antwort von /api/entities
let editing = false;
let appliances = [];      // was die Zeilen gerade zeigen
let rules = [];

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Zeigt auf dem Rahmen, was zu Hause gerade passiert: ein Fenster geht auf, es klingelt, die Waschmaschine ist fertig. Danach läuft deine Playlist weiter. Jede Änderung hier wird sofort gespeichert.",
    "Shows on the frame what is happening at home right now: a window opens, someone rings the doorbell, the washing machine is done. Then your playlist carries on. Every change here is saved immediately.",
    "Muestra en el marco lo que pasa en casa en este momento: se abre una ventana, llaman al timbre, la lavadora ha terminado. Después tu lista sigue. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  test: ["Probe-Anzeige", "Test display", "Prueba"],
  cancel: ["Beenden", "Stop", "Terminar"],
  factScreen: ["Bildschirm", "Screen", "Pantalla"],
  factWatching: ["Beobachtet", "Watching", "Vigilando"],
  factVersion: ["Version", "Version", "Versión"],
  recent: ["Zuletzt", "Recently", "Recientes"],
  noRecent: ["Noch keine Ereignisse.", "No events yet.", "Todavía no hay eventos."],
  connTitle: ["Mit Home Assistant verbinden", "Connect to Home Assistant", "Conectar con Home Assistant"],
  url: ["Adresse", "Address", "Dirección"],
  token: ["Langlebiger Zugangstoken", "Long-lived access token", "Token de acceso de larga duración"],
  tokenSet: ["gespeichert – leer lassen, um ihn zu behalten", "saved – leave empty to keep it", "guardado: déjalo vacío para conservarlo"],
  connect: ["Verbinden", "Connect", "Conectar"],
  connecting: ["Verbinde …", "Connecting …", "Conectando …"],
  howtoTitle: ["So bekommst du den Zugangstoken", "How to get the access token", "Cómo obtener el token de acceso"],
  howto1: ["Öffne Home Assistant und klicke unten links auf deinen <b>Namen</b> (Profil).",
    "Open Home Assistant and click your <b>name</b> at the bottom left (profile).",
    "Abre Home Assistant y haz clic en tu <b>nombre</b> abajo a la izquierda (perfil)."],
  howto2: ["Wähle oben den Reiter <b>Sicherheit</b> und scrolle ganz nach unten.",
    "Choose the <b>Security</b> tab at the top and scroll all the way down.",
    "Elige la pestaña <b>Seguridad</b> arriba y baja hasta el final."],
  howto3: ["Unter <b>Langlebige Zugangstoken</b> auf <b>Token erstellen</b> klicken, z. B. „DynaFrame“ als Namen eingeben.",
    "Under <b>Long-lived access tokens</b> click <b>Create token</b> and enter a name such as “DynaFrame”.",
    "En <b>Tokens de acceso de larga duración</b> pulsa <b>Crear token</b> e introduce un nombre, p. ej. «DynaFrame»."],
  howto4: ["Den angezeigten Token kopieren (er wird nur einmal gezeigt) und oben einfügen. Dann Verbinden.",
    "Copy the token shown (it is only shown once) and paste it above. Then Connect.",
    "Copia el token que aparece (solo se muestra una vez) y pégalo arriba. Después, Conectar."],
  profileLink: ["Profil in Home Assistant öffnen", "Open your profile in Home Assistant", "Abrir tu perfil en Home Assistant"],
  openTitle: ["Fenster und Türen", "Windows and doors", "Ventanas y puertas"],
  openEnabled: ["Anzeigen, wenn ein Fenster, eine Tür oder das Garagentor aufgeht",
    "Show when a window, a door or the garage door opens", "Mostrar cuando se abre una ventana, una puerta o el garaje"],
  openAll: ["Alle", "All", "Todas"],
  isOpen: ["offen", "open", "abierta"],
  openSome: ["Nur diese:", "Only these:", "Solo estas:"],
  nFound: ["({n} gefunden)", "({n} found)", "({n} encontradas)"],
  noneFound: ["(keine gefunden)", "(none found)", "(ninguna encontrada)"],
  openHint: ["Gefunden werden Fenster- und Türkontakte, die Home Assistant als solche kennt (Geräteklasse Fenster, Tür, Garagentor oder Öffnung).",
    "This finds window and door contacts that Home Assistant knows as such (device class window, door, garage door or opening).",
    "Se encuentran los contactos de ventanas y puertas que Home Assistant reconoce como tales (clase de dispositivo ventana, puerta, garaje o apertura)."],
  seconds: ["Anzeigen für … Sekunden", "Show for … seconds", "Mostrar durante … segundos"],
  bellTitle: ["Haustürklingel", "Doorbell", "Timbre"],
  bell: ["Klingel", "Doorbell", "Timbre"],
  camera: ["Kamera dazu", "Camera with it", "Cámara"],
  none: ["– keine –", "– none –", "– ninguna –"],
  bellGroup: ["Klingeln", "Doorbells", "Timbres"],
  otherGroup: ["Andere Schalter und Sensoren", "Other switches and sensors", "Otros interruptores y sensores"],
  bellWake: ["Auch einen ausgeschalteten Bildschirm einschalten", "Also switch on a screen that is off", "Encender también una pantalla apagada"],
  bellHint: ["Das Kamerabild wird während der Anzeige jede Sekunde neu geladen.",
    "The camera picture is reloaded every second while it is shown.",
    "La imagen de la cámara se recarga cada segundo mientras se muestra."],
  appTitle: ["Geräte fertig", "Appliance done", "Electrodoméstico listo"],
  appHint: ["Für Waschmaschine, Trockner oder Spülmaschine mit einer Steckdose, die die Leistung misst. Fertig ist ein Gerät, wenn es eine Weile lief und die Leistung dann für einige Minuten unter einer Schwelle bleibt.",
    "For a washing machine, dryer or dishwasher on a plug that measures power. An appliance is done when it ran for a while and its power then stays below a threshold for a few minutes.",
    "Para lavadora, secadora o lavavajillas con un enchufe que mide la potencia. Un aparato ha terminado cuando ha funcionado un rato y luego su potencia se queda unos minutos por debajo de un umbral."],
  appName: ["Name", "Name", "Nombre"],
  appNamePh: ["z. B. Waschmaschine", "e.g. Washing machine", "p. ej. Lavadora"],
  power: ["Leistungssensor", "Power sensor", "Sensor de potencia"],
  remove: ["Entfernen", "Remove", "Quitar"],
  addAppliance: ["+ Gerät hinzufügen", "+ Add appliance", "+ Añadir aparato"],
  stopMinutes: ["Fertig nach … Minuten", "Done after … minutes", "Listo tras … minutos"],
  stopWatts: ["unter … Watt", "below … watts", "por debajo de … vatios"],
  nowWatts: ["Gerade: {v}", "Now: {v}", "Ahora: {v}"],
  noPower: ["Home Assistant hat keine Sensoren, die Leistung in Watt messen.", "Home Assistant has no sensors measuring power in watts.",
    "Home Assistant no tiene sensores que midan la potencia en vatios."],
  ruleTitle: ["Eigene Ereignisse", "Own events", "Eventos propios"],
  optional: ["(optional)", "(optional)", "(opcional)"],
  ruleHint: ["Für alles andere: wenn eine Entität auf einen Zustand wechselt, z. B. der Briefkasten auf „on“ oder der Trockner-Status auf „Fertig“. Ohne Zustand zählt jede Änderung.",
    "For anything else: when an entity changes to a state, e.g. the letterbox to “on” or the dryer status to “Done”. Without a state, every change counts.",
    "Para todo lo demás: cuando una entidad cambia a un estado, p. ej. el buzón a «on» o el estado de la secadora a «Listo». Sin estado cuenta cualquier cambio."],
  entity: ["Entität", "Entity", "Entidad"],
  becomes: ["wird zu", "changes to", "cambia a"],
  anyChange: ["jede Änderung", "any change", "cualquier cambio"],
  ruleTitleField: ["Text auf dem Rahmen", "Text on the frame", "Texto en el marco"],
  ruleTitlePh: ["z. B. Die Post ist da", "e.g. The post has arrived", "p. ej. Ha llegado el correo"],
  addRule: ["+ Ereignis hinzufügen", "+ Add event", "+ Añadir evento"],
  quietTitle: ["Ruhezeit", "Quiet hours", "Horas de silencio"],
  quietEnabled: ["Nachts nichts anzeigen", "Show nothing at night", "No mostrar nada por la noche"],
  from: ["Von … Uhr", "From … o'clock", "Desde las …"],
  to: ["Bis … Uhr", "Until … o'clock", "Hasta las …"],
  bellInQuiet: ["Die Klingel trotzdem zeigen", "Still show the doorbell", "Mostrar el timbre de todos modos"],
  quietNow: ["Ruhezeit", "Quiet hours", "Horas de silencio"],
  autoTitle: ["Aus einer Automation", "From an automation", "Desde una automatización"],
  autoHint: ["Für Fortgeschrittene: Jede Automation in Home Assistant kann etwas auf den Rahmen bringen, indem sie das Ereignis dynaframe_live auslöst. icon ist eins von window, door, garage, doorbell, appliance, alarm, info; camera und seconds sind freiwillig.",
    "For advanced users: any automation in Home Assistant can put something on the frame by firing the dynaframe_live event. icon is one of window, door, garage, doorbell, appliance, alarm, info; camera and seconds are optional.",
    "Para usuarios avanzados: cualquier automatización de Home Assistant puede mostrar algo en el marco lanzando el evento dynaframe_live. icon es uno de window, door, garage, doorbell, appliance, alarm, info; camera y seconds son opcionales."],
  takeoverTitle: ["Wichtig", "Important", "Importante"],
  takeoverHint: ["Damit Home Assistant Live etwas zeigen darf, muss auf der Plugins-Seite des Rahmens <b>Allow takeover</b> eingeschaltet sein. Die Playlist „Home Assistant Live (takeover)“ benutzt das Plugin selbst; lass sie ausgeschaltet.",
    "For Home Assistant Live to be allowed to show anything, <b>Allow takeover</b> must be switched on on the frame's Plugins page. The “Home Assistant Live (takeover)” playlist is used by the plugin itself; leave it switched off.",
    "Para que Home Assistant Live pueda mostrar algo, <b>Allow takeover</b> debe estar activado en la página de plugins del marco. La lista «Home Assistant Live (takeover)» la usa el propio plugin; déjala desactivada."],
  showing: ["zeigt ein Ereignis", "showing an event", "mostrando un evento"],
  playlistRuns: ["Playlist läuft", "Playlist is playing", "La lista está en curso"],
  nEntities: ["{n} Entitäten", "{n} entities", "{n} entidades"],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time} h"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return false;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  return true;
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setNote(id, text, tone = "") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}
const setStatus = (text, tone) => setNote("statusNote", text, tone);

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes, quiet = false) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    if (!quiet) setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function make(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === "class") node.className = value;
    else if (key === "text") node.textContent = value;
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else node[key] = value;
  }
  for (const child of children) if (child) node.append(child);
  return node;
}

function label(row) {
  return row.name && row.name !== row.id ? row.name : row.id;
}

function fillSelect(select, groups, chosen) {
  // groups: [[Überschrift oder "", [{id, name}]]]
  select.replaceChildren(make("option", { value: "", text: t("none") }));
  let found = !chosen;
  for (const [title, rows] of groups) {
    if (!rows.length) continue;
    const parent = title ? make("optgroup", { label: title }) : select;
    for (const row of rows) {
      parent.append(make("option", { value: row.id, text: label(row) }));
      if (row.id === chosen) found = true;
    }
    if (title) select.append(parent);
  }
  if (!found) select.append(make("option", { value: chosen, text: chosen }));
  select.value = chosen || "";
}

// ---------------------------------------------------------------- Schritte

function renderOpenings(s) {
  const list = (entities && entities.openings) || [];
  el("openCount").textContent = entities ? (list.length ? t("nFound", { n: list.length }) : t("noneFound")) : "";
  el("openingsBody").hidden = !s.OpeningsEnabled;
  for (const radio of document.querySelectorAll('input[name="openingsAll"]')) {
    radio.checked = String(s.OpeningsAll) === radio.value;
  }
  const box = el("openingList");
  box.hidden = s.OpeningsAll;
  if (s.OpeningsAll) return;
  const chosen = new Set(s.Openings);
  box.replaceChildren(...list.map((row) => {
    const input = make("input", { type: "checkbox", checked: chosen.has(row.id) });
    input.addEventListener("change", () => {
      const next = new Set(current.settings.Openings);
      if (input.checked) next.add(row.id); else next.delete(row.id);
      save({ Openings: [...next] });
    });
    return make("label", {}, [input, make("span", { text: label(row) }),
      make("span", { class: "state", text: row.state === "on" ? t("isOpen") : "" })]);
  }));
}

function renderDoorbell(s) {
  const bells = (entities && entities.doorbells) || [];
  const others = (entities && entities.triggers) || [];
  fillSelect(el("Doorbell"), [[bells.length ? t("bellGroup") : "", bells], [t("otherGroup"), others]], s.Doorbell);
  fillSelect(el("DoorbellCamera"), [["", (entities && entities.cameras) || []]], s.DoorbellCamera);
}

function powerText(id) {
  const row = ((entities && entities.power) || []).find((r) => r.id === id);
  return row ? `${row.state} ${row.unit || ""}`.trim() : "";
}

function renderAppliances() {
  const power = (entities && entities.power) || [];
  const box = el("applianceRows");
  if (editing && box.contains(document.activeElement)) return;
  box.replaceChildren(...appliances.map((item, index) => {
    const name = make("input", { type: "text", value: item.name || "", placeholder: t("appNamePh") });
    name.addEventListener("focus", () => { editing = true; });
    name.addEventListener("blur", () => { editing = false; });
    name.addEventListener("change", () => { appliances[index].name = name.value.trim(); saveAppliances(); });
    const select = make("select");
    fillSelect(select, [["", power]], item.entity);
    select.addEventListener("change", () => {
      appliances[index].entity = select.value;
      if (!appliances[index].name) {
        const row = power.find((r) => r.id === select.value);
        appliances[index].name = row ? row.name.replace(/\s*(leistung|power|potencia|verbrauch)\s*$/i, "") : "";
      }
      saveAppliances();
    });
    const remove = make("button", { type: "button", class: "secondary remove", text: "✕", title: t("remove") });
    remove.addEventListener("click", () => { appliances.splice(index, 1); saveAppliances(); });
    const now = powerText(item.entity);
    return make("div", { class: "row" }, [
      make("label", { class: "field" }, [make("span", { text: t("appName") }), name]),
      make("label", { class: "field" }, [make("span", { text: t("power") }), select]),
      remove,
      now ? make("div", { class: "now", text: t("nowWatts", { v: now }) }) : null,
    ]);
  }));
  if (entities && !power.length && !appliances.length) {
    box.replaceChildren(make("p", { class: "hint", text: t("noPower") }));
  }
}

function saveAppliances() {
  // Zeilen ohne Sensor bleiben nur hier auf der Seite, bis einer gewählt ist.
  save({ Appliances: appliances.filter((a) => a.entity) }, true);
}

function stateOptions(id) {
  const row = ((entities && entities.all) || []).find((r) => r.id === id);
  if (!row) return [];
  if (row.options && row.options.length) return row.options;
  const domain = id.split(".")[0];
  if (["binary_sensor", "input_boolean", "switch", "light", "fan"].includes(domain)) return ["on", "off"];
  if (domain === "lock") return ["locked", "unlocked", "open"];
  if (domain === "cover") return ["open", "closed"];
  if (domain === "person" || domain === "device_tracker") return ["home", "not_home"];
  if (domain === "alarm_control_panel") return ["triggered", "armed_away", "armed_home", "disarmed"];
  return row.state ? [row.state] : [];
}

function renderRules() {
  const box = el("ruleRows");
  if (editing && box.contains(document.activeElement)) return;
  box.replaceChildren(...rules.map((item, index) => {
    const listId = `states${index}`;
    const entityInput = make("input", { type: "text", value: item.entity || "", placeholder: "binary_sensor.briefkasten",
      spellcheck: false, autocomplete: "off" });
    entityInput.setAttribute("list", "allEntities");
    const states = make("datalist", { id: listId });
    const fillStates = () => states.replaceChildren(...stateOptions(entityInput.value.trim()).map((v) => make("option", { value: v })));
    fillStates();
    entityInput.addEventListener("input", fillStates);
    entityInput.addEventListener("change", () => { rules[index].entity = entityInput.value.trim(); saveRules(); });
    const to = make("input", { type: "text", value: item.to || "", placeholder: t("anyChange"), autocomplete: "off" });
    to.setAttribute("list", listId);
    to.addEventListener("change", () => { rules[index].to = to.value.trim(); saveRules(); });
    const title = make("input", { type: "text", value: item.title || "", placeholder: t("ruleTitlePh") });
    title.addEventListener("change", () => { rules[index].title = title.value.trim(); saveRules(); });
    const remove = make("button", { type: "button", class: "secondary remove", text: "✕", title: t("remove") });
    remove.addEventListener("click", () => { rules.splice(index, 1); saveRules(); });
    for (const input of [entityInput, to, title]) {
      input.addEventListener("focus", () => { editing = true; });
      input.addEventListener("blur", () => { editing = false; });
    }
    return make("div", { class: "row rule" }, [
      make("label", { class: "field" }, [make("span", { text: t("entity") }), entityInput]),
      make("label", { class: "field" }, [make("span", { text: t("becomes") }), to, states]),
      make("label", { class: "field" }, [make("span", { text: t("ruleTitleField") }), title]),
      remove,
    ]);
  }));
}

function saveRules() {
  save({ Rules: rules.filter((r) => r.entity) }, true);
}

function renderEntityList() {
  const list = el("allEntities");
  if (list.childElementCount || !entities) return;
  list.replaceChildren(...entities.all.map((row) => make("option", { value: row.id, label: label(row) })));
}

// ---------------------------------------------------------------- Status

function renderStatus(state) {
  const c = state.connection;
  const dd = el("factConnection");
  dd.textContent = c.text;
  dd.className = c.state;
  el("factScreen").textContent = state.showing ? t("showing") : (state.quietNow ? t("quietNow") : t("playlistRuns"));
  el("factWatching").textContent = c.state === "ok" ? t("nEntities", { n: c.watching || 0 }) : "—";
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Dynaframe-Stuff/issues/new?title=" +
    encodeURIComponent(`[Home Assistant Live ${state.version}] `);
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;
  const notes = [state.note, state.lastError].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.lastError ? "bad" : "");

  const recent = el("recentList");
  recent.replaceChildren(...(state.recent.length ? state.recent.map((e) => make("li", {}, [
    make("span", { class: "time", text: clock(e.at) }),
    make("span", { class: "what", text: e.title }),
    e.text ? make("span", { class: "text", text: e.text }) : null,
  ])) : [make("li", { class: "empty", text: t("noRecent") })]));
}

function render(state) {
  const first = current === null;
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  const languageChanged = applyLanguage(s.Language);
  renderStatus(state);

  const ready = state.tokenSet && s.Url;
  el("afterConnect").classList.toggle("locked", !ready);
  el("howto").open = !state.tokenSet;
  el("Token").placeholder = state.tokenSet ? t("tokenSet") : "";
  if (document.activeElement !== el("Url") && (first || !editing)) el("Url").value = s.Url;
  const link = el("profileLink");
  link.hidden = !s.Url;
  if (s.Url) link.href = `${s.Url}/profile/security`;

  if (!editing) {
    for (const name of NUMBER_FIELDS) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    el("Language").value = lang;
    // Neue Zeilen ohne Entität gibt es nur hier; sie bleiben, bis eine gewählt ist.
    appliances = [...s.Appliances.map((a) => ({ ...a })), ...appliances.filter((a) => !a.entity)];
    rules = [...s.Rules.map((r) => ({ ...r })), ...rules.filter((r) => !r.entity)];
  }
  renderOpenings(s);
  renderDoorbell(s);
  renderAppliances();
  renderRules();
  const reachable = ["ok", "busy"].includes(state.connection.state);
  if (ready && (!entities || languageChanged) && reachable) loadEntities();
}

let loadingEntities = false;
async function loadEntities() {
  if (loadingEntities) return;
  loadingEntities = true;
  try {
    entities = await api("./api/entities");
    renderEntityList();
    if (current) {
      renderOpenings(current.settings);
      renderDoorbell(current.settings);
      renderAppliances();
      renderRules();
    }
  } catch (error) {
    setNote("connNote", error.message, "bad");
  } finally {
    loadingEntities = false;
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

// ---------------------------------------------------------------- Eingaben

for (const name of NUMBER_FIELDS) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", () => save({ [name]: Number(input.value) }));
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const radio of document.querySelectorAll('input[name="openingsAll"]')) {
  radio.addEventListener("change", () => {
    const all = radio.value === "true";
    // Beim Wechsel auf "Nur diese" mit allen gefundenen anfangen; abwählen ist leichter als suchen.
    const changes = { OpeningsAll: all };
    if (!all && !current.settings.Openings.length && entities) changes.Openings = entities.openings.map((r) => r.id);
    save(changes);
  });
}
for (const id of ["Doorbell", "DoorbellCamera"]) el(id).addEventListener("change", (e) => save({ [id]: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});
for (const id of ["Url", "Token"]) {
  el(id).addEventListener("focus", () => { editing = true; });
  el(id).addEventListener("blur", () => { editing = false; });
  el(id).addEventListener("keydown", (e) => { if (e.key === "Enter") el("connectButton").click(); });
}
el("addAppliance").addEventListener("click", () => { appliances.push({ name: "", entity: "" }); renderAppliances(); });
el("addRule").addEventListener("click", () => { rules.push({ entity: "", to: "", title: "" }); renderRules(); });

el("connectButton").addEventListener("click", async () => {
  const button = el("connectButton");
  button.disabled = true;
  setNote("connNote", t("connecting"), "busy");
  try {
    const result = await api("./api/connect", { method: "POST",
      body: JSON.stringify({ Url: el("Url").value.trim(), Token: el("Token").value.trim() }) });
    el("Token").value = "";
    setNote("connNote", result.message || "", "ok");
    entities = null;
    el("allEntities").replaceChildren();
    editing = false;
    await refresh();
  } catch (error) {
    setNote("connNote", error.message, "bad");
    await refresh();
  } finally {
    button.disabled = false;
  }
});

for (const [id, path] of [["testButton", "test"], ["cancelButton", "cancel"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(`./api/${path}`, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}

refresh();
setInterval(refresh, 5000);
