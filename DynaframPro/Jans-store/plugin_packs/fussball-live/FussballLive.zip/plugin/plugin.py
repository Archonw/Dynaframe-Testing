#!/usr/bin/env python3
"""Fußball Live - der Plugin-Teil des Fußball-Live-Pakets.

Die Szene "fussball-live" zeichnet Spieltage und Tabellen. Dieses Plugin
macht, was eine Szene nicht kann:

- Es liest die Ergebnisse der gewählten Ligen (leagues.py) in seinem eigenen
  Takt: jede Minute, solange ein Spiel läuft, sonst seltener. Vereinswappen
  werden einmal geladen und lokal ausgeliefert.
- Es holt die Szene alle X Minuten für Y Sekunden über die laufende
  Playlist (Display-Takeover) und gibt den Bildschirm danach zurück. Dazu
  wahlweise nur an Spieltagen, nur bei laufenden Spielen oder bei einem Tor.
- Show, Cancel und Toggle machen dasselbe von Hand oder aus einer
  Automation.
- Alle Einstellungen liegen auf einer Seite (Plugins > Fußball Live öffnen).

Die Szene erreicht die Seite dieses Plugins über den Proxy der Weboberfläche
auf :8003 (der Proxy der Engine lehnt lokale Adressen ab), wie bei Live
Flights. Antwortet das Plugin nicht, liest die Szene die Quellen selbst.
"""

import hashlib
import json
import os
import re
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import leagues  # noqa: E402
import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "FussballLive"
DISPLAY_NAME = "Fußball Live"
SCENE_ID = "fussball-live"       # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"   # Einstellungen und Zustand; bleibt bei Updates
CACHE_DIR = PLUGIN_DIR / "cache"  # Wappen; darf gelöscht werden
LOGO_DIR = CACHE_DIR / "logos"

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
SERVICE_STATUS = f"{PLUGIN_ID}.Status"

EVENT_GOAL = "fussball_tor"
EVENT_STARTED = "fussball_anzeige_gestartet"
EVENT_ENDED = "fussball_anzeige_beendet"


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def ensure_dirs():
    for folder in (DATA_DIR, CACHE_DIR, LOGO_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    ensure_dirs()
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "Leagues":        {"kind": "leagues", "default": list(leagues.DEFAULT_LEAGUES)},
    "PageSeconds":    {"kind": "number", "default": 20, "min": 5, "max": 300},
    "ShowTable":      {"kind": "bool", "default": True},
    # Wann die Szene von selbst über die Playlist geholt wird.
    "AutoMode":       {"kind": "choice", "default": "always",
                       "options": ["off", "always", "matchday", "live"]},
    "EveryMinutes":   {"kind": "number", "default": 15, "min": 2, "max": 720},
    "ShowForSeconds": {"kind": "number", "default": 60, "min": 10, "max": 3600},
    "ActiveFrom":     {"kind": "number", "default": 8, "min": 0, "max": 23},
    "ActiveTo":       {"kind": "number", "default": 23, "min": 1, "max": 24},
    "GoalTakeover":   {"kind": "bool", "default": False},
    "GoalSeconds":    {"kind": "number", "default": 30, "min": 10, "max": 600},
    # Die Namen des House Standards, wie in den anderen Szenen-Plugins.
    "MakePlaylist":   {"kind": "bool", "default": False},
    # Sprache der Plugin-Seite, der Hinweise und der Szene.
    "Language":       {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "leagues":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        chosen = []  # in der Reihenfolge, die der Nutzer gewählt hat
        for item in items:
            lid = str(item).strip().lower()
            if lid in leagues.LEAGUES and lid not in chosen:
                chosen.append(lid)
        return chosen
    return str(raw)[:200]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Fußball Live ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Fußball Live ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Fußball-Live-Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Ergebnisse
# --------------------------------------------------------------------------

_data_lock = threading.Lock()
# league id -> {"round", "matches", "table", "source", "matchesAt", "tableAt", "error"}
_data = {}
_version = {"n": 0}
_scores = {}   # match id -> (home, away), um Tore zu erkennen
_goals = []    # erkannte Tore, die noch nicht gezeigt wurden


def bump():
    with _data_lock:
        _version["n"] += 1


def any_live(data=None):
    data = _data if data is None else data
    return any(m["state"] == "live" for row in data.values() for m in row.get("matches") or [])


def matchday_today(data=None):
    """Hat eine gewählte Liga heute ein Spiel, oder läuft eines?"""
    data = _data if data is None else data
    today = datetime.now().date()
    for row in data.values():
        for match in row.get("matches") or []:
            if match["state"] == "live":
                return True
            if match["kickoff"] and datetime.fromtimestamp(match["kickoff"]).date() == today:
                return True
    return False


def soon_kickoff(row, within):
    t = now()
    return any(m["state"] == "pre" and 0 <= m["kickoff"] - t <= within for m in row.get("matches") or [])


def started_since_read(row):
    """Ein Spiel, das beim letzten Lesen noch nicht lief, aber laut Anstoßzeit
    seit bis zu drei Stunden läuft oder gerade zu Ende ist."""
    t = now()
    return any(m["state"] == "pre" and m["kickoff"] and 0 <= t - m["kickoff"] <= 3 * 3600
               for m in row.get("matches") or [])


def matches_due(row):
    """Wie oft eine Liga gelesen wird: jede Minute bei Live-Spielen oder kurz
    vor Anstoß, alle 10 Minuten an Spieltagen, sonst jede halbe Stunde."""
    age = now() - (row.get("matchesAt") or 0)
    if row.get("error"):
        # Nach einem Fehler in 2 Minuten neu versuchen, nicht erst im normalen Takt.
        return age >= 120
    if any(m["state"] == "live" for m in row.get("matches") or []) or soon_kickoff(row, 600) \
            or started_since_read(row):
        return age >= 60
    if matchday_today({"x": row}):
        return age >= 600
    return age >= 1800


def table_due(row, live):
    """Die Tabelle bei Live-Spielen alle 5 Minuten, an Spieltagen alle 10
    Minuten (Endstände), sonst stündlich."""
    age = now() - (row.get("tableAt") or 0)
    if live:
        return age >= 300
    return age >= (600 if matchday_today({"x": row}) else 3600)


def detect_goals(league_id, matches):
    found = []
    for match in matches:
        key = match["id"]
        score = (match["scoreHome"], match["scoreAway"])
        before = _scores.get(key)
        _scores[key] = score
        if before is None or None in score or None in before or match["state"] != "live":
            continue
        if sum(score) > sum(before):
            found.append({"league": league_id, "match": match, "at": now()})
    return found


def refresh_data(force=False):
    chosen = settings()["Leagues"]
    show_table = settings()["ShowTable"]
    changed = False
    for league_id in chosen:
        with _data_lock:
            row = dict(_data.get(league_id) or {})
        if force or matches_due(row):
            try:
                round_name, matches, source = leagues.fetch_matches(league_id)
                goals = detect_goals(league_id, matches)
                row.update({"round": round_name, "matches": matches, "source": source,
                            "matchesAt": now(), "error": ""})
                if goals:
                    with _data_lock:
                        _goals.extend(goals)
                    for goal in goals:
                        announce_goal(goal)
            except leagues.SourceError as exc:
                row.update(error=str(exc), matchesAt=now())
                plugin.log(f"{leagues.LEAGUES[league_id]['name']}: {exc}", level="warning")
            changed = True
        live = any(m["state"] == "live" for m in row.get("matches") or [])
        if show_table and leagues.LEAGUES[league_id]["table"] and (force or table_due(row, live)):
            try:
                row.update(table=leagues.fetch_table(league_id), tableAt=now())
            except leagues.SourceError as exc:
                row["tableAt"] = now() - 3000  # in 10 Minuten noch einmal
                plugin.log(f"Tabelle {leagues.LEAGUES[league_id]['name']}: {exc}", level="warning")
            changed = True
        with _data_lock:
            _data[league_id] = row
    with _data_lock:
        for league_id in [k for k in _data if k not in chosen]:
            del _data[league_id]
            changed = True
    if changed:
        bump()
        save_cache()


CACHE_FILE = CACHE_DIR / "results.json"


def save_cache():
    with _data_lock:
        payload = {"data": _data, "scores": {k: list(v) for k, v in _scores.items()}}
    try:
        write_json(CACHE_FILE, payload)
    except OSError as exc:
        plugin.log(f"Konnte die Ergebnisse nicht zwischenspeichern: {exc}", level="warning")


def load_cache():
    """Der letzte Stand, damit die Szene nach einem Neustart sofort etwas
    zeigt. Er wird beim ersten Lesen ersetzt."""
    stored = read_json(CACHE_FILE, {}) or {}
    with _data_lock:
        for key, row in (stored.get("data") or {}).items():
            if key in leagues.LEAGUES and isinstance(row, dict):
                row["matchesAt"] = 0
                row["tableAt"] = 0
                _data[key] = row
        for key, value in (stored.get("scores") or {}).items():
            if isinstance(value, list) and len(value) == 2:
                _scores[key] = tuple(value)


def short_score(match):
    return f"{match['home']['short']} {match['scoreHome']}:{match['scoreAway']} {match['away']['short']}"


def announce_goal(goal):
    match = goal["match"]
    scorer = (match.get("lastGoal") or {}).get("name") or ""
    plugin.log(f"Tor: {short_score(match)}" + (f" ({scorer})" if scorer else ""))
    emit(EVENT_GOAL, liga=leagues.LEAGUES[goal["league"]]["name"], heim=match["home"]["name"],
         gast=match["away"]["name"], stand=f"{match['scoreHome']}:{match['scoreAway']}", torschuetze=scorer)


def emit(event, **data):
    try:
        plugin.emit_event(event, {key: str(value) for key, value in data.items()})
    except Exception as exc:  # pragma: no cover
        plugin.log(f"Konnte das Ereignis {event} nicht senden: {exc}", level="warning")


# ---- Wappen ---------------------------------------------------------------
# Die Szene lädt Wappen über das Plugin: einmal aus dem Netz, danach von der
# SD-Karte. Nur Adressen, die in den Ergebnissen vorkommen, werden geladen.

_logo_urls = {}
LOGO_TYPES = {b"\x89PNG": ("png", "image/png"), b"<svg": ("svg", "image/svg+xml"),
              b"<?xm": ("svg", "image/svg+xml"), b"GIF8": ("gif", "image/gif"),
              b"\xff\xd8\xff": ("jpg", "image/jpeg"), b"RIFF": ("webp", "image/webp")}


def logo_key(url):
    if not url or not str(url).startswith(("https://", "http://")):
        return ""
    key = hashlib.sha1(url.encode("utf-8")).hexdigest()[:20]
    _logo_urls[key] = url
    return key


def logo_type(body):
    head = body[:5].lstrip()
    for magic, kind in LOGO_TYPES.items():
        if head.startswith(magic):
            return kind
    return None


def logo_bytes(key):
    """(body, content type) oder None."""
    if not re.fullmatch(r"[0-9a-f]{20}", key or ""):
        return None
    for path in LOGO_DIR.glob(f"{key}.*"):
        try:
            body = path.read_bytes()
        except OSError:
            continue
        kind = logo_type(body)
        if kind:
            return body, kind[1]
    url = _logo_urls.get(key)
    if not url:
        return None
    try:
        response = requests.get(url, headers={"User-Agent": leagues.HTTP_HEADERS["User-Agent"]},
                                timeout=(8, 15))
    except requests.RequestException:
        return None
    body = response.content or b""
    kind = logo_type(body)
    if response.status_code >= 400 or not kind or len(body) > 1_500_000:
        return None
    ensure_dirs()
    try:
        (LOGO_DIR / f"{key}.{kind[0]}").write_bytes(body)
    except OSError:
        pass
    return body, kind[1]


def with_logo(team):
    key = logo_key(team.get("logo"))
    return dict(team, logo=f"api/logo/{key}" if key else "")


def snapshot():
    """Alles, was die Szene braucht. Unter /api/scene abgerufen."""
    values = settings()
    with _data_lock:
        data = {k: dict(v) for k, v in _data.items()}
        version_n = _version["n"]
    pages = []
    for league_id in values["Leagues"]:
        league = leagues.LEAGUES[league_id]
        row = data.get(league_id) or {}
        matches = [dict(m, home=with_logo(m["home"]), away=with_logo(m["away"]))
                   for m in row.get("matches") or []]
        table = None
        if values["ShowTable"] and league["table"] and row.get("table"):
            table = [dict(r, team=with_logo(r["team"])) for r in row["table"]]
        pages.append({"id": league_id, "name": leagues.display_name(league_id, values["Language"]), "color": league["color"],
                      "round": texts.round_name(values["Language"], row.get("round") or ""),
                      "matches": matches, "table": table,
                      "source": row.get("source") or "", "updatedAt": row.get("matchesAt") or 0,
                      "error": row.get("error") or ""})
    with _takeover_lock:
        focus = _takeover["focus"] if _takeover["handle"] is not None else None
    return {"version": version_n, "at": now(), "pageSeconds": values["PageSeconds"],
            "focus": focus, "pages": pages, "lang": values["Language"]}


# --------------------------------------------------------------------------
# Playlists: die Takeover-Playlist und auf Wunsch eine für den Besitzer
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Fußball Live (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Fußball Live abgespielt, wenn es den Bildschirm "
                                 "übernimmt. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
OWNER_PLAYLIST_NAME = "Fußball Live"
OWNER_PLAYLIST_DESCRIPTION = ("Vom Plugin Fußball Live angelegt. Ausschalten, planen oder löschen "
                              "wie jede Playlist.")
TAKEOVER_ITEM_SECONDS = 6 * 3600  # das Plugin beendet die Anzeige lange vorher
SCENE_SECONDS = 60                # recommendedDurationSec in scene.dynamic

_playlists = {"at": 0.0, "takeoverId": None, "note": "", "ownerNote": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Playlists werden nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError as exc:
        return exc.status != 404
    return bool(status.get("active"))


def create_playlist(name, description, seconds, enabled):
    created = engine_call("POST", "/playlists", {"name": name, "description": description}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": seconds})
    if not enabled:
        engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    return playlist_id


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, sechs Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    playlist_id = create_playlist(TAKEOVER_PLAYLIST_NAME, TAKEOVER_PLAYLIST_DESCRIPTION,
                                  TAKEOVER_ITEM_SECONDS, enabled=False)
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_owner_playlist(values):
    state = load_state()
    playlist_id = state.get("ownerPlaylistId")
    if playlist_id:
        if get_playlist(playlist_id) is None:
            save_state(ownerPlaylistId=None, ownerPlaylistDeleted=bool(values["MakePlaylist"]))
            if values["MakePlaylist"]:
                save_settings({"MakePlaylist": False})
                plugin.log("Die Playlist Fußball Live wurde gelöscht; sie wird nicht neu angelegt.")
        return ""
    if not values["MakePlaylist"]:
        return ""
    if screen_held():
        return tr("Wartet, bis der Bildschirm wieder frei ist.")
    playlist_id = create_playlist(OWNER_PLAYLIST_NAME, OWNER_PLAYLIST_DESCRIPTION, SCENE_SECONDS, enabled=True)
    save_state(ownerPlaylistId=playlist_id, ownerPlaylistDeleted=False)
    plugin.log(f"Playlist {OWNER_PLAYLIST_NAME} angelegt ({playlist_id}), eingeschaltet.")
    return ""


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists.update(note=_scene["note"], ownerNote=_scene["note"])
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")
        try:
            _playlists["ownerNote"] = maintain_owner_playlist(settings())
        except EngineError as exc:
            _playlists["ownerNote"] = tr("Konnte die Playlist Fußball Live nicht pflegen: {exc}", exc=exc)


def owner_playlist_text(values, state):
    if values["MakePlaylist"]:
        if state.get("ownerPlaylistId"):
            return tr("Angelegt: die Playlist Fußball Live steht unter Playlists.")
        return _playlists["ownerNote"] or tr("Noch nicht angelegt; das passiert innerhalb einer Minute.")
    if state.get("ownerPlaylistDeleted"):
        return tr("Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.")
    if state.get("ownerPlaylistId"):
        return tr("Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.")
    return ""


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
ENDED_REASON = {"released": "abgebrochen", "expired": "abgelaufen", "failed": "fehlgeschlagen",
                "preempted": "verdraengt"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "reason": None, "since": None, "until": None, "started": False,
             "token": 0, "note": "", "focus": None}
_schedule = {"nextAt": 0.0, "lastAt": 0.0}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Fußball Live ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Fußball Live auf der Plugins-Seite aus, deshalb kann es "
                  "den Bildschirm nicht übernehmen.")
    return ""


def display_is_off():
    """Nur wahr, wenn der Rahmen sagt, dass der Bildschirm aus ist. Fußball
    weckt keinen Bildschirm."""
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_turn_on_screen():
    """Läuft die Szene gerade als normaler Playlist-Eintrag? Ein Takeover
    darüber lässt den Rahmen danach gestoppt zurück (bekannter Fehler), und
    die Ergebnisse sind ohnehin zu sehen."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None,
                         note=tr("Der Rahmen hat die Anzeige beendet ({state}).", state=new_state))
    plugin.log(f"Der Rahmen hat Fußball Live beendet: {new_state}.")
    if started:
        emit(EVENT_ENDED, grund=ENDED_REASON.get(new_state, new_state))
    publish_status()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None, note="")
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    if started:
        emit(EVENT_ENDED, grund=reason)
    publish_status()
    if reason != "gestoppt":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def _release_after(seconds, token):
    if _stop_requested.wait(max(1, int(seconds))):
        return
    end_takeover("fertig", token)


def show_scene(reason="show", seconds=None, focus=None):
    """Die Szene für `seconds` über alles legen. True, wenn der Rahmen den
    Bildschirm hergegeben hat."""
    if _takeover["handle"] is not None:
        return _note(tr("Fußball Live ist schon auf dem Bildschirm."))
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Fußball Live wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    if scene_turn_on_screen():
        return _note(tr("Fußball Live läuft gerade in deiner Playlist; die Anzeige bleibt so."))
    if display_is_off():
        return _note(tr("Der Bildschirm ist aus. Fußball Live weckt ihn nicht."))
    seconds = int(seconds or settings()["ShowForSeconds"])
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Schrift; eine Bildunterschrift stört nur.
             "overlay": {"enabled": False}}
    try:
        handle = plugin.acquire_display_session(
            session_key=reason, state=state, display_name=DISPLAY_NAME,
            # Etwas länger als gewünscht: der Timer unten ist das ordentliche
            # Ende, die Grenze der Engine greift nur, wenn das Plugin stirbt.
            max_duration_seconds=seconds + 10, wake_if_off=False)
    except Exception as exc:
        return _note(f"Konnte Fußball Live nicht anzeigen: {exc}")
    if handle is None:
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    t = now()
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, reason=reason, since=t, until=t + seconds, started=False,
                         note="", focus=focus)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat Fußball Live nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(f"Konnte Fußball Live nicht anzeigen: {exc}")
    with _takeover_lock:
        if _takeover["token"] != token or _takeover["handle"] is None:
            return False
        _takeover["started"] = True
    emit(EVENT_STARTED, grund=reason)
    plugin.log(f"Fußball Live für {seconds} Sekunden auf dem Bildschirm ({reason}).")
    publish_status()
    threading.Thread(target=_release_after, args=(seconds, token),
                     name=f"{PLUGIN_ID}-timer", daemon=True).start()
    return True


def cancel_scene():
    if not end_takeover("abgebrochen"):
        _note(tr("Fußball Live hatte den Bildschirm nicht."))


def toggle_scene():
    if _takeover["handle"] is not None:
        cancel_scene()
    else:
        show_scene("show")


_action_lock = threading.Lock()


def run_action(name):
    """Show, Cancel und Toggle antworten sofort und arbeiten in einem Thread."""
    work = {"show": lambda: show_scene("show"), "cancel": cancel_scene, "toggle": toggle_scene}[name]
    showing = _takeover["handle"] is not None
    asking, returning = tr("Bitte den Rahmen um den Bildschirm."), tr("Gebe den Bildschirm zurück.")
    message = {"show": asking, "cancel": returning, "toggle": returning if showing else asking}[name]

    def run():
        with _action_lock:
            try:
                work()
            except Exception as exc:  # pragma: no cover
                _note(tr("{name} hat nicht geklappt: {exc}", name=name, exc=exc))
    threading.Thread(target=run, name=f"{PLUGIN_ID}-{name}", daemon=True).start()
    return {"success": True, "message": message}


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach Fußball Live nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# ---- Der Zeitplan ----------------------------------------------------------

def in_active_hours(values, moment=None):
    hour = (moment or datetime.now()).hour
    start, end = values["ActiveFrom"], values["ActiveTo"]
    if start == end:
        return True
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # über Mitternacht, z.B. 18 bis 2


def auto_wanted(values):
    """(ja/nein, Grund) für die regelmäßige Anzeige."""
    mode = values["AutoMode"]
    if mode == "off":
        return False, tr("Regelmäßige Anzeige ist aus.")
    if not values["Leagues"]:
        return False, tr("Keine Liga gewählt.")
    if not in_active_hours(values):
        return False, tr("Außerhalb von {start}–{end} Uhr.", start=values["ActiveFrom"], end=values["ActiveTo"])
    with _data_lock:
        data = dict(_data)
    if mode == "live" and not any_live(data):
        return False, tr("Gerade läuft kein Spiel.")
    if mode == "matchday" and not matchday_today(data):
        return False, tr("Heute ist in den gewählten Ligen kein Spieltag.")
    return True, ""


_auto = {"note": ""}


def decide_takeover():
    values = settings()
    if _takeover["handle"] is not None:
        with _takeover_lock:
            handle = _takeover["handle"]
        if handle is not None and str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
        return
    t = now()
    # Ein Tor geht vor, wenn gewünscht. Ein Tor, das niemand binnen zwei
    # Minuten zeigen konnte, ist keine Nachricht mehr.
    with _data_lock:
        _goals[:] = [g for g in _goals if t - g["at"] < 120]
        goal = _goals.pop(0) if _goals else None
    if goal is not None and values["GoalTakeover"] and in_active_hours(values):
        if show_scene("tor", values["GoalSeconds"], focus={"league": goal["league"], "match": goal["match"]["id"]}):
            _schedule["lastAt"] = t
            return
    wanted, why = auto_wanted(values)
    _auto["note"] = why
    if not wanted:
        _schedule["nextAt"] = 0.0
        return
    if not _schedule["nextAt"]:
        # Erste Runde nach dem Start oder nach einer Pause: nicht sofort,
        # sondern eine Minute später, damit der Rahmen fertig starten kann.
        _schedule["nextAt"] = max(t + 60, _schedule["lastAt"] + values["EveryMinutes"] * 60)
    if t < _schedule["nextAt"]:
        return
    if show_scene("zeitplan"):
        _schedule["lastAt"] = t
        _schedule["nextAt"] = t + values["EveryMinutes"] * 60
    else:
        # Nicht bekommen (Bildschirm aus, anderes Plugin, eigene Runde):
        # in zwei Minuten noch einmal versuchen.
        _schedule["nextAt"] = t + 120


# --------------------------------------------------------------------------
# Overlay-Text
# --------------------------------------------------------------------------

_overlay = {"text": None}


def status_line():
    with _data_lock:
        data = {k: dict(v) for k, v in _data.items()}
    live = [m for row in data.values() for m in row.get("matches") or [] if m["state"] == "live"]
    if live:
        scores = " · ".join(short_score(m) for m in live[:4]) + (" …" if len(live) > 4 else "")
        return tr("Live: {scores}", scores=scores)
    upcoming = sorted((m for row in data.values() for m in row.get("matches") or [] if m["state"] == "pre"),
                      key=lambda m: m["kickoff"])
    if upcoming:
        m = upcoming[0]
        when = datetime.fromtimestamp(m["kickoff"]).strftime("%d.%m. %H:%M")
        return tr("Nächstes Spiel: {when} {home} – {away}", when=when, home=m["home"]["short"], away=m["away"]["short"])
    return tr("Keine Spiele")


def publish_status():
    text = status_line()
    if _overlay["text"] == text:
        return
    _overlay["text"] = text
    try:
        plugin.update_overlay_text(SERVICE_STATUS, text)
    except Exception:
        pass


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

TICK_SECONDS = 15
_loop = {"lastCheckAt": None, "lastError": "", "force": False}


def tick(force=False):
    try:
        maintain_playlists(force)
        refresh_data(force)
        decide_takeover()
        _loop.update(lastCheckAt=local_text(now()), lastError="")
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")
    publish_status()


def main_loop():
    _stop_requested.wait(3)
    while not _stop_requested.is_set():
        _wake.clear()
        force, _loop["force"] = _loop["force"], False
        tick(force)
        _wake.wait(TICK_SECONDS)


def check_now():
    _loop["force"] = True
    _wake.set()
    return {"success": True, "message": tr("Lese die Ergebnisse jetzt neu.")}


# --------------------------------------------------------------------------
# Die Plugin-Seite und die Daten für die Szene
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def state_payload():
    values = settings()
    state = load_state()
    with _data_lock:
        data = {k: dict(v) for k, v in _data.items()}
    with _takeover_lock:
        takeover = {"active": _takeover["handle"] is not None, "reason": _takeover["reason"],
                    "until": local_text(_takeover["until"]), "note": _takeover["note"]}
    rows = []
    for league_id in values["Leagues"]:
        row = data.get(league_id) or {}
        matches = row.get("matches") or []
        rows.append({"id": league_id, "name": leagues.display_name(league_id, values["Language"]),
                     "round": texts.round_name(values["Language"], row.get("round") or ""),
                     "source": row.get("source") or "",
                     "matches": len(matches), "live": sum(1 for m in matches if m["state"] == "live"),
                     "at": local_text(row.get("matchesAt")), "error": row.get("error") or ""})
    return {
        "success": True,
        "version": version(),
        "settings": values,
        "leagues": [{"id": k, "name": leagues.display_name(k, values["Language"]), "table": v["table"]}
                    for k, v in leagues.LEAGUES.items()],
        "sources": rows,
        "status": status_line(),
        "scene": {"found": _scene["dbId"] is not None, "note": _scene["note"]},
        "takeover": takeover,
        "permission": takeover_permission_note(),
        "next": local_text(_schedule["nextAt"]) if _schedule["nextAt"] else "",
        "autoNote": _auto["note"],
        "ownerPlaylist": owner_playlist_text(values, state),
        "lastCheckAt": _loop["lastCheckAt"],
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
    }


def settings_saved(changed):
    if "MakePlaylist" in changed:
        if settings()["MakePlaylist"]:
            save_state(ownerPlaylistDeleted=False)
        threading.Thread(target=maintain_playlists, kwargs={"force": True}, daemon=True).start()
    if set(changed) & {"Leagues", "ShowTable"}:
        check_now()
    if "Language" in changed:
        bump()  # die Szene holt sich die Daten mit der neuen Sprache
        publish_status()
    if set(changed) & {"AutoMode", "EveryMinutes", "ActiveFrom", "ActiveTo"}:
        _schedule["nextAt"] = 0.0
    bump()
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(snapshot(), cors=True)
                return
            if path.startswith("/api/logo/"):
                found = logo_bytes(path.rsplit("/", 1)[-1])
                if found is None:
                    self._json({"success": False, "error": "Kein Wappen"}, 404, cors=True)
                else:
                    self._send(found[0], found[1], cache="max-age=604800", cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                changed = save_settings(self._body())
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(check_now())
                return
            if path in ("/api/show", "/api/cancel", "/api/toggle"):
                self._json(run_action(path.rsplit("/", 1)[-1]))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    ensure_dirs()
    plugin.log(f"Starte {PLUGIN_ID} {version()}")
    load_cache()

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: check_now())
    plugin.on_action("show", lambda _context=None: run_action("show"))
    plugin.on_action("cancel", lambda _context=None: run_action("cancel"))
    plugin.on_action("toggle", lambda _context=None: run_action("toggle"))

    start_studio()
    publish_status()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
