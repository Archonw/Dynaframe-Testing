"""Die Ligen und woher ihre Ergebnisse kommen.

Zwei öffentliche Quellen, beide ohne Schlüssel:

- OpenLigaDB (api.openligadb.de), gemeinschaftlich gepflegt, für die
  deutschen Ligen. Liefert Spieltag, Ergebnisse, Torschützen und Tabelle.
- ESPN (site.api.espn.com), die öffentliche Scoreboard-Schnittstelle der
  ESPN-Webseite, für Champions League und alle anderen Wettbewerbe. Sie ist
  nicht offiziell dokumentiert; fällt sie aus oder ändert sich, zeigt die
  Szene den letzten Stand und sagt, wie alt er ist.

Fällt OpenLigaDB aus, werden die deutschen Ligen bei ESPN gelesen.

Eine neue Liga ist ein Eintrag in LEAGUES: ein ESPN-Kürzel (siehe
https://site.api.espn.com/apis/site/v2/sports/soccer/<kürzel>/scoreboard)
und, wenn es sie dort gibt, das OpenLigaDB-Kürzel.

Alles hier gibt einheitliche Spiele zurück:
  {"id", "kickoff" (Epoch-Sekunden), "state": "pre"|"live"|"post"|"off",
   "minute": "67'" | "HZ" | "", "home": {"name","short","logo"},
   "away": {...}, "scoreHome", "scoreAway" (int oder None),
   "halftime": "1:0" | "", "lastGoal": {"minute","name","side"} | None}
"""

import re
import time
from datetime import datetime, timedelta, timezone

import requests

HTTP_HEADERS = {"User-Agent": "DynaFrame-FussballLive/0.1 (+https://github.com/Archonw/Dynaframe-Stuff)",
                "Accept": "application/json"}
TIMEOUT = (8, 20)

OPENLIGADB = "https://api.openligadb.de"
ESPN_SITE = "https://site.api.espn.com/apis/site/v2/sports/soccer"
ESPN_STANDINGS = "https://site.api.espn.com/apis/v2/sports/soccer"

# Reihenfolge = Reihenfolge der Seiten in der Szene.
LEAGUES = {
    "bl1":  {"name": "1. Bundesliga", "oldb": "bl1", "espn": "ger.1", "table": True, "color": "#d20515"},
    "bl2":  {"name": "2. Bundesliga", "oldb": "bl2", "espn": "ger.2", "table": True, "color": "#e4572e"},
    "ucl":  {"name": "Champions League", "oldb": None, "espn": "uefa.champions", "table": False,
             "color": "#2b6cff"},
    "bl3":  {"name": "3. Liga", "oldb": "bl3", "espn": "ger.3", "table": True, "color": "#6b7a8f"},
    "dfb":  {"name": "DFB-Pokal", "oldb": None, "espn": "ger.dfb_pokal", "table": False, "color": "#1f9d55"},
    "uel":  {"name": "Europa League", "oldb": None, "espn": "uefa.europa", "table": False, "color": "#f08c00"},
    "uecl": {"name": "Conference League", "oldb": None, "espn": "uefa.europa.conf", "table": False,
             "color": "#16a34a"},
    "epl":  {"name": "Premier League", "oldb": None, "espn": "eng.1", "table": True, "color": "#7b2cbf"},
    "liga": {"name": "LaLiga", "oldb": None, "espn": "esp.1", "table": True, "color": "#ee6c4d"},
    "sea":  {"name": "Serie A", "oldb": None, "espn": "ita.1", "table": True, "color": "#118ab2"},
    "l1":   {"name": "Ligue 1", "oldb": None, "espn": "fra.1", "table": True, "color": "#94a3b8"},
}
DEFAULT_LEAGUES = ["bl1", "bl2", "ucl"]


class SourceError(Exception):
    """Eine Quelle hat nicht brauchbar geantwortet."""


def get_json(url, params=None):
    try:
        response = requests.get(url, params=params, headers=HTTP_HEADERS, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise SourceError(f"{url}: {exc}") from exc
    if response.status_code >= 400:
        raise SourceError(f"{url}: HTTP {response.status_code}")
    try:
        return response.json()
    except ValueError as exc:
        raise SourceError(f"{url}: keine JSON-Antwort") from exc


def parse_time(text):
    if not text:
        return None
    try:
        moment = datetime.fromisoformat(str(text).strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.timestamp()


def as_int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


def season_year(now=None):
    """OpenLigaDB zählt die Saison 2026/27 als 2026."""
    moment = datetime.fromtimestamp(now or time.time())
    return moment.year if moment.month >= 7 else moment.year - 1


def estimated_minute(kickoff, now=None):
    """OpenLigaDB nennt keine Spielminute; geschätzt aus dem Anstoß, mit
    15 Minuten Pause und etwas Nachspielzeit. Nur als grobe Anzeige."""
    elapsed = int(((now or time.time()) - kickoff) // 60)
    if elapsed < 0:
        return ""
    if elapsed <= 45:
        return f"{max(1, elapsed)}'"
    if elapsed <= 48:
        return "45+'"
    if elapsed <= 63:
        return "HZ"
    second = elapsed - 18
    if second <= 90:
        return f"{max(46, second)}'"
    return "90+'"


def team(name, short, logo):
    name = (name or "").strip() or "?"
    return {"name": name, "short": (short or "").strip() or name, "logo": logo or ""}


# --------------------------------------------------------------------------
# OpenLigaDB
# --------------------------------------------------------------------------

def oldb_match(raw, now=None):
    now = now or time.time()
    kickoff = parse_time(raw.get("matchDateTimeUTC")) or parse_time(raw.get("matchDateTime")) or 0
    results = [r for r in raw.get("matchResults") or [] if isinstance(r, dict)]
    final = next((r for r in results if r.get("resultTypeID") == 2), None)
    half = next((r for r in results if r.get("resultTypeID") == 1), None)
    goals = sorted([g for g in raw.get("goals") or [] if isinstance(g, dict)],
                   key=lambda g: (g.get("scoreTeam1") or 0) + (g.get("scoreTeam2") or 0))
    finished = bool(raw.get("matchIsFinished"))

    home_score = away_score = None
    if goals:
        home_score, away_score = as_int(goals[-1].get("scoreTeam1")), as_int(goals[-1].get("scoreTeam2"))
    if final is not None:
        f_home, f_away = as_int(final.get("pointsTeam1")), as_int(final.get("pointsTeam2"))
        # Torliste und Ergebnis werden getrennt gepflegt; im Spiel ist mal das
        # eine, mal das andere weiter. Der Stand mit mehr Toren ist der neuere.
        if finished or home_score is None or \
                (f_home or 0) + (f_away or 0) > (home_score or 0) + (away_score or 0):
            home_score, away_score = f_home, f_away

    if finished:
        state = "post"
    elif kickoff and now >= kickoff:
        # Ein Spiel, das seit vier Stunden "läuft", ist in der Quelle nur
        # nicht abgeschlossen worden.
        state = "live" if now - kickoff < 4 * 3600 else "post"
    else:
        state = "pre"
    if state != "pre" and home_score is None:
        home_score = away_score = 0

    last_goal = None
    if goals:
        g = goals[-1]
        prev = goals[-2] if len(goals) > 1 else {"scoreTeam1": 0, "scoreTeam2": 0}
        side = "home" if (g.get("scoreTeam1") or 0) > (prev.get("scoreTeam1") or 0) else "away"
        minute = as_int(g.get("matchMinute"))
        last_goal = {"minute": f"{minute}'" if minute else "", "name": (g.get("goalGetterName") or "").strip(),
                     "side": side}

    t1, t2 = raw.get("team1") or {}, raw.get("team2") or {}
    return {
        "id": f"oldb-{raw.get('matchID')}",
        "kickoff": kickoff,
        "state": state,
        "minute": estimated_minute(kickoff, now) if state == "live" else "",
        "home": team(t1.get("teamName"), t1.get("shortName"), t1.get("teamIconUrl")),
        "away": team(t2.get("teamName"), t2.get("shortName"), t2.get("teamIconUrl")),
        "scoreHome": home_score,
        "scoreAway": away_score,
        "halftime": f"{half.get('pointsTeam1')}:{half.get('pointsTeam2')}" if half and state == "post" else "",
        "lastGoal": last_goal,
    }


def oldb_matchday(shortcut, now=None):
    data = get_json(f"{OPENLIGADB}/getmatchdata/{shortcut}")
    if not isinstance(data, list) or not data:
        raise SourceError(f"OpenLigaDB {shortcut}: kein Spieltag")
    group = (data[0].get("group") or {}).get("groupName") or ""
    matches = sorted((oldb_match(m, now) for m in data if isinstance(m, dict)), key=lambda m: m["kickoff"])
    return {"round": group, "matches": matches}


def oldb_table(shortcut, now=None):
    data = get_json(f"{OPENLIGADB}/getbltable/{shortcut}/{season_year(now)}")
    if not isinstance(data, list) or not data:
        raise SourceError(f"OpenLigaDB {shortcut}: keine Tabelle")
    rows = []
    for index, row in enumerate(data, start=1):
        rows.append({
            "rank": index,
            "team": team(row.get("teamName"), row.get("shortName"), row.get("teamIconUrl")),
            "played": as_int(row.get("matches")) or 0,
            "diff": as_int(row.get("goalDiff")) or 0,
            "goals": f"{row.get('goals', 0)}:{row.get('opponentGoals', 0)}",
            "points": as_int(row.get("points")) or 0,
        })
    return rows


# --------------------------------------------------------------------------
# ESPN
# --------------------------------------------------------------------------

def espn_logo(team_raw):
    if team_raw.get("logo"):
        return team_raw["logo"]
    logos = team_raw.get("logos") or []
    return (logos[0] or {}).get("href", "") if logos else ""


def espn_match(event):
    competition = (event.get("competitions") or [{}])[0]
    competitors = competition.get("competitors") or []
    home = next((c for c in competitors if c.get("homeAway") == "home"), competitors[0] if competitors else {})
    away = next((c for c in competitors if c.get("homeAway") == "away"),
                competitors[1] if len(competitors) > 1 else {})
    status = competition.get("status") or event.get("status") or {}
    kind = status.get("type") or {}
    raw_state = kind.get("state")
    name = str(kind.get("name") or "")
    if name in ("STATUS_POSTPONED", "STATUS_CANCELED", "STATUS_ABANDONED", "STATUS_SUSPENDED"):
        state = "off"
    elif raw_state == "in":
        state = "live"
    elif raw_state == "post" or kind.get("completed"):
        state = "post"
    else:
        state = "pre"
    minute = ""
    if state == "live":
        minute = "HZ" if name == "STATUS_HALFTIME" else str(status.get("displayClock") or kind.get("shortDetail") or "")
    elif state == "off":
        minute = "abgesagt" if name == "STATUS_CANCELED" else "verlegt"

    def score(c):
        return as_int(c.get("score")) if state in ("live", "post") else None

    def side(c):
        t = c.get("team") or {}
        return team(t.get("displayName"), t.get("shortDisplayName") or t.get("name"), espn_logo(t))

    return {
        "id": f"espn-{event.get('id')}",
        "kickoff": parse_time(event.get("date")) or 0,
        "state": state,
        "minute": minute,
        "home": side(home),
        "away": side(away),
        "scoreHome": score(home),
        "scoreAway": score(away),
        "halftime": "",
        "lastGoal": None,
    }


def pick_round(matches, now):
    """Aus einem Zeitfenster die Spiele, die zusammengehören: laufende,
    sonst die nächsten (wenn sie innerhalb von 2 Tagen beginnen), sonst die
    zuletzt gespielten. Ein "Spieltag" ist hier ein Block ohne Lücke von
    mehr als 2,5 Tagen."""
    if not matches:
        return []
    matches = sorted(matches, key=lambda m: m["kickoff"])
    blocks, current = [], [matches[0]]
    for match in matches[1:]:
        if match["kickoff"] - current[-1]["kickoff"] > 60 * 3600:
            blocks.append(current)
            current = []
        current.append(match)
    blocks.append(current)
    for block in blocks:
        if any(m["state"] == "live" for m in block):
            return block
    upcoming = [b for b in blocks if b[0]["kickoff"] > now]
    past = [b for b in blocks if b[0]["kickoff"] <= now]
    if upcoming and (upcoming[0][0]["kickoff"] - now < 2 * 86400 or not past):
        return upcoming[0]
    return past[-1] if past else upcoming[0]


def round_label(matches):
    if not matches:
        return ""
    days = sorted({datetime.fromtimestamp(m["kickoff"]).date() for m in matches if m["kickoff"]})
    if not days:
        return ""
    fmt = lambda d: d.strftime("%d.%m.")
    return fmt(days[0]) if len(days) == 1 else f"{fmt(days[0])} – {fmt(days[-1])}"


def espn_round(code, now=None):
    now = now or time.time()
    start = datetime.fromtimestamp(now) - timedelta(days=6)
    end = datetime.fromtimestamp(now) + timedelta(days=6)
    url = f"{ESPN_SITE}/{code}/scoreboard"
    dates = f"{start:%Y%m%d}-{end:%Y%m%d}"
    events = []
    # Manche Wettbewerbe (z. B. uefa.champions) lehnen den Zeitraum oder das
    # Limit mit HTTP 400 ab; dann die schlichteren Abfragen versuchen.
    for params in ({"dates": dates, "limit": 200}, {"dates": dates}):
        try:
            data = get_json(url, params)
        except SourceError:
            continue
        events = [e for e in (data or {}).get("events") or [] if isinstance(e, dict)]
        break
    if not events:
        # Keine Spiele in zwei Wochen (Winterpause, Länderspiele) oder der
        # Zeitraum wurde abgelehnt: der Standardaufruf liefert den nächsten Spieltag.
        data = get_json(url)
        events = [e for e in (data or {}).get("events") or [] if isinstance(e, dict)]
    matches = pick_round([espn_match(e) for e in events], now)
    return {"round": round_label(matches), "matches": matches}


def espn_table(code):
    data = get_json(f"{ESPN_STANDINGS}/{code}/standings")
    groups = (data or {}).get("children") or [data or {}]
    entries = []
    for group in groups:
        entries.extend(((group.get("standings") or {}).get("entries")) or [])
    if not entries:
        raise SourceError(f"ESPN {code}: keine Tabelle")
    rows = []
    for entry in entries:
        stats = {s.get("name"): s for s in entry.get("stats") or [] if isinstance(s, dict)}

        def value(*names):
            for name in names:
                if name in stats and stats[name].get("value") is not None:
                    try:
                        return int(float(stats[name]["value"]))
                    except (TypeError, ValueError):
                        pass
            return 0
        t = entry.get("team") or {}
        rows.append({
            "rank": value("rank"),
            "team": team(t.get("displayName"), t.get("shortDisplayName") or t.get("name"), espn_logo(t)),
            "played": value("gamesPlayed"),
            "diff": value("pointDifferential"),
            "goals": f"{value('pointsFor')}:{value('pointsAgainst')}",
            "points": value("points"),
        })
    rows.sort(key=lambda r: (r["rank"] or 999))
    for index, row in enumerate(rows, start=1):
        row["rank"] = row["rank"] or index
    return rows


# --------------------------------------------------------------------------
# Eine Liga lesen
# --------------------------------------------------------------------------

def _name_key(name):
    words = re.findall(r"[a-z0-9]+", str(name or "").lower()
                       .replace("ä", "a").replace("ö", "o").replace("ü", "u").replace("ß", "ss"))
    return {w for w in words if len(w) >= 4 or w.isdigit()}


def _same_team(a, b):
    return bool((_name_key(a["name"]) | _name_key(a["short"])) & (_name_key(b["name"]) | _name_key(b["short"])))


def overlay_espn_scores(matches, espn_code, now=None):
    """OpenLigaDB wird von Hand gepflegt und hängt bei Toren oft hinterher.
    Für laufende und gerade beendete Spiele den Stand von ESPN übernehmen.
    True, wenn ESPN etwas beigesteuert hat; Fehler bei ESPN sind egal."""
    t = now or time.time()
    recent = [m for m in matches if m["kickoff"] and 0 <= t - m["kickoff"] <= 4 * 3600 and m["state"] != "off"]
    if not recent:
        return False
    try:
        events = espn_round(espn_code, t)["matches"]
    except SourceError:
        return False
    used = False
    for m in recent:
        other = next((e for e in events if abs(e["kickoff"] - m["kickoff"]) <= 900
                      and _same_team(e["home"], m["home"]) and _same_team(e["away"], m["away"])), None)
        if other is None or other["state"] not in ("live", "post") or other["scoreHome"] is None:
            continue
        m.update(state=other["state"], scoreHome=other["scoreHome"], scoreAway=other["scoreAway"],
                 minute=other["minute"] if other["state"] == "live" else "")
        used = True
    return used


def fetch_matches(league_id, now=None):
    """(round, matches, source). OpenLigaDB zuerst, wo es die Liga hat."""
    league = LEAGUES[league_id]
    errors = []
    if league.get("oldb"):
        try:
            result = oldb_matchday(league["oldb"], now)
            source = "OpenLigaDB"
            if overlay_espn_scores(result["matches"], league["espn"], now):
                source = "OpenLigaDB · Live: ESPN"
            return result["round"], result["matches"], source
        except SourceError as exc:
            errors.append(str(exc))
    try:
        result = espn_round(league["espn"], now)
        return result["round"], result["matches"], "ESPN"
    except SourceError as exc:
        errors.append(str(exc))
    raise SourceError("; ".join(errors))


def fetch_table(league_id, now=None):
    league = LEAGUES[league_id]
    errors = []
    if league.get("oldb"):
        try:
            return oldb_table(league["oldb"], now)
        except SourceError as exc:
            errors.append(str(exc))
    try:
        return espn_table(league["espn"])
    except SourceError as exc:
        errors.append(str(exc))
    raise SourceError("; ".join(errors))
