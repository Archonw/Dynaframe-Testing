"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/FussballLive/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PageSeconds", "EveryMinutes", "ShowForSeconds", "ActiveFrom", "ActiveTo", "GoalSeconds"];
const CHECK_FIELDS = ["ShowTable", "GoalTakeover"];
let current = null;
let editing = false;

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error("Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.");
  }
  if ([502, 503, 504].includes(response.status)) {
    throw new Error(`Das Plugin wurde neu gestartet (HTTP ${response.status}). Lade die Seite neu.`);
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || `Fehler (HTTP ${response.status})`);
  return payload;
}

function setStatus(text, tone = "") {
  const node = el("statusNote");
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const time = date.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  return sameDay ? `${time} Uhr` : `${date.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit" })} ${time} Uhr`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(name, value) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify({ [name]: value }) });
    setStatus("Gespeichert.", "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function renderLeagues(state) {
  const list = el("leagueList");
  const chosen = new Set(state.settings.Leagues);
  if (list.childElementCount !== state.leagues.length) {
    list.innerHTML = "";
    for (const league of state.leagues) {
      const label = document.createElement("label");
      const box = document.createElement("input");
      box.type = "checkbox";
      box.value = league.id;
      box.addEventListener("change", () => {
        const selected = [...list.querySelectorAll("input:checked")].map((b) => b.value);
        save("Leagues", selected);
      });
      const text = document.createElement("span");
      text.textContent = league.name;
      label.append(box, text);
      list.append(label);
    }
  }
  for (const box of list.querySelectorAll("input")) box.checked = chosen.has(box.value);
}

function renderSources(state) {
  const list = el("sourceList");
  list.innerHTML = "";
  if (!state.sources.length) {
    list.innerHTML = '<li><span class="meta">Keine Liga gewählt.</span></li>';
    return;
  }
  for (const row of state.sources) {
    const li = document.createElement("li");
    const dot = row.error ? "bad" : row.at ? "" : "idle";
    const live = row.live ? ` · ${row.live} live` : "";
    li.innerHTML = `<span class="name"><span class="dot ${dot}"></span></span><span class="meta"></span>`;
    li.querySelector(".name").append(row.name);
    li.querySelector(".meta").textContent = row.at
      ? `${row.round || "ohne Spieltag"} · ${row.matches} Spiele${live} · ${row.source || "?"} · ${clock(row.at)}`
      : "noch nicht gelesen";
    if (row.error) {
      const err = document.createElement("span");
      err.className = "err";
      err.textContent = row.error;
      li.append(err);
    }
    list.append(li);
  }
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  el("factStatus").textContent = state.status || "—";
  el("factScreen").textContent = state.takeover.active
    ? `Fußball Live wird angezeigt${state.takeover.until ? ` bis ${clock(state.takeover.until)}` : ""}`
    : "Playlist läuft";
  el("factNext").textContent = s.AutoMode === "off" ? "aus" : state.next ? clock(state.next) : (state.autoNote || "—");
  el("factScene").textContent = state.scene.found ? "installiert" : "nicht gefunden";
  el("factVersion").textContent = state.version;

  const notes = [state.scene.note, state.takeover.note, state.lastError].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.lastError ? "bad" : "");
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;

  if (!editing) {
    for (const name of NUMBER_FIELDS) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    el("AutoMode").value = s.AutoMode;
    el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  }
  renderLeagues(state);
  renderSources(state);
  el("playlistNote").textContent = state.ownerPlaylist || "";

  const pages = s.Leagues.length;
  const needed = pages * s.PageSeconds;
  el("durationHint").textContent = pages > 1
    ? `${pages} Ligen × ${s.PageSeconds} s = ${needed} s für einen Durchlauf aller Seiten.` +
      (s.ShowForSeconds < needed ? ` Mit ${s.ShowForSeconds} s sind nicht alle Ligen zu sehen.` : "")
    : "";
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", () => save(name, Number(input.value)));
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save(name, e.target.checked));
el("AutoMode").addEventListener("change", (e) => save("AutoMode", e.target.value));
el("MakePlaylist").addEventListener("change", (e) => save("MakePlaylist", e.target.value === "true"));

for (const [id, path] of [["showButton", "show"], ["cancelButton", "cancel"], ["refreshButton", "refresh"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(`./api/${path}`, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}

refresh();
setInterval(refresh, 5000);
