/* Fußball Live - die Szene.
 *
 * Daten kommen vom Plugin Fußball Live, über den Proxy der Weboberfläche auf
 * :8003 (der Proxy der Engine lehnt lokale Adressen ab). Antwortet das
 * Plugin nicht, liest die Szene 1. und 2. Bundesliga (OpenLigaDB) und die
 * Champions League (ESPN) selbst über DynaFrameScene.fetchExternalJson.
 * Mit ?demo=1 zeigt sie Beispieldaten (zum Ansehen im Browser).
 *
 * Die Seiten (eine je Liga) wechseln im eingestellten Takt. Die Szene
 * braucht keine Eingabe.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "FussballLive";
  const POLL_MS = 15000;
  const FALLBACK_POLL_MS = 60000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  const pluginBase = params.get("plugin") ||
    `${location.protocol}//${location.hostname}:8003/Plugins/Advanced/${PLUGIN_ID}/`;

  const el = (id) => document.getElementById(id);
  const ui = {
    stage: el("stage"), accent: el("accent"), leagueName: el("leagueName"), roundName: el("roundName"),
    clock: el("clock"), updated: el("updated"), dots: el("dots"), page: el("page"),
    matches: el("matches"), table: el("table"), foot: el("foot")
  };

  let snapshot = null;      // {pages, pageSeconds, focus, at, mode}
  let pageIndex = 0;
  let pageTimer = null;
  let readySent = false;
  let lastScores = {};      // Spiel-id -> "2:1", um ein Tor kurz aufleuchten zu lassen
  let flash = new Set();
  let mode = DEMO ? "demo" : "plugin";
  let pluginFailures = 0;

  // ---------------------------------------------------------------- helpers

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function esc(text) {
    return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  const dayFmt = new Intl.DateTimeFormat("de-DE", { weekday: "short" });
  const dateFmt = new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit" });
  const timeFmt = new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit" });

  function initials(name) {
    const words = String(name || "?").replace(/[^\p{L}\p{N} ]/gu, "").split(/\s+/).filter((w) => w.length > 2 || /\d/.test(w));
    return (words.length ? words : [String(name || "?")]).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  }

  function logoUrl(path) {
    if (!path) return "";
    if (/^https?:\/\//.test(path)) return path;
    return new URL(path, pluginBase).toString();
  }

  function logo(team) {
    const url = logoUrl(team.logo);
    const badge = `<span class="badge">${esc(initials(team.name))}</span>`;
    if (!url) return badge;
    // Ein Wappen, das nicht lädt, wird zum Kürzel (siehe den error-Listener
    // unten); kein Inline-Handler, dessen Anführungszeichen das Markup brechen.
    return `<img class="logo" src="${esc(url)}" alt="" data-badge="${esc(initials(team.name))}">`;
  }

  document.addEventListener("error", (event) => {
    const img = event.target;
    if (!(img instanceof HTMLImageElement) || !img.classList.contains("logo")) return;
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = img.dataset.badge || "";
    img.replaceWith(badge);
  }, true);

  async function getJson(url) {
    if (window.DynaFrameScene?.fetchExternalJson) return window.DynaFrameScene.fetchExternalJson(url);
    const response = await fetch(url, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  // ------------------------------------------------------------ data: plugin

  async function loadFromPlugin() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(new URL("api/scene", pluginBase), { signal: controller.signal, cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (!data || !Array.isArray(data.pages)) throw new Error("unerwartete Antwort");
      data.mode = "plugin";
      return data;
    } finally {
      clearTimeout(timer);
    }
  }

  // ------------------------------------------------- data: direkt (Notfall)

  function minuteFromKickoff(kickoff) {
    const e = Math.floor((Date.now() / 1000 - kickoff) / 60);
    if (e < 0) return "";
    if (e <= 45) return `${Math.max(1, e)}'`;
    if (e <= 48) return "45+'";
    if (e <= 63) return "HZ";
    const s = e - 18;
    return s <= 90 ? `${Math.max(46, s)}'` : "90+'";
  }

  function oldbMatch(raw) {
    const kickoff = Date.parse(raw.matchDateTimeUTC || raw.matchDateTime) / 1000 || 0;
    const results = raw.matchResults || [];
    const final = results.find((r) => r.resultTypeID === 2);
    const goals = (raw.goals || []).slice().sort((a, b) => (a.scoreTeam1 + a.scoreTeam2) - (b.scoreTeam1 + b.scoreTeam2));
    const now = Date.now() / 1000;
    let state = raw.matchIsFinished ? "post" : (kickoff && now >= kickoff ? (now - kickoff < 4 * 3600 ? "live" : "post") : "pre");
    let h = null, a = null;
    if (goals.length) { h = goals[goals.length - 1].scoreTeam1; a = goals[goals.length - 1].scoreTeam2; }
    if (final && (raw.matchIsFinished || h === null)) { h = final.pointsTeam1; a = final.pointsTeam2; }
    if (state !== "pre" && h === null) { h = 0; a = 0; }
    const team = (t) => ({ name: t?.teamName || "?", short: t?.shortName || t?.teamName || "?", logo: t?.teamIconUrl || "" });
    const g = goals[goals.length - 1];
    return {
      id: `oldb-${raw.matchID}`, kickoff, state, minute: state === "live" ? minuteFromKickoff(kickoff) : "",
      home: team(raw.team1), away: team(raw.team2), scoreHome: h, scoreAway: a, halftime: "",
      lastGoal: g ? { minute: g.matchMinute ? `${g.matchMinute}'` : "", name: g.goalGetterName || "", side: "" } : null
    };
  }

  function espnMatch(event) {
    const comp = (event.competitions || [{}])[0];
    const cs = comp.competitors || [];
    const home = cs.find((c) => c.homeAway === "home") || cs[0] || {};
    const away = cs.find((c) => c.homeAway === "away") || cs[1] || {};
    const status = comp.status || event.status || {};
    const type = status.type || {};
    const off = ["STATUS_POSTPONED", "STATUS_CANCELED", "STATUS_ABANDONED", "STATUS_SUSPENDED"].includes(type.name);
    const state = off ? "off" : type.state === "in" ? "live" : (type.state === "post" || type.completed) ? "post" : "pre";
    const side = (c) => ({
      name: c.team?.displayName || "?", short: c.team?.shortDisplayName || c.team?.displayName || "?",
      logo: c.team?.logo || c.team?.logos?.[0]?.href || ""
    });
    const score = (c) => (state === "live" || state === "post") ? parseInt(c.score, 10) : null;
    return {
      id: `espn-${event.id}`, kickoff: Date.parse(event.date) / 1000 || 0, state,
      minute: state === "live" ? (type.name === "STATUS_HALFTIME" ? "HZ" : (status.displayClock || "")) : off ? "verlegt" : "",
      home: side(home), away: side(away), scoreHome: score(home), scoreAway: score(away), halftime: "", lastGoal: null
    };
  }

  function pickRound(matches) {
    if (!matches.length) return [];
    matches.sort((a, b) => a.kickoff - b.kickoff);
    const blocks = [];
    let cur = [matches[0]];
    for (const m of matches.slice(1)) {
      if (m.kickoff - cur[cur.length - 1].kickoff > 60 * 3600) { blocks.push(cur); cur = []; }
      cur.push(m);
    }
    blocks.push(cur);
    const now = Date.now() / 1000;
    const live = blocks.find((b) => b.some((m) => m.state === "live"));
    if (live) return live;
    const upcoming = blocks.filter((b) => b[0].kickoff > now);
    const past = blocks.filter((b) => b[0].kickoff <= now);
    if (upcoming.length && (upcoming[0][0].kickoff - now < 2 * 86400 || !past.length)) return upcoming[0];
    return past.length ? past[past.length - 1] : upcoming[0];
  }

  function ymd(date) {
    return `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
  }

  async function loadDirect() {
    const season = (() => { const d = new Date(); return d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1; })();
    const pages = [];
    const german = [["bl1", "1. Bundesliga", "#d20515"], ["bl2", "2. Bundesliga", "#e4572e"]];
    for (const [id, name, color] of german) {
      const page = { id, name, color, round: "", matches: [], table: null, source: "OpenLigaDB", updatedAt: Date.now() / 1000, error: "" };
      try {
        const data = await getJson(`https://api.openligadb.de/getmatchdata/${id}`);
        page.round = data?.[0]?.group?.groupName || "";
        page.matches = (data || []).map(oldbMatch).sort((a, b) => a.kickoff - b.kickoff);
        const table = await getJson(`https://api.openligadb.de/getbltable/${id}/${season}`).catch(() => null);
        if (Array.isArray(table) && table.length) {
          page.table = table.map((r, i) => ({
            rank: i + 1, team: { name: r.teamName, short: r.shortName || r.teamName, logo: r.teamIconUrl || "" },
            played: r.matches, diff: r.goalDiff, goals: `${r.goals}:${r.opponentGoals}`, points: r.points
          }));
        }
      } catch (error) {
        page.error = String(error.message || error);
      }
      pages.push(page);
    }
    const ucl = { id: "ucl", name: "Champions League", color: "#2b6cff", round: "", matches: [], table: null, source: "ESPN", updatedAt: Date.now() / 1000, error: "" };
    try {
      const from = new Date(Date.now() - 6 * 86400000), to = new Date(Date.now() + 6 * 86400000);
      const base = "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard";
      // ESPN lehnt den Zeitraum für die Champions League teils mit HTTP 400 ab;
      // dann liefert der Aufruf ohne Parameter den aktuellen Spieltag.
      let data = await getJson(`${base}?dates=${ymd(from)}-${ymd(to)}`).catch(() => null);
      if (!data?.events?.length) data = await getJson(base);
      ucl.matches = pickRound((data?.events || []).map(espnMatch));
      ucl.round = roundLabel(ucl.matches);
    } catch (error) {
      ucl.error = String(error.message || error);
    }
    pages.push(ucl);
    return { mode: "direct", pageSeconds: 20, focus: null, at: Date.now() / 1000, pages };
  }

  function roundLabel(matches) {
    const days = [...new Set(matches.filter((m) => m.kickoff).map((m) => dateFmt.format(new Date(m.kickoff * 1000))))];
    if (!days.length) return "";
    return days.length === 1 ? days[0] : `${days[0]} – ${days[days.length - 1]}`;
  }

  // ------------------------------------------------------------ data: demo

  function demoData() {
    const t = Date.now() / 1000;
    const m = (id, h, a, sh, sa, state, offset, minute, extra) => ({
      id, kickoff: t + offset, state, minute: minute || "", home: { name: h, short: h, logo: "" }, away: { name: a, short: a, logo: "" },
      scoreHome: sh, scoreAway: sa, halftime: "", lastGoal: extra || null
    });
    const table = ["FC Bayern", "Leverkusen", "Dortmund", "Leipzig", "Stuttgart", "Frankfurt", "Freiburg", "Mainz", "Wolfsburg",
      "Gladbach", "Union Berlin", "Hoffenheim", "Werder Bremen", "Augsburg", "St. Pauli", "Heidenheim", "Köln", "HSV"]
      .map((name, i) => ({ rank: i + 1, team: { name, short: name, logo: "" }, played: 7, diff: 14 - i * 2, goals: `${20 - i}:${6 + i}`, points: 19 - i }));
    return {
      mode: "demo", pageSeconds: 12, focus: null, at: t,
      pages: [
        { id: "bl1", name: "1. Bundesliga", color: "#d20515", round: "7. Spieltag", source: "Demo", updatedAt: t, error: "", table,
          matches: [
            m("1", "FC Bayern", "Dortmund", 2, 1, "live", -3900, "67'", { minute: "64'", name: "Kane", side: "home" }),
            m("2", "Leverkusen", "Leipzig", 0, 0, "live", -3900, "66'"),
            m("3", "Stuttgart", "Frankfurt", 3, 2, "post", -86400, "", null),
            m("4", "Freiburg", "Mainz", 1, 1, "post", -80000),
            m("5", "Wolfsburg", "Gladbach", 2, 0, "post", -80000),
            m("6", "Union Berlin", "Hoffenheim", 0, 3, "post", -80000),
            m("7", "Werder Bremen", "Augsburg", null, null, "pre", 9000),
            m("8", "St. Pauli", "Heidenheim", null, null, "pre", 86400 + 5400),
            m("9", "Köln", "HSV", null, null, "pre", 86400 + 12600)
          ] },
        { id: "ucl", name: "Champions League", color: "#2b6cff", round: "21.10. – 22.10.", source: "Demo", updatedAt: t, error: "", table: null,
          matches: ["Real Madrid|Juventus", "Arsenal|Atlético", "Bayern München|Club Brugge", "PSG|Leverkusen", "Inter|Benfica",
            "Liverpool|Napoli", "Barcelona|Olympiacos", "Man City|Villarreal", "Dortmund|Kopenhagen", "Chelsea|Ajax",
            "Atalanta|Slavia Prag", "Monaco|Tottenham", "Sporting|Marseille", "Eintracht Frankfurt|Galatasaray",
            "Newcastle|Benfica", "PSV|Napoli", "Bodø/Glimt|Qarabağ", "Union SG|Pafos"].map((pair, i) => {
            const [h, a] = pair.split("|");
            return i < 9 ? m(`c${i}`, h, a, i % 3, (i + 1) % 2, "post", -2 * 86400) : m(`c${i}`, h, a, null, null, "pre", -86400 + 3 * 86400);
          }) }
      ]
    };
  }

  // ----------------------------------------------------------------- render

  function kickoffText(match) {
    if (!match.kickoff) return "";
    const date = new Date(match.kickoff * 1000);
    const today = new Date();
    const sameDay = date.toDateString() === today.toDateString();
    const day = sameDay ? "Heute" : dayFmt.format(date).replace(".", "");
    return { top: day, bottom: timeFmt.format(date), date: dateFmt.format(date) };
  }

  function whenCell(match) {
    if (match.state === "live") return `<div class="when"><b><span class="pulse"></span>${esc(match.minute || "live")}</b>Live</div>`;
    if (match.state === "off") return `<div class="when"><b>${esc(match.minute || "verlegt")}</b></div>`;
    const k = kickoffText(match);
    if (match.state === "post") {
      return `<div class="when"><b>Ende</b>${esc(match.halftime ? `HZ ${match.halftime}` : k ? `${k.top} ${k.date}` : "")}</div>`;
    }
    return `<div class="when"><b>${esc(k.top || "")}</b>${esc(k.date || "")}</div>`;
  }

  function scoreCell(match) {
    if (match.state === "pre" || match.state === "off" || match.scoreHome === null || match.scoreHome === undefined) {
      const k = kickoffText(match);
      return `<div class="score pre">${esc(match.state === "off" ? "–:–" : (k.bottom || "–:–"))}</div>`;
    }
    return `<div class="score">${esc(match.scoreHome)}:${esc(match.scoreAway)}</div>`;
  }

  function goalLine(match, side) {
    const goal = match.lastGoal;
    if (match.state !== "live" || !goal || !goal.name) return "";
    if ((goal.side || "home") !== side) return "";
    return `<small>⚽ ${esc(goal.minute ? goal.minute + " " : "")}${esc(goal.name)}</small>`;
  }

  function matchRow(match) {
    const decided = match.state === "post" && match.scoreHome !== null;
    const homeLost = decided && match.scoreHome < match.scoreAway;
    const awayLost = decided && match.scoreAway < match.scoreHome;
    const classes = ["match", match.state, flash.has(match.id) ? "goal" : ""].join(" ");
    return `<div class="${classes}">
      ${whenCell(match)}
      <div class="team home${homeLost ? " lost" : ""}"><span class="name">${esc(match.home.short || match.home.name)}${goalLine(match, "home")}</span>${logo(match.home)}</div>
      ${scoreCell(match)}
      <div class="team away${awayLost ? " lost" : ""}">${logo(match.away)}<span class="name">${esc(match.away.short || match.away.name)}${goalLine(match, "away")}</span></div>
    </div>`;
  }

  function zoneClass(page, rank, count) {
    if (page.id === "bl1") return rank <= 4 ? "zone-cl" : rank <= 6 ? "zone-el" : rank === 16 ? "zone-rel" : rank >= 17 ? "zone-down" : "";
    if (page.id === "bl2" || page.id === "bl3") return rank <= 2 ? "zone-cl" : rank === 3 ? "zone-el" : rank === 16 && page.id === "bl2" ? "zone-rel" : rank > count - 2 ? "zone-down" : "";
    return "";
  }

  function tableHtml(page, liveNames) {
    const rows = page.table;
    const fit = Math.min(rows.length, 20);
    const shown = rows.slice(0, fit);
    const font = rows.length > 18 ? .9 : 1;
    const html = shown.map((r) => {
      const live = liveNames.has(r.team.name) || liveNames.has(r.team.short);
      return `<div class="row ${zoneClass(page, r.rank, rows.length)}${live ? " live" : ""}">
        <span class="rank">${esc(r.rank)}</span>${logo(r.team)}<span class="name">${esc(r.team.short || r.team.name)}</span>
        <span class="num">${esc(r.played)}</span><span class="num">${r.diff > 0 ? "+" : ""}${esc(r.diff)}</span><span class="pts">${esc(r.points)}</span>
      </div>`;
    }).join("");
    return `<h2>Tabelle${rows.length > fit ? ` · Top ${fit}` : ""}</h2>
      <div class="rows" style="--row-font:${font}rem">
        <div class="row head"><span>#</span><span></span><span>Verein</span><span class="num">Sp</span><span class="num">TD</span><span class="pts">Pkt</span></div>
        ${html}
      </div>`;
  }

  function render() {
    const pages = (snapshot?.pages || []).filter(Boolean);
    if (!pages.length) {
      ui.leagueName.textContent = "Fußball Live";
      ui.roundName.textContent = snapshot ? "Keine Liga gewählt" : "Ergebnisse werden geladen …";
      ui.matches.className = "matches";
      ui.matches.innerHTML = `<div class="empty">${snapshot ? "In den Einstellungen von Fußball Live ist keine Liga gewählt." : "Einen Moment …"}</div>`;
      ui.table.hidden = true;
      ui.page.classList.remove("with-table");
      return;
    }
    pageIndex %= pages.length;
    const page = pages[pageIndex];
    document.documentElement.style.setProperty("--accent", page.color || "#d20515");
    ui.leagueName.textContent = page.name;
    ui.roundName.textContent = page.round || "";

    const matches = page.matches || [];
    const liveCount = matches.filter((m) => m.state === "live").length;
    if (liveCount) ui.roundName.textContent = `${page.round ? page.round + " · " : ""}${liveCount} ${liveCount === 1 ? "Spiel" : "Spiele"} live`;

    const hasTable = Array.isArray(page.table) && page.table.length > 0;
    const portrait = innerHeight > innerWidth;
    ui.page.classList.toggle("with-table", hasTable);
    const two = matches.length > (hasTable ? (portrait ? 9 : 10) : 10) && !(hasTable && !portrait);
    ui.matches.className = `matches${two ? " two" : ""}${matches.length && matches.length < 6 ? " few" : ""}`;
    if (matches.length) {
      ui.matches.innerHTML = matches.map(matchRow).join("");
      if (two) ui.matches.style.gridTemplateRows = `repeat(${Math.ceil(matches.length / 2)}, minmax(0, 1fr))`;
      else ui.matches.style.gridTemplateRows = "";
    } else {
      ui.matches.style.gridTemplateRows = "";
      ui.matches.innerHTML = `<div class="empty">${esc(page.error ? "Die Ergebnisse sind gerade nicht erreichbar." : "Keine Spiele in den nächsten Tagen.")}</div>`;
    }
    if (hasTable) {
      const liveNames = new Set();
      matches.filter((m) => m.state === "live").forEach((m) => {
        [m.home.name, m.home.short, m.away.name, m.away.short].forEach((n) => liveNames.add(n));
      });
      ui.table.innerHTML = tableHtml(page, liveNames);
    }
    ui.table.hidden = !hasTable;

    ui.dots.innerHTML = pages.length > 1 ? pages.map((_, i) => `<span class="${i === pageIndex ? "on" : ""}"></span>`).join("") : "";
    renderMeta(page);
  }

  function renderMeta(page) {
    const at = page?.updatedAt || snapshot?.at;
    const age = at ? Date.now() / 1000 - at : Infinity;
    const stale = age > 15 * 60 || (page && page.error);
    ui.updated.textContent = at ? `Stand ${timeFmt.format(new Date(at * 1000))}` : "";
    ui.updated.classList.toggle("stale", Boolean(stale));
    const source = page?.source ? `Daten: ${page.source}` : "";
    const note = mode === "direct" ? "Plugin nicht erreichbar – Notbetrieb" : mode === "demo" ? "Beispieldaten" : "";
    ui.foot.innerHTML = `<span>${esc(source)}</span><span class="${note && mode !== "demo" ? "warn" : ""}">${esc(note)}</span>`;
  }

  function tickClock() {
    ui.clock.textContent = timeFmt.format(new Date());
  }

  // --------------------------------------------------------------- rotation

  function schedulePage() {
    clearTimeout(pageTimer);
    const pages = snapshot?.pages || [];
    if (pages.length < 2) return;
    const seconds = Math.max(5, Number(snapshot.pageSeconds) || 20);
    pageTimer = setTimeout(() => {
      ui.page.classList.add("fade");
      setTimeout(() => {
        pageIndex = (pageIndex + 1) % pages.length;
        render();
        ui.page.classList.remove("fade");
        schedulePage();
      }, 450);
    }, seconds * 1000);
  }

  function applySnapshot(data, first) {
    const before = snapshot;
    // Tore seit dem letzten Stand kurz aufleuchten lassen.
    const now = {};
    flash = new Set();
    for (const page of data.pages || []) {
      for (const m of page.matches || []) {
        const score = `${m.scoreHome}:${m.scoreAway}`;
        now[m.id] = score;
        if (!first && m.state === "live" && lastScores[m.id] && lastScores[m.id] !== score) flash.add(m.id);
      }
    }
    lastScores = now;
    snapshot = data;
    if (first) {
      // Bei einer Übernahme wegen eines Tores mit dieser Liga beginnen.
      const focus = data.focus && data.focus.league;
      const index = focus ? (data.pages || []).findIndex((p) => p.id === focus) : -1;
      pageIndex = index >= 0 ? index : (parseInt(params.get("page"), 10) || 0);
    }
    const pageCountChanged = !before || (before.pages || []).length !== (data.pages || []).length ||
      before.pageSeconds !== data.pageSeconds;
    render();
    if (first || pageCountChanged) schedulePage();
  }

  // ------------------------------------------------------------------ loop

  async function poll(first) {
    let data = null;
    if (mode === "demo") {
      data = demoData();
    } else {
      try {
        data = await loadFromPlugin();
        pluginFailures = 0;
        mode = "plugin";
      } catch (_) {
        pluginFailures += 1;
        if (first || pluginFailures >= 3 || mode === "direct") {
          try {
            data = await loadDirect();
            mode = "direct";
          } catch (_) {
            data = null;
          }
        }
      }
    }
    if (data) applySnapshot(data, first || !snapshot);
    else if (snapshot) renderMeta((snapshot.pages || [])[pageIndex]);
    else render();
    ready();
    const wait = mode === "direct" ? FALLBACK_POLL_MS : POLL_MS;
    setTimeout(() => poll(false), wait);
  }

  function start() {
    tickClock();
    setInterval(tickClock, 5000);
    render();
    // Spätestens nach 5 s ist der erste Stand (oder "Einen Moment …") da.
    setTimeout(ready, 5000);
    poll(true);
    window.addEventListener("resize", () => render());
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
