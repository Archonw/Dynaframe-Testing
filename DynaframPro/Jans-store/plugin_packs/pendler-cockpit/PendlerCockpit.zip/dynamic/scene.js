/* Pendler-Cockpit - die Szene.
 *
 * Holt alle 10 Sekunden die Daten des Plugins Pendler-Cockpit und zeigt sie
 * als Karten: Fahrzeit mit dem Auto, Abfahrten an der Haltestelle, Regen in
 * den nächsten zwei Stunden, Spritpreise. Oben Uhrzeit, Wetter und
 * Warnungen, unten die Nachrichten als Laufband. Karten, die nicht
 * eingerichtet sind, fallen weg; die anderen teilen sich den Platz.
 *
 * Uhr, "in 4 Min." und der Losgeh-Hinweis laufen jede Sekunde im Browser
 * weiter, auch wenn das Plugin gerade nichts Neues hat.
 *
 * ?demo=1 zeigt erfundene Daten, ?lang=en.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "PendlerCockpit";
  const POLL_MS = 10000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  // Die Plugin-Seite ist über den Proxy der Weboberfläche erreichbar. Je nach
  // DynaFrame-Version auf :8003 oder direkt auf Port 80; die Szene probiert der
  // Reihe nach und bleibt bei der Adresse, die antwortet.
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  let baseIndex = 0;

  const TEXT = {
    de: {
      toWork: "Zur Arbeit", min: "Min.", traffic: "+{n} Min. Verkehr", free: "frei", via: "über {via}",
      leaveBy: "Losfahren bis {time}", arrive: "für {time}", late: "{time} schon vorbei", alt: "oder {via}: {n} Min.",
      departures: "Abfahrten", walk: "{n} Min. zu Fuß", inMin: "in {n} Min.", now: "jetzt", cancelled: "fällt aus",
      goNow: "Jetzt los!", goIn: "In {n} Min. los", goTo: "zur {line} um {time}", noDep: "Gerade keine Abfahrten.",
      rain: "Regen", dryAll: "Trocken bis {time}", rainFrom: "Regen ab {time}", rainNow: "Es regnet",
      rainUntil: "Es regnet, bis etwa {time}", rainLong: "Es regnet, die nächsten 2 Stunden",
      light: "leicht", moderate: "mäßig", heavy: "stark",
      fuel: "Sprit", avg: "Ø {n} Tage", below: "{n} ct unter Ø", above: "{n} ct über Ø", same: "wie Ø",
      learning: "Durchschnitt nach 2 Tagen", fuelNone: "Gerade keine offene Tankstelle.",
      offline: "Pendler-Cockpit antwortet nicht", waiting: "Lädt …",
      empty: "Noch nichts eingerichtet. Öffne das Pendler-Cockpit auf der Plugins-Seite des Rahmens.",
      stale: "Stand {time}", news: "Nachrichten", until: "bis {time}",
    },
    en: {
      toWork: "To work", min: "min", traffic: "+{n} min traffic", free: "clear", via: "via {via}",
      leaveBy: "Leave by {time}", arrive: "for {time}", late: "{time} already passed", alt: "or {via}: {n} min",
      departures: "Departures", walk: "{n} min walk", inMin: "in {n} min", now: "now", cancelled: "cancelled",
      goNow: "Leave now!", goIn: "Leave in {n} min", goTo: "for the {line} at {time}", noDep: "No departures right now.",
      rain: "Rain", dryAll: "Dry until {time}", rainFrom: "Rain from {time}", rainNow: "Raining",
      rainUntil: "Raining until about {time}", rainLong: "Raining for the next 2 hours",
      light: "light", moderate: "moderate", heavy: "heavy",
      fuel: "Fuel", avg: "{n}-day avg.", below: "{n} ct below avg.", above: "{n} ct above avg.", same: "at average",
      learning: "Average after 2 days", fuelNone: "No station open right now.",
      offline: "Commuter Cockpit is not responding", waiting: "Loading …",
      empty: "Nothing set up yet. Open Pendler-Cockpit on the frame's Plugins page.",
      stale: "As of {time}", news: "News", until: "until {time}",
    },
    es: {
      toWork: "Al trabajo", min: "min", traffic: "+{n} min de tráfico", free: "fluido", via: "por {via}",
      leaveBy: "Sal antes de las {time}", arrive: "para las {time}", late: "las {time} ya pasaron", alt: "o {via}: {n} min",
      departures: "Salidas", walk: "{n} min a pie", inMin: "en {n} min", now: "ahora", cancelled: "cancelado",
      goNow: "¡Sal ya!", goIn: "Sal en {n} min", goTo: "para el {line} de las {time}", noDep: "Ahora no hay salidas.",
      rain: "Lluvia", dryAll: "Seco hasta las {time}", rainFrom: "Lluvia desde las {time}", rainNow: "Está lloviendo",
      rainUntil: "Llueve hasta las {time} aprox.", rainLong: "Llueve las próximas 2 horas",
      light: "débil", moderate: "moderada", heavy: "fuerte",
      fuel: "Combustible", avg: "media {n} días", below: "{n} ct bajo la media", above: "{n} ct sobre la media",
      same: "en la media", learning: "Media tras 2 días", fuelNone: "Ninguna gasolinera abierta ahora.",
      offline: "Pendler-Cockpit no responde", waiting: "Cargando …",
      empty: "Aún no hay nada configurado. Abre Pendler-Cockpit en la página de plugins del marco.",
      stale: "Datos de las {time}", news: "Noticias", until: "hasta las {time}",
    },
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const FUEL_NAMES = { e5: "Super E5", e10: "Super E10", diesel: "Diesel" };

  const el = (id) => document.getElementById(id);
  let lang = params.get("lang") || "de";
  let data = null;
  let reachable = true;
  let failures = 0;
  let readySent = false;
  let tickerKey = "";

  function t(key, values = {}) {
    const text = (TEXT[lang] || TEXT.de)[key] ?? TEXT.de[key] ?? key;
    return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
  }

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  const nowSec = () => Date.now() / 1000;

  function clock(epoch) {
    return new Date(epoch * 1000).toLocaleTimeString(LOCALES[lang] || "de-DE", { hour: "2-digit", minute: "2-digit" });
  }

  function esc(text) {
    return String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  }

  function km(value) {
    return Number(value).toLocaleString(LOCALES[lang] || "de-DE", { maximumFractionDigits: 1 });
  }

  function priceHtml(price) {
    // 1,689 -> 1,68 mit hochgestellter 9, wie an der Zapfsäule.
    const text = price.toFixed(3);
    const main = text.slice(0, -1), last = text.slice(-1);
    return `${esc(lang === "en" ? main : main.replace(".", ","))}<sup>${last}</sup>`;
  }

  // ------------------------------------------------------------ Symbole

  const ICONS = {
    car: '<path d="M5 16V11l2-5h10l2 5v5M5 16h14M5 16v2.5M19 16v2.5M7.5 13.2h.01M16.5 13.2h.01M4 11h16"/>',
    train: '<rect x="6" y="3" width="12" height="14" rx="3"/><path d="M6 10h12M9 20l-1.5 1.5M15 20l1.5 1.5M9 14h.01M15 14h.01"/>',
    bus: '<rect x="5" y="3" width="14" height="15" rx="2"/><path d="M5 11h14M8 18v2.5M16 18v2.5M8.5 14.5h.01M15.5 14.5h.01M5 7h14"/>',
    rain: '<path d="M7 15a4 4 0 0 1-.6-8A5.5 5.5 0 0 1 17 8a3.5 3.5 0 0 1 .5 7z"/><path d="M8 18l-1 2.5M12 18l-1 2.5M16 18l-1 2.5"/>',
    fuel: '<path d="M5 20V5a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v15M4 20h11M5 10h9M14 8l3 2v7a1.5 1.5 0 0 0 3 0V9l-3-3"/>',
    warn: '<path d="M12 3l9.5 17h-19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
    walk: '<circle cx="13" cy="4.5" r="1.6"/><path d="M10 21l2.2-6.5L15 17v4M9 11l2.5-3.5 3 1.5 1.5 3 2.5 1M11.5 7.5L10 14"/>',
    road: '<path d="M8 3L5 21M16 3l3 18M12 4v3M12 10v3M12 16v4"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  };

  function icon(name, cls = "") {
    return `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
      stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
  }

  // Wetter nach den Symbolnamen von Bright Sky.
  function weatherIcon(name) {
    const sun = '<circle cx="12" cy="12" r="4.2" fill="#ffd166" stroke="none"/><path stroke="#ffd166" d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/>';
    const moon = '<path fill="#c9d6ea" stroke="none" d="M15.5 3.5a8.5 8.5 0 1 0 5 13.6A7 7 0 0 1 15.5 3.5z"/>';
    const cloud = (x = 0, y = 0, c = "#c4cfdd") => `<path transform="translate(${x} ${y})" fill="${c}" stroke="none" d="M7 19a4.5 4.5 0 0 1-.7-8.95A6 6 0 0 1 17.8 11 4 4 0 0 1 17.5 19z"/>`;
    const drops = '<path stroke="#6cb6ff" d="M8 20.5l-1 2M12 20.5l-1 2M16 20.5l-1 2"/>';
    const flakes = '<path stroke="#e8f1ff" d="M8 21.5h.01M12 22.5h.01M16 21.5h.01"/>';
    const bolt = '<path fill="#ffd166" stroke="none" d="M12.5 14l-3 5h2.5l-1 4 4-6h-2.5l1.5-3z"/>';
    const parts = {
      "clear-day": sun, "clear-night": moon,
      "partly-cloudy-day": `<g transform="translate(-3 -4) scale(.8)">${sun}</g>${cloud(1.5, 1)}`,
      "partly-cloudy-night": `<g transform="translate(-2 -4) scale(.75)">${moon}</g>${cloud(1.5, 1)}`,
      cloudy: cloud(0, -1), fog: `${cloud(0, -3, "#9aa7b8")}<path stroke="#9aa7b8" d="M4 19.5h16M6 22h12"/>`,
      wind: '<path stroke="#c4cfdd" d="M3 9h11a3 3 0 1 0-3-3M3 13h15a3 3 0 1 1-3 3M3 17h7"/>',
      rain: cloud(0, -3) + drops, sleet: cloud(0, -3) + drops + flakes, snow: cloud(0, -3) + flakes,
      hail: cloud(0, -3) + flakes, thunderstorm: cloud(0, -4, "#9aa7b8") + bolt,
    };
    return `<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" aria-hidden="true">${parts[name] || cloud(0, -1)}</svg>`;
  }

  // ------------------------------------------------------------ Karten

  function renderRoute(view) {
    const card = el("routeCard");
    card.hidden = !view;
    if (!view) return;
    const head = `<h2>${icon("car")}<span>${esc(t("toWork"))}${view.work ? ` · ${esc(view.work)}` : ""}</span></h2>`;
    if (view.seconds == null) {
      card.innerHTML = head + `<p class="msg ${view.error ? "bad" : ""}">${esc(view.error || t("waiting"))}</p>`;
      return;
    }
    const minutes = Math.round(view.seconds / 60);
    const delay = Math.max(0, Math.round((view.seconds - view.normalSeconds) / 60));
    const tone = delay >= 10 ? "bad" : delay >= 3 ? "warn" : "ok";
    let leave = "";
    if (view.leaveBy) {
      const left = view.leaveBy - nowSec();
      leave = left > -300
        ? `<p class="leave ${left < 600 ? "soon" : ""}">${icon("clock")}<em><b>${esc(t("leaveBy", { time: clock(view.leaveBy) }))}</b> <span>${esc(t("arrive", { time: view.arriveBy }))}</span></em></p>`
        : "";
    }
    const alts = (view.alternatives || []).filter((a) => a.via).slice(0, 1)
      .map((a) => `<p class="alt">${esc(t("alt", { via: a.via, n: Math.round(a.seconds / 60) }))}</p>`).join("");
    const events = (view.events || []).map((e) => `<li class="${e.kind}">${icon(e.kind === "closure" ? "warn" : "road")}
      <span><b>${esc(e.title)}</b> ${esc(e.text || e.subtitle)}</span></li>`).join("");
    const old = nowSec() - view.at > 20 * 60 ? `<p class="stale">${esc(t("stale", { time: clock(view.at) }))}</p>` : "";
    card.innerHTML = head + `
      <div class="big"><b>${minutes}</b><span>${esc(t("min"))}</span>
        <em class="chip ${tone}">${esc(delay > 0 ? t("traffic", { n: delay }) : t("free"))}</em></div>
      <p class="sub">${km(view.km)} km${view.via ? ` · ${esc(t("via", { via: view.via }))}` : ""}</p>
      ${leave}${alts}${events ? `<ul class="events">${events}</ul>` : ""}${old}
      <p class="credit">${view.provider === "mapbox" ? "© Mapbox" : "Google Maps"}</p>`;
  }

  function nextToCatch(view) {
    const t0 = nowSec();
    const walk = (view.walk || 0) * 60;
    return (view.rows || []).find((r) => !r.cancelled && r.when - t0 >= walk - 20) || null;
  }

  function renderTransit(view) {
    const card = el("transitCard");
    card.hidden = !view;
    if (!view) return;
    const kindIcon = (view.rows || []).every((r) => r.kind === "bus") && view.rows.length ? "bus" : "train";
    const head = `<h2>${icon(kindIcon)}<span>${esc(view.stop)}</span>${view.walk ? `<small>${icon("walk")}${esc(t("walk", { n: view.walk }))}</small>` : ""}</h2>`;
    if (!view.rows || !view.rows.length) {
      card.innerHTML = head + `<p class="msg ${view.error ? "bad" : ""}">${esc(view.error || (view.at ? t("noDep") : t("waiting")))}</p>`;
      return;
    }
    const t0 = nowSec();
    const catchIt = nextToCatch(view);
    let hint = "";
    if (catchIt) {
      const left = Math.floor((catchIt.when - t0 - (view.walk || 0) * 60) / 60);
      hint = `<p class="go ${left <= 1 ? "now" : left <= 5 ? "soon" : ""}"><b>${esc(left <= 0 ? t("goNow") : t("goIn", { n: left }))}</b>
        <span>${esc(t("goTo", { line: catchIt.line, time: clock(catchIt.when) }))}</span></p>`;
    }
    const rows = view.rows.slice(0, 7).map((r) => {
      const mins = Math.round((r.when - t0) / 60);
      const away = r.cancelled ? t("cancelled") : mins <= 0 ? t("now") : t("inMin", { n: mins });
      const delay = r.delayMin ? `<i class="${r.delayMin >= 5 ? "bad" : "warn"}">+${r.delayMin}</i>` : "";
      return `<li class="${r.cancelled ? "cancelled" : ""} ${r === catchIt ? "catch" : ""}">
        <span class="line ${esc(r.kind)}">${esc(r.line)}</span>
        <span class="dir">${esc(r.direction)}${r.remarks && r.remarks.length && !r.cancelled ? `<small>${esc(r.remarks[0])}</small>` : ""}</span>
        <span class="when"><span><b>${clock(r.planned)}</b>${delay}</span><small>${esc(away)}</small></span></li>`;
    }).join("");
    card.innerHTML = head + hint + `<ul class="deps">${rows}</ul>`;
  }

  function intensity(mmh) {
    return mmh >= 7.5 ? t("heavy") : mmh >= 2.5 ? t("moderate") : t("light");
  }

  function renderRain(view) {
    const card = el("rainCard");
    card.hidden = !view;
    if (!view) return;
    const head = `<h2>${icon("rain")}<span>${esc(t("rain"))}</span></h2>`;
    const frames = (view.frames || []).filter((f) => f.at >= nowSec() - 300);
    if (!frames.length) {
      card.innerHTML = head + `<p class="msg">${esc(t("waiting"))}</p>`;
      return;
    }
    const s = view.summary || {};
    const last = frames[frames.length - 1].at;
    let line;
    if (s.now) line = s.endAt ? t("rainUntil", { time: clock(s.endAt) }) : t("rainLong");
    else line = s.startAt ? t("rainFrom", { time: clock(s.startAt) }) : t("dryAll", { time: clock(last) });
    const wet = s.now || s.startAt;
    const top = Math.max(2.5, ...frames.map((f) => f.mmh));
    const bars = frames.map((f) => {
      const h = f.mmh > 0 ? Math.max(6, Math.sqrt(f.mmh / top) * 100) : 2;
      const cls = f.mmh >= 7.5 ? "heavy" : f.mmh >= 2.5 ? "mid" : f.mmh >= 0.2 ? "light" : "dry";
      return `<i class="${cls}" style="height:${h.toFixed(0)}%"></i>`;
    }).join("");
    const first = frames[0].at;
    card.innerHTML = head + `
      <p class="rainline ${wet ? "wet" : "dry"}"><b>${esc(line)}</b>${wet ? ` <span>${esc(intensity(s.maxMmh || 0))}</span>` : ""}</p>
      <div class="bars">${bars}</div>
      <div class="axis"><span>${clock(first)}</span><span>${clock(first + 3600)}</span><span>${clock(last)}</span></div>`;
  }

  function sparkline(daily) {
    if (!daily || daily.length < 2) return "";
    const prices = daily.map((d) => d.price);
    const lo = Math.min(...prices), hi = Math.max(...prices);
    const span = Math.max(0.01, hi - lo);
    const pts = prices.map((p, i) => `${(i / (prices.length - 1) * 100).toFixed(1)},${(26 - (p - lo) / span * 22).toFixed(1)}`);
    return `<svg class="spark" viewBox="0 0 100 30" preserveAspectRatio="none"><polyline points="${pts.join(" ")}"/></svg>`;
  }

  function renderFuel(view) {
    const card = el("fuelCard");
    card.hidden = !view;
    if (!view) return;
    const head = `<h2>${icon("fuel")}<span>${esc(FUEL_NAMES[view.fuel] || t("fuel"))}</span></h2>`;
    const credit = '<p class="credit">tankerkoenig.de · CC BY 4.0</p>';
    if (!view.best || !view.best.length) {
      card.innerHTML = head + `<p class="msg ${view.error ? "bad" : ""}">${esc(view.error || (view.at ? t("fuelNone") : t("waiting")))}</p>` + credit;
      return;
    }
    const best = view.best[0];
    let compare = `<span class="muted">${esc(t("learning"))}</span>`;
    let tone = "";
    if (view.average) {
      const diff = Math.round((view.average - best.price) * 100);
      tone = diff >= 3 ? "ok" : diff <= -3 ? "bad" : "";
      compare = `<em class="chip ${tone || "plain"}">${esc(diff > 0 ? t("below", { n: diff }) : diff < 0 ? t("above", { n: -diff }) : t("same"))}</em>
        <span class="muted">${esc(t("avg", { n: view.avgDays }))} ${priceHtml(view.average)}</span>`;
    }
    const cheapNow = view.below && best.price <= view.below;
    const others = view.best.slice(1, 3).map((s) => `<li><span>${esc(s.brand)} <small>${esc(s.place)} · ${km(s.km)} km</small></span><b>${priceHtml(s.price)}</b></li>`).join("");
    card.innerHTML = head + `
      <div class="big price ${cheapNow ? "hit" : ""}"><b>${priceHtml(best.price)}</b><span>€</span></div>
      <p class="sub">${esc(best.brand)} · ${esc(best.place)} · ${km(best.km)} km</p>
      <p class="compare">${compare}</p>
      ${sparkline(view.daily)}
      ${others ? `<ul class="stations">${others}</ul>` : ""}${credit}`;
  }

  function renderBanners(d) {
    const box = el("banners");
    const rows = [];
    const focus = (d.alerts || []).find((a) => a.id === d.focus);
    if (focus && focus.kind !== "warning") {
      rows.push(`<div class="banner ${focus.kind} lvl${focus.level}">${icon(focus.kind === "fuel" ? "fuel" : focus.kind === "transit" ? "train" : focus.kind === "leave" ? "clock" : "warn")}
        <p><b>${esc(focus.title)}</b>${focus.text ? ` <span>${esc(focus.text)}</span>` : ""}</p></div>`);
    }
    for (const w of d.warnings || []) {
      rows.push(`<div class="banner warning lvl${w.level}">${icon("warn")}<p><b>${esc(w.title || w.event)}</b>
        ${w.until ? `<span>${esc(t("until", { time: clock(w.until) }))} · ${esc(w.source)}</span>` : `<span>${esc(w.source)}</span>`}</p></div>`);
    }
    box.innerHTML = rows.slice(0, 3).join("");
    box.hidden = !rows.length;
  }

  function renderTicker(items) {
    const box = el("ticker");
    const key = (items || []).join("|");
    box.hidden = !items || !items.length;
    if (key === tickerKey) return;
    tickerKey = key;
    if (!items || !items.length) return;
    const tape = el("tape");
    const html = items.map((i) => `<span>${esc(i)}</span>`).join('<i class="sep">•</i>');
    // Zweimal hintereinander, damit das Band ohne Lücke umläuft.
    tape.innerHTML = `<div class="run">${html}<i class="sep">•</i></div><div class="run" aria-hidden="true">${html}<i class="sep">•</i></div>`;
    requestAnimationFrame(() => {
      const width = tape.firstElementChild.getBoundingClientRect().width;
      const speed = Math.max(60, window.innerWidth / 14);  // Pixel pro Sekunde
      tape.style.setProperty("--dur", `${(width / speed).toFixed(1)}s`);
      tape.style.setProperty("--shift", `-${width.toFixed(0)}px`);
      tape.classList.remove("rolling");
      void tape.offsetWidth;
      tape.classList.add("rolling");
    });
  }

  function layout() {
    const names = ["route", "transit", "rain", "fuel"].filter((n) => !el(`${n}Card`).hidden);
    const stage = el("stage");
    const grid = el("cards");
    stage.dataset.cards = String(names.length);
    el("empty").hidden = names.length > 0 || !data;
    el("empty").textContent = reachable ? t("empty") : t("offline");
    for (const n of ["route", "transit", "rain", "fuel"]) el(`${n}Card`).style.gridArea = n;
    const others = names.filter((n) => n !== "transit");
    const hasTransit = names.includes("transit");
    let areas, cols, rows;
    if (window.innerHeight > window.innerWidth) {
      // Hochformat: Auto und Abfahrten über die ganze Breite, Regen und Sprit nebeneinander.
      const lines = [];
      if (names.includes("route")) lines.push(["route route", "auto"]);
      if (hasTransit) lines.push(["transit transit", "minmax(0, 1.3fr)"]);
      const pair = ["rain", "fuel"].filter((n) => names.includes(n));
      if (pair.length === 2) lines.push(["rain fuel", "minmax(0, 1fr)"]);
      else if (pair.length === 1) lines.push([`${pair[0]} ${pair[0]}`, "minmax(0, 1fr)"]);
      if (!hasTransit && lines.length) lines[lines.length - 1][1] = "minmax(0, 1fr)";
      areas = lines.map((l) => `"${l[0]}"`).join(" ");
      rows = lines.map((l) => l[1]).join(" ");
      cols = "1fr 1fr";
    } else if (hasTransit && others.length >= 2) {
      // Querformat: die Abfahrtsliste braucht Höhe und bekommt eine ganze Spalte.
      // Mit allen vier: das Auto links über beide Zeilen, Sprit und Regen rechts übereinander.
      const [a, b, c] = others;
      areas = c ? `"route transit fuel" "route transit rain"` : `"${a} transit" "${b} transit"`;
      cols = c ? "1fr 1.2fr 1fr" : "1fr 1.15fr";
      rows = c ? "minmax(0, 1.25fr) minmax(0, 1fr)" : "minmax(0, 1fr) minmax(0, 1fr)";
    } else {
      areas = `"${names.join(" ")}"`;
      cols = names.map(() => "1fr").join(" ") || "1fr";
      rows = "minmax(0, 1fr)";
    }
    grid.style.gridTemplateAreas = names.length ? areas : "";
    grid.style.gridTemplateColumns = cols;
    grid.style.gridTemplateRows = rows;
    for (const n of names) trim(el(`${n}Card`));
  }

  // Was nicht mehr ganz in die Karte passt, fällt von unten her weg, statt
  // halb abgeschnitten zu werden. Die Abfahrtsliste kürzt sich zeilenweise.
  function trim(card) {
    const fits = () => card.scrollHeight <= card.clientHeight + 1;
    card.classList.remove("tight");
    if (!fits()) card.classList.add("tight");
    const list = card.querySelector(".deps");
    while (list && !fits() && list.children.length > 1) list.lastElementChild.remove();
    const parts = [...card.children].filter((c) => c.tagName !== "H2" && !c.classList.contains("credit")
      && !c.classList.contains("big") && !c.classList.contains("deps"));
    // Die Ausweichroute ist am ehesten verzichtbar, dann geht es von unten nach oben.
    // Die erste Zeile unter der großen Zahl ist die Kernaussage; sie bleibt immer.
    for (const alt of card.querySelectorAll(":scope > .alt")) if (!fits()) alt.remove();
    const rest = parts.filter((c) => c.isConnected);
    for (let i = rest.length - 1; i >= 1 && !fits(); i--) rest[i].remove();
  }

  function renderClock() {
    const date = new Date();
    el("clock").textContent = date.toLocaleTimeString(LOCALES[lang] || "de-DE", { hour: "2-digit", minute: "2-digit" });
    el("date").textContent = date.toLocaleDateString(LOCALES[lang] || "de-DE", { weekday: "long", day: "numeric", month: "long" });
  }

  function render() {
    renderClock();
    if (!data) {
      el("empty").hidden = false;
      el("empty").textContent = reachable ? t("waiting") : t("offline");
      return;
    }
    document.documentElement.lang = lang;
    const weather = data.rain && data.rain.weather;
    el("weather").hidden = !(weather && weather.temp != null);
    if (weather && weather.temp != null) {
      el("wicon").innerHTML = weatherIcon(weather.icon);
      el("temp").textContent = `${Math.round(weather.temp)}°`;
    }
    renderBanners(data);
    renderRoute(data.route);
    renderTransit(data.transit);
    renderRain(data.rain);
    renderFuel(data.fuel);
    renderTicker(data.news);
    layout();
    el("stage").classList.toggle("offline", !reachable);
  }

  function apply(payload) {
    data = payload;
    if (payload.lang && TEXT[payload.lang]) lang = payload.lang;
    render();
    ready();
  }

  async function poll() {
    if (DEMO) return;
    const url = new URL("api/scene", pluginBases[baseIndex]);
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 12000);
    try {
      const response = await fetch(url, { cache: "no-store", signal: abort.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      failures = 0;
      reachable = true;
      apply(await response.json());
    } catch (_) {
      failures += 1;
      baseIndex = (baseIndex + 1) % pluginBases.length;
      if (failures >= 2 * pluginBases.length) {
        reachable = false;
        render();
        ready();
      } else {
        setTimeout(poll, 1500);  // gleich die nächste Adresse probieren
      }
    } finally {
      clearTimeout(timer);
    }
  }

  // ------------------------------------------------------------ Demo

  function demo() {
    const n = nowSec();
    const at = (m) => n + m * 60;
    const frames = [];
    for (let i = -1; i < 25; i++) {
      const m = i * 5;
      const mmh = m < 35 ? 0 : m < 80 ? +(Math.sin((m - 35) / 45 * Math.PI) * 3.2).toFixed(2) : 0;
      frames.push({ at: Math.floor(n / 300) * 300 + m * 60, mmh });
    }
    const dep = (line, kind, dir, mins, delay = 0, extra = {}) => ({
      line, kind, direction: dir, planned: Math.floor(at(mins) / 60) * 60, when: Math.floor(at(mins) / 60) * 60 + delay * 60,
      delayMin: delay || null, cancelled: false, platform: "", remarks: [], ...extra });
    const daily = [1.739, 1.729, 1.749, 1.719, 1.709, 1.729, 1.699, 1.719, 1.709, 1.689, 1.699, 1.679, 1.689, 1.669]
      .map((price, i) => ({ day: `d${i}`, price }));
    apply({
      at: n, lang, commute: "active", window: "06:00–09:00",
      route: { at: n - 60, seconds: 34 * 60, normalSeconds: 26 * 60, km: 27.4, via: "A5", work: "Eschborn",
        arriveBy: "08:00", leaveBy: null, alternatives: [{ seconds: 38 * 60, via: "B8" }],
        events: [{ kind: "warning", title: "A5 | Frankfurt → Basel", subtitle: "Stau zwischen Nordwestkreuz und Westkreuz", blocked: false }] },
      transit: { at: n - 20, stop: "Bad Homburg Bahnhof", walk: 6, rows: [
        dep("S5", "sbahn", "Frankfurt Süd", 4), dep("S5", "sbahn", "Frankfurt Süd", 9, 3),
        dep("RB15", "train", "Frankfurt Hbf", 13), dep("261", "bus", "Oberursel Bf", 15),
        dep("S5", "sbahn", "Frankfurt Süd", 24, 0, { cancelled: true }), dep("U2", "ubahn", "Südbahnhof", 27),
        dep("S5", "sbahn", "Frankfurt Süd", 39)] },
      rain: { at: n - 120, frames, summary: { now: false, startAt: frames.find((f) => f.mmh >= 0.2).at, endAt: null, maxMmh: 3.2 },
        weather: { temp: 11.4, icon: "partly-cloudy-day" } },
      fuel: { at: n - 300, fuel: "e10", average: 1.712, avgDays: 7, daysKnown: 9, daily, below: 1.69,
        best: [{ brand: "JET", place: "Frankfurter Landstr. 120", km: 1.8, price: 1.669 },
          { brand: "ARAL", place: "Bad Homburg", km: 2.4, price: 1.689 }, { brand: "Shell", place: "Oberursel", km: 3.9, price: 1.699 }] },
      warnings: params.has("warn") ? [{ source: "DWD", level: 3, title: "Amtliche Unwetterwarnung vor Sturmböen", event: "Sturmböen", until: at(180) }] : [],
      news: ["Bundestag beschließt Haushalt für das kommende Jahr", "Bahn kündigt neue Verbindungen im Rhein-Main-Gebiet an",
        "Spritpreise sinken zum dritten Mal in Folge", "DFB-Pokal: Eintracht zieht ins Achtelfinale ein",
        "Wetter: Am Wochenende wird es stürmisch"],
      alerts: params.has("alert") ? [{ id: 1, kind: "traffic", title: "Stau auf dem Weg zur Arbeit", text: "34 Min. statt 26 Min.", level: 2, at: n }] : [],
      focus: params.has("alert") ? 1 : null,
    });
  }

  // ------------------------------------------------------------ Start

  window.addEventListener("resize", () => { tickerKey = ""; render(); });
  render();
  if (DEMO) demo();
  else {
    poll();
    setInterval(poll, POLL_MS);
  }
  setInterval(render, 1000);
  // Auch ohne Antwort nicht ewig auf dem Ladebild hängen.
  setTimeout(ready, 4000);
})();
