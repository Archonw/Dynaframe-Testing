# Pendler-Cockpit

Das Pendler-Cockpit zeigt morgens alles für den Weg zur Arbeit auf einem Bildschirm:

- **Fahrzeit mit dem Auto** jetzt und ohne Verkehr, mit Strecke, Alternative und Meldungen der Autobahn GmbH auf dem Weg. Mit „Ankunft um“ auch, bis wann du losfahren musst.
- **Abfahrten** an deiner Bus- oder Bahnhaltestelle mit Verspätungen und Ausfällen, dazu „In 4 Min. los“ mit deinem Fußweg eingerechnet.
- **Regen** in den nächsten zwei Stunden aus dem Regenradar des Deutschen Wetterdienstes, dazu die Temperatur.
- **Spritpreise** für die Sorten, die du brauchst (Super E5, Super E10, Diesel), an allen Tankstellen im Umkreis oder nur an denen, die du anhakst, mit dem Vergleich zum Durchschnitt der letzten Tage. Autogas (LPG) gibt es nicht: Die Markttransparenzstelle, von der Tankerkönig die Preise hat, erfasst nur Benzin und Diesel.
- **Warnungen** von DWD und NINA für deinen Wohnort.
- **Nachrichten** als Laufband (tagesschau.de oder ein eigener RSS-Feed).

Was du nicht einrichtest, fällt weg; die übrigen Karten teilen sich den Platz. Die Szene passt sich Quer- und Hochformat an. Sprache: Deutsch, Englisch oder Spanisch.

## Wann es auf den Bildschirm kommt

- **Im Pendel-Zeitfenster** (Standard: Mo–Fr 6:00–9:00) alle paar Minuten kurz, die ganze Zeit, nur bei Hinweisen oder nie von selbst.
- **Bei Hinweisen:** Stau ab einer einstellbaren Verspätung, Ausfall oder Verspätung deiner Linie, Sprit unter einem Preis oder deutlich unter dem Durchschnitt, Unwetter, „Zeit zum Losfahren“.
- **In einer Playlist** wie jede andere Szene; die Plugin-Seite legt dafür auf Knopfdruck die Playlist „Pendler-Cockpit“ an.

Ein ausgeschalteter Bildschirm wird nie geweckt.

## Einrichten

1. Paket installieren (über den Store oder Plugins > Hochladen).
2. Auf der Plugins-Seite bei Pendler-Cockpit **Allow takeover** einschalten.
3. **Open Pendler-Cockpit** öffnen und den **Wohnort** suchen lassen. Die nächste Haltestelle wird gleich eingetragen.
4. Optional: Adresse der Arbeit und für die Fahrzeit einen **Google-Schlüssel** oder einen **Mapbox-Token** eintragen. Mapbox geht ohne Zahlungsart (so macht es auch MMM-Traffic für den MagicMirror); Google ist in Deutschland meist etwas genauer. Stehen beide da, nimmt das Plugin Google. Die Plugin-Seite erklärt für beide Schritt für Schritt, wie man den Schlüssel bekommt.
5. Optional: einen kostenlosen **Tankerkönig-Schlüssel** von [onboarding.tankerkoenig.de](https://onboarding.tankerkoenig.de/) für die Spritpreise.
6. Mit **Jetzt anzeigen** ausprobieren.

Findet die Plugin-Seite in der Nähe keine Haltestelle, kannst du sie darunter nach Namen suchen.

Adressen und Schlüssel bleiben auf dem Rahmen.

## Kosten und Abfragen

- **Mapbox:** Ohne Zahlungsart sind 10.000 Fahrzeit-Abfragen im Monat frei, mit Zahlungsart 100.000. Werktags 6–9 Uhr alle 5 Minuten sind rund 800. Die Adresse der Arbeit wird dafür einmal bei OpenStreetMap nachgeschlagen.
- **Fahrzeit außerhalb des Zeitfensters:** nur, solange die Szene zu sehen ist, höchstens alle 10 Minuten.
- **Google:** Die Fahrzeit mit Verkehr zählt bei Google als „Compute Routes Pro“. Das Plugin fragt nur im Pendel-Zeitfenster, Standard alle 5 Minuten; werktags 6–9 Uhr sind das rund 800 Abfragen im Monat und damit im kostenlosen Monatskontingent. Google verlangt trotzdem eine hinterlegte Zahlungsart. Wer sicher gehen will, setzt in der Cloud Console ein Tageskontingent.
- **Tankerkönig:** alle 10 Minuten zu krummen Zeiten, wie Tankerkönig es für Heimautomation erbittet; tagsüber in den eingestellten Hinweis-Stunden.
- **Abfahrten:** jede Minute, solange die Szene zu sehen ist, sonst im Zeitfenster alle 2 Minuten.
- **Regen, Wetter, Warnungen, Nachrichten:** alle 5 bis 15 Minuten in den Hinweis-Stunden.

## Wenn etwas nicht stimmt

Die Plugin-Seite zeigt unter *Datenquellen* für jede Quelle, wann sie zuletzt geholt wurde und was schiefging.

- **Es kommt nichts auf den Bildschirm.** Ist *Allow takeover* an? Liegt die Uhrzeit im Zeitfenster und ist der Wochentag angehakt?
- **„Die Routes API ist für diesen Schlüssel nicht aktiviert“** oder **„verlangt eine Zahlungsart“:** in der Google Cloud Console nachholen; es wirkt nach ein paar Minuten.
- **Abfahrten fehlen.** Die Abfahrten kommen von [Transitous](https://transitous.org), einem offenen, nicht kommerziellen Fahrplandienst mit den Echtzeitdaten der Verkehrsverbünde, bei einer Störung von v6.db.transport.rest. Wer von einer älteren Version kommt, wählt die Haltestelle einmal neu aus. Fallen beide Dienste aus, geht es meist nach kurzer Zeit von selbst weiter. Für Fortgeschrittene lässt sich eine eigene transport.rest-Instanz eintragen.
- **Downloads beim Installieren schlagen fehl.** Ein Werbeblocker im Netz (z. B. Pi-hole) muss `files.pythonhosted.org` erlauben.

Die Playlist **Pendler-Cockpit (takeover)** benutzt das Plugin selbst. Lass sie ausgeschaltet; wird sie gelöscht, legt das Plugin sie neu an.

## Datenquellen

Google Maps (Routes API) oder Mapbox (Directions API), [Transitous](https://transitous.org) (Fahrplandaten der Verkehrsverbünde, [Quellen](https://transitous.org/sources/), © OpenStreetMap-Mitwirkende; Ersatz [transport.rest](https://v6.db.transport.rest)), [Tankerkönig](https://www.tankerkoenig.de) (Daten der MTS-K, CC BY 4.0), Deutscher Wetterdienst über [Bright Sky](https://brightsky.dev), [NINA](https://warnung.bund.de) (BBK), [Autobahn GmbH](https://autobahn.api.bund.dev), tagesschau.de, OpenStreetMap (Nominatim).
