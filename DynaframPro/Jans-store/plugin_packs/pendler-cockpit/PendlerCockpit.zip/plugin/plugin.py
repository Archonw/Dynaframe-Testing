#!/usr/bin/env python3
"""Pendler-Cockpit - der Plugin-Teil des Pakets.

Alles für den Weg zur Arbeit auf einem Bildschirm: die Fahrzeit mit dem Auto
jetzt und normal (Google Routes API oder Mapbox, eigener Schlüssel), die nächsten
Abfahrten an der Haltestelle (DB, ohne Schlüssel), Regen in den nächsten zwei
Stunden (Regenradar des DWD), Warnungen von DWD und NINA, Spritpreise in der
Nähe (Tankerkönig, freier Schlüssel) und die Nachrichten als Laufband.

Gefragt wird nur, wenn es etwas nützt: Fahrzeit und Abfahrten im
Pendel-Zeitfenster (z. B. werktags 6 bis 9 Uhr) oder solange die Szene zu
sehen ist; Sprit, Wetter, Warnungen und Nachrichten tagsüber.

Die Szene kommt auf drei Wegen auf den Bildschirm: regelmäßig im Zeitfenster
(alle paar Minuten oder durchgehend), bei einem Hinweis (Stau, Ausfall, Sprit
billig, Unwetter, Zeit zum Losfahren) oder als normaler Playlist-Eintrag.

Die Szene erreicht die Seite dieses Plugins über den Proxy der Weboberfläche
(:8003 oder Port 80), wie Weltkarte Live.
"""

import json
import os
import random
import re
import sys
import threading
import time
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import sources  # noqa: E402
import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "PendlerCockpit"
DISPLAY_NAME = "Pendler-Cockpit"
SCENE_ID = "pendler-cockpit"       # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen und Zustand; bleibt bei Updates

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip().replace(",", ".")))
    except (TypeError, ValueError):
        return default


def as_float(value, default=None):
    try:
        return float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält die Schlüssel
        except OSError:
            pass


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

HHMM = re.compile(r"^\s*(\d{1,2})[:.](\d{2})\s*$")

SETTINGS = {
    "Language":        {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
    # Wohnort: Grundlage für Haltestelle, Tankstellen, Regen und Warnungen.
    "Home":            {"kind": "text", "default": ""},
    "HomeLat":         {"kind": "float", "default": None},
    "HomeLon":         {"kind": "float", "default": None},
    "HomeName":        {"kind": "text", "default": ""},
    # Mit dem Auto zur Arbeit: Google Routes API oder Mapbox, je nachdem,
    # welcher Schlüssel eingetragen ist (beide: Google).
    "Work":            {"kind": "text", "default": ""},
    "WorkLat":         {"kind": "float", "default": None},
    "WorkLon":         {"kind": "float", "default": None},
    "WorkGeo":         {"kind": "text", "default": ""},   # die Adresse, zu der WorkLat/Lon gehören
    "GoogleKey":       {"kind": "secret", "default": ""},
    "MapboxKey":       {"kind": "secret", "default": ""},
    "AvoidTolls":      {"kind": "bool", "default": False},
    "ArriveBy":        {"kind": "hhmm", "default": ""},
    "RouteMinutes":    {"kind": "number", "default": 5, "min": 3, "max": 30},
    "TrafficAlertMinutes": {"kind": "number", "default": 10, "min": 0, "max": 120},
    "LeaveReminderMinutes": {"kind": "number", "default": 0, "min": 0, "max": 30},
    # Bus und Bahn.
    "StopId":          {"kind": "text", "default": ""},
    "StopName":        {"kind": "text", "default": ""},
    "WalkMinutes":     {"kind": "number", "default": 5, "min": 0, "max": 60},
    "Lines":           {"kind": "list", "default": []},
    "Directions":      {"kind": "text", "default": ""},
    "TransitAlert":    {"kind": "bool", "default": True},
    "TransitDelayMinutes": {"kind": "number", "default": 10, "min": 2, "max": 120},
    "TransportUrl":    {"kind": "text", "default": ""},
    # Sprit (Tankerkönig).
    "TankerKey":       {"kind": "secret", "default": ""},
    "Fuel":            {"kind": "choice", "default": "e10", "options": list(sources.FUELS)},  # bis 0.2.0
    "Fuels":           {"kind": "fuels", "default": []},      # leer: wie "Fuel"
    "FuelStations":    {"kind": "ids", "default": []},        # leer: alle im Umkreis
    "FuelRadius":      {"kind": "number", "default": 5, "min": 1, "max": 25},
    "FuelBelow":       {"kind": "price", "default": 0.0},     # bis 0.2.0, für "Fuel"
    "FuelBelowE5":     {"kind": "price", "default": 0.0},
    "FuelBelowE10":    {"kind": "price", "default": 0.0},
    "FuelBelowDiesel": {"kind": "price", "default": 0.0},
    "FuelAvgDays":     {"kind": "number", "default": 7, "min": 2, "max": 30},
    "FuelAvgCents":    {"kind": "number", "default": 0, "min": 0, "max": 50},
    # Termine aus einem oder mehreren Kalendern (ICS, z. B. Nextcloud).
    "CalendarUrls":    {"kind": "urls", "default": []},
    "CalendarUser":    {"kind": "text", "default": ""},
    "CalendarPassword": {"kind": "secret", "default": ""},
    "CalendarDays":    {"kind": "number", "default": 3, "min": 1, "max": 31},
    "CalendarCount":   {"kind": "number", "default": 5, "min": 1, "max": 12},
    # Wetter, Regen, Warnungen, Nachrichten.
    "Rain":            {"kind": "bool", "default": True},
    "Warnings":        {"kind": "bool", "default": True},
    "WarnAlertLevel":  {"kind": "number", "default": 3, "min": 0, "max": 4},
    "News":            {"kind": "choice", "default": "tagesschau",
                        "options": ["tagesschau", "bbc", "elpais", "custom", "off"]},
    "NewsUrl":         {"kind": "text", "default": ""},
    # Das Pendel-Zeitfenster und wie die Szene darin auf den Bildschirm kommt.
    "Days":            {"kind": "days", "default": [0, 1, 2, 3, 4]},
    "From":            {"kind": "hhmm", "default": "06:00"},
    "To":              {"kind": "hhmm", "default": "09:00"},
    "ShowMode":        {"kind": "choice", "default": "every", "options": ["every", "always", "alerts", "off"]},
    "EveryMinutes":    {"kind": "number", "default": 10, "min": 2, "max": 120},
    "ShowForSeconds":  {"kind": "number", "default": 60, "min": 10, "max": 1800},
    # Hinweise.
    "AlertSeconds":    {"kind": "number", "default": 60, "min": 10, "max": 600},
    "AlertFrom":       {"kind": "number", "default": 6, "min": 0, "max": 23},
    "AlertTo":         {"kind": "number", "default": 22, "min": 1, "max": 24},
}

SECRETS = [name for name, spec in SETTINGS.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
FUEL_FILE = DATA_DIR / "fuel_history.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "float":
        return as_float(raw, None)
    if kind == "price":
        value = as_float(raw, 0.0) or 0.0
        return round(value, 3) if 0.5 <= value <= 5 else 0.0
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "secret":
        return re.sub(r"\s+", "", str(raw))[:200]
    if kind == "hhmm":
        match = HHMM.match(str(raw))
        if not match or int(match.group(1)) > 23 or int(match.group(2)) > 59:
            return "" if name == "ArriveBy" else default
        return f"{int(match.group(1)):02d}:{match.group(2)}"
    if kind == "days":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        return sorted({d for d in (as_int(i, -1) for i in items) if 0 <= d <= 6})
    if kind == "list":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        return sorted({str(i).strip()[:12] for i in items if str(i).strip()})[:30]
    if kind == "fuels":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        chosen = {str(i).strip().lower() for i in items}
        fuels = [f for f in sources.FUELS if f in chosen]
        return fuels or (["none"] if "none" in chosen else [])  # "none": bewusst keine Sorte
    if kind == "urls":
        items = raw if isinstance(raw, list) else re.split(r"[\s,]+", str(raw))
        urls = [str(i).strip()[:500] for i in items if re.match(r"^(https?|webcal)://", str(i).strip())]
        return list(dict.fromkeys(urls))[:5]
    if kind == "ids":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        return sorted({str(i).strip()[:64] for i in items if str(i).strip()})[:30]
    return str(raw).strip()[:300]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


def minutes_of(hhmm):
    match = HHMM.match(hhmm or "")
    return int(match.group(1)) * 60 + int(match.group(2)) if match else None


def has_home(values):
    return values["HomeLat"] is not None and values["HomeLon"] is not None


def route_provider(values):
    """Wer die Fahrzeit liefert: "google", "mapbox" oder "" (keiner)."""
    if values["GoogleKey"]:
        return "google"
    if values["MapboxKey"]:
        return "mapbox"
    return ""


def route_ready(values):
    if not (values["Home"] and values["Work"]):
        return False
    provider = route_provider(values)
    return provider == "google" or (provider == "mapbox" and has_home(values))


def work_coords(values):
    """Mapbox braucht Koordinaten; die Adresse der Arbeit wird einmal bei
    OpenStreetMap nachgeschlagen und gemerkt, bis sie sich ändert."""
    work = values["Work"].strip()
    if values["WorkGeo"] == work and values["WorkLat"] is not None and values["WorkLon"] is not None:
        return values["WorkLat"], values["WorkLon"]
    try:
        found = sources.geocode(work, values["Language"])
    except sources.SourceError as exc:
        if exc.code in ("not-found", "no-address"):
            raise sources.SourceError("work-not-found") from exc
        raise
    save_settings({"WorkLat": found["lat"], "WorkLon": found["lon"], "WorkGeo": work})
    return found["lat"], found["lon"]


def transit(values, motis_call, rest_call):
    """Haltestellen: zuerst Transitous, sonst v6.db.transport.rest.
    Mit einer eigenen Adresse unter "Für Fortgeschrittene" nur diese."""
    custom = values["TransportUrl"].strip().rstrip("/")
    if custom.startswith(("http://", "https://")):
        return rest_call(custom)
    try:
        return motis_call()
    except sources.SourceError as first:
        try:
            return rest_call(sources.TRANSPORT_URL)
        except sources.SourceError as second:
            plugin.log(f"Haltestellen: Transitous {first}; transport.rest {second}", level="warning")
            raise first from second


def db_stop_id(stop):
    """Nummern wie 8000001 stammen von der DB (transport.rest); Transitous-Kennungen sehen anders aus."""
    return str(stop or "").strip().isdigit()


def departures_of(values, stop):
    custom = values["TransportUrl"].strip().rstrip("/")
    if custom.startswith(("http://", "https://")):
        return sources.departures(stop, custom)
    if not db_stop_id(stop):
        return sources.transitous_departures(stop, values["Language"])
    # Haltestelle aus einer älteren Version: geht nur, solange transport.rest antwortet.
    try:
        return sources.departures(stop, sources.TRANSPORT_URL)
    except sources.SourceError as exc:
        raise sources.SourceError("old-stop", str(exc)) from exc


def transport_base(values):
    url = values["TransportUrl"].strip().rstrip("/")
    return url if url.startswith(("http://", "https://")) else sources.TRANSPORT_URL


# --------------------------------------------------------------------------
# Wann ist Pendelzeit?
# --------------------------------------------------------------------------

def commute_state(values, moment=None):
    """"active" im Zeitfenster, "soon" bis 15 Minuten davor, sonst "off"."""
    moment = moment or datetime.now()
    start, end = minutes_of(values["From"]), minutes_of(values["To"])
    if start is None or end is None or start == end or moment.weekday() not in values["Days"]:
        return "off"
    minute = moment.hour * 60 + moment.minute
    if start < end:
        if start <= minute < end:
            return "active"
        if start - 15 <= minute < start:
            return "soon"
        return "off"
    # Über Mitternacht (Nachtschicht), z. B. 21:00 bis 01:00.
    if minute >= start or minute < end:
        return "active"
    return "soon" if start - 15 <= minute < start else "off"


def commute_end(values, moment=None):
    """Epoche, zu der das laufende Zeitfenster endet."""
    moment = moment or datetime.now()
    end = minutes_of(values["To"]) or 0
    stop = moment.replace(hour=end // 60, minute=end % 60, second=0, microsecond=0)
    if stop <= moment:
        stop += timedelta(days=1)
    return stop.timestamp()


def in_alert_hours(values, moment=None):
    hour = (moment or datetime.now()).hour
    start, end = values["AlertFrom"], values["AlertTo"]
    if start == end:
        return True
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end


# --------------------------------------------------------------------------
# Daten holen
# --------------------------------------------------------------------------

_data_lock = threading.Lock()
_data = {name: {"at": 0.0, "next": 0.0, "error": "", "value": None}
         for name in ("route", "departures", "rain", "weather", "dwd", "nina", "fuel", "news", "autobahn",
                     "calendar")}
_seen = {"scene": 0.0}       # wann die Szene zuletzt gefragt hat
_nina_cover = {}            # "id@version" -> liegt der Wohnort im Gebiet?
_force = threading.Event()


def scene_visible():
    return now() - _seen["scene"] < 60 or _takeover["handle"] is not None


def wanted_interval(name, values, t):
    """Sekunden bis zur nächsten Abfrage dieser Quelle, oder None (gerade nicht)."""
    commute = commute_state(values)
    visible = scene_visible()
    day = in_alert_hours(values)
    home = has_home(values)
    if name == "route":
        # Google und Mapbox kosten ab einem Kontingent Geld: im Zeitfenster im
        # eingestellten Takt, sonst nur, solange die Szene zu sehen ist, und
        # dann höchstens alle 10 Minuten.
        if not route_ready(values):
            return None
        if commute != "off":
            return values["RouteMinutes"] * 60
        return max(600, values["RouteMinutes"] * 60) if visible else None
    if name == "departures":
        if not values["StopId"]:
            return None
        if visible:
            return 60
        return 120 if commute != "off" else None
    if name == "rain":
        if not (home and values["Rain"]):
            return None
        return 300 if (commute != "off" or visible) else (600 if day else None)
    if name == "weather":
        return 600 if home and (day or visible) else None
    if name in ("dwd", "nina"):
        return 300 if home and values["Warnings"] else None
    if name == "fuel":
        if not (home and values["TankerKey"] and chosen_fuels(values)):
            return None
        # Tankerkönig bittet um krumme Zeiten mit etwas Zufall.
        if day:
            return 600 + random.randint(5, 55)
        return 1800 + random.randint(5, 55) if visible else None
    if name == "news":
        if values["News"] == "off" or (values["News"] == "custom" and not values["NewsUrl"]):
            return None
        return 900 if (day or visible) else None
    if name == "calendar":
        if not values["CalendarUrls"]:
            return None
        return 600 if (commute != "off" or visible) else (1800 if day else None)
    return None


def news_url(values):
    if values["News"] == "custom":
        return values["NewsUrl"]
    return sources.NEWS_FEEDS.get(values["News"], sources.NEWS_FEEDS["tagesschau"])


def fetch(name, values):
    """Holt eine Quelle; gibt den neuen Wert zurück (Fehler als SourceError)."""
    lat, lon = values["HomeLat"], values["HomeLon"]
    if name == "route":
        if route_provider(values) == "mapbox":
            value = sources.route_mapbox(values["MapboxKey"], (lat, lon), work_coords(values),
                                         values["Language"], values["AvoidTolls"])
        else:
            value = sources.route(values["GoogleKey"], values["Home"], values["Work"], values["Language"],
                                  values["AvoidTolls"])
        value["provider"] = route_provider(values)
        return value
    if name == "departures":
        stop = values["StopId"]
        return {"stop": stop, "rows": departures_of(values, stop)}
    if name == "rain":
        return sources.rain(lat, lon)
    if name == "weather":
        return sources.current_weather(lat, lon)
    if name == "dwd":
        return sources.dwd_alerts(lat, lon, values["Language"])
    if name == "nina":
        return {"alerts": nina_here(lat, lon, values["Language"])}
    if name == "fuel":
        stations = sources.fuel_stations(values["TankerKey"], lat, lon, values["FuelRadius"])
        record_fuel(my_stations(stations, values))
        return {"stations": stations}
    if name == "news":
        return sources.news(news_url(values))
    if name == "calendar":
        return {"events": sources.calendar_events(values["CalendarUrls"], values["CalendarUser"],
                                                  values["CalendarPassword"], values["CalendarDays"])}
    raise ValueError(name)


def nina_here(lat, lon, language):
    found = []
    checked = 0
    for row in sources.nina_list():
        key = f"{row['id']}@{row['version']}"
        if key not in _nina_cover:
            if checked >= 25:   # der Rest kommt in fünf Minuten dran
                continue
            checked += 1
            try:
                _nina_cover[key] = sources.nina_covers(row["id"], lat, lon)
            except sources.SourceError:
                continue
        if _nina_cover[key]:
            titles = row["titles"]
            found.append({"id": f"nina:{row['id']}", "source": "NINA", "level": row["level"],
                          "title": str(titles.get(language) or titles.get("de") or titles.get("en") or "")[:160],
                          "event": "", "text": "", "from": None, "until": None})
    if len(_nina_cover) > 500:
        _nina_cover.clear()
    return found


def refresh_autobahn(route_value):
    """Meldungen und Sperrungen auf den Autobahnen der schnellsten Route."""
    best = (route_value or {}).get("routes", [None])[0]
    if not best or not best["roads"]:
        with _data_lock:
            _data["autobahn"].update(value={"events": []}, at=now(), error="")
        return
    line = sources.decode_polyline(best["polyline"])
    events = sources.autobahn_events(best["roads"], line)
    with _data_lock:
        _data["autobahn"].update(value={"events": events}, at=now(), error="")


def refresh(name, values, force=False):
    t = now()
    with _data_lock:
        row = _data[name]
        due = force or t >= row["next"]
    if not due:
        return False
    interval = wanted_interval(name, values, t)
    if interval is None and not force:
        with _data_lock:
            row["next"] = t + 30
        return False
    try:
        value = fetch(name, values)
        error = ""
    except sources.SourceError as exc:
        value, error = None, exc.code
        plugin.log(f"{name}: {exc}", level="warning")
    except Exception as exc:  # pragma: no cover - eine Quelle darf die anderen nicht aufhalten
        value, error = None, f"bug:{exc}"
        plugin.log(f"{name}: {exc}", level="error")
    with _data_lock:
        if value is not None:
            row.update(value=value, at=now())
        row["error"] = error
        # Nach einem Fehler nicht gleich wieder, aber auch nicht ewig warten.
        wait = interval or 300
        if error in ("key", "disabled", "billing", "denied", "no-key"):
            wait = max(wait, 1800)
        elif error:
            wait = min(max(wait, 120), 900)
        row["next"] = now() + wait
    if name == "route" and value is not None:
        try:
            refresh_autobahn(value)
        except Exception as exc:  # pragma: no cover
            plugin.log(f"Autobahn: {exc}", level="warning")
    check_alerts(name)
    return True


def data_loop():
    _stop_requested.wait(3)
    while not _stop_requested.is_set():
        force = _force.is_set()
        _force.clear()
        values = settings()
        for name in ("departures", "route", "rain", "weather", "dwd", "nina", "fuel", "news", "calendar"):
            if _stop_requested.is_set():
                return
            try:
                refresh(name, values, force=force and wanted_interval(name, values, now()) is not None)
            except Exception as exc:  # pragma: no cover
                plugin.log(f"Abruf {name} fehlgeschlagen: {exc}", level="error")
        _force.wait(5)


def refresh_all():
    """Nach dem Speichern oder auf Knopfdruck: alles, was gerade gefragt ist, sofort."""
    with _data_lock:
        for row in _data.values():
            row["next"] = 0.0
    _force.set()


# --------------------------------------------------------------------------
# Spritpreis-Verlauf (für den Durchschnitt der letzten Tage)
# --------------------------------------------------------------------------

_fuel_lock = threading.Lock()


def chosen_fuels(values):
    if values["Fuels"] == ["none"]:
        return []
    return values["Fuels"] or [values["Fuel"]]


def fuel_limit(values, fuel):
    """Der Preis, unter dem es einen Hinweis gibt (0 = keiner)."""
    limit = values.get(f"FuelBelow{fuel.capitalize() if fuel == 'diesel' else fuel.upper()}") or 0.0
    if not limit and not values["Fuels"] and fuel == values["Fuel"]:
        limit = values["FuelBelow"]
    return limit


def my_stations(stations, values):
    """Nur die angehakten Tankstellen; ohne Auswahl alle im Umkreis."""
    wanted = set(values["FuelStations"])
    if not wanted:
        return stations
    picked = [s for s in stations if s["id"] in wanted]
    return picked


def best_price(stations, fuel):
    prices = [s["prices"][fuel] for s in stations if s["open"] and fuel in s["prices"]]
    return min(prices) if prices else None


def record_fuel(stations):
    """Je Sorte der billigste Preis jeder Stunde, 35 Tage lang."""
    hour = str(int(now() // 3600 * 3600))
    with _fuel_lock:
        history = read_json(FUEL_FILE, {}) or {}
        changed = False
        for fuel in sources.FUELS:
            price = best_price(stations, fuel)
            if price is None:
                continue
            row = history.setdefault(fuel, {})
            if hour not in row or price < row[hour]:
                row[hour] = price
                changed = True
        cutoff = now() - 35 * 86400
        for fuel in list(history):
            for key in [k for k in history[fuel] if as_int(k) < cutoff]:
                del history[fuel][key]
                changed = True
        if changed:
            write_json(FUEL_FILE, history)


def fuel_stats(fuel, days):
    """(Durchschnitt der letzten `days` Tage ohne heute, Tagestiefs der letzten 14 Tage)."""
    with _fuel_lock:
        row = (read_json(FUEL_FILE, {}) or {}).get(fuel) or {}
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    start = today - days * 86400
    past = [p for k, p in row.items() if start <= as_int(k) < today]
    seen_days = {int((as_int(k) - start) // 86400) for k in row if start <= as_int(k) < today}
    average = round(sum(past) / len(past), 3) if past and len(seen_days) >= 2 else None
    lows = {}
    for key, price in row.items():
        day = datetime.fromtimestamp(as_int(key)).strftime("%Y-%m-%d")
        lows[day] = min(price, lows.get(day, 99))
    daily = [{"day": d, "price": lows[d]} for d in sorted(lows)[-14:]]
    return average, daily, len(seen_days)


# --------------------------------------------------------------------------
# Hinweise: wenn etwas Besonderes ist, die Szene von selbst zeigen
# --------------------------------------------------------------------------

_alerts_lock = threading.Lock()
_alerts = []                 # neueste zuerst
_alert_counter = {"n": 0}
_armed = {}                  # Bedingung -> war sie beim letzten Mal schon wahr?
_fired = {}                  # Schlüssel -> Zeit
ALERT_KEEP_SECONDS = 15 * 60


def add_alert(kind, key, title, text="", level=2, bypass_hours=False):
    """Ein Hinweis, höchstens einmal je Schlüssel."""
    t = now()
    if key in _fired:
        return None
    values = settings()
    _fired[key] = t
    if not bypass_hours and not in_alert_hours(values):
        plugin.log(f"Außerhalb der Hinweis-Zeit: {title}")
        return None
    with _alerts_lock:
        _alert_counter["n"] += 1
        alert = {"id": _alert_counter["n"], "kind": kind, "key": key, "title": title, "text": text,
                 "level": level, "at": t, "shown": False}
        _alerts.insert(0, alert)
        del _alerts[12:]
    plugin.log(f"Hinweis: {title}" + (f" – {text}" if text else ""))
    _wake.set()
    return alert


def recent_alerts(t=None):
    t = t or now()
    with _alerts_lock:
        return [dict(a) for a in _alerts if t - a["at"] < ALERT_KEEP_SECONDS]


def recent_list():
    """Die letzten Hinweise für die Plugin-Seite, auch ältere."""
    with _alerts_lock:
        return [{"kind": a["kind"], "title": a["title"], "text": a["text"], "at": local_text(a["at"])}
                for a in _alerts[:6]]


def edge(key, condition):
    """True, wenn `condition` gerade von falsch auf wahr gewechselt ist."""
    before = _armed.get(key, False)
    _armed[key] = bool(condition)
    return bool(condition) and not before


def today_key():
    return datetime.now().strftime("%Y-%m-%d")


def value_of(name):
    with _data_lock:
        row = _data[name]
        return row["value"], row["at"]


def check_alerts(name):
    values = settings()
    commute = commute_state(values) == "active"
    if name == "route":
        check_traffic(values, commute)
    elif name == "departures":
        check_transit(values, commute)
    elif name == "fuel":
        check_fuel(values)
    elif name in ("dwd", "nina"):
        check_warnings(values, name)
    # Alte Schlüssel vergessen, damit der Speicher nicht wächst.
    cutoff = now() - 2 * 86400
    for key in [k for k, at in _fired.items() if at < cutoff]:
        del _fired[key]


def check_traffic(values, commute):
    value, _at = value_of("route")
    limit = values["TrafficAlertMinutes"]
    if not value or not limit:
        return
    best = value["routes"][0]
    delay = (best["seconds"] - best["normalSeconds"]) / 60
    # Wieder scharf erst, wenn es deutlich besser geworden ist (kein Flattern).
    if delay < limit - 3:
        _armed["traffic"] = False
    if commute and delay >= limit and not _armed.get("traffic"):
        _armed["traffic"] = True
        add_alert("traffic", f"traffic:{today_key()}:{int(now() // 1800)}",
                  tr("Stau auf dem Weg zur Arbeit"),
                  tr("{min} Min. statt {normal} Min.", min=round(best["seconds"] / 60),
                     normal=round(best["normalSeconds"] / 60)), level=2)


def matching_departures(values, rows):
    lines = {l.lower() for l in values["Lines"]}
    words = [w.strip().lower() for w in values["Directions"].split(",") if w.strip()]
    out = []
    for row in rows or []:
        if lines and row["line"].lower() not in lines:
            continue
        if words and not any(w in row["direction"].lower() for w in words):
            continue
        out.append(row)
    return out


def check_transit(values, commute):
    value, _at = value_of("departures")
    if not value or not values["TransitAlert"] or not commute:
        return
    t = now()
    for row in matching_departures(values, value["rows"]):
        if row["planned"] > t + 3600 or row["when"] < t:
            continue
        stamp = datetime.fromtimestamp(row["planned"]).strftime("%H:%M")
        name = f"{row['line']} {stamp}" + (f" → {row['direction']}" if row["direction"] else "")
        if row["cancelled"]:
            add_alert("transit", f"cancel:{row['id']}", tr("Fällt aus: {name}", name=name),
                      (row["remarks"] or [""])[0], level=2)
        elif (row["delayMin"] or 0) >= values["TransitDelayMinutes"]:
            add_alert("transit", f"delay:{row['id']}", tr("{min} Min. später: {name}", min=row["delayMin"],
                                                         name=name), (row["remarks"] or [""])[0], level=2)


FUEL_LABELS = {"e5": "Super E5", "e10": "Super E10", "diesel": "Diesel"}


def check_fuel(values):
    value, _at = value_of("fuel")
    if not value:
        return
    stations = my_stations(value["stations"], values)
    for fuel in chosen_fuels(values):
        check_one_fuel(values, fuel, stations)


def check_one_fuel(values, fuel, stations):
    best = best_price(stations, fuel)
    if best is None:
        return
    limit = fuel_limit(values, fuel)
    average, _daily, _days = fuel_stats(fuel, values["FuelAvgDays"])
    below = bool(limit) and best <= limit
    cheap = bool(values["FuelAvgCents"]) and average is not None and \
        best <= average - values["FuelAvgCents"] / 100
    label = FUEL_LABELS.get(fuel, fuel)
    station = min((s for s in stations if s["open"] and s["prices"].get(fuel) == best),
                  key=lambda s: s["km"], default=None)
    where = f"{station['brand']}, {station['place'] or station['street']}" if station else ""
    # Je Sorte höchstens alle drei Stunden, und erst wieder, wenn der Preis zwischendurch drüber war.
    turned_below, turned_cheap = edge(f"fuel-below:{fuel}", below), edge(f"fuel-cheap:{fuel}", cheap)
    last = (load_state().get("lastFuelAlerts") or {}).get(fuel, 0)
    if (turned_below or turned_cheap) and now() - last > 3 * 3600:
        alerts = dict(load_state().get("lastFuelAlerts") or {})
        alerts[fuel] = now()
        save_state(lastFuelAlerts=alerts)
        if below:
            text = f"{limit:.3f}"
            text = text[:-1] if text.endswith("0") else text
            title = tr("{fuel} unter {limit} €", fuel=label,
                       limit=text if values["Language"] == "en" else text.replace(".", ","))
        else:
            title = tr("{fuel} {cents} ct unter dem Schnitt", fuel=label,
                       cents=round((average - best) * 100))
        add_alert("fuel", f"fuel:{fuel}:{best}:{int(now() // 3600)}", title,
                  f"{price_text(best)} € · {where}", level=1)


def price_text(price):
    language = settings()["Language"]
    text = f"{price:.3f}" if price < 10 else f"{price:.2f}"
    return text if language == "en" else text.replace(".", ",")


def check_warnings(values, name):
    value, _at = value_of(name)
    level = values["WarnAlertLevel"]
    if not value or not level:
        return
    for alert in value["alerts"]:
        if alert["level"] >= level:
            add_alert("warning", alert["id"], alert["title"] or alert["event"], alert["event"],
                      level=alert["level"], bypass_hours=alert["level"] >= 4)


def check_leave_reminder(values):
    """Mit dem Auto und "Ankunft um": rechtzeitig sagen, wann es losgehen muss."""
    lead = values["LeaveReminderMinutes"]
    arrive = minutes_of(values["ArriveBy"])
    if not lead or arrive is None or commute_state(values) == "off":
        return
    value, at = value_of("route")
    if not value or now() - at > 20 * 60:
        return
    leave = leave_by(values, value)
    if leave and 0 <= leave - now() <= lead * 60:
        clock = datetime.fromtimestamp(leave).strftime("%H:%M")
        add_alert("leave", f"leave:{today_key()}", tr("Zeit zum Losfahren"),
                  tr("Spätestens um {time} los, um {arrive} da zu sein.", time=clock, arrive=values["ArriveBy"]),
                  level=2)


def leave_by(values, route_value):
    arrive = minutes_of(values["ArriveBy"])
    if arrive is None or not route_value:
        return None
    target = datetime.now().replace(hour=arrive // 60, minute=arrive % 60, second=0, microsecond=0).timestamp()
    leave = target - route_value["routes"][0]["seconds"]
    return leave if leave > now() - 3600 else None


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Pendler-Cockpit ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Pendler-Cockpit ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Playlists: die Takeover-Playlist und auf Knopfdruck eine für den Besitzer
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Pendler-Cockpit (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Pendler-Cockpit abgespielt, wenn es den Bildschirm "
                                 "übernimmt. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 6 * 3600  # das Plugin beendet die Anzeige lange vorher
PLAYLIST_SECONDS = 60

_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Playlists werden nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError as exc:
        return exc.status != 404
    return bool(status.get("active"))


def create_playlist(name, description, seconds, enabled):
    created = engine_call("POST", "/playlists", {"name": name, "description": description}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": seconds})
    if not enabled:
        engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    return playlist_id


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, sechs Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    playlist_id = create_playlist(TAKEOVER_PLAYLIST_NAME, TAKEOVER_PLAYLIST_DESCRIPTION,
                                  TAKEOVER_ITEM_SECONDS, enabled=False)
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")


def make_playlist():
    """Legt die Playlist "Pendler-Cockpit" mit der Szene an (oder sagt, dass es sie schon gibt)."""
    find_scene()
    if _scene["dbId"] is None:
        return {"success": False, "error": _scene["note"]}
    try:
        existing = next((p for p in all_playlists() if p.get("name") == DISPLAY_NAME), None)
        if existing:
            return {"success": True, "message": tr("Die Playlist {name} gibt es schon.", name=DISPLAY_NAME)}
        if screen_held():
            return {"success": False, "error": tr("Gerade hält etwas den Bildschirm. Versuch es gleich noch einmal.")}
        playlist_id = create_playlist(DISPLAY_NAME, tr("Fahrzeit, Abfahrten, Regen, Sprit und Nachrichten."),
                                      PLAYLIST_SECONDS, enabled=True)
    except EngineError as exc:
        plugin.log(f"Playlist: {exc}", level="warning")
        return {"success": False, "error": tr("Konnte die Playlist nicht anlegen: {exc}", exc=exc)}
    plugin.log(f"Playlist {DISPLAY_NAME} angelegt ({playlist_id}).")
    return {"success": True, "message": tr("Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens "
                                           "oder nimm die Szene in eine andere Playlist auf.", name=DISPLAY_NAME)}


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
MAX_SESSION_SECONDS = 3600   # durchgehend: höchstens eine Stunde am Stück, dann neu

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "reason": None, "since": None, "until": None, "started": False,
             "token": 0, "note": "", "focus": None}
_schedule = {"nextAt": 0.0, "lastAt": 0.0, "note": "", "retryAt": 0.0}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Pendler-Cockpit ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Pendler-Cockpit auf der Plugins-Seite aus. Schalte es ein, "
                  "sonst kommt die Szene nicht von selbst auf den Bildschirm.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_turn_on_screen():
    """Läuft die Szene gerade als normaler Playlist-Eintrag? Dann ist sie
    ohnehin zu sehen, und ein Takeover darüber kann den Rahmen danach
    gestoppt zurücklassen (bekannter Fehler)."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None)
        if new_state == "preempted":
            # Etwas Wichtigeres hat den Bildschirm: nicht gleich wieder dagegen drücken.
            _schedule["retryAt"] = now() + 120
    plugin.log(f"Der Rahmen hat Pendler-Cockpit beendet: {new_state}.")
    _wake.set()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    _wake.set()
    if reason != "gestoppt":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def _release_after(seconds, token):
    if _stop_requested.wait(max(1, int(seconds))):
        return
    end_takeover("fertig", token)


def show_scene(reason, seconds, focus=None):
    """Die Szene für `seconds` über alles legen. True, wenn der Rahmen den
    Bildschirm hergegeben hat."""
    if _takeover["handle"] is not None:
        return _note(tr("Pendler-Cockpit ist schon auf dem Bildschirm."))
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Pendler-Cockpit wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    if reason != "test" and scene_turn_on_screen():
        return _note(tr("Pendler-Cockpit läuft gerade in deiner Playlist; die Anzeige bleibt so."))
    if display_is_off():
        return _note(tr("Der Bildschirm ist aus. Pendler-Cockpit weckt ihn nicht."))
    seconds = int(seconds)
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Schrift; eine Bildunterschrift stört nur.
             "overlay": {"enabled": False}}
    try:
        handle = plugin.acquire_display_session(
            session_key=reason, state=state, display_name=DISPLAY_NAME,
            # Etwas länger als gewünscht: der Timer unten ist das ordentliche
            # Ende, die Grenze der Engine greift nur, wenn das Plugin stirbt.
            max_duration_seconds=seconds + 10, wake_if_off=False)
    except Exception as exc:
        return _note(tr("Konnte Pendler-Cockpit nicht anzeigen: {exc}", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    t = now()
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, reason=reason, since=t, until=t + seconds, started=False,
                         note="", focus=focus)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat Pendler-Cockpit nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(tr("Konnte Pendler-Cockpit nicht anzeigen: {exc}", exc=exc))
    with _takeover_lock:
        if _takeover["token"] != token or _takeover["handle"] is None:
            return False
        _takeover["started"] = True
    plugin.log(f"Pendler-Cockpit für {seconds} Sekunden auf dem Bildschirm ({reason}).")
    threading.Thread(target=_release_after, args=(seconds, token), name=f"{PLUGIN_ID}-timer", daemon=True).start()
    _seen["scene"] = now()  # gleich frische Abfahrten holen
    return True


def cancel_scene():
    if not end_takeover("abgebrochen"):
        _note(tr("Pendler-Cockpit hatte den Bildschirm nicht."))
    # Laufende Hinweise gelten als gesehen.
    with _alerts_lock:
        for alert in _alerts:
            alert["shown"] = True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach dem Pendler-Cockpit nicht zu deiner Playlist zurückgekehrt. Starte sie "
                 "auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# --------------------------------------------------------------------------
# Der Zeitplan
# --------------------------------------------------------------------------

def anything_configured(values):
    return route_ready(values) or bool(values["StopId"]) or has_home(values)


def schedule_wanted(values):
    """(ja/nein, Grund) für die regelmäßige Anzeige im Zeitfenster."""
    mode = values["ShowMode"]
    if mode in ("off", "alerts"):
        return False, tr("Regelmäßige Anzeige ist aus.")
    if not anything_configured(values):
        return False, tr("Noch nichts eingerichtet.")
    if commute_state(values) != "active":
        return False, tr("Außerhalb des Zeitfensters ({start}–{end} Uhr).", start=values["From"], end=values["To"])
    return True, ""


def decide_takeover():
    values = settings()
    t = now()
    with _takeover_lock:
        handle = _takeover["handle"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        # Was die Szene gerade zeigt, gilt als gesehen.
        with _alerts_lock:
            for alert in _alerts:
                alert["shown"] = True
        return
    if t < _schedule["retryAt"]:
        return
    # Ein neuer Hinweis geht vor. Einer, der zehn Minuten niemand zeigen
    # konnte, ist keine Nachricht mehr.
    with _alerts_lock:
        pending = [a for a in _alerts if not a["shown"] and t - a["at"] < 600]
    if pending:
        alert = max(pending, key=lambda a: (a["level"], a["at"]))
        seconds = values["AlertSeconds"]
        if show_scene("hinweis", seconds, focus=alert["id"]):
            with _alerts_lock:
                for row in _alerts:
                    row["shown"] = True
            _schedule["lastAt"] = t
            return
        if visible_without_takeover():
            with _alerts_lock:
                for row in pending:
                    row["shown"] = True
        else:
            _schedule["retryAt"] = t + 30
        return
    wanted, why = schedule_wanted(values)
    _schedule["note"] = why
    if not wanted:
        _schedule["nextAt"] = 0.0
        return
    if values["ShowMode"] == "always":
        seconds = int(min(MAX_SESSION_SECONDS, commute_end(values) - t))
        if seconds < 20:
            return
        if not show_scene("zeitfenster", seconds):
            _schedule["retryAt"] = t + 60
        return
    if not _schedule["nextAt"]:
        # Erste Runde im Zeitfenster: nach einer Minute, dann im Takt.
        _schedule["nextAt"] = max(t + 60, _schedule["lastAt"] + values["EveryMinutes"] * 60)
    if t < _schedule["nextAt"]:
        return
    if show_scene("zeitplan", values["ShowForSeconds"]):
        _schedule["lastAt"] = t
        _schedule["nextAt"] = t + values["EveryMinutes"] * 60
    else:
        # Nicht bekommen (Bildschirm aus, anderes Plugin, läuft schon in der Playlist):
        # in zwei Minuten noch einmal.
        _schedule["nextAt"] = t + 120


def visible_without_takeover():
    return now() - _seen["scene"] < 30


def test_show():
    """Sofort zeigen, für die eingestellte Anzeigedauer."""
    def run():
        refresh_all()
        _seen["scene"] = now()
        show_scene("test", settings()["ShowForSeconds"])
    threading.Thread(target=run, name=f"{PLUGIN_ID}-test", daemon=True).start()
    return {"success": True, "message": tr("Bitte den Rahmen um den Bildschirm.")}


_loop = {"lastError": ""}


def tick():
    try:
        maintain_playlists()
        check_leave_reminder(settings())
        decide_takeover()
        _loop["lastError"] = ""
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")


def main_loop():
    _stop_requested.wait(2)
    while not _stop_requested.is_set():
        _wake.clear()
        tick()
        _wake.wait(5)


# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

def route_view(values):
    if not route_ready(values):
        return None
    value, at = value_of("route")
    with _data_lock:
        error = _data["route"]["error"]
    view = {"at": at, "error": error_text("route", error) if error and not value else "", "arriveBy": values["ArriveBy"],
            "work": values["Work"].split(",")[0][:40], "provider": route_provider(values)}
    if value:
        best = value["routes"][0]
        view.update(seconds=best["seconds"], normalSeconds=best["normalSeconds"], km=round(best["meters"] / 1000, 1),
                    via=best["via"], leaveBy=leave_by(values, value),
                    alternatives=[{"seconds": r["seconds"], "via": r["via"]} for r in value["routes"][1:3]])
    events, _ = value_of("autobahn")
    view["events"] = (events or {}).get("events", [])[:3]
    return view


def transit_view(values):
    if not values["StopId"]:
        return None
    value, at = value_of("departures")
    with _data_lock:
        error = _data["departures"]["error"]
    rows = []
    if value and value.get("stop") == values["StopId"]:
        t = now()
        rows = [r for r in matching_departures(values, value["rows"]) if r["when"] > t - 60][:10]
    custom = values["TransportUrl"].strip().startswith(("http://", "https://"))
    return {"at": at, "stop": values["StopName"] or values["StopId"], "walk": values["WalkMinutes"],
            "credit": "" if custom or db_stop_id(values["StopId"]) else "transitous.org · © OpenStreetMap",
            "error": error_text("departures", error) if error and not rows else "",
            "rows": [{k: r[k] for k in ("line", "kind", "direction", "planned", "when", "delayMin", "cancelled",
                                        "platform", "remarks")} for r in rows]}


def rain_view(values):
    if not (values["Rain"] and has_home(values)):
        return None
    value, at = value_of("rain")
    weather, _ = value_of("weather")
    frames = (value or {}).get("frames") or []
    return {"at": at, "frames": frames, "summary": sources.rain_summary(frames, now()) if frames else None,
            "weather": weather}


def fuel_view(values):
    if not (values["TankerKey"] and has_home(values) and chosen_fuels(values)):
        return None
    value, at = value_of("fuel")
    with _data_lock:
        error = _data["fuel"]["error"]
    stations = my_stations((value or {}).get("stations", []), values)
    rows = []
    for fuel in chosen_fuels(values):
        open_ones = sorted((s for s in stations if s["open"] and fuel in s["prices"]),
                           key=lambda s: (s["prices"][fuel], s["km"]))
        average, daily, days = fuel_stats(fuel, values["FuelAvgDays"])
        rows.append({"fuel": fuel, "average": average, "daysKnown": days, "daily": daily,
                     "below": fuel_limit(values, fuel) or None,
                     "best": [{"brand": s["brand"], "place": s["place"] or s["street"], "km": s["km"],
                               "price": s["prices"][fuel]} for s in open_ones[:3]]})
    first = rows[0]
    # Die erste Sorte auch flach, wie bis 0.2.0.
    return {"at": at, "error": error_text("fuel", error) if error and not value else "",
            "avgDays": values["FuelAvgDays"], "fuels": rows, **first}


def warnings_view(values):
    if not (values["Warnings"] and has_home(values)):
        return []
    rows = []
    for name in ("dwd", "nina"):
        value, _ = value_of(name)
        rows += [a for a in (value or {}).get("alerts", []) if a["level"] >= 2]
    rows.sort(key=lambda a: -a["level"])
    return [{k: a[k] for k in ("source", "level", "title", "event", "until")} for a in rows[:4]]


def calendar_view(values):
    if not values["CalendarUrls"]:
        return None
    value, at = value_of("calendar")
    with _data_lock:
        error = _data["calendar"]["error"]
    t = now()
    events = [e for e in (value or {}).get("events", []) if e["end"] > t]
    return {"at": at, "error": error_text("calendar", error) if error and not events else "",
            "days": values["CalendarDays"], "events": events[:values["CalendarCount"]]}


def scene_payload():
    _seen["scene"] = now()
    values = settings()
    news, _ = value_of("news")
    with _takeover_lock:
        focus = _takeover["focus"]
    return {
        "at": now(),
        "lang": values["Language"],
        "commute": commute_state(values),
        "window": f"{values['From']}–{values['To']}",
        "route": route_view(values),
        "transit": transit_view(values),
        "rain": rain_view(values),
        "fuel": fuel_view(values),
        "calendar": calendar_view(values),
        "warnings": warnings_view(values),
        "news": [i["title"] for i in (news or {}).get("items", [])][:12] if values["News"] != "off" else [],
        "alerts": [{k: a[k] for k in ("id", "kind", "title", "text", "level", "at")} for a in recent_alerts()],
        "focus": focus,
    }


# --------------------------------------------------------------------------
# Fehlertexte
# --------------------------------------------------------------------------

def error_text(source, code):
    code = str(code or "")
    if not code:
        return ""
    if source == "route" and code == "work-not-found":
        return tr("Die Adresse der Arbeit wurde nicht gefunden. Versuch es mit Straße, Hausnummer und Ort.")
    if source == "route" and route_provider(settings()) == "mapbox":
        known = {
            "key": "Mapbox nimmt den Schlüssel nicht an. Prüfe, ob er vollständig kopiert ist.",
            "denied": "Mapbox erlaubt diesem Schlüssel die Abfrage nicht. Prüfe die Einschränkungen des Schlüssels.",
            "quota": "Das Kontingent bei Mapbox ist erschöpft.",
            "no-route": "Mapbox findet keine Route zwischen den beiden Adressen.",
        }
        if code in known:
            return tr(known[code])
    if source == "route":
        known = {
            "no-key": "Trage den Google-Schlüssel ein.",
            "key": "Google nimmt den Schlüssel nicht an. Prüfe, ob er vollständig kopiert ist.",
            "disabled": "Die Routes API ist für diesen Schlüssel nicht aktiviert. Aktiviere sie in der Google Cloud Console.",
            "billing": "Google verlangt für das Projekt eine Zahlungsart. Hinterlege sie in der Google Cloud Console.",
            "denied": "Google erlaubt diesem Schlüssel die Routes API nicht. Prüfe die Einschränkungen des Schlüssels.",
            "quota": "Das Kontingent bei Google ist erschöpft.",
            "no-route": "Google findet keine Route zwischen den beiden Adressen.",
        }
        if code in known:
            return tr(known[code])
    if source == "fuel":
        if code in ("key", "no-key"):
            return tr("Tankerkönig nimmt den Schlüssel nicht an.")
        if code == "refused":
            return tr("Tankerkönig hat die Anfrage abgelehnt.")
    if source == "calendar":
        known = {
            "login": "Der Kalender verlangt eine Anmeldung. Prüfe Benutzername und App-Passwort.",
            "not-found": "Den Kalender gibt es unter diesem Link nicht. Prüfe den Link.",
            "not-ics": "Unter diesem Link liegt kein Kalender. Nimm den Freigabe-Link oder den internen Link aus Nextcloud.",
            "missing-lib": "Ein Baustein für Kalender fehlt. Installiere das Paket noch einmal.",
        }
        if code in known:
            return tr(known[code])
    if source == "departures" and code == "old-stop":
        return tr("Die Haltestelle stammt aus einer älteren Version. Wähle sie bitte neu aus.")
    if source == "departures" and code == "key":
        return tr("Der Abfahrtsdienst lehnt Anfragen von diesem Rahmen ab (Fehler 403).")
    if source == "departures" and code.startswith("http:"):
        return tr("Der Abfahrtsdienst antwortet mit Fehler {code}. Meist ist das nach kurzer Zeit vorbei.",
                  code=code[5:])
    if code == "unreachable":
        return tr("Der Dienst ist gerade nicht erreichbar.")
    if code == "quota":
        return tr("Zu viele Anfragen; es geht gleich von selbst weiter.")
    if code == "format":
        return tr("Der Dienst hat etwas Unerwartetes geschickt.")
    if code == "ssl":
        return tr("Die sichere Verbindung zum Dienst ist fehlgeschlagen. Stimmt die Uhrzeit des Rahmens?")
    if code.startswith("http:"):
        return tr("Der Dienst antwortet mit Fehler {code}.", code=code[5:])
    return code


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def source_status(values):
    """Je Quelle: eingerichtet?, zuletzt geholt, Fehler."""
    out = {}
    with _data_lock:
        rows = {k: dict(v) for k, v in _data.items()}
    for name, row in rows.items():
        if name == "autobahn":
            continue
        out[name] = {"at": local_text(row["at"]), "error": error_text(name, row["error"]),
                     "active": wanted_interval(name, values, now()) is not None}
    return out


def state_payload():
    values = settings()
    state = load_state()
    with _takeover_lock:
        showing = _takeover["handle"] is not None
        note = _takeover["note"]
        until = _takeover["until"]
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    fuel_value, _ = value_of("fuel")
    route_value, _ = value_of("route")
    departures, _ = value_of("departures")
    lines = {}
    for row in (departures or {}).get("rows", []):
        lines.setdefault(row["line"], {"line": row["line"], "kind": row["kind"], "directions": []})
        if row["direction"] and row["direction"] not in lines[row["line"]]["directions"]:
            lines[row["line"]]["directions"].append(row["direction"])
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "secrets": {name: bool(values[name]) for name in SECRETS},
        "commute": commute_state(values),
        "showing": showing,
        "showingUntil": local_text(until) if until else "",
        "schedule": _schedule["note"],
        "nextAt": local_text(_schedule["nextAt"]) if _schedule["nextAt"] else "",
        "note": note or _playlists["note"] or _scene["note"],
        "permission": takeover_permission_note(),
        "sources": source_status(values),
        "route": route_view(values) if route_value else None,
        "fuelStations": [{"id": s["id"], "brand": s["brand"], "place": s["place"] or s["street"], "km": s["km"],
                          "prices": s["prices"], "open": s["open"]}
                         for s in sorted((fuel_value or {}).get("stations", []), key=lambda s: s["km"])[:25]],
        "lines": sorted(lines.values(), key=lambda l: (len(l["line"]), l["line"]))[:30],
        "alerts": recent_list(),
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
    }


def find_home(address):
    values = settings()
    try:
        found = sources.geocode(address, values["Language"])
    except sources.SourceError as exc:
        if exc.code in ("not-found", "no-address"):
            return {"success": False, "error": tr("Diese Adresse wurde nicht gefunden. Versuch es mit Straße, "
                                                  "Hausnummer und Ort.")}
        return {"success": False, "error": error_text("home", exc.code)}
    save_settings({"Home": address, "HomeLat": found["lat"], "HomeLon": found["lon"], "HomeName": found["name"]})
    message = tr("Gefunden: {name}", name=found["name"])
    stops = []
    try:
        stops = transit(settings(), lambda: sources.transitous_nearby(found["lat"], found["lon"]),
                        lambda base: sources.nearby_stops(found["lat"], found["lon"], base))
    except sources.SourceError as exc:
        plugin.log(f"Haltestellen: {exc}", level="warning")
    # Die nächste Haltestelle gleich eintragen, wenn noch keine gewählt ist.
    current = settings()["StopId"]
    if stops and (not current or (db_stop_id(current) and not db_stop_id(stops[0]["id"]))):
        save_settings({"StopId": stops[0]["id"], "StopName": stops[0]["name"],
                       "WalkMinutes": max(1, round((stops[0]["meters"] or 400) / 80))})
        message += " " + tr("Nächste Haltestelle: {stop}.", stop=stops[0]["name"])
    refresh_all()
    return {"success": True, "message": message, "stops": stops}


def stops_payload():
    values = settings()
    if not has_home(values):
        return {"success": False, "error": tr("Trage zuerst deinen Wohnort ein.")}
    try:
        lat, lon = values["HomeLat"], values["HomeLon"]
        stops = transit(values, lambda: sources.transitous_nearby(lat, lon),
                        lambda base: sources.nearby_stops(lat, lon, base))
    except sources.SourceError as exc:
        plugin.log(f"Haltestellen: {exc}", level="warning")
        return {"success": False, "error": with_detail(error_text("departures", exc.code), exc)}
    if not stops:
        return {"success": False, "error": tr("In 2 km Umkreis wurde keine Haltestelle gefunden. Such sie darunter nach Namen.")}
    return {"success": True, "stops": stops}


def with_detail(text, exc):
    """Für die Plugin-Seite: der Satz und dahinter klein, was genau schiefging."""
    detail = str(getattr(exc, "detail", "") or "")[:160]
    return f"{text} ({detail})" if detail else text


def search_stops_payload(query):
    values = settings()
    if not str(query or "").strip():
        return {"success": False, "error": tr("Gib einen Namen ein, z. B. „Bad Homburg Bahnhof“.")}
    try:
        lat, lon = (values["HomeLat"], values["HomeLon"]) if has_home(values) else (None, None)
        stops = transit(values, lambda: sources.transitous_search(query, lat, lon),
                        lambda base: sources.search_stops(query, base))
    except sources.SourceError as exc:
        plugin.log(f"Haltestellen: {exc}", level="warning")
        return {"success": False, "error": with_detail(error_text("departures", exc.code), exc)}
    if not stops:
        return {"success": False, "error": tr("Keine Haltestelle mit diesem Namen gefunden.")}
    return {"success": True, "stops": stops}


def decimal_text(number, values):
    text = f"{number:g}"
    return text if values["Language"] == "en" else text.replace(".", ",")


def test_route():
    values = settings()
    if not route_ready(values):
        if values["Home"] and values["Work"] and route_provider(values) == "mapbox":
            return {"success": False, "error": tr("Trage zuerst deinen Wohnort ein.")}
        return {"success": False, "error": tr("Trage Wohnort, Arbeit und einen Schlüssel von Google oder Mapbox ein.")}
    refresh("route", values, force=True)
    value, _ = value_of("route")
    with _data_lock:
        error = _data["route"]["error"]
    if error:
        return {"success": False, "error": error_text("route", error)}
    best = value["routes"][0]
    return {"success": True, "message": tr("Jetzt {min} Min. ({km} km), ohne Verkehr {normal} Min.",
                                           min=round(best["seconds"] / 60), km=decimal_text(round(best["meters"] / 1000, 1), values),
                                           normal=round(best["normalSeconds"] / 60))}


def test_calendar():
    values = settings()
    if not values["CalendarUrls"]:
        return {"success": False, "error": tr("Trage zuerst einen Kalender-Link ein.")}
    refresh("calendar", values, force=True)
    value, _ = value_of("calendar")
    with _data_lock:
        error = _data["calendar"]["error"]
    if error:
        return {"success": False, "error": error_text("calendar", error) or error}
    events = (value or {}).get("events", [])
    if not events:
        return {"success": True, "message": tr("Gefunden, aber in den nächsten {days} Tagen steht nichts an.",
                                               days=values["CalendarDays"])}
    first = events[0]
    when = datetime.fromtimestamp(first["start"]).strftime("%d.%m. %H:%M") if not first["allDay"] \
        else datetime.fromtimestamp(first["start"]).strftime("%d.%m.")
    return {"success": True, "message": tr("{n} Termine in den nächsten {days} Tagen, als Nächstes: {title} ({when}).",
                                           n=len(events), days=values["CalendarDays"], title=first["title"], when=when)}


def test_fuel():
    values = settings()
    if not (values["TankerKey"] and has_home(values)):
        return {"success": False, "error": tr("Trage zuerst deinen Wohnort und den Tankerkönig-Schlüssel ein.")}
    refresh("fuel", values, force=True)
    value, _ = value_of("fuel")
    with _data_lock:
        error = _data["fuel"]["error"]
    if error:
        return {"success": False, "error": error_text("fuel", error)}
    stations = my_stations(value["stations"], values)
    best = best_price(stations, (chosen_fuels(values) or ["e10"])[0])
    return {"success": True, "message": tr("{n} Tankstellen im Umkreis, am günstigsten {price} €.", n=len(stations),
                                           price=price_text(best) if best else "–")}


def settings_saved(changed):
    if set(changed) & {"Home", "HomeLat", "HomeLon"}:
        _nina_cover.clear()
        for name in ("rain", "weather", "dwd", "nina", "fuel"):
            with _data_lock:
                _data[name].update(value=None, at=0.0, error="")
    if set(changed) & {"Work", "GoogleKey", "MapboxKey", "Home", "HomeLat", "HomeLon", "AvoidTolls"}:
        with _data_lock:
            _data["route"].update(value=None, at=0.0, error="")
            _data["autobahn"].update(value=None, at=0.0, error="")
    if "StopId" in changed or "TransportUrl" in changed:
        with _data_lock:
            _data["departures"].update(value=None, at=0.0, error="")
    if set(changed) & {"CalendarUrls", "CalendarUser", "CalendarPassword", "CalendarDays"}:
        with _data_lock:
            _data["calendar"].update(value=None, at=0.0, error="")
    if set(changed) & {"News", "NewsUrl", "Language"}:
        with _data_lock:
            _data["news"].update(value=None, at=0.0, error="")
    if set(changed) & {"ShowMode", "EveryMinutes", "From", "To", "Days"}:
        _schedule["nextAt"] = 0.0
    if set(changed) & {"Fuel", "Fuels", "FuelStations"}:
        for key in [k for k in _armed if k.startswith("fuel-")]:
            _armed.pop(key, None)
    # Die Fahrzeit nur neu fragen, wenn sich am Weg etwas geändert hat.
    for name, row in _data.items():
        if name != "route" or set(changed) & {"Work", "GoogleKey", "MapboxKey", "Home", "HomeLat", "HomeLon", "AvoidTolls"}:
            row["next"] = 0.0
    _force.set()
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/stops":
                self._json(stops_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(), cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)  # ein leeres Feld heißt: den alten behalten
                for name in ("HomeLat", "HomeLon", "HomeName", "WorkLat", "WorkLon", "WorkGeo"):
                    body.pop(name, None)  # setzt nur die Adresssuche
                changed = save_settings(body)
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/forget":
                name = str(self._body().get("name") or "")
                if name in SECRETS:
                    with _settings_lock:
                        stored = read_json(SETTINGS_FILE, {}) or {}
                        stored[name] = ""
                        write_json(SETTINGS_FILE, stored)
                    settings_saved([name])
                self._json({"success": True})
                return
            if path == "/api/stop-search":
                self._json(search_stops_payload(str(self._body().get("q") or "")[:80]))
                return
            if path == "/api/home":
                self._json(find_home(str(self._body().get("Home") or "").strip()[:300]))
                return
            if path == "/api/route-test":
                self._json(test_route())
                return
            if path == "/api/fuel-test":
                self._json(test_fuel())
                return
            if path == "/api/calendar-test":
                self._json(test_calendar())
                return
            if path == "/api/refresh":
                refresh_all()
                self._json({"success": True, "message": tr("Die Daten werden neu geladen.")})
                return
            if path == "/api/test":
                self._json(test_show())
                return
            if path == "/api/cancel":
                cancel_scene()
                self._json({"success": True, "message": tr("Gebe den Bildschirm zurück.")})
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starte {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("show", lambda _context=None: test_show())
    plugin.on_action("cancel", lambda _context=None: (cancel_scene(), {"success": True})[1])

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=data_loop, name=f"{PLUGIN_ID}-data", daemon=True).start()
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _force.set()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
