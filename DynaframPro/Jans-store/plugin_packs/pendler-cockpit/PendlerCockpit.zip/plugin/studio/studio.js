"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/PendlerCockpit/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
let current = null;
let editing = false;
let stops = null;          // Antwort von /api/stops

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Alles für den Weg zur Arbeit auf einem Bildschirm: Fahrzeit mit Verkehr, die nächsten Abfahrten, Regen in den nächsten zwei Stunden, Spritpreise, Warnungen und Nachrichten. Richte nur ein, was du brauchst; der Rest bleibt weg. Jede Änderung wird sofort gespeichert.",
    "Everything for the way to work on one screen: travel time with traffic, the next departures, rain in the next two hours, fuel prices, warnings and news. Set up only what you need; the rest stays out of the way. Every change is saved immediately.",
    "Todo para ir al trabajo en una pantalla: tiempo de viaje con tráfico, las próximas salidas, lluvia en las próximas dos horas, precios del combustible, avisos y noticias. Configura solo lo que necesites; lo demás no aparece. Cada cambio se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  show: ["Jetzt anzeigen", "Show now", "Mostrar ahora"],
  cancel: ["Beenden", "Stop", "Terminar"],
  refresh: ["Daten neu laden", "Reload data", "Recargar datos"],
  factCommute: ["Pendelzeit", "Commute window", "Horario de trayecto"],
  factScreen: ["Bildschirm", "Screen", "Pantalla"],
  factVersion: ["Version", "Version", "Versión"],
  sources: ["Datenquellen", "Data sources", "Fuentes de datos"],
  recent: ["Letzte Hinweise", "Recent alerts", "Avisos recientes"],
  noRecent: ["Noch keine Hinweise.", "No alerts yet.", "Todavía no hay avisos."],
  commuteActive: ["jetzt ({window})", "now ({window})", "ahora ({window})"],
  commuteSoon: ["gleich ({window})", "soon ({window})", "pronto ({window})"],
  commuteOff: ["{window}", "{window}", "{window}"],
  showing: ["zeigt das Cockpit bis {time}", "showing the cockpit until {time}", "mostrando la cabina hasta las {time}"],
  playlistRuns: ["Playlist läuft", "Playlist is playing", "La lista está en curso"],
  nextAt: ["nächste Anzeige {time}", "next display {time}", "próxima vez {time}"],
  srcRoute: ["Fahrzeit ({by})", "Travel time ({by})", "Tiempo de viaje ({by})"],
  providerGoogle: ["Die Fahrzeit kommt jetzt von Google.", "Travel time now comes from Google.", "El tiempo de viaje viene ahora de Google."],
  providerMapbox: ["Die Fahrzeit kommt jetzt von Mapbox.", "Travel time now comes from Mapbox.", "El tiempo de viaje viene ahora de Mapbox."],
  providerBoth: ["Beide Schlüssel sind eingetragen; das Plugin nimmt Google.", "Both keys are set; the plugin uses Google.", "Hay dos claves; el plugin usa Google."],
  srcDepartures: ["Abfahrten (DB)", "Departures (DB)", "Salidas (DB)"],
  srcRain: ["Regenradar (DWD)", "Rain radar (DWD)", "Radar de lluvia (DWD)"],
  srcWeather: ["Wetter (DWD)", "Weather (DWD)", "Tiempo (DWD)"],
  srcDwd: ["Warnungen (DWD)", "Warnings (DWD)", "Avisos (DWD)"],
  srcNina: ["Warnungen (NINA)", "Warnings (NINA)", "Avisos (NINA)"],
  srcFuel: ["Sprit (Tankerkönig)", "Fuel (Tankerkönig)", "Combustible (Tankerkönig)"],
  srcNews: ["Nachrichten", "News", "Noticias"],
  srcIdle: ["gerade nicht gefragt", "not needed right now", "no se consulta ahora"],
  srcAt: ["zuletzt {time}", "last {time}", "última vez {time}"],
  srcNever: ["noch nicht geholt", "not fetched yet", "aún sin datos"],
  homeTitle: ["Wohnort", "Home", "Domicilio"],
  homeHint: ["Von hier aus sucht das Plugin die Haltestelle, die Tankstellen, das Regenradar und die Warnungen. Die Adresse wird einmal bei OpenStreetMap nachgeschlagen.",
    "From here the plugin looks for your stop, petrol stations, the rain radar and warnings. The address is looked up once on OpenStreetMap.",
    "Desde aquí el plugin busca la parada, las gasolineras, el radar de lluvia y los avisos. La dirección se consulta una vez en OpenStreetMap."],
  homeAddress: ["Adresse", "Address", "Dirección"],
  find: ["Suchen", "Find", "Buscar"],
  finding: ["Suche …", "Searching …", "Buscando …"],
  homeFound: ["Gefunden: {name}", "Found: {name}", "Encontrado: {name}"],
  optional: ["(optional)", "(optional)", "(opcional)"],
  carTitle: ["Mit dem Auto zur Arbeit", "By car to work", "En coche al trabajo"],
  carHint: ["Die Fahrzeit mit dem Verkehr von jetzt und zum Vergleich ohne kommt von Google Maps oder von Mapbox. Trag einen der beiden Schlüssel ein; stehen beide da, nimmt das Plugin Google. Mapbox geht ohne Zahlungsart, Google ist in Deutschland meist etwas genauer. Gefragt wird nur im Pendel-Zeitfenster.",
    "The travel time with current traffic and, for comparison, without comes from Google Maps or from Mapbox. Enter one of the two keys; if both are there, the plugin uses Google. Mapbox works without a payment method, Google is usually a bit more accurate in Germany. It is only asked during the commute window.",
    "El tiempo de viaje con el tráfico actual y, para comparar, sin él viene de Google Maps o de Mapbox. Introduce una de las dos claves; si hay dos, el plugin usa Google. Mapbox funciona sin método de pago; Google suele ser algo más preciso en Alemania. Solo se consulta en el horario de trayecto."],
  work: ["Adresse der Arbeit", "Work address", "Dirección del trabajo"],
  googleKey: ["Google-Schlüssel (Routes API)", "Google key (Routes API)", "Clave de Google (Routes API)"],
  mapboxKey: ["oder Mapbox-Token", "or Mapbox token", "o token de Mapbox"],
  forgetGoogle: ["Google-Schlüssel löschen", "Delete Google key", "Borrar clave de Google"],
  forgetMapbox: ["Mapbox-Schlüssel löschen", "Delete Mapbox key", "Borrar clave de Mapbox"],
  mapboxHowTitle: ["So bekommst du den Mapbox-Schlüssel (etwa 3 Minuten, ohne Zahlungsart)", "How to get the Mapbox key (about 3 minutes, no payment method)", "Cómo obtener la clave de Mapbox (unos 3 minutos, sin método de pago)"],
  m1: ["Auf <a href=\"https://account.mapbox.com/auth/signup/\" target=\"_blank\" rel=\"noopener\">mapbox.com</a> ein kostenloses Konto anlegen. Eine Kreditkarte ist nicht nötig.",
    "Create a free account at <a href=\"https://account.mapbox.com/auth/signup/\" target=\"_blank\" rel=\"noopener\">mapbox.com</a>. No credit card is needed.",
    "Crea una cuenta gratuita en <a href=\"https://account.mapbox.com/auth/signup/\" target=\"_blank\" rel=\"noopener\">mapbox.com</a>. No hace falta tarjeta de crédito."],
  m2: ["Nach der Anmeldung zeigt die Seite <b>Tokens</b> den <b>Default public token</b> (beginnt mit <code>pk.</code>).",
    "After signing in, the <b>Tokens</b> page shows the <b>Default public token</b> (it starts with <code>pk.</code>).",
    "Tras iniciar sesión, la página <b>Tokens</b> muestra el <b>Default public token</b> (empieza por <code>pk.</code>)."],
  m3: ["Den Token kopieren und oben bei Mapbox einfügen, dann „Fahrzeit jetzt abfragen“.",
    "Copy the token, paste it into the Mapbox field above, then “Check travel time now”.",
    "Copia el token, pégalo arriba en el campo de Mapbox y pulsa «Consultar tiempo de viaje»."],
  mCost: ["Kosten: Ohne Zahlungsart erlaubt Mapbox 10.000 Fahrzeit-Abfragen im Monat, mit Zahlungsart 100.000 kostenlos. Werktags 6 bis 9 Uhr alle 5 Minuten sind rund 800 im Monat. Die Adresse der Arbeit schlägt das Plugin dafür einmal bei OpenStreetMap nach.",
    "Cost: without a payment method Mapbox allows 10,000 travel time requests a month, with one 100,000 for free. Weekdays 6 to 9 every 5 minutes is about 800 a month. For this the plugin looks up the work address once at OpenStreetMap.",
    "Coste: sin método de pago Mapbox permite 10.000 consultas al mes, con método de pago 100.000 gratis. Días laborables de 6 a 9 cada 5 minutos son unas 800 al mes. Para ello el plugin busca una vez la dirección del trabajo en OpenStreetMap."],
  keySet: ["gespeichert – leer lassen, um ihn zu behalten", "saved – leave empty to keep it", "guardada: déjala vacía para conservarla"],
  forget: ["Schlüssel löschen", "Delete key", "Borrar clave"],
  routeTest: ["Fahrzeit jetzt abfragen", "Check travel time now", "Consultar tiempo de viaje"],
  asking: ["Frage …", "Asking …", "Consultando …"],
  googleHowTitle: ["So bekommst du den Google-Schlüssel (etwa 5 Minuten)", "How to get the Google key (about 5 minutes)", "Cómo obtener la clave de Google (unos 5 minutos)"],
  g1: ["Öffne die <a href=\"https://console.cloud.google.com/\" target=\"_blank\" rel=\"noopener\">Google Cloud Console</a> und melde dich mit deinem Google-Konto an. Lege ein neues Projekt an, z. B. „DynaFrame“.",
    "Open the <a href=\"https://console.cloud.google.com/\" target=\"_blank\" rel=\"noopener\">Google Cloud Console</a> and sign in with your Google account. Create a new project, e.g. “DynaFrame”.",
    "Abre la <a href=\"https://console.cloud.google.com/\" target=\"_blank\" rel=\"noopener\">Google Cloud Console</a> e inicia sesión con tu cuenta de Google. Crea un proyecto nuevo, p. ej. «DynaFrame»."],
  g2: ["Unter <b>Abrechnung</b> eine Zahlungsart hinterlegen. Google verlangt das, auch wenn du im Freikontingent bleibst.",
    "Add a payment method under <b>Billing</b>. Google requires this even if you stay within the free quota.",
    "Añade un método de pago en <b>Facturación</b>. Google lo exige aunque no superes la cuota gratuita."],
  g3: ["Unter <b>APIs &amp; Dienste &gt; Bibliothek</b> nach <b>Routes API</b> suchen und <b>Aktivieren</b> drücken.",
    "Under <b>APIs &amp; Services &gt; Library</b> search for <b>Routes API</b> and press <b>Enable</b>.",
    "En <b>APIs y servicios &gt; Biblioteca</b> busca <b>Routes API</b> y pulsa <b>Habilitar</b>."],
  g4: ["Unter <b>APIs &amp; Dienste &gt; Anmeldedaten</b> auf <b>Anmeldedaten erstellen &gt; API-Schlüssel</b> klicken.",
    "Under <b>APIs &amp; Services &gt; Credentials</b> click <b>Create credentials &gt; API key</b>.",
    "En <b>APIs y servicios &gt; Credenciales</b> pulsa <b>Crear credenciales &gt; Clave de API</b>."],
  g5: ["Den Schlüssel bearbeiten: bei <b>API-Einschränkungen</b> nur die <b>Routes API</b> erlauben. Dann kann er für nichts anderes benutzt werden.",
    "Edit the key: under <b>API restrictions</b> allow only the <b>Routes API</b>. Then it cannot be used for anything else.",
    "Edita la clave: en <b>Restricciones de API</b> permite solo <b>Routes API</b>. Así no sirve para nada más."],
  g6: ["Den Schlüssel kopieren und oben einfügen, dann „Fahrzeit jetzt abfragen“.",
    "Copy the key, paste it above, then “Check travel time now”.",
    "Copia la clave, pégala arriba y pulsa «Consultar tiempo de viaje»."],
  gCost: ["Kosten: Abfragen mit Verkehr zählen bei Google als „Compute Routes Pro“; davon sind mehrere Tausend im Monat frei. Werktags 6 bis 9 Uhr alle 5 Minuten sind rund 800 im Monat. Wer sicher gehen will, setzt in der Cloud Console ein Kontingent pro Tag.",
    "Cost: requests with traffic count as “Compute Routes Pro” at Google; several thousand of them are free each month. Weekdays 6 to 9 every 5 minutes is about 800 a month. To be safe, set a daily quota in the Cloud Console.",
    "Coste: las consultas con tráfico cuentan como «Compute Routes Pro» en Google; varios miles al mes son gratis. Días laborables de 6 a 9 cada 5 minutos son unas 800 al mes. Para ir sobre seguro, fija una cuota diaria en la Cloud Console."],
  arriveBy: ["Ankunft um (optional)", "Arrive by (optional)", "Llegada a las (opcional)"],
  trafficAlert: ["Hinweis bei Stau ab … Min. mehr (0 = nie)", "Alert on traffic from … min extra (0 = never)", "Aviso de atasco desde … min de más (0 = nunca)"],
  leaveReminder: ["„Zeit zum Losfahren“ … Min. vorher (0 = nie)", "“Time to leave” … min before (0 = never)", "«Hora de salir» … min antes (0 = nunca)"],
  routeMinutes: ["Fahrzeit abfragen alle … Min.", "Check travel time every … min", "Consultar el tiempo cada … min"],
  avoidTolls: ["Mautstraßen meiden", "Avoid toll roads", "Evitar peajes"],
  arriveHint: ["Mit „Ankunft um“ zeigt die Szene, bis wann du losfahren musst; der Hinweis „Zeit zum Losfahren“ holt sie dann von selbst auf den Bildschirm.",
    "With “Arrive by” the scene shows when you have to leave; the “Time to leave” alert then brings it onto the screen by itself.",
    "Con «Llegada a las» la escena muestra hasta cuándo debes salir; el aviso «Hora de salir» la lleva sola a la pantalla."],
  transitTitle: ["Bus und Bahn", "Bus and train", "Autobús y tren"],
  transitHint: ["Die Abfahrten kommen von der Deutschen Bahn und enthalten auch Busse, Straßen- und U-Bahnen. Kein Schlüssel nötig.",
    "Departures come from Deutsche Bahn and include buses, trams and underground. No key needed.",
    "Las salidas vienen de Deutsche Bahn e incluyen autobuses, tranvías y metro. No hace falta clave."],
  stop: ["Haltestelle", "Stop", "Parada"],
  noStop: ["– keine –", "– none –", "– ninguna –"],
  loadingStops: ["Lade Haltestellen …", "Loading stops …", "Cargando paradas …"],
  walk: ["Fußweg dorthin (Min.)", "Walk there (min)", "A pie hasta allí (min)"],
  lines: ["Nur diese Linien", "Only these lines", "Solo estas líneas"],
  linesHint: ["Ohne Auswahl werden alle Linien gezeigt. Die Liste füllt sich, sobald Abfahrten geladen sind.",
    "Without a selection all lines are shown. The list fills once departures are loaded.",
    "Sin selección se muestran todas las líneas. La lista se llena cuando se cargan las salidas."],
  directions: ["Nur Richtung (Wörter, durch Komma getrennt)", "Only direction (words, separated by commas)", "Solo dirección (palabras separadas por comas)"],
  transitAlert: ["Hinweis bei Ausfall oder Verspätung", "Alert on cancellation or delay", "Aviso de cancelación o retraso"],
  transitDelay: ["Verspätung ab … Min.", "Delay from … min", "Retraso desde … min"],
  transportAdv: ["Für Fortgeschrittene: eigener Abfahrtsdienst", "Advanced: own departure service", "Avanzado: servicio de salidas propio"],
  transportAdvHint: ["Standard: die Fahrplanauskunft von bahn.de, bei einer Störung v6.db.transport.rest. Hier lässt sich stattdessen eine eigene Instanz von transport.rest eintragen (z. B. selbst betrieben); dann fragt das Plugin nur diese.",
    "Default: the bahn.de journey planner, and v6.db.transport.rest if that fails. Enter your own transport.rest instance here instead (e.g. self-hosted); the plugin then only asks that one.",
    "Por defecto: el buscador de bahn.de y, si falla, v6.db.transport.rest. Aquí puedes poner tu propia instancia de transport.rest (p. ej. alojada por ti); entonces el plugin solo consulta esa."],
  fuelTitle: ["Spritpreise", "Fuel prices", "Precios del combustible"],
  fuelHint: ["Die Preise kommen von Tankerkönig (Markttransparenzstelle für Kraftstoffe). Dafür brauchst du einen kostenlosen Schlüssel.",
    "Prices come from Tankerkönig (German fuel market transparency unit). You need a free key for this.",
    "Los precios vienen de Tankerkönig (oficina alemana de transparencia de combustibles). Necesitas una clave gratuita."],
  tankerKey: ["Tankerkönig-Schlüssel", "Tankerkönig key", "Clave de Tankerkönig"],
  radius: ["Umkreis (km)", "Radius (km)", "Radio (km)"],
  fuelTest: ["Preise jetzt abfragen", "Check prices now", "Consultar precios"],
  tankerHowTitle: ["So bekommst du den Tankerkönig-Schlüssel", "How to get the Tankerkönig key", "Cómo obtener la clave de Tankerkönig"],
  t1: ["Auf <a href=\"https://onboarding.tankerkoenig.de/\" target=\"_blank\" rel=\"noopener\">onboarding.tankerkoenig.de</a> Name und E-Mail eintragen und den Nutzungsbedingungen zustimmen.",
    "On <a href=\"https://onboarding.tankerkoenig.de/\" target=\"_blank\" rel=\"noopener\">onboarding.tankerkoenig.de</a> enter your name and e-mail and accept the terms of use.",
    "En <a href=\"https://onboarding.tankerkoenig.de/\" target=\"_blank\" rel=\"noopener\">onboarding.tankerkoenig.de</a> introduce tu nombre y correo y acepta las condiciones de uso."],
  t2: ["Der Schlüssel kommt per E-Mail. Ihn kopieren und oben einfügen.", "The key arrives by e-mail. Copy it and paste it above.", "La clave llega por correo. Cópiala y pégala arriba."],
  tCost: ["Kostenlos für private Nutzung. Das Plugin fragt alle 10 Minuten, wie Tankerkönig es für Heimautomation erbittet.",
    "Free for private use. The plugin asks every 10 minutes, as Tankerkönig requests for home automation.",
    "Gratis para uso privado. El plugin consulta cada 10 minutos, como pide Tankerkönig para domótica."],
  fuelAlertTitle: ["Hinweis, wenn Sprit günstig ist", "Alert when fuel is cheap", "Aviso cuando el combustible está barato"],
  fuelBelowE5: ["Super E5 unter … € (leer = nie)", "Super E5 below … € (empty = never)", "Super E5 por debajo de … € (vacío = nunca)"],
  fuelBelowE10: ["Super E10 unter … € (leer = nie)", "Super E10 below … € (empty = never)", "Super E10 por debajo de … € (vacío = nunca)"],
  fuelBelowDiesel: ["Diesel unter … € (leer = nie)", "Diesel below … € (empty = never)", "Diésel por debajo de … € (vacío = nunca)"],
  fuelTypes: ["Sorten", "Fuel types", "Tipos"],
  fuelStationsTitle: ["Nur diese Tankstellen", "Only these stations", "Solo estas gasolineras"],
  fuelStationsHint: ["Ohne Auswahl zählen alle Tankstellen im Umkreis. Die Liste füllt sich, sobald Preise geladen sind.",
    "Without a selection all stations in the radius count. The list fills once prices have been loaded.",
    "Sin selección cuentan todas las gasolineras del radio. La lista se llena en cuanto se cargan los precios."],
  closed: ["zu", "closed", "cerrada"],
  stopQuery: ["Andere Haltestelle suchen …", "Search another stop …", "Buscar otra parada …"],
  search: ["Suchen", "Search", "Buscar"],
  stopsFound: ["{n} Haltestellen gefunden; wähle oben eine aus.", "{n} stops found; pick one above.", "{n} paradas encontradas; elige una arriba."],
  fuelAvgCents: ["oder … Cent unter dem Durchschnitt (0 = nie)", "or … cents below the average (0 = never)", "o … céntimos bajo la media (0 = nunca)"],
  fuelAvgDays: ["Durchschnitt der letzten … Tage", "Average of the last … days", "Media de los últimos … días"],
  fuelAvgHint: ["Den Durchschnitt rechnet das Plugin selbst aus den Preisen, die es tagsüber sieht; er steht nach zwei Tagen.",
    "The plugin works out the average itself from the prices it sees during the day; it is available after two days.",
    "El plugin calcula la media con los precios que ve durante el día; está disponible tras dos días."],
  weatherTitle: ["Regen, Warnungen und Nachrichten", "Rain, warnings and news", "Lluvia, avisos y noticias"],
  rain: ["Regen in den nächsten 2 Stunden (Regenradar des DWD)", "Rain in the next 2 hours (DWD rain radar)", "Lluvia en las próximas 2 horas (radar del DWD)"],
  warnings: ["Warnungen von DWD und NINA zeigen", "Show DWD and NINA warnings", "Mostrar avisos del DWD y de NINA"],
  warnLevel: ["Von selbst anzeigen ab", "Show by itself from", "Mostrar por sí sola desde"],
  lvl0: ["nie", "never", "nunca"],
  lvl2: ["Warnung (markantes Wetter)", "warning (significant weather)", "aviso (tiempo significativo)"],
  lvl3: ["Unwetter", "severe weather", "tiempo severo"],
  lvl4: ["extremes Unwetter", "extreme weather", "tiempo extremo"],
  news: ["Nachrichten als Laufband", "News ticker", "Noticias en cinta"],
  newsCustom: ["eigener RSS-Feed", "own RSS feed", "feed RSS propio"],
  newsOff: ["aus", "off", "desactivado"],
  newsUrl: ["Adresse des RSS-Feeds", "RSS feed address", "Dirección del feed RSS"],
  whenTitle: ["Wann auf den Bildschirm", "When on screen", "Cuándo en pantalla"],
  whenHint: ["Im Pendel-Zeitfenster fragt das Plugin Fahrzeit und Abfahrten ab und holt die Szene über die laufende Playlist. Außerhalb davon kommt sie nur bei Hinweisen (Sprit, Warnungen) oder wenn du sie in eine Playlist aufnimmst.",
    "During the commute window the plugin checks travel time and departures and brings the scene over the running playlist. Outside it, the scene only comes for alerts (fuel, warnings) or if you add it to a playlist.",
    "En el horario de trayecto el plugin consulta el tiempo de viaje y las salidas y muestra la escena sobre la lista en curso. Fuera de él, solo aparece con avisos (combustible, alertas) o si la añades a una lista."],
  from: ["Von", "From", "Desde"],
  to: ["Bis", "Until", "Hasta"],
  modeEvery: ["alle paar Minuten kurz", "briefly every few minutes", "brevemente cada pocos minutos"],
  modeAlways: ["die ganze Zeit", "the whole time", "todo el tiempo"],
  modeAlerts: ["nur bei Hinweisen", "only for alerts", "solo con avisos"],
  modeOff: ["nie von selbst", "never by itself", "nunca por sí sola"],
  every: ["Alle … Minuten", "Every … minutes", "Cada … minutos"],
  showFor: ["für … Sekunden", "for … seconds", "durante … segundos"],
  alertsTitle: ["Hinweise", "Alerts", "Avisos"],
  alertSeconds: ["Hinweis zeigen für … Sekunden", "Show an alert for … seconds", "Mostrar un aviso durante … segundos"],
  alertFrom: ["Hinweise und Abfragen ab … Uhr", "Alerts and checks from … o'clock", "Avisos y consultas desde las …"],
  alertTo: ["bis … Uhr", "until … o'clock", "hasta las …"],
  alertsHint: ["Stau und Ausfälle gibt es nur im Pendel-Zeitfenster, günstigen Sprit und Unwetter den ganzen Tag in diesen Stunden. Extremes Unwetter kommt immer. Ein ausgeschalteter Bildschirm wird nie geweckt.",
    "Traffic and cancellations only come during the commute window, cheap fuel and severe weather all day within these hours. Extreme weather always comes. A screen that is off is never woken.",
    "Atascos y cancelaciones solo en el horario de trayecto; combustible barato y tiempo severo todo el día en estas horas. El tiempo extremo siempre. Nunca se enciende una pantalla apagada."],
  playlist: ["Playlist „Pendler-Cockpit“ anlegen", "Create the “Pendler-Cockpit” playlist", "Crear la lista «Pendler-Cockpit»"],
  takeoverTitle: ["Wichtig", "Important", "Importante"],
  takeoverHint: ["Damit das Pendler-Cockpit von selbst auf den Bildschirm kommt, muss auf der Plugins-Seite des Rahmens <b>Allow takeover</b> eingeschaltet sein. Die Playlist „Pendler-Cockpit (takeover)“ benutzt das Plugin selbst; lass sie ausgeschaltet.",
    "For Pendler-Cockpit to come onto the screen by itself, <b>Allow takeover</b> must be switched on on the frame's Plugins page. The “Pendler-Cockpit (takeover)” playlist is used by the plugin itself; leave it switched off.",
    "Para que Pendler-Cockpit aparezca solo en la pantalla, <b>Allow takeover</b> debe estar activado en la página de plugins del marco. La lista «Pendler-Cockpit (takeover)» la usa el propio plugin; déjala desactivada."],
  creditHint: ["Daten: Google Maps oder Mapbox, Deutsche Bahn (bahn.de), Tankerkönig (CC BY 4.0), Deutscher Wetterdienst über Bright Sky, NINA (BBK), Autobahn GmbH, OpenStreetMap.",
    "Data: Google Maps or Mapbox, Deutsche Bahn (bahn.de), Tankerkönig (CC BY 4.0), Deutscher Wetterdienst via Bright Sky, NINA (BBK), Autobahn GmbH, OpenStreetMap.",
    "Datos: Google Maps o Mapbox, Deutsche Bahn (bahn.de), Tankerkönig (CC BY 4.0), Deutscher Wetterdienst vía Bright Sky, NINA (BBK), Autobahn GmbH, OpenStreetMap."],
  days: [["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"], ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"]],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time} h"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return typeof text === "string" ? text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? "")) : text;
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return false;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  renderDays();
  return true;
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setNote(id, text, tone = "") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}
const setStatus = (text, tone) => setNote("statusNote", text, tone);

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes, quiet = false) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    if (!quiet) setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function make(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === "class") node.className = value;
    else if (key === "text") node.textContent = value;
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else node[key] = value;
  }
  for (const child of children) if (child) node.append(child);
  return node;
}

// ---------------------------------------------------------------- Anzeige

function renderDays() {
  const box = el("days");
  const chosen = current ? current.settings.Days : [0, 1, 2, 3, 4];
  const names = t("days");
  box.replaceChildren(...names.map((name, i) => make("label", {}, [
    make("input", { type: "checkbox", checked: chosen.includes(i), onchange: saveDays, value: String(i) }),
    make("span", { text: name }),
  ])));
}

function saveDays() {
  const days = [...el("days").querySelectorAll("input:checked")].map((i) => Number(i.value));
  save({ Days: days });
}

let howtoSet = false;

const SOURCE_NAMES = { route: "srcRoute", departures: "srcDepartures", rain: "srcRain", weather: "srcWeather",
  dwd: "srcDwd", nina: "srcNina", fuel: "srcFuel", news: "srcNews" };

function renderStatus(state) {
  const s = state.settings;
  const window = `${s.From}–${s.To}`;
  el("factCommute").textContent = t(state.commute === "active" ? "commuteActive" : state.commute === "soon" ? "commuteSoon" : "commuteOff", { window });
  el("factCommute").className = state.commute === "active" ? "ok" : "";
  el("factScreen").textContent = state.showing ? t("showing", { time: clock(state.showingUntil) })
    : (state.nextAt ? t("nextAt", { time: clock(state.nextAt) }) : t("playlistRuns"));
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Dynaframe-Stuff/issues/new?title=" +
    encodeURIComponent(`[Pendler-Cockpit ${state.version}] `);
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;
  const notes = [state.note, state.lastError].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.lastError ? "bad" : "");

  const rows = Object.entries(SOURCE_NAMES).map(([key, label]) => {
    const row = state.sources[key] || {};
    const tone = row.error ? "bad" : row.at ? "ok" : "idle";
    let info = row.error || (row.at ? t("srcAt", { time: clock(row.at) }) : t("srcNever"));
    if (!row.active && !row.error) info = row.at ? `${t("srcAt", { time: clock(row.at) })} · ${t("srcIdle")}` : t("srcIdle");
    return make("li", {}, [make("span", { class: `dot ${row.active || row.error ? tone : "idle"}` }),
      make("span", { class: "name", text: t(label, { by: state.secrets.MapboxKey && !state.secrets.GoogleKey ? "Mapbox" : "Google" }) }), make("span", { class: `info ${row.error ? "bad" : ""}`, text: info })]);
  });
  el("sourceList").replaceChildren(...rows);

  el("recentList").replaceChildren(...(state.alerts.length ? state.alerts.map((a) => make("li", {}, [
    make("span", { class: "time", text: clock(a.at) }),
    make("span", { class: "what", text: a.title }),
    a.text ? make("span", { class: "text", text: a.text }) : null,
  ])) : [make("li", { class: "empty", text: t("noRecent") })]));
}

function renderStops(s) {
  const select = el("StopId");
  const list = stops || [];
  const options = [make("option", { value: "", text: t("noStop") })];
  let found = !s.StopId;
  for (const stop of list) {
    options.push(make("option", { value: stop.id, text: stop.meters != null ? `${stop.name} · ${stop.meters} m` : stop.name }));
    if (stop.id === s.StopId) found = true;
  }
  if (!found) options.push(make("option", { value: s.StopId, text: s.StopName || s.StopId }));
  select.replaceChildren(...options);
  select.value = s.StopId || "";
}

const FUEL_NAMES = { e5: "Super E5", e10: "Super E10", diesel: "Diesel" };

function chosenFuels(s) {
  return s.Fuels && s.Fuels.length ? s.Fuels : [s.Fuel];
}

function renderFuels(state) {
  const s = state.settings;
  const chosen = new Set(chosenFuels(s));
  el("fuelList").replaceChildren(...Object.entries(FUEL_NAMES).map(([id, name]) => make("label", {}, [
    make("input", { type: "checkbox", checked: chosen.has(id), value: id, onchange: saveFuels }),
    make("span", { text: name }),
  ])));
  for (const field of document.querySelectorAll("[data-fuel]")) field.hidden = !chosen.has(field.dataset.fuel);
  const picked = new Set(s.FuelStations);
  const list = [...state.fuelStations];
  for (const id of picked) if (!list.some((x) => x.id === id)) list.push({ id, brand: id.slice(0, 8), place: "", km: null, prices: {} });
  el("stationList").replaceChildren(...list.map((x) => {
    const prices = [...chosen].filter((f) => x.prices[f]).map((f) => `${FUEL_NAMES[f].replace("Super ", "")} ${String(x.prices[f].toFixed(3)).replace(".", lang === "en" ? "." : ",")}`);
    return make("label", {}, [
      make("input", { type: "checkbox", checked: picked.has(x.id), value: x.id, onchange: saveStations }),
      make("span", {}, [make("span", { text: x.brand }),
        make("span", { class: "dirs", text: [x.place, x.km != null ? `${String(x.km).replace(".", lang === "en" ? "." : ",")} km` : "", x.open === false ? t("closed") : "", ...prices].filter(Boolean).join(" · ") })]),
    ]);
  }));
}

function saveFuels() {
  const fuels = [...el("fuelList").querySelectorAll("input:checked")].map((i) => i.value);
  if (!fuels.length) {
    refresh();
    return;  // mindestens eine Sorte
  }
  save({ Fuels: fuels });
}

function saveStations() {
  save({ FuelStations: [...el("stationList").querySelectorAll("input:checked")].map((i) => i.value) });
}

async function searchStops() {
  const q = el("stopQuery").value.trim();
  if (!q) return;
  setNote("stopNote", t("asking"));
  try {
    const found = (await api("./api/stop-search", { method: "POST", body: JSON.stringify({ q }) })).stops;
    const near = (stops || []).filter((x) => !found.some((f) => f.id === x.id));
    stops = [...found, ...near];
    if (current) renderStops(current.settings);
    setNote("stopNote", t("stopsFound", { n: found.length }), "ok");
    el("StopId").focus();
  } catch (error) {
    setNote("stopNote", error.message, "bad");
  }
}

function renderLines(state) {
  const chosen = new Set(state.settings.Lines);
  const lines = [...state.lines];
  for (const name of chosen) if (!lines.some((l) => l.line === name)) lines.push({ line: name, kind: "", directions: [] });
  el("lineList").replaceChildren(...lines.map((l) => make("label", {}, [
    make("input", { type: "checkbox", checked: chosen.has(l.line), value: l.line, onchange: saveLines }),
    make("span", {}, [make("span", {}, [make("span", { class: `line-badge ${l.kind}`, text: l.line })]),
      make("span", { class: "dirs", text: l.directions.slice(0, 3).join(" · ") })]),
  ])));
}

function saveLines() {
  save({ Lines: [...el("lineList").querySelectorAll("input:checked")].map((i) => i.value) });
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  const languageChanged = applyLanguage(s.Language);
  renderStatus(state);
  el("afterHome").classList.toggle("locked", s.HomeLat == null);
  if (!editing) {
    for (const node of document.querySelectorAll("[data-setting]")) {
      const name = node.dataset.setting;
      if (document.activeElement === node) continue;
      if (node.type === "checkbox") node.checked = Boolean(s[name]);
      else if ("secret" in node.dataset) {
        node.value = "";
        node.placeholder = state.secrets[name] ? t("keySet") : "";
      } else if ("price" in node.dataset) node.value = s[name] ? String(s[name]).replace(".", lang === "en" ? "." : ",") : "";
      else node.value = s[name] ?? "";
    }
    if (document.activeElement !== el("Home")) el("Home").value = s.Home || "";
    for (const radio of document.querySelectorAll('input[name="ShowMode"]')) radio.checked = radio.value === s.ShowMode;
    renderDays();
  }
  if (s.HomeName && !el("homeNote").textContent) setNote("homeNote", t("homeFound", { name: s.HomeName }), "ok");
  const anyKey = state.secrets.GoogleKey || state.secrets.MapboxKey;
  // Die Anleitung nur beim ersten Laden aufklappen, danach entscheidet der Nutzer.
  if (!howtoSet) {
    howtoSet = true;
    el("mapboxHowto").open = !anyKey && Boolean(s.Work);
  }
  el("providerNote").textContent = state.secrets.GoogleKey && state.secrets.MapboxKey ? t("providerBoth")
    : state.secrets.GoogleKey ? t("providerGoogle") : state.secrets.MapboxKey ? t("providerMapbox") : "";
  el("newsUrlField").hidden = s.News !== "custom";
  el("everyFields").hidden = s.ShowMode !== "every";
  for (const button of document.querySelectorAll("[data-forget]")) button.hidden = !state.secrets[button.dataset.forget];
  renderStops(s);
  renderLines(state);
  renderFuels(state);
  if (s.HomeLat != null && (stops === null || languageChanged)) loadStops();
}

let loadingStops = false;
async function loadStops() {
  if (loadingStops) return;
  loadingStops = true;
  stops = [];
  try {
    stops = (await api("./api/stops")).stops;
    setNote("stopNote", "");
  } catch (error) {
    setNote("stopNote", error.message, "bad");
  } finally {
    loadingStops = false;
    if (current) renderStops(current.settings);
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

// ---------------------------------------------------------------- Eingaben

for (const node of document.querySelectorAll("[data-setting]")) {
  const name = node.dataset.setting;
  node.addEventListener("focus", () => { editing = true; });
  node.addEventListener("blur", () => { editing = false; });
  node.addEventListener("change", () => {
    let value = node.type === "checkbox" ? node.checked : node.value;
    if (node.type === "number" || name === "WarnAlertLevel") value = Number(value);
    if ("price" in node.dataset) value = String(value).replace(",", ".");
    if ("secret" in node.dataset && !String(value).trim()) return;
    if (name === "Language") applyLanguage(value);
    save({ [name]: value }).then(() => { if ("secret" in node.dataset) node.value = ""; });
  });
}
for (const radio of document.querySelectorAll('input[name="ShowMode"]')) {
  radio.addEventListener("change", () => save({ ShowMode: radio.value }));
}
el("StopId").addEventListener("change", (e) => {
  const stop = (stops || []).find((s) => s.id === e.target.value);
  const changes = { StopId: e.target.value, StopName: stop ? stop.name : "", Lines: [] };
  if (stop && stop.meters != null) changes.WalkMinutes = Math.max(1, Math.round(stop.meters / 80));
  save(changes);
});
for (const button of document.querySelectorAll("[data-forget]")) {
  button.addEventListener("click", async () => {
    await api("./api/forget", { method: "POST", body: JSON.stringify({ name: button.dataset.forget }) }).catch(() => {});
    refresh();
  });
}

el("stopSearch").addEventListener("click", searchStops);
el("stopQuery").addEventListener("keydown", (e) => { if (e.key === "Enter") searchStops(); });
el("stopQuery").addEventListener("focus", () => { editing = true; });
el("stopQuery").addEventListener("blur", () => { editing = false; });
el("Home").addEventListener("keydown", (e) => { if (e.key === "Enter") el("homeButton").click(); });
el("Home").addEventListener("focus", () => { editing = true; });
el("Home").addEventListener("blur", () => { editing = false; });
el("homeButton").addEventListener("click", async () => {
  const button = el("homeButton");
  button.disabled = true;
  setNote("homeNote", t("finding"), "busy");
  try {
    const result = await api("./api/home", { method: "POST", body: JSON.stringify({ Home: el("Home").value.trim() }) });
    setNote("homeNote", result.message, "ok");
    stops = result.stops || null;
    editing = false;
    await refresh();
  } catch (error) {
    setNote("homeNote", error.message, "bad");
  } finally {
    button.disabled = false;
  }
});

async function runTest(buttonId, noteId, path) {
  const button = el(buttonId);
  button.disabled = true;
  setNote(noteId, t("asking"), "busy");
  try {
    const result = await api(path, { method: "POST" });
    setNote(noteId, result.message || "", "ok");
  } catch (error) {
    setNote(noteId, error.message, "bad");
  } finally {
    button.disabled = false;
    refresh();
  }
}
el("routeButton").addEventListener("click", () => runTest("routeButton", "routeNote", "./api/route-test"));
el("fuelButton").addEventListener("click", () => runTest("fuelButton", "fuelNote", "./api/fuel-test"));
el("playlistButton").addEventListener("click", () => runTest("playlistButton", "playlistNote", "./api/playlist"));

for (const [id, path] of [["showButton", "test"], ["cancelButton", "cancel"], ["refreshButton", "refresh"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(`./api/${path}`, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}

renderDays();
refresh();
setInterval(refresh, 5000);
