"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Außerhalb des Zeitfensters ({start}–{end} Uhr).": (
        "Outside the commute window ({start}–{end}).", "Fuera del horario de trayecto ({start}–{end})."),
    "Bitte den Rahmen um den Bildschirm.": ("Asking the frame for the screen.", "Pidiendo la pantalla al marco."),
    "Das Kontingent bei Google ist erschöpft.": ("The Google quota is used up.", "La cuota de Google está agotada."),
    "Der Abfahrtsdienst antwortet mit Fehler {code}. Meist ist das nach kurzer Zeit vorbei.": (
        "The departure service answers with error {code}. This usually passes after a short while.",
        "El servicio de salidas responde con el error {code}. Suele pasar al poco rato."),
    "Der Bildschirm ist aus. Pendler-Cockpit weckt ihn nicht.": (
        "The screen is off. Pendler-Cockpit does not wake it.", "La pantalla está apagada. Pendler-Cockpit no la enciende."),
    "Der Dienst antwortet mit Fehler {code}.": ("The service answers with error {code}.",
                                               "El servicio responde con el error {code}."),
    "Der Dienst hat etwas Unerwartetes geschickt.": ("The service sent something unexpected.",
                                                     "El servicio ha enviado algo inesperado."),
    "Der Dienst ist gerade nicht erreichbar.": ("The service cannot be reached right now.",
                                                "El servicio no está disponible ahora."),
    "Der Rahmen hat Pendler-Cockpit nicht rechtzeitig angezeigt.": (
        "The frame did not show Pendler-Cockpit in time.", "El marco no ha mostrado Pendler-Cockpit a tiempo."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.", "El marco no ha creado la lista {name}."),
    "Der Rahmen ist nach dem Pendler-Cockpit nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.": (
        "After Pendler-Cockpit the frame did not return to your playlist. Restart it on the frame's home page. "
        "This does not happen with a saved playlist instead of a Quick Mix.",
        "Tras Pendler-Cockpit el marco no ha vuelto a tu lista. Iníciala de nuevo en la página principal del marco. "
        "Con una lista guardada en lugar de un Quick Mix no pasa."),
    "Das Kontingent bei Mapbox ist erschöpft.": ("The Mapbox quota is used up.", "La cuota de Mapbox está agotada."),
    "Die Adresse der Arbeit wurde nicht gefunden. Versuch es mit Straße, Hausnummer und Ort.": (
        "The work address was not found. Try street, house number and town.",
        "No se ha encontrado la dirección del trabajo. Prueba con calle, número y localidad."),
    "Mapbox erlaubt diesem Schlüssel die Abfrage nicht. Prüfe die Einschränkungen des Schlüssels.": (
        "Mapbox does not allow this request for this key. Check the key's restrictions.",
        "Mapbox no permite esta consulta con esta clave. Revisa las restricciones de la clave."),
    "Mapbox findet keine Route zwischen den beiden Adressen.": (
        "Mapbox finds no route between the two addresses.", "Mapbox no encuentra ruta entre las dos direcciones."),
    "Mapbox nimmt den Schlüssel nicht an. Prüfe, ob er vollständig kopiert ist.": (
        "Mapbox does not accept the key. Check that it was copied completely.",
        "Mapbox no acepta la clave. Comprueba que se ha copiado entera."),
    "Gib einen Namen ein, z. B. „Bad Homburg Bahnhof“.": (
        "Enter a name, e.g. “Bad Homburg Bahnhof”.", "Escribe un nombre, p. ej. «Bad Homburg Bahnhof»."),
    "Keine Haltestelle mit diesem Namen gefunden.": ("No stop found with this name.",
                                                     "No se ha encontrado ninguna parada con ese nombre."),
    "In 2 km Umkreis wurde keine Haltestelle gefunden. Such sie darunter nach Namen.": (
        "No stop found within 2 km. Search for it by name below.",
        "No hay ninguna parada en 2 km. Búscala por nombre abajo."),
    "Die Daten werden neu geladen.": ("Reloading the data.", "Recargando los datos."),
    "Die Playlist {name} gibt es schon.": ("The playlist {name} already exists.", "La lista {name} ya existe."),
    "Die Routes API ist für diesen Schlüssel nicht aktiviert. Aktiviere sie in der Google Cloud Console.": (
        "The Routes API is not enabled for this key. Enable it in the Google Cloud Console.",
        "La Routes API no está habilitada para esta clave. Habilítala en la Google Cloud Console."),
    "Die Szene Pendler-Cockpit ist auf der Plugins-Seite ausgeschaltet.": (
        "The Pendler-Cockpit scene is switched off on the Plugins page.",
        "La escena Pendler-Cockpit está desactivada en la página de plugins."),
    "Die Szene Pendler-Cockpit ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The Pendler-Cockpit scene is not installed on this frame. Install the package again.",
        "La escena Pendler-Cockpit no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Szene Pendler-Cockpit wurde nicht gefunden.": ("The Pendler-Cockpit scene was not found.",
                                                        "No se ha encontrado la escena Pendler-Cockpit."),
    "Die Takeover-Playlist ist noch nicht angelegt.": ("The takeover playlist has not been created yet.",
                                                       "La lista de takeover aún no está creada."),
    "Die sichere Verbindung zum Dienst ist fehlgeschlagen. Stimmt die Uhrzeit des Rahmens?": (
        "The secure connection to the service failed. Is the frame's clock right?",
        "Ha fallado la conexión segura con el servicio. ¿Está bien la hora del marco?"),
    "Diese Adresse wurde nicht gefunden. Versuch es mit Straße, Hausnummer und Ort.": (
        "This address was not found. Try street, house number and town.",
        "No se ha encontrado esta dirección. Prueba con calle, número y localidad."),
    "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.": (
        "This frame is too old to hand the screen to a plugin.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "Etwas anderes hat gerade den Bildschirm.": ("Something else has the screen right now.",
                                                 "Otra cosa tiene la pantalla ahora mismo."),
    "Fahrzeit, Abfahrten, Regen, Sprit und Nachrichten.": (
        "Travel time, departures, rain, fuel and news.", "Tiempo de viaje, salidas, lluvia, combustible y noticias."),
    "Fällt aus: {name}": ("Cancelled: {name}", "Cancelado: {name}"),
    "Gebe den Bildschirm zurück.": ("Handing the screen back.", "Devolviendo la pantalla."),
    "Gefunden: {name}": ("Found: {name}", "Encontrado: {name}"),
    "Gerade hält etwas den Bildschirm. Versuch es gleich noch einmal.": (
        "Something is holding the screen right now. Try again in a moment.",
        "Algo tiene la pantalla ahora. Inténtalo de nuevo en un momento."),
    "Google erlaubt diesem Schlüssel die Routes API nicht. Prüfe die Einschränkungen des Schlüssels.": (
        "Google does not allow the Routes API for this key. Check the key's restrictions.",
        "Google no permite la Routes API con esta clave. Revisa las restricciones de la clave."),
    "Google findet keine Route zwischen den beiden Adressen.": (
        "Google finds no route between the two addresses.", "Google no encuentra ruta entre las dos direcciones."),
    "Google nimmt den Schlüssel nicht an. Prüfe, ob er vollständig kopiert ist.": (
        "Google does not accept the key. Check that it was copied completely.",
        "Google no acepta la clave. Comprueba que se ha copiado entera."),
    "Google verlangt für das Projekt eine Zahlungsart. Hinterlege sie in der Google Cloud Console.": (
        "Google requires a payment method for the project. Add one in the Google Cloud Console.",
        "Google exige un método de pago para el proyecto. Añádelo en la Google Cloud Console."),
    "Jetzt {min} Min. ({km} km), ohne Verkehr {normal} Min.": (
        "Now {min} min ({km} km), without traffic {normal} min.",
        "Ahora {min} min ({km} km), sin tráfico {normal} min."),
    "Konnte Pendler-Cockpit nicht anzeigen: {exc}": ("Could not show Pendler-Cockpit: {exc}",
                                                     "No se ha podido mostrar Pendler-Cockpit: {exc}"),
    "Konnte die Playlist nicht anlegen: {exc}": ("Could not create the playlist: {exc}",
                                                 "No se ha podido crear la lista: {exc}"),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": ("Could not create the takeover playlist: {exc}",
                                                          "No se ha podido crear la lista de takeover: {exc}"),
    "Noch nichts eingerichtet.": ("Nothing set up yet.", "Aún no hay nada configurado."),
    "Nächste Haltestelle: {stop}.": ("Nearest stop: {stop}.", "Parada más cercana: {stop}."),
    "Pendler-Cockpit hatte den Bildschirm nicht.": ("Pendler-Cockpit did not have the screen.",
                                                    "Pendler-Cockpit no tenía la pantalla."),
    "Pendler-Cockpit ist auf der Plugins-Seite ausgeschaltet.": (
        "Pendler-Cockpit is switched off on the Plugins page.",
        "Pendler-Cockpit está desactivado en la página de plugins."),
    "Pendler-Cockpit ist schon auf dem Bildschirm.": ("Pendler-Cockpit is already on screen.",
                                                      "Pendler-Cockpit ya está en pantalla."),
    "Pendler-Cockpit läuft gerade in deiner Playlist; die Anzeige bleibt so.": (
        "Pendler-Cockpit is playing in your playlist right now; the screen stays as it is.",
        "Pendler-Cockpit se está mostrando en tu lista; la pantalla se queda así."),
    "Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens oder nimm die Szene in eine andere Playlist auf.": (
        "Playlist {name} created. Start it on the frame's home page, or add the scene to another playlist.",
        "Lista {name} creada. Iníciala en la página principal del marco o añade la escena a otra lista."),
    "Regelmäßige Anzeige ist aus.": ("Regular display is off.", "La visualización periódica está desactivada."),
    "Spätestens um {time} los, um {arrive} da zu sein.": (
        "Leave by {time} to arrive by {arrive}.", "Sal antes de las {time} para llegar a las {arrive}."),
    "Stau auf dem Weg zur Arbeit": ("Traffic on the way to work", "Atasco de camino al trabajo"),
    "Tankerkönig hat die Anfrage abgelehnt.": ("Tankerkönig refused the request.", "Tankerkönig ha rechazado la consulta."),
    "Tankerkönig nimmt den Schlüssel nicht an.": ("Tankerkönig does not accept the key.", "Tankerkönig no acepta la clave."),
    "Trage Wohnort, Arbeit und einen Schlüssel von Google oder Mapbox ein.": (
        "Enter your home, your work and a Google or Mapbox key.",
        "Introduce el domicilio, el trabajo y una clave de Google o Mapbox."),
    "Trage den Google-Schlüssel ein.": ("Enter the Google key.", "Introduce la clave de Google."),
    "Trage zuerst deinen Wohnort ein.": ("First enter your home address.", "Introduce primero tu domicilio."),
    "Trage zuerst deinen Wohnort und den Tankerkönig-Schlüssel ein.": (
        "First enter your home address and the Tankerkönig key.",
        "Introduce primero tu domicilio y la clave de Tankerkönig."),
    "Zeit zum Losfahren": ("Time to leave", "Hora de salir"),
    "Zu viele Anfragen; es geht gleich von selbst weiter.": (
        "Too many requests; it carries on by itself shortly.", "Demasiadas consultas; seguirá sola en breve."),
    "{fuel} unter {limit} €": ("{fuel} below €{limit}", "{fuel} por debajo de {limit} €"),
    "{fuel} {cents} ct unter dem Schnitt": ("{fuel} {cents} ct below average", "{fuel} {cents} ct bajo la media"),
    "{min} Min. später: {name}": ("{min} min late: {name}", "{min} min de retraso: {name}"),
    "{min} Min. statt {normal} Min.": ("{min} min instead of {normal} min", "{min} min en lugar de {normal} min"),
    "{n} Tankstellen im Umkreis, am günstigsten {price} €.": (
        "{n} stations nearby, cheapest €{price}.", "{n} gasolineras cerca, la más barata a {price} €."),
    "„Allow takeover“ ist für Pendler-Cockpit auf der Plugins-Seite aus. Schalte es ein, sonst kommt die Szene nicht von selbst auf den Bildschirm.": (
        "“Allow takeover” is off for Pendler-Cockpit on the Plugins page. Switch it on, otherwise the scene "
        "cannot come onto the screen by itself.",
        "«Allow takeover» está desactivado para Pendler-Cockpit en la página de plugins. Actívalo; si no, la "
        "escena no puede aparecer sola en la pantalla."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
