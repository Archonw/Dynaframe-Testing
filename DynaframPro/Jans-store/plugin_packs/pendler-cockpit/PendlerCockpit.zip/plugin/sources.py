"""Die Datenquellen des Pendler-Cockpits.

Jede Funktion holt genau eine Sache und gibt ein schlichtes dict zurück, das
die Szene so verwenden kann. Fehler kommen als SourceError mit einem kurzen
Code, den plugin.py in einen Satz für die Plugin-Seite übersetzt.

- Fahrzeit:    Google Routes API oder Mapbox Directions (je eigener Schlüssel),
               mit und ohne Verkehr.
- Abfahrten:   Transitous (offener Fahrplandienst auf Basis von MOTIS, alle Busse
               und Bahnen mit Echtzeit, ohne Schlüssel); wahlweise
               v6.db.transport.rest oder eine andere Instanz.
- Spritpreise: Tankerkönig (freier Schlüssel, Daten CC BY 4.0, MTS-K).
- Regen:       Bright Sky /radar, das Regenradar des DWD mit 2 Stunden Vorhersage.
- Wetter:      Bright Sky /current_weather.
- Warnungen:   Bright Sky /alerts (DWD) und NINA (warnung.bund.de) für den Ort.
- Autobahn:    Verkehrsmeldungen und Sperrungen der Autobahn GmbH entlang der Route.
- Nachrichten: ein RSS-Feed, Standard tagesschau.de.
- Adresse:     Nominatim (OpenStreetMap) macht aus dem Wohnort Koordinaten.

Für Tests lassen sich alle Adressen über Umgebungsvariablen umbiegen
(PC_GOOGLE_URL, PC_MAPBOX_URL, PC_TRANSITOUS_URL, PC_TRANSPORT_URL, PC_TANKER_URL, PC_BRIGHTSKY_URL, PC_NINA_URL,
PC_AUTOBAHN_URL, PC_NOMINATIM_URL).
"""

import math
import os
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime

import requests

USER_AGENT = "DynaFrame-PendlerCockpit/0.5 (+https://github.com/Archonw/Dynaframe-Stuff)"
TIMEOUT = (8, 20)

GOOGLE_URL = os.environ.get("PC_GOOGLE_URL", "https://routes.googleapis.com/directions/v2:computeRoutes")
MAPBOX_URL = os.environ.get("PC_MAPBOX_URL", "https://api.mapbox.com/directions/v5/mapbox/driving-traffic")
TRANSITOUS_URL = os.environ.get("PC_TRANSITOUS_URL", "https://api.transitous.org/api")
TRANSPORT_URL = os.environ.get("PC_TRANSPORT_URL", "https://v6.db.transport.rest")
TANKER_URL = os.environ.get("PC_TANKER_URL", "https://creativecommons.tankerkoenig.de/json")
BRIGHTSKY_URL = os.environ.get("PC_BRIGHTSKY_URL", "https://api.brightsky.dev")
NINA_URL = os.environ.get("PC_NINA_URL", "https://warnung.bund.de/api31")
AUTOBAHN_URL = os.environ.get("PC_AUTOBAHN_URL", "https://verkehr.autobahn.de/o/autobahn")
NOMINATIM_URL = os.environ.get("PC_NOMINATIM_URL", "https://nominatim.openstreetmap.org")

NEWS_FEEDS = {
    "tagesschau": "https://www.tagesschau.de/index~rss2.xml",
    "bbc": "https://feeds.bbci.co.uk/news/world/rss.xml",
    "elpais": "https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada",
}


class SourceError(Exception):
    """code ist kurz und maschinenlesbar, z. B. "key", "quota", "http:503"."""

    def __init__(self, code, detail=""):
        super().__init__(code if not detail else f"{code}: {detail}")
        self.code = code
        self.detail = detail


def _session():
    session = requests.Session()
    session.headers["User-Agent"] = USER_AGENT
    return session


_http = _session()


def _get(url, params=None, headers=None, expect="json"):
    try:
        response = _http.get(url, params=params, headers=headers, timeout=TIMEOUT)
    except requests.exceptions.SSLError as exc:
        raise SourceError("ssl", str(exc)) from exc
    except requests.RequestException as exc:
        raise SourceError("unreachable", str(exc)) from exc
    if response.status_code in (401, 403):
        raise SourceError("key", f"HTTP {response.status_code}")
    if response.status_code == 429:
        raise SourceError("quota", "HTTP 429")
    if response.status_code >= 400:
        raise SourceError(f"http:{response.status_code}")
    if expect == "text":
        return response.content
    try:
        return response.json()
    except ValueError as exc:
        raise SourceError("format", "keine JSON-Antwort") from exc


def utc_now():
    return datetime.now(timezone.utc)


def parse_time(value):
    """ISO-Zeit (mit Z oder Offset) -> Epoche, sonst None."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def seconds_of(value):
    """Google schreibt Dauern als "1834s"."""
    match = re.match(r"^\s*(\d+(?:\.\d+)?)s\s*$", str(value or ""))
    return round(float(match.group(1))) if match else None


# --------------------------------------------------------------------------
# Geometrie
# --------------------------------------------------------------------------

def distance_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def decode_polyline(encoded):
    """Googles Encoded Polyline -> [(lat, lon)]."""
    points, index, lat, lon = [], 0, 0, 0
    encoded = encoded or ""
    while index < len(encoded):
        values = []
        for _ in range(2):
            shift = result = 0
            while True:
                if index >= len(encoded):
                    return points
                byte = ord(encoded[index]) - 63
                index += 1
                result |= (byte & 0x1F) << shift
                shift += 5
                if byte < 0x20:
                    break
            values.append(~(result >> 1) if result & 1 else result >> 1)
        lat += values[0]
        lon += values[1]
        points.append((lat / 1e5, lon / 1e5))
    return points


def distance_to_line_km(lat, lon, line):
    """Kleinster Abstand eines Punkts zu einem Linienzug, flach gerechnet
    (für ein paar Kilometer genau genug)."""
    if not line:
        return float("inf")
    kx = 111.32 * math.cos(math.radians(lat))
    ky = 110.57
    best = float("inf")
    px, py = lon * kx, lat * ky
    prev = None
    for la, lo in line:
        cur = (lo * kx, la * ky)
        if prev is None:
            best = min(best, math.hypot(cur[0] - px, cur[1] - py))
        else:
            ax, ay = prev
            bx, by = cur
            dx, dy = bx - ax, by - ay
            length = dx * dx + dy * dy
            t = 0.0 if length == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / length))
            best = min(best, math.hypot(ax + t * dx - px, ay + t * dy - py))
        prev = cur
    return best


def point_in_ring(lat, lon, ring):
    """ring: [[lon, lat], ...] wie in GeoJSON."""
    inside = False
    j = len(ring) - 1
    for i in range(len(ring)):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def point_in_geometry(lat, lon, geometry):
    if not isinstance(geometry, dict):
        return False
    kind = geometry.get("type")
    coords = geometry.get("coordinates") or []
    if kind == "Polygon":
        polygons = [coords]
    elif kind == "MultiPolygon":
        polygons = coords
    elif kind == "GeometryCollection":
        return any(point_in_geometry(lat, lon, g) for g in geometry.get("geometries") or [])
    else:
        return False
    for polygon in polygons:
        if polygon and point_in_ring(lat, lon, polygon[0]) and \
                not any(point_in_ring(lat, lon, hole) for hole in polygon[1:]):
            return True
    return False


# --------------------------------------------------------------------------
# Adresse -> Koordinaten (Nominatim, nur auf Knopfdruck)
# --------------------------------------------------------------------------

LATLON = re.compile(r"^\s*(-?\d{1,2}(?:\.\d+)?)\s*[,; ]\s*(-?\d{1,3}(?:\.\d+)?)\s*$")


def geocode(address, language="de"):
    """{"lat", "lon", "name"} für eine Adresse. "50.11, 8.68" geht auch."""
    address = str(address or "").strip()
    if not address:
        raise SourceError("no-address")
    match = LATLON.match(address)
    if match:
        lat, lon = float(match.group(1)), float(match.group(2))
        return {"lat": lat, "lon": lon, "name": f"{lat:.4f}, {lon:.4f}"}
    rows = _get(f"{NOMINATIM_URL}/search", params={"q": address, "format": "jsonv2", "limit": 1,
                                                    "accept-language": language})
    if not isinstance(rows, list) or not rows:
        raise SourceError("not-found")
    row = rows[0]
    try:
        return {"lat": float(row["lat"]), "lon": float(row["lon"]),
                "name": str(row.get("display_name") or address)[:160]}
    except (KeyError, TypeError, ValueError) as exc:
        raise SourceError("format") from exc


# --------------------------------------------------------------------------
# Fahrzeit (Google Routes API)
# --------------------------------------------------------------------------

ROUTE_FIELDS = ",".join([
    "routes.duration", "routes.staticDuration", "routes.distanceMeters", "routes.description",
    "routes.polyline.encodedPolyline", "routes.routeLabels", "routes.warnings",
])
ROAD = re.compile(r"\bA\s?(\d{1,3})\b")


def route(key, origin, destination, language="de", avoid_tolls=False):
    """Fahrzeit jetzt (mit Verkehr) und normal (ohne), für die schnellste
    Route und bis zu zwei Alternativen.

    Abgerechnet wird bei Google als "Compute Routes Pro" (wegen der
    Verkehrsdaten); das monatliche Freikontingent reicht für einen Rahmen,
    der morgens alle paar Minuten fragt, locker aus."""
    if not key:
        raise SourceError("no-key")
    body = {
        "origin": {"address": origin},
        "destination": {"address": destination},
        "travelMode": "DRIVE",
        "routingPreference": "TRAFFIC_AWARE",
        "computeAlternativeRoutes": True,
        "languageCode": {"de": "de-DE", "en": "en-GB", "es": "es-ES"}.get(language, "de-DE"),
        "units": "METRIC",
    }
    if avoid_tolls:
        body["routeModifiers"] = {"avoidTolls": True}
    headers = {"Content-Type": "application/json", "X-Goog-Api-Key": key, "X-Goog-FieldMask": ROUTE_FIELDS}
    try:
        response = _http.post(GOOGLE_URL, json=body, headers=headers, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise SourceError("unreachable", str(exc)) from exc
    try:
        payload = response.json()
    except ValueError:
        payload = {}
    if response.status_code >= 400 or "error" in payload:
        error = payload.get("error") or {}
        reasons = " ".join(str(d.get("reason") or "") for d in error.get("details") or [] if isinstance(d, dict))
        message = str(error.get("message") or "")
        status = str(error.get("status") or "")
        if "API_KEY" in reasons or "API key not valid" in message:
            raise SourceError("key", message)
        if "SERVICE_DISABLED" in reasons or "has not been used" in message or "disabled" in message:
            raise SourceError("disabled", message)
        if "BILLING" in reasons or "billing" in message.lower():
            raise SourceError("billing", message)
        if status == "RESOURCE_EXHAUSTED" or response.status_code == 429:
            raise SourceError("quota", message)
        if status == "PERMISSION_DENIED":
            raise SourceError("denied", message)
        raise SourceError(f"http:{response.status_code}", message)
    routes = []
    for row in payload.get("routes") or []:
        traffic = seconds_of(row.get("duration"))
        if traffic is None:
            continue
        normal = seconds_of(row.get("staticDuration")) or traffic
        description = str(row.get("description") or "")
        routes.append({
            "seconds": traffic,
            "normalSeconds": normal,
            "meters": int(row.get("distanceMeters") or 0),
            "via": description[:60],
            "roads": sorted({f"A{n}" for n in ROAD.findall(description)}, key=lambda r: int(r[1:])),
            "polyline": (row.get("polyline") or {}).get("encodedPolyline") or "",
            "labels": row.get("routeLabels") or [],
        })
    if not routes:
        raise SourceError("no-route")
    routes.sort(key=lambda r: r["seconds"])
    return {"routes": routes[:3]}


def route_mapbox(token, origin, destination, language="de", avoid_tolls=False):
    """Wie route(), nur über Mapbox (Profil driving-traffic), so wie es
    MMM-Traffic macht. origin und destination sind (lat, lon).

    Mapbox braucht keine Zahlungsart: ohne Karte sind 10.000 Abfragen im
    Monat frei, mit Karte 100.000. "Ohne Verkehr" ist duration_typical, die
    übliche Fahrzeit zu dieser Stunde."""
    if not token:
        raise SourceError("no-key")
    coords = f"{origin[1]:.6f},{origin[0]:.6f};{destination[1]:.6f},{destination[0]:.6f}"
    params = {"access_token": token, "alternatives": "true", "geometries": "polyline", "overview": "full",
              "steps": "false", "language": language if language in ("de", "en", "es") else "de"}
    if avoid_tolls:
        params["exclude"] = "toll"
    try:
        response = _http.get(f"{MAPBOX_URL}/{coords}", params=params, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise SourceError("unreachable", str(exc)) from exc
    try:
        payload = response.json()
    except ValueError:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    message = str(payload.get("message") or "")
    code = str(payload.get("code") or "")
    if response.status_code == 401:
        raise SourceError("key", message)
    if response.status_code == 403:
        raise SourceError("denied", message)
    if response.status_code == 429:
        raise SourceError("quota", message)
    if code in ("NoRoute", "NoSegment") or response.status_code == 422:
        raise SourceError("no-route", message or code)
    if response.status_code >= 400 or (code and code != "Ok"):
        raise SourceError(f"http:{response.status_code}", message or code)
    routes = []
    for row in payload.get("routes") or []:
        if not isinstance(row, dict) or row.get("duration") is None:
            continue
        traffic = int(round(float(row["duration"])))
        typical = row.get("duration_typical")
        normal = int(round(float(typical))) if typical is not None else traffic
        description = ", ".join(str(leg.get("summary") or "") for leg in row.get("legs") or []
                                if isinstance(leg, dict) and leg.get("summary"))
        routes.append({
            "seconds": traffic,
            "normalSeconds": normal,
            "meters": int(row.get("distance") or 0),
            "via": description[:60],
            "roads": sorted({f"A{n}" for n in ROAD.findall(description)}, key=lambda r: int(r[1:])),
            "polyline": row.get("geometry") if isinstance(row.get("geometry"), str) else "",
            "labels": [],
        })
    if not routes:
        raise SourceError("no-route")
    routes.sort(key=lambda r: r["seconds"])
    return {"routes": routes[:3]}


# --------------------------------------------------------------------------
# Abfahrten (DB über transport.rest)
# --------------------------------------------------------------------------

PRODUCT_KIND = {
    "nationalExpress": "train", "national": "train", "regionalExpress": "train", "regional": "train",
    "suburban": "sbahn", "subway": "ubahn", "tram": "tram", "bus": "bus", "ferry": "ferry", "taxi": "bus",
}


def nearby_stops(lat, lon, base=None):
    rows = _get(f"{(base or TRANSPORT_URL).rstrip('/')}/locations/nearby",
                params={"latitude": f"{lat:.5f}", "longitude": f"{lon:.5f}", "results": 12,
                        "distance": 2000, "poi": "false", "linesOfStops": "false"})
    if isinstance(rows, dict):
        rows = rows.get("locations") or rows.get("stops") or []
    stops = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict) or row.get("type") not in ("stop", "station") or not row.get("id"):
            continue
        products = row.get("products") or {}
        stops.append({
            "id": str(row["id"]),
            "name": str(row.get("name") or row["id"])[:80],
            "meters": int(row.get("distance") or 0),
            "kinds": sorted({PRODUCT_KIND.get(k, "bus") for k, v in products.items() if v}),
        })
    stops.sort(key=lambda s: s["meters"])
    return stops


def search_stops(query, base=None):
    """Haltestellen nach Namen, z. B. "Bad Homburg Bahnhof"."""
    query = str(query or "").strip()
    if not query:
        return []
    rows = _get(f"{(base or TRANSPORT_URL).rstrip('/')}/locations",
                params={"query": query[:80], "results": 12, "stops": "true", "addresses": "false",
                        "poi": "false", "linesOfStops": "false", "language": "de"})
    stops = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict) or row.get("type") not in ("stop", "station") or not row.get("id"):
            continue
        products = row.get("products") or {}
        stops.append({"id": str(row["id"]), "name": str(row.get("name") or row["id"])[:80], "meters": None,
                      "kinds": sorted({PRODUCT_KIND.get(k, "bus") for k, v in products.items() if v})})
    return stops


def _line_name(line):
    name = str(line.get("name") or line.get("fahrtNr") or "").strip()
    # "Bus 123" -> "123", "STR 4" -> "4": das Symbol zeigt die Art schon.
    return re.sub(r"^(Bus|STR|Tram|Str)\s+", "", name)[:12]


def departures(stop_id, base=None, minutes=90):
    payload = _get(f"{(base or TRANSPORT_URL).rstrip('/')}/stops/{requests.utils.quote(str(stop_id))}/departures",
                   params={"duration": minutes, "results": 30, "remarks": "true", "language": "de"})
    rows = payload.get("departures") if isinstance(payload, dict) else payload
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        line = row.get("line") or {}
        planned = parse_time(row.get("plannedWhen"))
        actual = parse_time(row.get("when")) or planned
        if planned is None and actual is None:
            continue
        delay = row.get("delay")
        remarks = []
        for remark in row.get("remarks") or []:
            if isinstance(remark, dict) and remark.get("type") in ("warning", "status"):
                text = str(remark.get("summary") or remark.get("text") or "").strip()
                if text and text not in remarks:
                    remarks.append(text[:140])
        out.append({
            "id": str(row.get("tripId") or f"{_line_name(line)}-{planned}")[:120],
            "line": _line_name(line),
            "kind": PRODUCT_KIND.get(line.get("product"), "bus"),
            "direction": str(row.get("direction") or "").strip()[:60],
            "planned": planned or actual,
            "when": actual or planned,
            "delayMin": round(delay / 60) if isinstance(delay, (int, float)) else None,
            "cancelled": bool(row.get("cancelled")),
            "platform": str(row.get("platform") or row.get("plannedPlatform") or "")[:8],
            "remarks": remarks[:2],
        })
    out.sort(key=lambda d: d["when"])
    return out


# --------------------------------------------------------------------------
# Abfahrten über Transitous (https://transitous.org)
#
# Offener, nicht kommerzieller Fahrplandienst auf Basis von MOTIS mit den
# offenen Fahrplan- und Echtzeitdaten der Verkehrsverbünde. Kein Schlüssel;
# Bedingungen: erkennbarer User-Agent, Namensnennung, sparsam fragen (das
# Plugin fragt höchstens einmal pro Minute und nur bei sichtbarer Szene oder
# im Zeitfenster).
# --------------------------------------------------------------------------

MOTIS_KIND = {"BUS": "bus", "COACH": "bus", "ODM": "bus", "FLEX": "bus", "TRAM": "tram", "CABLE_CAR": "tram",
              "FUNICULAR": "tram", "AERIAL_LIFT": "tram", "SUBWAY": "ubahn", "METRO": "ubahn",
              "SUBURBAN": "sbahn", "FERRY": "ferry", "RAIL": "train", "REGIONAL_RAIL": "train",
              "REGIONAL_FAST_RAIL": "train", "HIGHSPEED_RAIL": "train", "LONG_DISTANCE": "train",
              "NIGHT_RAIL": "train"}
NEARBY_KM = 2.0


def _km_between(lat1, lon1, lat2, lon2):
    rad = math.radians
    a = math.sin(rad(lat2 - lat1) / 2) ** 2 + \
        math.cos(rad(lat1)) * math.cos(rad(lat2)) * math.sin(rad(lon2 - lon1) / 2) ** 2
    return 6371.0 * 2 * math.asin(math.sqrt(min(1.0, a)))


def _motis_kinds(modes):
    return sorted({MOTIS_KIND.get(str(m), "bus") for m in modes or []})


def _motis_stops(rows, lat=None, lon=None):
    """Haltestellen aus Transitous (geocode oder map/stops); gleiche Namen nur einmal."""
    stops, seen = [], {}
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        stop_id = str(row.get("stopId") or row.get("id") or "")
        name = str(row.get("name") or "").strip()[:80]
        if not stop_id or not name or row.get("type") not in (None, "STOP"):
            continue
        meters = None
        if lat is not None and isinstance(row.get("lat"), (int, float)) and isinstance(row.get("lon"), (int, float)):
            meters = int(round(_km_between(lat, lon, row["lat"], row["lon"]) * 1000))
        stop = {"id": stop_id, "name": name, "meters": meters, "kinds": _motis_kinds(row.get("modes"))}
        if name in seen:
            other = seen[name]
            other["kinds"] = sorted(set(other["kinds"]) | set(stop["kinds"]))
            if meters is not None and (other["meters"] is None or meters < other["meters"]):
                other["meters"] = meters
            continue
        seen[name] = stop
        stops.append(stop)
    return stops


def transitous_nearby(lat, lon):
    dlat = NEARBY_KM / 111.0
    dlon = NEARBY_KM / (111.0 * max(0.2, math.cos(math.radians(lat))))
    rows = _get(f"{TRANSITOUS_URL}/v6/map/stops",
                params={"min": f"{lat - dlat:.5f},{lon - dlon:.5f}", "max": f"{lat + dlat:.5f},{lon + dlon:.5f}",
                        "grouped": "true"})
    stops = [s for s in _motis_stops(rows, lat, lon) if s["meters"] is None or s["meters"] <= NEARBY_KM * 1000]
    stops.sort(key=lambda s: s["meters"] if s["meters"] is not None else 99999)
    return stops[:12]


def transitous_search(query, lat=None, lon=None):
    query = str(query or "").strip()
    if not query:
        return []
    params = {"text": query[:80], "type": "STOP", "numResults": 12, "language": "de"}
    if lat is not None and lon is not None:
        params["place"] = f"{lat:.5f},{lon:.5f}"
    return _motis_stops(_get(f"{TRANSITOUS_URL}/v1/geocode", params=params), lat, lon)


def transitous_departures(stop_id, language="de"):
    payload = _get(f"{TRANSITOUS_URL}/v6/stoptimes",
                   params={"stopId": str(stop_id), "n": 30, "language": language})
    rows = payload.get("stopTimes") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        raise SourceError("format", "keine Abfahrten in der Antwort")
    out = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        place = row.get("place") or {}
        planned = parse_time(place.get("scheduledDeparture"))
        actual = parse_time(place.get("departure")) if row.get("realTime") else None
        if planned is None:
            continue
        planned = int(planned)
        actual = int(actual) if actual is not None else None
        remarks = []
        for alert in place.get("alerts") or []:
            text = str((alert or {}).get("headerText") or (alert or {}).get("descriptionText") or "").strip()
            if text and text not in remarks:
                remarks.append(text[:140])
        line = str(row.get("routeShortName") or row.get("displayName") or "").strip()
        line = re.sub(r"^(Bus|STR|Tram|Str)\s+", "", line)[:12]
        out.append({
            "id": str(row.get("tripId") or f"{line}-{planned}")[:120],
            "line": line,
            "kind": MOTIS_KIND.get(str(row.get("mode")), "bus"),
            "direction": str(row.get("headsign") or "").strip()[:60],
            "planned": planned,
            "when": actual or planned,
            "delayMin": round((actual - planned) / 60) if actual is not None else None,
            "cancelled": bool(row.get("cancelled") or row.get("tripCancelled") or place.get("cancelled")),
            "platform": str(place.get("track") or place.get("scheduledTrack") or "")[:8],
            "remarks": remarks[:2],
        })
    out.sort(key=lambda d: d["when"])
    return out


# --------------------------------------------------------------------------
# Spritpreise (Tankerkönig)
# --------------------------------------------------------------------------

FUELS = ("e5", "e10", "diesel")


def fuel_stations(key, lat, lon, radius_km):
    """Alle Tankstellen im Umkreis mit allen drei Preisen.

    Tankerkönig bittet Heimautomationen, höchstens alle 5 Minuten zu fragen;
    das Plugin fragt alle 10 Minuten zu einer krummen Zeit."""
    if not key:
        raise SourceError("no-key")
    payload = _get(f"{TANKER_URL}/list.php", params={"lat": f"{lat:.5f}", "lng": f"{lon:.5f}",
                                                       "rad": max(1, min(25, radius_km)), "type": "all",
                                                       "apikey": key})
    if not isinstance(payload, dict):
        raise SourceError("format")
    if not payload.get("ok"):
        message = str(payload.get("message") or "")
        if "apikey" in message.lower() or "api-key" in message.lower() or "key" in message.lower():
            raise SourceError("key", message)
        raise SourceError("refused", message)
    stations = []
    for row in payload.get("stations") or []:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        prices = {}
        for fuel in FUELS:
            value = row.get(fuel)
            if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0.5:
                prices[fuel] = round(float(value), 3)
        brand = str(row.get("brand") or "").strip()
        name = str(row.get("name") or "").strip()
        stations.append({
            "id": str(row["id"]),
            "brand": (brand or name)[:30],
            "name": name[:60],
            "street": " ".join(str(row.get(k) or "").strip() for k in ("street", "houseNumber")).strip()[:60],
            "place": str(row.get("place") or "").strip().title()[:40],
            "km": round(float(row.get("dist") or 0), 1),
            "open": bool(row.get("isOpen")),
            "prices": prices,
        })
    return stations


# --------------------------------------------------------------------------
# Wetter, Regenradar und DWD-Warnungen (Bright Sky)
# --------------------------------------------------------------------------

RAIN_MM_H = 0.2   # ab hier zählt es als Regen (0,2 mm in der Stunde)


def rain(lat, lon):
    """Regen am Ort für die nächsten zwei Stunden, in 5-Minuten-Schritten.

    Bright Sky liefert das DWD-Radarprodukt RV: gemessene Werte und die
    Vorhersage für zwei Stunden. Ein Wert ist 0,01 mm in 5 Minuten. Das
    Plugin nimmt um den Ort 3 x 3 km und davon den größten Wert."""
    start = (utc_now() - timedelta(minutes=5)).replace(second=0, microsecond=0)
    payload = _get(f"{BRIGHTSKY_URL}/radar", params={"lat": f"{lat:.4f}", "lon": f"{lon:.4f}", "distance": 1000,
                                                       "format": "plain", "date": start.isoformat()})
    frames = []
    for row in (payload or {}).get("radar") or []:
        at = parse_time(row.get("timestamp"))
        grid = row.get("precipitation_5")
        if at is None or not isinstance(grid, list):
            continue
        values = [v for line in grid if isinstance(line, list) for v in line if isinstance(v, (int, float))]
        if not values:
            continue
        frames.append({"at": at, "mmh": round(max(values) * 0.01 * 12, 2)})
    if not frames:
        raise SourceError("format", "kein Radarbild")
    frames.sort(key=lambda f: f["at"])
    return {"frames": frames[:26]}


def rain_summary(frames, t):
    """{"now": bool, "startAt": t|None, "endAt": t|None, "maxMmh"}."""
    ahead = [f for f in frames if f["at"] >= t - 300]
    if not ahead:
        return {"now": False, "startAt": None, "endAt": None, "maxMmh": 0}
    wet = [f["mmh"] >= RAIN_MM_H for f in ahead]
    summary = {"now": wet[0], "startAt": None, "endAt": None, "maxMmh": max(f["mmh"] for f in ahead)}
    if wet[0]:
        for frame, is_wet in zip(ahead, wet):
            if not is_wet:
                summary["endAt"] = frame["at"]
                break
    else:
        for frame, is_wet in zip(ahead, wet):
            if is_wet:
                summary["startAt"] = frame["at"]
                break
    return summary


def current_weather(lat, lon):
    payload = _get(f"{BRIGHTSKY_URL}/current_weather", params={"lat": f"{lat:.4f}", "lon": f"{lon:.4f}"})
    weather = (payload or {}).get("weather") or {}
    temperature = weather.get("temperature")
    return {
        "temp": round(float(temperature), 1) if isinstance(temperature, (int, float)) else None,
        "icon": str(weather.get("icon") or "")[:30],
        "condition": str(weather.get("condition") or "")[:20],
    }


SEVERITY = {"minor": 1, "moderate": 2, "severe": 3, "extreme": 4}


def dwd_alerts(lat, lon, language="de"):
    payload = _get(f"{BRIGHTSKY_URL}/alerts", params={"lat": f"{lat:.4f}", "lon": f"{lon:.4f}"})
    suffix = "de" if language == "de" else "en"
    alerts = []
    for row in (payload or {}).get("alerts") or []:
        if not isinstance(row, dict):
            continue
        level = SEVERITY.get(str(row.get("severity") or "").lower(), 1)
        alerts.append({
            "id": f"dwd:{row.get('alert_id') or row.get('id')}",
            "source": "DWD",
            "level": level,
            "title": str(row.get(f"headline_{suffix}") or row.get("headline_de") or row.get(f"event_{suffix}")
                         or "")[:120],
            "event": str(row.get(f"event_{suffix}") or row.get("event_de") or "")[:60],
            "text": str(row.get(f"description_{suffix}") or row.get("description_de") or "")[:400],
            "from": parse_time(row.get("onset") or row.get("effective")),
            "until": parse_time(row.get("expires")),
        })
    location = (payload or {}).get("location") or {}
    return {"alerts": alerts, "place": str(location.get("name") or location.get("district") or "")[:60]}


# --------------------------------------------------------------------------
# NINA (Bevölkerungsschutz): Warnungen, deren Gebiet den Wohnort enthält
# --------------------------------------------------------------------------

NINA_SOURCES = ("mowas", "katwarn", "biwapp", "police")
NINA_LEVEL = {"minor": 1, "moderate": 2, "severe": 3, "extreme": 4, "unknown": 1}


def nina_list():
    """Alle gerade aktiven Meldungen (ohne DWD, die kommen über Bright Sky)."""
    rows = []
    for source in NINA_SOURCES:
        try:
            items = _get(f"{NINA_URL}/{source}/mapData.json")
        except SourceError:
            continue
        for item in items if isinstance(items, list) else []:
            if isinstance(item, dict) and item.get("id"):
                title = item.get("i18nTitle") or {}
                rows.append({"id": str(item["id"]), "version": item.get("version"),
                             "level": NINA_LEVEL.get(str(item.get("severity") or "").lower(), 1),
                             "titles": title if isinstance(title, dict) else {},
                             "source": source})
    return rows


def nina_covers(warning_id, lat, lon):
    geo = _get(f"{NINA_URL}/warnings/{requests.utils.quote(warning_id)}.geojson")
    features = geo.get("features") if isinstance(geo, dict) else None
    if features is None and isinstance(geo, dict) and geo.get("type") in ("Polygon", "MultiPolygon"):
        features = [{"geometry": geo}]
    return any(point_in_geometry(lat, lon, f.get("geometry")) for f in features or [] if isinstance(f, dict))


# --------------------------------------------------------------------------
# Autobahn: Meldungen und Sperrungen nahe der Route
# --------------------------------------------------------------------------

def autobahn_events(roads, line, within_km=1.5):
    events = []
    for road in roads[:4]:
        for kind in ("warning", "closure"):
            try:
                payload = _get(f"{AUTOBAHN_URL}/{road}/services/{kind}")
            except SourceError:
                continue
            for row in (payload or {}).get(kind) or []:
                if not isinstance(row, dict) or row.get("future") is True:
                    continue
                coordinate = row.get("coordinate") or {}
                try:
                    lat, lon = float(coordinate.get("lat")), float(coordinate.get("long"))
                except (TypeError, ValueError):
                    continue
                if distance_to_line_km(lat, lon, line) > within_km:
                    continue
                # Die erste Zeile ist meist "Beginn: …", eine weitere wiederholt Straße und Richtung.
                description = [str(d).strip() for d in row.get("description") or [] if str(d).strip()
                               and not re.match(r"^(Beginn|Ende|Start|Dauer)\b", str(d).strip())
                               and "->" not in str(d)]
                event = {
                    "id": str(row.get("identifier") or "")[:200],
                    "kind": kind,
                    "road": road,
                    "title": str(row.get("title") or road).strip()[:90],
                    "subtitle": str(row.get("subtitle") or "").strip()[:90],
                    "text": " ".join(description[:2])[:200],
                    "blocked": str(row.get("isBlocked")).lower() == "true",
                }
                # Dieselbe Meldung kommt oft doppelt (als Warnung und als Sperrung, oder mit zwei Kennungen).
                same = next((e for e in events if (e["title"], e["subtitle"], e["text"])
                             == (event["title"], event["subtitle"], event["text"])), None)
                if same:
                    same["blocked"] = same["blocked"] or event["blocked"]
                    continue
                events.append(event)
    return events


# --------------------------------------------------------------------------
# Nachrichten (RSS oder Atom)
# --------------------------------------------------------------------------

def news(url):
    body = _get(url, expect="text")
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        raise SourceError("format", "kein RSS") from exc
    items = []
    for node in root.iter():
        tag = node.tag.rsplit("}", 1)[-1]
        if tag not in ("item", "entry"):
            continue
        title = published = ""
        for child in node:
            name = child.tag.rsplit("}", 1)[-1]
            if name == "title":
                title = "".join(child.itertext()).strip()
            elif name in ("pubDate", "published", "updated") and not published:
                published = (child.text or "").strip()
        if not title:
            continue
        at = None
        if published:
            try:
                at = parsedate_to_datetime(published).timestamp()
            except (TypeError, ValueError):
                at = parse_time(published)
        items.append({"title": re.sub(r"\s+", " ", title)[:200], "at": at})
        if len(items) >= 15:
            break
    if not items:
        raise SourceError("format", "keine Meldungen")
    return {"items": items}
